import React from 'react';
import {Composition} from 'remotion';
import {Kabel} from './Kabel';

export const RemotionRoot: React.FC = () => (
  <Composition id="Kabel" component={Kabel} durationInFrames={6582} fps={60} width={1080} height={1920} />
);
