import React from 'react';
import {Composition} from 'remotion';
import {Kabel, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Kabel';

export const RemotionRoot: React.FC = () => (
  <Composition id="Kabel" component={Kabel} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
