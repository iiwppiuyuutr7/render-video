/**
 * "Bagaimana Internet Bisa Menghubungkan Seluruh Dunia?" – kabel bawah laut
 * 1080x1920 (9:16) · 60 fps · ±109,7 detik (6582 frame)
 * Audio: public/narration.mp3 (voiceover) + public/sfx/*.wav (efek suara, diatur di bagian SFX paling bawah)
 * Semua waktu di file ini dalam DETIK pada audio narasi.
 */
import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Sequence,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;

export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_SECONDS = 109.7;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SECONDS * FPS);

const OUT = '#2a1a2c';
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;

/* ───────────────── timestamp kata [kata, mulai, selesai] ─────────────────
 * Hasil alignment narasi (public/narration.mp3). Kalau ada kata yang terasa
 * meleset, cukup ubah angka mulai/selesainya di sini — semua visual & caption
 * mengikuti lewat W('kata', urutanKe).
 */
const WORDS: Array<[string, number, number]> = [
  ["Hampir", 0.00, 0.35],
  ["setiap", 0.35, 0.84],
  ["hari", 0.84, 1.19],
  ["kita", 1.19, 1.54],
  ["menonton", 1.54, 2.03],
  ["video,", 2.03, 2.52],
  ["bermain", 2.68, 3.14],
  ["game,", 3.14, 3.48],
  ["dan", 3.63, 3.80],
  ["mengirim", 3.80, 4.19],
  ["pesan", 4.19, 4.47],
  ["lewat", 4.47, 4.75],
  ["internet.", 4.75, 5.14],
  ["Tapi", 5.67, 5.97],
  ["pernahkah", 5.97, 6.52],
  ["terpikir", 6.52, 6.93],
  ["bagaimana", 6.93, 7.70],
  ["data", 7.70, 8.00],
  ["bisa", 8.00, 8.30],
  ["berpindah", 8.30, 8.71],
  ["dari", 8.71, 9.01],
  ["Indonesia", 9.01, 9.65],
  ["ke", 9.65, 9.84],
  ["Amerika", 9.84, 10.36],
  ["hanya", 10.36, 10.91],
  ["dalam", 10.91, 11.21],
  ["hitungan", 11.21, 11.62],
  ["detik?", 11.62, 11.92],
  ["Banyak", 12.44, 12.76],
  ["orang", 12.76, 13.08],
  ["mengira", 13.08, 13.53],
  ["internet", 13.53, 13.98],
  ["dunia", 13.98, 14.42],
  ["dikirim", 14.42, 14.87],
  ["lewat", 14.87, 15.19],
  ["satelit.", 15.19, 15.64],
  ["Kenyataannya,", 16.19, 16.93],
  ["lebih", 17.27, 17.59],
  ["dari", 17.59, 17.90],
  ["99", 17.90, 18.88],
  ["persen", 18.88, 19.20],
  ["lalu", 19.20, 19.51],
  ["lintas", 19.51, 19.83],
  ["data", 19.83, 20.15],
  ["internasional", 20.15, 21.23],
  ["dibawa", 21.23, 21.67],
  ["oleh", 21.67, 21.99],
  ["kabel", 21.99, 22.31],
  ["bawah", 22.31, 22.62],
  ["laut.", 22.62, 22.94],
  ["Satelit", 23.47, 23.91],
  ["tetap", 23.91, 24.23],
  ["penting", 24.23, 24.55],
  ["untuk", 24.55, 24.87],
  ["wilayah", 24.87, 25.31],
  ["terpencil,", 25.31, 25.75],
  ["tapi", 26.15, 26.47],
  ["kabel", 26.47, 26.96],
  ["di", 26.96, 27.16],
  ["dasar", 27.16, 27.48],
  ["lautan", 27.48, 27.93],
  ["adalah", 27.93, 28.52],
  ["tulang", 28.52, 28.84],
  ["punggung", 28.84, 29.16],
  ["utamanya.", 29.16, 29.73],
  ["Di", 30.27, 30.51],
  ["dalam", 30.51, 30.89],
  ["kabel", 30.89, 31.27],
  ["terdapat", 31.27, 31.81],
  ["serat", 31.81, 32.19],
  ["kaca", 32.19, 32.58],
  ["yang", 32.58, 32.81],
  ["sangat", 32.81, 33.20],
  ["tipis.", 33.20, 33.58],
  ["Data", 33.90, 34.26],
  ["digital", 34.26, 34.76],
  ["diubah", 34.76, 35.25],
  ["menjadi", 35.25, 35.75],
  ["sinyal", 35.75, 36.11],
  ["cahaya,", 36.11, 36.61],
  ["dikirim", 36.87, 37.25],
  ["melalui", 37.25, 37.74],
  ["serat", 37.74, 38.02],
  ["tersebut,", 38.02, 38.40],
  ["lalu", 38.80, 39.11],
  ["diterjemahkan", 39.11, 39.79],
  ["kembali", 39.79, 40.23],
  ["menjadi", 40.23, 40.67],
  ["data", 40.67, 40.98],
  ["di", 40.98, 41.17],
  ["tujuan.", 41.17, 41.61],
  ["Cahaya", 42.10, 42.54],
  ["bisa", 42.54, 42.85],
  ["merambat", 42.85, 43.28],
  ["di", 43.28, 43.48],
  ["dalam", 43.48, 43.79],
  ["serat", 43.79, 44.27],
  ["karena", 44.27, 44.70],
  ["prinsip", 44.70, 45.02],
  ["yang", 45.02, 45.21],
  ["disebut", 45.21, 45.86],
  ["pemantulan", 45.86, 46.42],
  ["internal", 46.42, 46.86],
  ["total.", 46.86, 47.17],
  ["Selama", 47.62, 48.09],
  ["menempuh", 48.09, 48.55],
  ["ribuan", 48.55, 49.02],
  ["kilometer,", 49.02, 49.61],
  ["kekuatan", 49.84, 50.47],
  ["sinyal", 50.47, 50.83],
  ["perlahan", 50.83, 51.32],
  ["berkurang.", 51.32, 51.81],
  ["Karena", 52.19, 52.59],
  ["itu", 52.59, 53.00],
  ["dipasang", 53.00, 53.40],
  ["repeater", 53.40, 53.90],
  ["atau", 53.90, 54.47],
  ["penguat", 54.47, 54.87],
  ["optik,", 54.87, 55.16],
  ["dengan", 55.56, 55.89],
  ["jarak", 55.89, 56.21],
  ["puluhan", 56.21, 56.66],
  ["hingga", 56.66, 56.99],
  ["sekitar", 56.99, 57.44],
  ["seratus", 57.44, 57.89],
  ["kilometer,", 57.89, 58.47],
  ["dan", 58.73, 58.94],
  ["listriknya", 58.94, 59.41],
  ["dialirkan", 59.41, 60.02],
  ["lewat", 60.02, 60.36],
  ["konduktor", 60.36, 60.84],
  ["di", 60.84, 61.05],
  ["dalam", 61.05, 61.39],
  ["kabel.", 61.39, 61.73],
  ["Kabel", 62.22, 62.56],
  ["dipasang", 62.56, 63.04],
  ["oleh", 63.04, 63.38],
  ["kapal", 63.38, 63.72],
  ["khusus", 63.72, 64.07],
  ["yang", 64.07, 64.28],
  ["membawa", 64.28, 64.75],
  ["gulungan", 64.75, 65.23],
  ["kabel.", 65.23, 65.57],
  ["Di", 66.04, 66.25],
  ["laut", 66.25, 66.60],
  ["dangkal,", 66.60, 66.95],
  ["kabel", 67.17, 67.49],
  ["ditanam", 67.49, 67.94],
  ["di", 67.94, 68.14],
  ["bawah", 68.14, 68.47],
  ["dasar", 68.47, 68.79],
  ["laut", 68.79, 69.36],
  ["agar", 69.36, 69.68],
  ["terhindar", 69.68, 70.13],
  ["dari", 70.13, 70.46],
  ["jangkar", 70.46, 70.78],
  ["kapal", 70.78, 71.11],
  ["dan", 71.11, 71.46],
  ["aktivitas", 71.46, 72.03],
  ["penangkapan", 72.03, 72.61],
  ["ikan,", 72.61, 72.93],
  ["sedangkan", 73.32, 73.76],
  ["di", 73.76, 73.95],
  ["laut", 73.95, 74.27],
  ["dalam", 74.27, 74.75],
  ["kabel", 74.75, 75.06],
  ["cukup", 75.06, 75.38],
  ["diletakkan", 75.38, 75.94],
  ["di", 75.94, 76.13],
  ["dasar.", 76.13, 76.45],
  ["Ujung", 76.91, 77.25],
  ["kabel", 77.25, 77.60],
  ["terhubung", 77.60, 78.07],
  ["ke", 78.07, 78.28],
  ["stasiun", 78.28, 78.76],
  ["pendaratan", 78.76, 79.37],
  ["kabel,", 79.37, 79.71],
  ["lalu", 80.00, 80.29],
  ["menyambung", 80.29, 80.70],
  ["ke", 80.70, 80.88],
  ["jaringan", 80.88, 81.28],
  ["darat", 81.28, 81.78],
  ["hingga", 81.78, 82.08],
  ["sampai", 82.08, 82.48],
  ["ke", 82.48, 82.66],
  ["perangkat", 82.66, 83.07],
  ["kita.", 83.07, 83.36],
  ["Jika", 83.81, 84.19],
  ["kabel", 84.19, 84.57],
  ["terputus,", 84.57, 85.09],
  ["bukan", 85.26, 85.59],
  ["berarti", 85.59, 86.05],
  ["internet", 86.05, 86.51],
  ["langsung", 86.51, 86.84],
  ["mati,", 86.84, 87.17],
  ["karena", 87.56, 88.00],
  ["banyak", 88.00, 88.31],
  ["jaringan", 88.31, 88.75],
  ["punya", 88.75, 89.19],
  ["jalur", 89.19, 89.50],
  ["alternatif,", 89.50, 90.06],
  ["dan", 90.55, 90.75],
  ["kapal", 90.75, 91.08],
  ["khusus", 91.08, 91.41],
  ["akan", 91.41, 91.88],
  ["memperbaikinya.", 91.88, 92.71],
  ["Teknologi", 93.25, 93.75],
  ["ini", 93.75, 94.03],
  ["bukan", 94.03, 94.31],
  ["hal", 94.31, 94.48],
  ["baru.", 94.48, 94.76],
  ["Sejak", 95.23, 95.60],
  ["tahun", 95.60, 95.96],
  ["1866,", 95.96, 97.65],
  ["kabel", 97.92, 98.26],
  ["telegraf", 98.26, 98.74],
  ["transatlantik", 98.74, 99.35],
  ["sudah", 99.35, 99.86],
  ["menghubungkan", 99.86, 100.47],
  ["Eropa", 100.47, 100.94],
  ["dan", 100.94, 101.16],
  ["Amerika", 101.16, 101.76],
  ["Utara.", 101.76, 102.24],
  ["Jadi,", 102.68, 103.13],
  ["salah", 103.29, 103.62],
  ["satu", 103.62, 103.95],
  ["fondasi", 103.95, 104.41],
  ["utama", 104.41, 104.87],
  ["dunia", 104.87, 105.33],
  ["digital", 105.33, 105.79],
  ["modern", 105.79, 106.38],
  ["justru", 106.38, 106.71],
  ["berada", 106.71, 107.17],
  ["jauh", 107.17, 107.50],
  ["di", 107.50, 107.70],
  ["bawah", 107.70, 108.03],
  ["permukaan", 108.03, 108.62],
  ["laut.", 108.62, 108.95],
];

/* ───────────────────────── util ───────────────────────── */
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const easeIn = Easing.in(Easing.cubic);
const easeInOut = Easing.inOut(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9áéíóúñ-]/g, '');
/** waktu mulai kata ke-`nth` (mulai dari 0) yang cocok dengan `text` */
const W = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, s] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return s;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};
/** waktu SELESAI kata */
const WE = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, , e] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return e;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};

/* ───────────────────────── konteks waktu ───────────────────────── */
const TCtx = createContext(0); // detik-audio absolut
const LCtx = createContext(0); // detik sejak scene mulai
const useT = () => useContext(TCtx);
const useLT = () => useContext(LCtx);

const Scene: React.FC<{a: number; b: number; fade?: number; children?: React.ReactNode}> = ({
  a,
  b,
  fade = 0.2,
  children,
}) => {
  const t = useT();
  if (t < a || t >= b + fade + 0.05) return null;
  const lt = t - a;
  return (
    <LCtx.Provider value={lt}>
      <AbsoluteFill style={{opacity: fade > 0 ? clamp(lt / fade) : 1, overflow: 'hidden'}}>
        {children}
      </AbsoluteFill>
    </LCtx.Provider>
  );
};

type Shake = {a: number; d: number; amp: number};
const Cam: React.FC<{
  z0?: number;
  z1?: number;
  dur?: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  r0?: number;
  r1?: number;
  shakes?: Shake[];
  children?: React.ReactNode;
}> = ({z0 = 1, z1 = 1, dur = 5, x0 = 0, x1 = 0, y0 = 0, y1 = 0, r0 = 0, r1 = 0, shakes = [], children}) => {
  const lt = useLT();
  const t = useT();
  const p = easeInOut(prog(lt, 0, dur));
  let sx = 0;
  let sy = 0;
  for (const s of shakes) {
    const q = prog(t, s.a, s.d);
    if (q > 0 && q < 1) {
      const k = (1 - q) * s.amp;
      sx += Math.sin(t * 93) * k;
      sy += Math.cos(t * 71) * k;
    }
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${lerp(x0, x1, p) + sx}px,${lerp(y0, y1, p) + sy}px) scale(${lerp(z0, z1, p)}) rotate(${lerp(r0, r1, p)}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── SVG dasar ───────────────────────── */
const Defs = () => (
  <defs>
    <radialGradient id="glowYellow">
      <stop offset="0" stopColor="#fff6b0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ffc93a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff9a2e" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowCyan">
      <stop offset="0" stopColor="#e8ffff" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#6fe6ff" stopOpacity="0.55" />
      <stop offset="1" stopColor="#2fb4ff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowWhite">
      <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowBlue">
      <stop offset="0.72" stopColor="#7ccfff" stopOpacity="0.6" />
      <stop offset="1" stopColor="#7ccfff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowGreen">
      <stop offset="0" stopColor="#b8ffd0" stopOpacity="0.9" />
      <stop offset="1" stopColor="#4cff9a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowRed">
      <stop offset="0" stopColor="#ffd0c0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ff5a3a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff2a1a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="earthShade" cx="0.35" cy="0.3" r="0.9">
      <stop offset="0.5" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#000" stopOpacity="0.5" />
    </radialGradient>
    <linearGradient id="seaGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#3aa6e6" />
      <stop offset="0.45" stopColor="#1668b0" />
      <stop offset="1" stopColor="#0a2a5c" />
    </linearGradient>
    <linearGradient id="deepGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#0f4a86" />
      <stop offset="0.5" stopColor="#082a58" />
      <stop offset="1" stopColor="#030d24" />
    </linearGradient>
    <linearGradient id="sandGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#e8c98a" />
      <stop offset="1" stopColor="#b88f55" />
    </linearGradient>
    <linearGradient id="sandDeep" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#5b5b7a" />
      <stop offset="1" stopColor="#2c2c48" />
    </linearGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#fff" stopOpacity="0.3" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </linearGradient>
  </defs>
);

const S: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    width={WIDTH}
    height={HEIGHT}
    style={{position: 'absolute', left: 0, top: 0}}
  >
    <Defs />
    {children}
  </svg>
);

/* ───────────────────────── background ───────────────────────── */
const Stars: React.FC<{n?: number}> = ({n = 70}) => {
  const t = useT();
  return (
    <S>
      {Array.from({length: n}).map((_, i) => {
        const x = random(`sx${i}`) * WIDTH;
        const y = (random(`sy${i}`) * HEIGHT + t * (4 + random(`sv${i}`) * 8)) % HEIGHT;
        const r = 1.5 + random(`sr${i}`) * 3;
        const o = 0.45 + 0.55 * Math.abs(Math.sin(t * (0.8 + random(`sf${i}`) * 2) + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#fff" opacity={o} />;
      })}
    </S>
  );
};

const SpaceBG: React.FC = () => (
  <>
    <AbsoluteFill style={{background: 'radial-gradient(120% 80% at 50% 30%, #1f2570 0%, #0d123f 55%, #04061a 100%)'}} />
    <Stars />
  </>
);

const NavyBG: React.FC<{grid?: boolean}> = ({grid = true}) => (
  <>
    <AbsoluteFill style={{background: 'radial-gradient(120% 80% at 50% 40%, #1c3f7a 0%, #0f2350 55%, #070f2a 100%)'}} />
    {grid && (
      <S>
        {Array.from({length: 17}).map((_, i) => (
          <line key={`v${i}`} x1={i * 70} y1={0} x2={i * 70} y2={HEIGHT} stroke="#fff" strokeOpacity={0.05} strokeWidth={2} />
        ))}
        {Array.from({length: 28}).map((_, i) => (
          <line key={`h${i}`} x1={0} y1={i * 70} x2={WIDTH} y2={i * 70} stroke="#fff" strokeOpacity={0.05} strokeWidth={2} />
        ))}
      </S>
    )}
  </>
);

const Vignette = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
    }}
  />
);

/* ───────────────────────── objek umum ───────────────────────── */
const waveLine = (y: number, amp: number, len: number, ph: number, x0 = -40, x1 = WIDTH + 40) => {
  let d = `M${x0},${y}`;
  for (let x = x0; x <= x1; x += 20) d += ` L${x},${(y + Math.sin((x / len) * Math.PI * 2 + ph) * amp).toFixed(1)}`;
  return d;
};

/** permukaan laut + gelombang depan */
const SeaSurface: React.FC<{y: number; fill?: string}> = ({y, fill = 'url(#seaGrad)'}) => {
  const t = useT();
  return (
    <S>
      <rect x={0} y={y} width={WIDTH} height={HEIGHT - y} fill={fill} />
      <path d={waveLine(y, 9, 180, t * 2.2) + ` L${WIDTH + 40},${y - 80} L-40,${y - 80} Z`} fill="#bfe8f8" opacity={0} />
      <path d={waveLine(y, 9, 180, t * 2.2)} fill="none" stroke="#bff0ff" strokeWidth={6} opacity={0.85} />
    </S>
  );
};

/** kabel: garis tebal dengan outline, highlight, dan (opsional) cahaya yang mengalir */
const CableSVG: React.FC<{
  d: string;
  w?: number;
  color?: string;
  flow?: number; // px/detik, undefined = tidak ada pulsa
  flowColor?: string;
  draw?: number; // 0..1 progres gambar
  opacity?: number;
  dash?: string;
}> = ({d, w = 24, color = '#4b4f7a', flow, flowColor = '#8ff0ff', draw = 1, opacity = 1, dash}) => {
  const t = useT();
  if (draw <= 0) return null;
  const dr = draw < 1 ? {pathLength: 1, strokeDasharray: `${draw} 2`} : {};
  return (
    <g opacity={opacity}>
      <path d={d} fill="none" stroke={OUT} strokeWidth={w + 10} strokeLinecap="round" strokeLinejoin="round" {...dr} />
      <path d={d} fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" {...dr} />
      <path d={d} fill="none" stroke="#fff" strokeOpacity={0.22} strokeWidth={w * 0.22} strokeLinecap="round" strokeLinejoin="round" transform={`translate(0 ${-w * 0.2})`} {...dr} />
      {flow !== undefined && draw >= 1 && (
        <path
          d={d}
          fill="none"
          stroke={flowColor}
          strokeWidth={w * 0.42}
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray={dash ?? `${w * 1.1} ${w * 4.2}`}
          strokeDashoffset={-t * flow}
        />
      )}
    </g>
  );
};

/** penampang kabel (sheath, kawat baja, tabung konduktor, serat kaca) */
const CableCross: React.FC<{
  x: number;
  y: number;
  r?: number;
  t0?: number; // waktu mulai muncul berlapis (detik-audio)
  step?: number;
  glowFiber?: number;
  glowCopper?: number;
}> = ({x, y, r = 330, t0 = 0, step = 0.35, glowFiber = 0, glowCopper = 0}) => {
  const t = useT();
  const k = r / 330;
  const l1 = pop(t, t0, 0.4);
  const l2 = pop(t, t0 + step, 0.4);
  const l3 = pop(t, t0 + step * 2, 0.4);
  const l4 = pop(t, t0 + step * 3, 0.4);
  const fibers: Array<[number, number]> = [[0, 0]];
  for (let i = 0; i < 6; i++) fibers.push([Math.cos((i / 6) * Math.PI * 2) * 66, Math.sin((i / 6) * Math.PI * 2) * 66]);
  return (
    <g transform={`translate(${x} ${y}) scale(${k})`}>
      <g transform={`scale(${l1})`}>
        <circle r={330} fill="#2b2e44" stroke={OUT} strokeWidth={9} />
        <circle r={316} fill="none" stroke="#fff" strokeOpacity={0.12} strokeWidth={8} />
      </g>
      <g transform={`scale(${l2})`}>
        {Array.from({length: 26}).map((_, i) => {
          const a = (i / 26) * Math.PI * 2;
          return <circle key={i} cx={Math.cos(a) * 262} cy={Math.sin(a) * 262} r={25} fill="#b7bfd6" stroke={OUT} strokeWidth={4} />;
        })}
      </g>
      <g transform={`scale(${l3})`}>
        <circle r={222} fill="#d98b4a" stroke={OUT} strokeWidth={7} />
        {glowCopper > 0 && <circle r={222} fill="url(#glowYellow)" opacity={glowCopper} />}
        <circle r={190} fill="#f0a868" opacity={0.55} />
      </g>
      <g transform={`scale(${l4})`}>
        <circle r={170} fill="#e9e3d0" stroke={OUT} strokeWidth={6} />
        {fibers.map(([fx, fy], i) => (
          <g key={i}>
            {glowFiber > 0 && <circle cx={fx} cy={fy} r={62} fill="url(#glowCyan)" opacity={glowFiber} />}
            <circle cx={fx} cy={fy} r={28} fill="#8ff0ff" stroke={OUT} strokeWidth={4} />
            <circle cx={fx - 8} cy={fy - 8} r={8} fill="#fff" opacity={0.85} />
          </g>
        ))}
      </g>
    </g>
  );
};

const Fish: React.FC<{x: number; y: number; s?: number; flip?: boolean; color?: string}> = ({x, y, s = 1, flip = false, color = '#ff9a4a'}) => {
  const t = useT();
  const wag = Math.sin(t * 9 + x) * 8;
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <path d={`M-52,0 L-90,${-28 + wag} L-90,${28 + wag} Z`} fill={color} stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
      <ellipse cx={0} cy={0} rx={60} ry={36} fill={color} stroke={OUT} strokeWidth={5} />
      <path d="M-10,-34 Q10,-62 36,-32Z" fill={color} stroke={OUT} strokeWidth={4} />
      <circle cx={30} cy={-8} r={9} fill="#fff" stroke={OUT} strokeWidth={3} />
      <circle cx={33} cy={-8} r={4} fill={OUT} />
    </g>
  );
};

const Satellite: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {[-1, 1].map((side) => (
      <g key={side}>
        <rect x={side > 0 ? 62 : -182} y={-34} width={120} height={68} rx={6} fill="#3b6fe0" stroke={OUT} strokeWidth={6} />
        {[1, 2].map((i) => (
          <line key={i} x1={(side > 0 ? 62 : -182) + i * 40} y1={-34} x2={(side > 0 ? 62 : -182) + i * 40} y2={34} stroke="#9cc0ff" strokeWidth={3} />
        ))}
        <line x1={side > 0 ? 62 : -182} y1={0} x2={side > 0 ? 182 : -62} y2={0} stroke="#9cc0ff" strokeWidth={3} />
        <rect x={side > 0 ? 44 : -62} y={-6} width={18} height={12} fill="#aab2c8" stroke={OUT} strokeWidth={4} />
      </g>
    ))}
    <rect x={-48} y={-48} width={96} height={96} rx={14} fill="#f2c14e" stroke={OUT} strokeWidth={7} />
    <rect x={-48} y={-48} width={96} height={30} rx={14} fill="#fff" opacity={0.25} />
    <circle cx={0} cy={6} r={20} fill="#2a1a2c" opacity={0.25} />
    <path d="M-30,48 L0,92 L30,48Z" fill="#ddd" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
    <ellipse cx={0} cy={96} rx={40} ry={12} fill="#e8e8f2" stroke={OUT} strokeWidth={5} />
  </g>
);

const Ship: React.FC<{x: number; y: number; s?: number; t: number; flip?: boolean; spool?: boolean}> = ({x, y, s = 1, t, flip = false, spool = true}) => {
  const rot = t * 120;
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      {/* lambung */}
      <path d="M-290,-14 L310,-14 L250,100 L-250,100 Z" fill="#c94b3b" stroke={OUT} strokeWidth={8} strokeLinejoin="round" />
      <path d="M-282,6 L296,6 L290,28 L-272,28 Z" fill="#fff" opacity={0.9} />
      <circle cx={-190} cy={60} r={9} fill="#ffe27a" stroke={OUT} strokeWidth={4} />
      <circle cx={-110} cy={60} r={9} fill="#ffe27a" stroke={OUT} strokeWidth={4} />
      <circle cx={-30} cy={60} r={9} fill="#ffe27a" stroke={OUT} strokeWidth={4} />
      {/* anjungan */}
      <rect x={110} y={-118} width={130} height={106} rx={10} fill="#f4f0e6" stroke={OUT} strokeWidth={7} />
      <rect x={134} y={-182} width={86} height={66} rx={8} fill="#f4f0e6" stroke={OUT} strokeWidth={7} />
      {[0, 1, 2].map((i) => (
        <rect key={i} x={124 + i * 34} y={-96} width={24} height={24} rx={4} fill="#7ccfff" stroke={OUT} strokeWidth={4} />
      ))}
      <rect x={146} y={-166} width={62} height={30} rx={5} fill="#7ccfff" stroke={OUT} strokeWidth={4} />
      <rect x={160} y={-226} width={16} height={46} fill="#aab2c8" stroke={OUT} strokeWidth={4} />
      <rect x={188} y={-226} width={16} height={46} fill="#e0443a" stroke={OUT} strokeWidth={4} />
      {/* crane A-frame di buritan */}
      <path d="M-290,-14 L-262,-130 L-232,-14" fill="none" stroke={OUT} strokeWidth={12} strokeLinejoin="round" strokeLinecap="round" />
      <path d="M-290,-14 L-262,-130 L-232,-14" fill="none" stroke="#f2c14e" strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={-262} cy={-130} r={13} fill="#aab2c8" stroke={OUT} strokeWidth={5} />
      {/* gulungan kabel */}
      {spool && (
        <g transform="translate(-100 -84)">
          <circle r={86} fill="#2b2e44" stroke={OUT} strokeWidth={8} />
          {[70, 56, 42].map((r, i) => (
            <circle key={i} r={r} fill="none" stroke="#5b5f8a" strokeWidth={9} />
          ))}
          <circle r={20} fill="#aab2c8" stroke={OUT} strokeWidth={5} />
          {[0, 1, 2, 3].map((i) => (
            <line key={i} x1={0} y1={0} x2={0} y2={-80} stroke="#aab2c8" strokeWidth={5} transform={`rotate(${rot + i * 90})`} />
          ))}
        </g>
      )}
    </g>
  );
};

const Phone: React.FC<{x: number; y: number; w?: number; h?: number; rot?: number; screen?: string; children?: React.ReactNode}> = ({
  x,
  y,
  w = 300,
  h = 560,
  rot = 0,
  screen = '#26357a',
  children,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot})`}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={w * 0.14} fill="#1b1830" stroke={OUT} strokeWidth={8} />
    <rect x={-w / 2 + 14} y={-h / 2 + 14} width={w - 28} height={h - 28} rx={w * 0.1} fill={screen} />
    <rect x={-w * 0.12} y={-h / 2 + 22} width={w * 0.24} height={14} rx={7} fill="#0d0b1c" />
    {children}
  </g>
);

const PlayIcon: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-90} y={-62} width={180} height={124} rx={34} fill="#ff4b4b" stroke={OUT} strokeWidth={7} />
    <path d="M-22,-34 L40,0 L-22,34Z" fill="#fff" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
  </g>
);

const Gamepad: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-100,-30 C-100,-60 -60,-64 -40,-52 L40,-52 C60,-64 100,-60 100,-30 L112,40 C116,74 80,80 64,56 L40,24 L-40,24 L-64,56 C-80,80 -116,74 -112,40Z" fill="#6a6ff0" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
    <rect x={-76} y={-22} width={22} height={52} rx={5} fill="#fff" stroke={OUT} strokeWidth={4} />
    <rect x={-91} y={-7} width={52} height={22} rx={5} fill="#fff" stroke={OUT} strokeWidth={4} />
    <circle cx={56} cy={-12} r={12} fill="#ffcf4a" stroke={OUT} strokeWidth={4} />
    <circle cx={84} cy={8} r={12} fill="#ff5a5a" stroke={OUT} strokeWidth={4} />
  </g>
);

const Chat: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#3ddc84'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-86,-60 H86 Q108,-60 108,-38 V38 Q108,60 86,60 H-10 L-52,100 V60 H-86 Q-108,60 -108,38 V-38 Q-108,-60 -86,-60Z" fill={color} stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
    {[-44, 0, 44].map((dx) => (
      <circle key={dx} cx={dx} cy={0} r={11} fill="#fff" />
    ))}
  </g>
);

const WifiArcs: React.FC<{x: number; y: number; s?: number; t: number; color?: string; dir?: number}> = ({x, y, s = 1, t, color = '#fff', dir = -90}) => (
  <g transform={`translate(${x} ${y}) rotate(${dir + 90}) scale(${s})`}>
    {[0, 1, 2].map((i) => {
      const r = 44 + i * 34;
      const o = 0.35 + 0.65 * Math.max(0, Math.sin(t * 6 - i * 1.1));
      return <path key={i} d={`M${-r * 0.7},${-r * 0.7} A${r},${r} 0 0 1 ${r * 0.7},${-r * 0.7}`} fill="none" stroke={color} strokeWidth={11} strokeLinecap="round" opacity={o} />;
    })}
    <circle cx={0} cy={0} r={11} fill={color} />
  </g>
);

const Check: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#3ddc84'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill={color} stroke={OUT} strokeWidth={7} />
    <path d="M-22,2 L-6,20 L26,-18" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
  </g>
);

const Cross: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill="#ff4b4b" stroke={OUT} strokeWidth={7} />
    <path d="M-20,-20 L20,20 M20,-20 L-20,20" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" />
  </g>
);

const Person: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  shirt?: string;
  pants?: string;
  hair?: string;
  glasses?: boolean;
  armL?: number;
  armR?: number;
  mouth?: 'smile' | 'o' | 'flat';
  look?: number;
}> = ({x, y, s = 1, flip = false, shirt = '#4a7bb5', pants = '#2b2f55', hair = '#4a2f22', glasses = false, armL = 15, armR = 15, mouth = 'smile', look = 0}) => {
  const arm = (ang: number, side: number) => {
    const sx = side * 36;
    const sy = -172;
    const a = (ang * side * Math.PI) / 180;
    const L = 88;
    const ex = sx + Math.sin(a) * L;
    const ey = sy + Math.cos(a) * L;
    return (
      <g>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={OUT} strokeWidth={31} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={shirt} strokeWidth={20} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={13} fill="#f7efe4" stroke={OUT} strokeWidth={4} />
      </g>
    );
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={60} ry={10} fill="#000" opacity={0.2} />
      <rect x={-29} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <rect x={6} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <ellipse cx={-20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      <ellipse cx={20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      {arm(armL, -1)}
      <rect x={-42} y={-195} width={84} height={112} rx={28} fill={shirt} stroke={OUT} strokeWidth={6} />
      {arm(armR, 1)}
      <circle cx={look * 5} cy={-248} r={50} fill="#f7efe4" stroke={OUT} strokeWidth={6} />
      <path
        d={`M${-50 + look * 5},-252 A50,50 0 0 1 ${50 + look * 5},-252 Q${look * 5},-292 ${-50 + look * 5},-252Z`}
        fill={hair}
        stroke={OUT}
        strokeWidth={4}
      />
      <circle cx={-17 + look * 6} cy={-250} r={6} fill={OUT} />
      <circle cx={17 + look * 6} cy={-250} r={6} fill={OUT} />
      {glasses && (
        <g fill="none" stroke={OUT} strokeWidth={4}>
          <circle cx={-17 + look * 6} cy={-250} r={14} />
          <circle cx={17 + look * 6} cy={-250} r={14} />
          <line x1={-3 + look * 6} y1={-250} x2={3 + look * 6} y2={-250} />
        </g>
      )}
      {mouth === 'smile' && <path d={`M${-14 + look * 5},-226 Q${look * 5},-212 ${14 + look * 5},-226`} fill="none" stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
      {mouth === 'o' && <ellipse cx={look * 5} cy={-222} rx={8} ry={10} fill={OUT} />}
      {mouth === 'flat' && <line x1={-12 + look * 5} y1={-222} x2={12 + look * 5} y2={-222} stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
    </g>
  );
};

/* ───────────────────────── efek ───────────────────────── */
const Sparks: React.FC<{
  x: number;
  y: number;
  t0: number;
  n?: number;
  speed?: number;
  life?: number;
  g?: number;
  color?: string;
  size?: number;
  seed?: string;
}> = ({x, y, t0, n = 30, speed = 500, life = 1.2, g = 600, color = '#ffc85a', size = 7, seed = 'sp'}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0 || age > life) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const v = (0.3 + random(`${seed}v${i}`) * 0.7) * speed;
        const px = x + Math.cos(a) * v * age;
        const py = y + Math.sin(a) * v * age + 0.5 * g * age * age;
        const o = 1 - age / life;
        return <circle key={i} cx={px} cy={py} r={size * (0.5 + random(`${seed}r${i}`)) * o} fill={color} opacity={o} />;
      })}
    </g>
  );
};

const Ring: React.FC<{x: number; y: number; t0: number; max?: number; dur?: number; color?: string; w?: number}> = ({x, y, t0, max = 300, dur = 0.9, color = '#fff', w = 12}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (p <= 0 || p >= 1) return null;
  return <circle cx={x} cy={y} r={max * easeOut(p)} fill="none" stroke={color} strokeWidth={w * (1 - p)} opacity={1 - p * 0.7} />;
};

const Flash: React.FC<{t0: number; dur?: number; color?: string}> = ({t0, dur = 0.5, color = '#fff'}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (t < t0 || p >= 1) return null;
  return <AbsoluteFill style={{background: color, opacity: 0.85 * (1 - easeOut(p))}} />;
};

/** bola cahaya yang bergerak di sepanjang garis lurus */
const Pulses: React.FC<{x0: number; y0: number; x1: number; y1: number; n?: number; speed?: number; r?: number; color?: string; glow?: string}> = ({
  x0,
  y0,
  x1,
  y1,
  n = 4,
  speed = 0.8,
  r = 15,
  color = '#fff7b0',
  glow = 'url(#glowYellow)',
}) => {
  const t = useT();
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const p = (t * speed + i / n) % 1;
        const x = lerp(x0, x1, p);
        const y = lerp(y0, y1, p);
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={r * 3} fill={glow} />
            <circle cx={x} cy={y} r={r} fill={color} stroke={OUT} strokeWidth={3} />
          </g>
        );
      })}
    </g>
  );
};

/* ───────────────────────── UI: label, caption ───────────────────────── */
const Pill: React.FC<{
  x: number;
  y: number;
  text: string;
  at: number;
  color?: string;
  size?: number;
  rot?: number;
  sub?: string;
  until?: number;
  bg?: string;
}> = ({x, y, text, at, color = '#ffb84d', size = 54, rot = 0, sub, until, bg = 'rgba(18,12,30,0.88)'}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const outP = until !== undefined ? 1 - prog(t, until - 0.2, 0.2) : 1;
  const p = pop(t, at, 0.4) * (outP > 0 ? outP : 0);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`,
        background: bg,
        border: `5px solid ${color}`,
        color: '#fff',
        padding: sub ? '12px 38px' : '14px 36px',
        borderRadius: sub ? 44 : 999,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: 2,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {text}
      {sub && <div style={{fontSize: size * 0.52, fontWeight: 600, opacity: 0.85, letterSpacing: 1}}>{sub}</div>}
    </div>
  );
};

/** catatan tulisan tangan */
const Note: React.FC<{x: number; y: number; text: string; at: number; color?: string; size?: number; rot?: number; until?: number}> = ({
  x,
  y,
  text,
  at,
  color = '#ffe27a',
  size = 62,
  rot = -4,
  until,
}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const p = eo(t, at, 0.35);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${0.8 + 0.2 * p})`,
        opacity: p,
        fontFamily: HAND,
        fontWeight: 700,
        fontSize: size,
        color,
        whiteSpace: 'nowrap',
        textShadow: '0 4px 10px rgba(0,0,0,0.55)',
      }}
    >
      {text}
    </div>
  );
};

const Caption: React.FC = () => {
  const t = useT();
  let idx = -1;
  for (let i = 0; i < WORDS.length; i++) {
    if (WORDS[i][1] <= t) idx = i;
    else break;
  }
  if (idx < 0) return null;
  const [w, s, e] = WORDS[idx];
  if (t > e + 0.28) return null;
  const sc = 0.82 + 0.18 * backOut(prog(t, s, 0.16));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '46%',
        textAlign: 'center',
        transform: `translateY(-50%) scale(${sc})`,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 92,
        color: '#fff',
        letterSpacing: -1,
        WebkitTextStroke: '12px rgba(22,12,34,0.9)',
        paintOrder: 'stroke fill',
        textShadow: '0 6px 14px rgba(0,0,0,0.55)',
        padding: '0 40px',
      }}
    >
      {w}
    </div>
  );
};

/* ═══════════════════════════ SCENES ═══════════════════════════ */

/* 1 ─ hook (0 – 5.67) */
const SceneHook = () => {
  const t = useT();
  const tV = W('video');
  const tG = W('game');
  const tP = W('pesan');
  const tI = W('internet', 0);
  const titleO = Math.min(eo(t, 0.15, 0.6), 1 - prog(t, 4.3, 0.5));
  const bob = Math.sin(t * 2.2) * 8;
  const screenIcon = t < tG ? 0 : t < tP ? 1 : 2;
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#2d7a76 0%,#256a68 100%)'}} />
      <S>
        {/* ubin dinding */}
        {Array.from({length: 10}).map((_, i) => (
          <line key={`v${i}`} x1={i * 120} y1={900} x2={i * 120} y2={1660} stroke="#1c4f4c" strokeWidth={5} opacity={0.5} />
        ))}
        {Array.from({length: 7}).map((_, i) => (
          <line key={`h${i}`} x1={0} y1={920 + i * 120} x2={WIDTH} y2={920 + i * 120} stroke="#1c4f4c" strokeWidth={5} opacity={0.5} />
        ))}
        <rect x={0} y={1660} width={WIDTH} height={260} fill="#d8c59c" />
        <rect x={0} y={1650} width={WIDTH} height={14} fill="#a78d5f" />
        {/* jam dinding */}
        <g transform="translate(900 560)">
          <circle r={70} fill="#f4f0e6" stroke={OUT} strokeWidth={8} />
          <line x1={0} y1={0} x2={0} y2={-44} stroke={OUT} strokeWidth={7} strokeLinecap="round" transform={`rotate(${t * 6})`} />
          <line x1={0} y1={0} x2={30} y2={0} stroke={OUT} strokeWidth={7} strokeLinecap="round" transform={`rotate(${t * 0.5})`} />
        </g>
        <Person x={150} y={1800} s={1.05} shirt="#e38b3d" look={2} mouth="o" armR={140} />
        <Person x={930} y={1800} s={1.05} flip shirt="#7a6ae0" hair="#222" glasses look={2} mouth="smile" armR={140} />
        {/* ikon melayang */}
        <g transform={`translate(0 ${bob})`}>
          <g transform={`translate(190 790) scale(${pop(t, tV, 0.45)})`}>
            <circle r={150} fill="url(#glowWhite)" opacity={0.25} />
            <PlayIcon x={0} y={0} s={1} />
          </g>
          <g transform={`translate(890 760) scale(${pop(t, tG, 0.45)})`}>
            <circle r={150} fill="url(#glowWhite)" opacity={0.25} />
            <Gamepad x={0} y={0} s={1.15} />
          </g>
          <g transform={`translate(200 1350) scale(${pop(t, tP, 0.45)})`}>
            <circle r={150} fill="url(#glowWhite)" opacity={0.25} />
            <Chat x={0} y={0} s={1.1} />
          </g>
        </g>
        {/* ponsel */}
        <g transform={`translate(0 ${bob * 0.6})`}>
          <Phone x={540} y={1060} w={380} h={700} rot={-3} screen="#25347a">
            {screenIcon === 0 && <PlayIcon x={0} y={-10} s={1.5} />}
            {screenIcon === 1 && <Gamepad x={0} y={-10} s={1.7} />}
            {screenIcon === 2 && <Chat x={0} y={-10} s={1.6} />}
            <rect x={-120} y={170} width={240} height={14} rx={7} fill="#fff" opacity={0.3} />
            <rect x={-120} y={200} width={170} height={14} rx={7} fill="#fff" opacity={0.2} />
          </Phone>
        </g>
        {t >= tI && <WifiArcs x={540} y={640} s={1.6} t={t} color="#fff" />}
      </S>
      <div
        style={{
          position: 'absolute',
          top: 150,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: titleO,
          transform: `translateY(${(1 - titleO) * -30}px)`,
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          textShadow: '0 6px 18px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{fontSize: 50, letterSpacing: 8, color: '#ffd45a'}}>BAGAIMANA</div>
        <div style={{fontSize: 112, marginTop: 8}}>INTERNET</div>
        <div style={{fontSize: 60, color: '#8ff0ff'}}>MENGHUBUNGKAN DUNIA?</div>
      </div>
      <Pill x={540} y={520} text="INTERNET" at={tI + 0.05} color="#8ff0ff" size={60} />
    </>
  );
};

/* 2 ─ Indonesia → Amerika (5.67 – 12.44) */
const qpt = (a: [number, number], b: [number, number], c: [number, number], u: number): [number, number] => {
  const v = 1 - u;
  return [v * v * a[0] + 2 * v * u * b[0] + u * u * c[0], v * v * a[1] + 2 * v * u * b[1] + u * u * c[1]];
};

const Pin: React.FC<{x: number; y: number; color: string; at: number}> = ({x, y, color, at}) => {
  const t = useT();
  const p = pop(t, at, 0.4);
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      <ellipse cx={0} cy={4} rx={30} ry={9} fill="#000" opacity={0.3} />
      <path d="M0,0 C-30,-45 -44,-68 -44,-94 A44,44 0 1 1 44,-94 C44,-68 30,-45 0,0Z" fill={color} stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
      <circle cx={0} cy={-94} r={16} fill="#fff" stroke={OUT} strokeWidth={5} />
    </g>
  );
};

const SceneRoute = () => {
  const t = useT();
  const A: [number, number] = [210, 1030];
  const B: [number, number] = [570, 430];
  const C: [number, number] = [930, 1050];
  const t0 = W('berpindah');
  const t1 = W('hanya');
  const u = easeInOut(prog(t, t0, t1 - t0 + 0.2));
  const [px, py] = qpt(A, B, C, u);
  const arc = `M${A[0]},${A[1]} Q${B[0]},${B[1]} ${C[0]},${C[1]}`;
  const tq = W('Tapi');
  const sw = W('hitungan');
  return (
    <>
      <NavyBG />
      <Cam z0={1.04} z1={1} dur={6.7}>
        <S>
          {/* daratan */}
          <g fill="#5fae5c" stroke={OUT} strokeWidth={6} strokeLinejoin="round">
            <ellipse cx={130} cy={1000} rx={110} ry={36} transform="rotate(40 130 1000)" />
            <ellipse cx={250} cy={1130} rx={110} ry={26} transform="rotate(-6 250 1130)" />
            <ellipse cx={290} cy={1010} rx={78} ry={64} />
            <ellipse cx={410} cy={1080} rx={52} ry={22} />
            <ellipse cx={90} cy={1110} rx={34} ry={20} />
            <path d="M880,830 C930,790 1090,800 1120,840 L1120,1330 C1050,1370 960,1340 930,1260 C905,1190 885,1110 885,1040 C885,950 855,870 880,830Z" />
          </g>
          <path d={arc} fill="none" stroke="#fff" strokeOpacity={0.3} strokeWidth={6} strokeDasharray="4 22" strokeLinecap="round" />
          {u > 0 && <path d={arc} fill="none" stroke="#ffd45a" strokeWidth={9} strokeLinecap="round" pathLength={1} strokeDasharray={`${u} 2`} />}
          <Pin x={A[0]} y={A[1]} color="#ff5a5a" at={W('Indonesia')} />
          <Pin x={C[0]} y={C[1] + 6} color="#4aa8ff" at={W('Amerika', 0)} />
          {u > 0 && u < 1 && (
            <g>
              <circle cx={px} cy={py} r={70} fill="url(#glowYellow)" />
              <rect x={px - 24} y={py - 24} width={48} height={48} rx={10} fill="#fff7b0" stroke={OUT} strokeWidth={6} transform={`rotate(${t * 180} ${px} ${py})`} />
            </g>
          )}
          {t >= t1 && <Ring x={C[0]} y={C[1]} t0={t1 - 0.1} max={230} color="#ffd45a" />}
          {/* stopwatch */}
          {t >= W('dalam', 0) && (
            <g transform={`translate(540 380) scale(${pop(t, W('dalam', 0), 0.45)})`}>
              <circle r={120} fill="#f4f0e6" stroke={OUT} strokeWidth={9} />
              <rect x={-18} y={-152} width={36} height={26} rx={6} fill="#aab2c8" stroke={OUT} strokeWidth={5} />
              {Array.from({length: 12}).map((_, i) => (
                <line key={i} x1={0} y1={-98} x2={0} y2={-84} stroke={OUT} strokeWidth={5} strokeLinecap="round" transform={`rotate(${i * 30})`} />
              ))}
              <line x1={0} y1={0} x2={0} y2={-80} stroke="#e0443a" strokeWidth={8} strokeLinecap="round" transform={`rotate(${(t - sw) * 420})`} />
              <circle r={10} fill={OUT} />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={A[0]} y={1260} text="INDONESIA" at={W('Indonesia') + 0.1} color="#ff8a8a" size={46} />
      <Pill x={820} y={1400} text="AMERIKA" at={W('Amerika', 0) + 0.1} color="#7ccfff" size={46} />
      <Note x={540} y={520} text="?" at={tq} size={220} color="#ffe27a" rot={6} until={W('dalam', 0)} />
      <Pill x={540} y={600} text="HITUNGAN DETIK" at={sw} color="#ffd45a" size={54} />
    </>
  );
};

/* 3 ─ mitos satelit (12.44 – 16.19) */
const SceneSat = () => {
  const t = useT();
  const tS = W('satelit', 0);
  const tX = tS + 0.55;
  const tD = W('dikirim', 0);
  const bob = Math.sin(t * 2.4) * 14;
  const shake = t > tX ? Math.sin(t * 90) * 6 * (1 - prog(t, tX, 0.5)) : 0;
  return (
    <>
      <SpaceBG />
      <Cam z0={1.06} z1={1} dur={3.75}>
        <S>
          <g transform="translate(540 1720)">
            <circle r={620} fill="url(#glowBlue)" />
            <circle r={540} fill="#2f7fd6" stroke={OUT} strokeWidth={10} />
            <path d="M-300,-440 C-200,-500 -80,-480 -20,-420 C30,-370 -40,-330 -120,-300 C-220,-270 -330,-340 -300,-440Z" fill="#62b85c" stroke={OUT} strokeWidth={5} />
            <path d="M150,-440 C240,-420 330,-340 300,-260 C260,-190 160,-230 130,-300 C110,-350 120,-410 150,-440Z" fill="#62b85c" stroke={OUT} strokeWidth={5} />
          </g>
          {t >= tD &&
            [-1, 0, 1].map((k) => {
              const o = 0.5 + 0.5 * Math.sin(t * 8 + k);
              return <line key={k} x1={540 + k * 40} y1={760} x2={540 + k * 220} y2={1260} stroke="#ffd45a" strokeWidth={8} strokeDasharray="14 18" strokeDashoffset={-t * 120} opacity={o} strokeLinecap="round" />;
            })}
          <Satellite x={540 + shake} y={560 + bob} s={1.5} rot={-8} />
          {t >= tD && <WifiArcs x={540} y={680 + bob} s={1.1} t={t} color="#ffd45a" dir={90} />}
          {t >= tX && (
            <g transform={`translate(540 ${560 + bob}) scale(${pop(t, tX, 0.45) * 2.3})`}>
              <Cross x={0} y={0} s={1} />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={540} y={300} text="SATELIT?" at={tS} color="#ffd45a" size={72} until={tX + 0.8} />
      <Flash t0={tX} dur={0.3} color="#ff6a4a" />
    </>
  );
};

/* 4 ─ 99 persen (16.19 – 23.47) */
const ScenePersen = () => {
  const t = useT();
  const t99 = W('99');
  const tEnd = WE('persen');
  const p = easeOut(prog(t, t99, tEnd - t99));
  const shown = Math.round(99 * p);
  const CX = 540;
  const CY = 1250;
  const R = 235;
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(120% 80% at 50% 40%, #1d5a63 0%, #0f3d44 55%, #07222a 100%)'}} />
      <Cam z0={1.05} z1={1} dur={7}>
        <S>
          <g transform={`translate(${CX} ${CY}) rotate(-90)`}>
            <circle r={R} fill="none" stroke={OUT} strokeWidth={104} />
            <circle r={R} fill="none" stroke="#173a44" strokeWidth={80} />
            <circle r={R} fill="none" stroke="#8ff0ff" strokeWidth={80} pathLength={1} strokeDasharray={`${0.99 * p} 2`} strokeLinecap="butt" />
            <circle r={R} fill="none" stroke="#ffb84d" strokeWidth={80} pathLength={1} strokeDasharray="0.01 0.99" strokeDashoffset={-0.99} opacity={p > 0.98 ? 1 : 0} />
          </g>
          <circle cx={CX} cy={CY} r={R + 70} fill="url(#glowCyan)" opacity={0.18 * p} />
        </S>
      </Cam>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: CY - 98,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 150,
          color: '#fff',
          WebkitTextStroke: '10px rgba(22,12,34,0.9)',
          paintOrder: 'stroke fill',
          opacity: eo(t, t99 - 0.1, 0.2),
        }}
      >
        {'>'}
        {shown}%
      </div>
      <Pill x={540} y={560} text="LALU LINTAS DATA" sub="INTERNASIONAL" at={W('lalu')} color="#8ff0ff" size={54} />
      <S>
        {t >= W('kabel', 0) && (
          <g transform={`translate(0 ${(1 - eo(t, W('kabel', 0), 0.4)) * 60})`} opacity={eo(t, W('kabel', 0), 0.4)}>
            <rect x={110} y={1610} width={860} height={140} rx={40} fill="rgba(18,12,30,0.88)" stroke="#8ff0ff" strokeWidth={5} />
            <path d="M170,1680 q30,-50 60,0 t60,0 t60,0" fill="none" stroke="#8ff0ff" strokeWidth={12} strokeLinecap="round" />
          </g>
        )}
      </S>
      {t >= W('kabel', 0) && (
        <div style={{position: 'absolute', left: 390, top: 1610, height: 140, display: 'flex', alignItems: 'center', fontFamily: FONT, fontWeight: 800, fontSize: 44, color: '#fff', letterSpacing: 1, opacity: eo(t, W('kabel', 0), 0.4)}}>
          KABEL BAWAH LAUT
        </div>
      )}
      <Pill x={540} y={1810} text="SATELIT < 1%" at={tEnd + 0.4} color="#ffb84d" size={46} />
    </>
  );
};

/* 5 ─ satelit: wilayah terpencil · kabel: tulang punggung (23.47 – 30.27) */
const yB = (x: number) => 1640 + 24 * Math.sin(x / 170);
const cableSea = (() => {
  let d = `M-40,${yB(-40).toFixed(1)}`;
  for (let x = -40; x <= 1120; x += 30) d += ` L${x},${yB(x).toFixed(1)}`;
  return d;
})();

const SceneBackbone = () => {
  const t = useT();
  const tS = W('Satelit', 1);
  const tT = W('terpencil');
  const tK = W('tulang');
  const bob = Math.sin(t * 2.4) * 10;
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#8fd6f5 0%,#d6f1fb 30%)'}} />
      <S>
        {/* awan */}
        {[[200, 160, 1], [820, 300, 0.8]].map(([cx, cy, k], i) => (
          <g key={i} transform={`translate(${(cx as number) + Math.sin(t * 0.4 + i) * 20} ${cy}) scale(${k})`} fill="#fff" stroke={OUT} strokeWidth={5}>
            <ellipse cx={0} cy={0} rx={110} ry={44} />
            <ellipse cx={-40} cy={-30} rx={56} ry={40} />
            <ellipse cx={34} cy={-40} rx={64} ry={48} />
          </g>
        ))}
        <rect x={0} y={560} width={WIDTH} height={HEIGHT - 560} fill="url(#seaGrad)" />
        <path d={waveLine(560, 9, 180, t * 2.2)} fill="none" stroke="#bff0ff" strokeWidth={6} opacity={0.85} />
        {/* pulau terpencil */}
        <g>
          <path d="M680,566 Q760,470 850,470 Q940,470 1020,566Z" fill="#e8c98a" stroke={OUT} strokeWidth={6} />
          <path d="M930,486 C940,420 930,380 900,340" fill="none" stroke={OUT} strokeWidth={22} strokeLinecap="round" />
          <path d="M930,486 C940,420 930,380 900,340" fill="none" stroke="#a9733f" strokeWidth={12} strokeLinecap="round" />
          {[-60, -20, 20, 60].map((a, i) => (
            <path key={i} d="M900,340 Q940,300 990,330 Q940,330 900,340Z" fill="#4faa57" stroke={OUT} strokeWidth={4} transform={`rotate(${a - 10} 900 340)`} />
          ))}
          <rect x={740} y={440} width={86} height={60} fill="#e6d6b4" stroke={OUT} strokeWidth={6} />
          <path d="M728,442 L783,396 L838,442Z" fill="#c94b3b" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
          <circle cx={783} cy={470} r={10} fill="#7ccfff" stroke={OUT} strokeWidth={3} />
        </g>
        {/* satelit + sinyal */}
        <g transform={`translate(0 ${bob})`}>
          <line x1={330} y1={320} x2={785} y2={420} stroke="#ffd45a" strokeWidth={8} strokeDasharray="14 18" strokeDashoffset={-t * 120} strokeLinecap="round" opacity={eo(t, tS + 0.3, 0.4)} />
          <Satellite x={300} y={230} s={0.8} rot={-14} />
        </g>
        {t >= tT && <Ring x={783} y={420} t0={tT} max={150} color="#ffd45a" />}
        {/* dasar laut + kabel */}
        <path d={`M-40,${yB(-40)} ${cableSea.slice(cableSea.indexOf('L'))} L1120,1960 L-40,1960Z`} fill="url(#sandGrad)" stroke={OUT} strokeWidth={6} transform="translate(0 26)" />
        <Fish x={220 + Math.sin(t * 0.8) * 40} y={1180} s={0.7} />
        <Fish x={850 - Math.sin(t * 0.7) * 40} y={1330} s={0.55} flip color="#ffd45a" />
        <CableSVG d={cableSea} w={34} flow={340} flowColor="#8ff0ff" />
        {/* tulang punggung */}
        {Array.from({length: 11}).map((_, i) => {
          const x = 70 + i * 94;
          const a = (Math.atan2(yB(x + 4) - yB(x - 4), 8) * 180) / Math.PI;
          const sc = pop(t, tK + i * 0.05, 0.3);
          return (
            <g key={i} transform={`translate(${x} ${yB(x)}) rotate(${a}) scale(${sc})`}>
              <rect x={-30} y={-26} width={60} height={52} rx={22} fill="#f4efe0" stroke={OUT} strokeWidth={5} />
              <circle cx={0} cy={0} r={8} fill="#c9bfa5" />
            </g>
          );
        })}
      </S>
      <Pill x={540} y={730} text="SATELIT" sub="WILAYAH TERPENCIL" at={tT - 0.15} color="#ffd45a" size={50} until={W('tapi', 1) + 0.1} />
      <Pill x={540} y={1440} text="TULANG PUNGGUNG" at={tK} color="#8ff0ff" size={62} />
    </>
  );
};

/* 6 ─ isi kabel (30.27 – 33.90) */
const SceneCross = () => {
  const t = useT();
  const tK = W('kabel', 2);
  const tSerat = W('serat', 0);
  const tTipis = W('sangat');
  const gf = eo(t, tSerat, 0.4) * (0.6 + 0.4 * Math.sin(t * 8));
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(90% 60% at 50% 48%, #1e4b63 0%, #0e2433 70%, #07131c 100%)'}} />
      <Cam z0={0.82} z1={t > tSerat ? 1.1 : 1} dur={3.6}>
        <S>
          <CableCross x={540} y={940} r={330} t0={tK - 0.1} step={0.28} glowFiber={gf} />
          {t >= tSerat && <Ring x={540} y={940} t0={tSerat} max={260} color="#8ff0ff" />}
        </S>
      </Cam>
      <Pill x={540} y={380} text="SERAT KACA" at={tSerat} color="#8ff0ff" size={72} />
      <Note x={540} y={1420} text="sangat tipis…" at={tTipis} size={84} color="#fff" rot={-3} />
    </>
  );
};

/* 7 ─ data → cahaya → data (33.90 – 42.10) */
const Bits: React.FC<{t0: number; t1: number; x0: number; x1: number; y: number; seed: string; color?: string}> = ({t0, t1, x0, x1, y, seed, color = '#fff'}) => {
  const t = useT();
  if (t < t0 || t > t1) return null;
  return (
    <g>
      {Array.from({length: 5}).map((_, i) => {
        const p = ((t - t0) / (t1 - t0) + i / 5) % 1;
        const x = lerp(x0, x1, p);
        const bit = random(`${seed}${i}${Math.floor((t - t0) * 4)}`) > 0.5 ? '1' : '0';
        return (
          <text key={i} x={x} y={y + Math.sin(p * 9 + i) * 16} fontSize={44} fontFamily={FONT} fontWeight={800} fill={color} stroke={OUT} strokeWidth={8} paintOrder="stroke" textAnchor="middle" opacity={Math.sin(p * Math.PI)}>
            {bit}
          </text>
        );
      })}
    </g>
  );
};

const SceneLight = () => {
  const t = useT();
  const Y = 1180;
  const tDat = W('Data', 2);
  const tSin = W('sinyal', 0);
  const tDik = W('dikirim', 1);
  const tLalu = W('lalu', 1);
  const tKem = W('kembali');
  const tTuj = W('tujuan');
  const boxA = t >= tSin;
  const boxB = t >= tLalu;
  const pulsing = t >= tDik && t < tLalu + 0.1;
  return (
    <>
      <NavyBG />
      <S>
        {/* serat */}
        <rect x={400} y={Y - 36} width={290} height={72} rx={36} fill="#b9e6ff" stroke={OUT} strokeWidth={8} />
        <rect x={400} y={Y - 14} width={290} height={28} rx={14} fill="#e9fbff" opacity={0.9} />
        {pulsing &&
          [0, 1, 2, 3].map((i) => {
            const p = ((t - tDik) * 0.55 + i / 4) % 1;
            return <circle key={i} cx={lerp(410, 680, p)} cy={Y} r={15} fill="#fff7b0" stroke="#ffb84d" strokeWidth={5} />;
          })}
        {/* kotak pengirim */}
        <g>
          <rect x={250} y={Y - 90} width={150} height={180} rx={18} fill="#6a6ff0" stroke={OUT} strokeWidth={8} />
          <circle cx={325} cy={Y - 30} r={32} fill={boxA ? '#ffe27a' : '#2a2f6a'} stroke={OUT} strokeWidth={6} />
          {boxA && <circle cx={325} cy={Y - 30} r={90} fill="url(#glowYellow)" opacity={0.7 + 0.3 * Math.sin(t * 12)} />}
          <rect x={275} y={Y + 24} width={100} height={18} rx={9} fill="#fff" opacity={0.3} />
        </g>
        {/* kotak penerima */}
        <g>
          <rect x={690} y={Y - 90} width={150} height={180} rx={18} fill="#6a6ff0" stroke={OUT} strokeWidth={8} />
          <circle cx={765} cy={Y - 30} r={32} fill={boxB ? '#8ff0ff' : '#2a2f6a'} stroke={OUT} strokeWidth={6} />
          {boxB && t < tTuj + 0.3 && <circle cx={765} cy={Y - 30} r={90} fill="url(#glowCyan)" opacity={0.7 + 0.3 * Math.sin(t * 12)} />}
          <rect x={715} y={Y + 24} width={100} height={18} rx={9} fill="#fff" opacity={0.3} />
        </g>
        <Phone x={110} y={Y} w={170} h={310} screen="#25347a">
          <Chat x={0} y={-10} s={0.65} />
        </Phone>
        <Phone x={970} y={Y} w={170} h={310} screen="#25347a">
          <Chat x={0} y={-10} s={0.65} color="#6fb7ff" />
        </Phone>
        <Bits t0={tDat} t1={tSin + 0.3} x0={150} x1={250} y={Y + 8} seed="a" />
        <Bits t0={tKem} t1={tTuj + 0.2} x0={850} x1={925} y={Y + 8} seed="b" color="#8ff0ff" />
        {t >= tTuj && <Check x={970} y={Y - 230} s={pop(t, tTuj, 0.4)} />}
      </S>
      <Pill x={540} y={700} text="DATA DIGITAL" at={tDat} until={tSin} color="#ffffff" size={64} />
      <Pill x={540} y={700} text="SINYAL CAHAYA" at={tSin} until={tDik} color="#ffd45a" size={64} />
      <Pill x={540} y={700} text="MELALUI SERAT" at={tDik} until={tLalu} color="#8ff0ff" size={64} />
      <Pill x={540} y={700} text="JADI DATA LAGI" at={tLalu} color="#6fe6a0" size={64} />
    </>
  );
};

/* 8 ─ pemantulan internal total (42.10 – 47.62) */
const SceneTIR = () => {
  const t = useT();
  const t0 = W('merambat');
  const t1 = WE('total');
  const p = prog(t, t0, t1 - t0 - 0.2);
  const pts: Array<[number, number]> = [[-40, 1190]];
  const yT = 1090;
  const yB2 = 1290;
  pts.push([60, yB2]);
  for (let i = 0; i < 6; i++) pts.push([60 + (i + 1) * 200, i % 2 === 0 ? yT : yB2]);
  const d = pts.map((q, i) => `${i === 0 ? 'M' : 'L'}${q[0]},${q[1]}`).join(' ');
  const tSerat = W('serat', 2);
  const tPem = W('pemantulan');
  return (
    <>
      <NavyBG />
      <S>
        <rect x={-30} y={1020} width={WIDTH + 60} height={340} rx={30} fill="#7fc4f2" stroke={OUT} strokeWidth={8} />
        <rect x={-30} y={1062} width={WIDTH + 60} height={256} fill="#e6f9ff" stroke={OUT} strokeWidth={5} />
        {p > 0 && <path d={d} fill="none" stroke="#ffd45a" strokeOpacity={0.35} strokeWidth={30} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${p} 2`} />}
        {p > 0 && <path d={d} fill="none" stroke="#ff9a2e" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${p} 2`} />}
        {pts.slice(1).map((q, i) => {
          const along = (i + 1) / (pts.length - 1);
          const hit = p >= along - 0.01;
          if (!hit) return null;
          const age = (p - along) * (t1 - t0);
          return <circle key={i} cx={q[0]} cy={q[1]} r={26 + 30 * clamp(1 - age / 0.4)} fill="url(#glowWhite)" opacity={clamp(1 - age / 0.5)} />;
        })}
      </S>
      <Note x={190} y={960} text="selubung" at={tSerat} size={58} color="#bfe8ff" rot={-5} />
      <Note x={190} y={1410} text="inti serat" at={tSerat + 0.2} size={58} color="#fff" rot={4} />
      <Pill x={540} y={700} text="PEMANTULAN" sub="INTERNAL TOTAL" at={tPem} color="#ffd45a" size={64} />
    </>
  );
};

/* 9 ─ sinyal melemah (47.62 – 52.19) */
const SceneAtten = () => {
  const t = useT();
  const lt = useLT();
  const Y = 1180;
  const draw = easeInOut(prog(lt, 0.2, 3.6));
  const xEnd = WIDTH * draw;
  let d = `M0,${Y}`;
  for (let x = 0; x <= xEnd; x += 6) {
    const A = 170 * Math.exp(-x / 430);
    d += ` L${x},${(Y + Math.sin((x / 70) * Math.PI * 2 - t * 8) * A).toFixed(1)}`;
  }
  const tK = W('kekuatan');
  const level = 1 - 0.85 * easeInOut(prog(t, tK, WE('berkurang') - tK));
  return (
    <>
      <NavyBG />
      <S>
        <line x1={0} y1={Y} x2={WIDTH} y2={Y} stroke="#fff" strokeOpacity={0.18} strokeWidth={4} strokeDasharray="10 14" />
        <path d={d} fill="none" stroke={OUT} strokeWidth={20} strokeLinecap="round" strokeLinejoin="round" />
        <path d={d} fill="none" stroke="#ffd45a" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
        {/* penggaris jarak */}
        <g opacity={eo(t, W('ribuan') - 0.1, 0.4)}>
          <line x1={60} y1={1460} x2={1020} y2={1460} stroke="#fff" strokeWidth={8} strokeLinecap="round" />
          <path d="M60,1460 l30,-22 M60,1460 l30,22 M1020,1460 l-30,-22 M1020,1460 l-30,22" stroke="#fff" strokeWidth={8} strokeLinecap="round" />
          {Array.from({length: 9}).map((_, i) => (
            <line key={i} x1={60 + i * 120} y1={1444} x2={60 + i * 120} y2={1476} stroke="#fff" strokeWidth={6} />
          ))}
        </g>
        {/* meter sinyal */}
        <g transform="translate(540 540)" opacity={eo(t, tK - 0.1, 0.4)}>
          <rect x={-300} y={-52} width={600} height={104} rx={30} fill="#0b1636" stroke={OUT} strokeWidth={8} />
          <rect x={-282} y={-34} width={564 * level} height={68} rx={20} fill={level > 0.5 ? '#6fe6a0' : level > 0.25 ? '#ffd45a' : '#ff5a5a'} />
        </g>
      </S>
      <Pill x={540} y={1560} text="RIBUAN KILOMETER" at={W('ribuan')} color="#fff" size={56} />
      <Pill x={540} y={410} text="KEKUATAN SINYAL" at={tK} color="#ffd45a" size={56} />
    </>
  );
};

/* 10 ─ repeater (52.19 – 62.22) */
const RepeaterBox: React.FC<{x: number; y: number; at: number; glow?: number}> = ({x, y, at, glow = 0}) => {
  const t = useT();
  const p = pop(t, at, 0.4);
  if (t < at) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      {glow > 0 && <circle r={150} fill="url(#glowYellow)" opacity={glow} />}
      <rect x={-62} y={-80} width={124} height={160} rx={20} fill="#f08a3c" stroke={OUT} strokeWidth={8} />
      <rect x={-46} y={-64} width={92} height={60} rx={10} fill="#ffe0b8" opacity={0.5} />
      <path d="M-26,-46 L30,-26 L-26,-6Z" fill="#fff" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
      <circle cx={-30} cy={40} r={9} fill="#6fe6a0" stroke={OUT} strokeWidth={3} />
      <circle cx={0} cy={40} r={9} fill="#ffd45a" stroke={OUT} strokeWidth={3} />
      <circle cx={30} cy={40} r={9} fill="#ff5a5a" stroke={OUT} strokeWidth={3} />
    </g>
  );
};

const SceneRepeater = () => {
  const t = useT();
  const Y = 1180;
  const rx = [270, 540, 810];
  const rt = [W('repeater'), W('repeater') + 0.28, W('repeater') + 0.56];
  const active = rx.filter((_, i) => t >= rt[i]);
  const tJarak = W('puluhan');
  const tLis = W('listriknya');
  const tKon = W('konduktor');
  const power = t >= tLis;
  let d = `M-10,${Y}`;
  for (let x = -10; x <= WIDTH + 10; x += 6) {
    const r0 = active.filter((a) => a <= x).pop() ?? 0;
    const A = 150 * Math.exp(-(x - r0) / 330);
    d += ` L${x},${(Y + Math.sin((x / 70) * Math.PI * 2 - t * 8) * A).toFixed(1)}`;
  }
  return (
    <>
      <NavyBG />
      <S>
        <CableSVG d={`M-40,${Y} L${WIDTH + 40},${Y}`} w={30} color="#4b4f7a" flow={power ? 420 : undefined} flowColor="#ffe27a" dash="28 120" />
        <path d={d} fill="none" stroke={OUT} strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />
        <path d={d} fill="none" stroke="#ffd45a" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
        {rx.map((x, i) => (
          <RepeaterBox key={i} x={x} y={Y} at={rt[i]} glow={power ? 0.55 + 0.35 * Math.sin(t * 10 + i) : 0} />
        ))}
        {/* jarak antar repeater */}
        {t >= tJarak && t < tLis && (
          <g opacity={eo(t, tJarak, 0.4)}>
            <line x1={270} y1={1380} x2={540} y2={1380} stroke="#fff" strokeWidth={8} strokeLinecap="round" />
            <path d="M270,1380 l26,-20 M270,1380 l26,20 M540,1380 l-26,-20 M540,1380 l-26,20" stroke="#fff" strokeWidth={8} strokeLinecap="round" />
            <line x1={270} y1={1260} x2={270} y2={1400} stroke="#fff" strokeOpacity={0.5} strokeWidth={4} strokeDasharray="8 10" />
            <line x1={540} y1={1260} x2={540} y2={1400} stroke="#fff" strokeOpacity={0.5} strokeWidth={4} strokeDasharray="8 10" />
          </g>
        )}
        {/* inset penampang: konduktor */}
        {t >= tKon - 0.3 && (
          <g opacity={eo(t, tKon - 0.3, 0.4)}>
            <CableCross x={540} y={1560} r={170} t0={-10} glowCopper={0.5 + 0.5 * Math.sin(t * 8)} />
          </g>
        )}
        {power && t < tKon - 0.3 && <Ring x={270} y={Y} t0={tLis} max={200} color="#ffd45a" />}
      </S>
      <Pill x={540} y={640} text="REPEATER" sub="PENGUAT OPTIK" at={rt[0]} until={tJarak - 0.1} color="#ffb84d" size={64} />
      <Pill x={540} y={1470} text="PULUHAN – ±100 KM" at={tJarak + 0.1} until={tLis - 0.1} color="#fff" size={52} />
      <Pill x={540} y={640} text="LISTRIK" at={tLis} color="#ffd45a" size={72} until={tKon - 0.1} />
      <Pill x={540} y={640} text="KONDUKTOR" at={tKon} color="#ffb06a" size={72} />
    </>
  );
};

/* 11 ─ kapal pemasang kabel (62.22 – 66.04) */
const SceneShip = () => {
  const t = useT();
  const lt = useLT();
  const bob = Math.sin(t * 2.2) * 8;
  const drift = lt * -16;
  const tK = W('kapal', 0);
  const tG = W('gulungan');
  const lay = eo(t, 62.4, 2.2);
  const cable = 'M374,956 L298,906 C262,930 252,1000 252,1090 C250,1250 200,1400 120,1580';
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#8fd6f5 0%,#e3f5fb 60%)'}} />
      <Cam z0={1.05} z1={1.0} dur={3.8}>
        <S>
          <g transform={`translate(${Math.sin(t * 0.5) * 20} 0)`} fill="#fff" stroke={OUT} strokeWidth={5}>
            <ellipse cx={220} cy={330} rx={120} ry={44} />
            <ellipse cx={180} cy={300} rx={58} ry={40} />
            <ellipse cx={780} cy={470} rx={130} ry={46} />
            <ellipse cx={830} cy={436} rx={64} ry={46} />
          </g>
          <rect x={0} y={1090} width={WIDTH} height={HEIGHT - 1090} fill="url(#seaGrad)" />
          <g transform={`translate(${drift} ${bob})`}>
            <Ship x={560} y={1040} t={lt} />
            <g transform="translate(0 0)">
              <CableSVG d={cable} w={16} color="#4b4f7a" draw={lay} />
            </g>
          </g>
          <rect x={0} y={1090} width={WIDTH} height={HEIGHT - 1090} fill="#0a2a5c" opacity={0.35} />
          <path d={waveLine(1090, 10, 170, t * 2.4)} fill="none" stroke="#bff0ff" strokeWidth={7} />
          <path d={waveLine(1100, 8, 120, -t * 2.9)} fill="none" stroke="#fff" strokeOpacity={0.4} strokeWidth={5} />
          <Fish x={820 + Math.sin(t) * 30} y={1500} s={0.6} flip />
        </S>
      </Cam>
      <Pill x={540} y={640} text="KAPAL KHUSUS" at={tK} until={tG - 0.1} color="#ffb84d" size={64} />
      <Pill x={540} y={640} text="GULUNGAN KABEL" at={tG} color="#8ff0ff" size={64} />
      <Note x={540} y={760} text="(cable-laying ship)" at={tK + 0.2} size={56} color="#2a1a2c" rot={-2} />
    </>
  );
};

/* 12 ─ laut dangkal: kabel ditanam (66.04 – 73.32) */
const Anchor: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <g fill="none" stroke={OUT} strokeWidth={24} strokeLinecap="round" strokeLinejoin="round">
      <circle cx={0} cy={-80} r={20} />
      <path d="M0,-60 V70 M-34,-34 H34 M-70,20 C-60,70 -30,86 0,86 C30,86 60,70 70,20" />
    </g>
    <g fill="none" stroke="#c7ccdd" strokeWidth={12} strokeLinecap="round" strokeLinejoin="round">
      <circle cx={0} cy={-80} r={20} />
      <path d="M0,-60 V70 M-34,-34 H34 M-70,20 C-60,70 -30,86 0,86 C30,86 60,70 70,20" />
    </g>
  </g>
);

const SmallBoat: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#c94b3b'}) => {
  const t = useT();
  return (
    <g transform={`translate(${x} ${y + Math.sin(t * 2 + x) * 5}) scale(${s})`}>
      <path d="M-120,-16 L130,-16 L90,50 L-90,50Z" fill={color} stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
      <rect x={-20} y={-80} width={70} height={64} rx={8} fill="#f4f0e6" stroke={OUT} strokeWidth={6} />
      <rect x={-6} y={-66} width={42} height={26} rx={4} fill="#7ccfff" stroke={OUT} strokeWidth={4} />
      <line x1={-90} y1={-16} x2={-90} y2={-100} stroke={OUT} strokeWidth={8} strokeLinecap="round" />
    </g>
  );
};

const SceneShallow = () => {
  const t = useT();
  const tJ = W('jangkar');
  const tF = W('aktivitas');
  const tD = W('ditanam');
  const SEA = 470;
  const FLOOR = 1290;
  const CY = 1500;
  const aq = easeIn(prog(t, tJ, 0.65));
  const ay = lerp(540, FLOOR - 60, aq);
  const ax = 330 + 28 + (t > tJ + 0.65 ? Math.min(90, (t - tJ - 0.65) * 120) : 0);
  const net = t >= tF;
  const nx = 780 + Math.sin((t - tF) * 1.6) * 70;
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#8fd6f5 0%,#d6f1fb 24%)'}} />
      <S>
        <rect x={0} y={SEA} width={WIDTH} height={HEIGHT - SEA} fill="url(#seaGrad)" />
        <path d={waveLine(SEA, 9, 180, t * 2.2)} fill="none" stroke="#bff0ff" strokeWidth={6} />
        {/* dasar laut + lapisan pasir */}
        <rect x={0} y={FLOOR} width={WIDTH} height={HEIGHT - FLOOR} fill="url(#sandGrad)" stroke={OUT} strokeWidth={6} />
        <rect x={0} y={CY - 70} width={WIDTH} height={140} fill="#c9a468" opacity={0.85} />
        <path d={`M0,${FLOOR + 90} Q270,${FLOOR + 60} 540,${FLOOR + 96} T1080,${FLOOR + 80}`} fill="none" stroke="#b88f55" strokeWidth={6} />
        {[130, 330, 560, 760, 960].map((x, i) => (
          <circle key={i} cx={x} cy={FLOOR + 220 + (i % 3) * 60} r={10 + (i % 2) * 6} fill="#b88f55" opacity={0.8} />
        ))}
        <CableSVG d={`M-40,${CY} L${WIDTH + 40},${CY}`} w={32} flow={280} />
        <Fish x={650 + Math.sin(t * 0.8) * 50} y={900} s={0.55} flip color="#ffd45a" />
        {/* kapal & jangkar */}
        <SmallBoat x={330} y={SEA - 40} s={1.1} />
        {t >= tJ - 0.3 && (
          <>
            <line x1={358} y1={SEA - 10} x2={ax} y2={ay - 90} stroke={OUT} strokeWidth={8} strokeDasharray="1 0" />
            <Anchor x={ax} y={ay} s={0.8} rot={aq < 1 ? Math.sin(t * 6) * 10 : 8} />
          </>
        )}
        <Sparks x={ax} y={FLOOR - 4} t0={tJ + 0.65} n={14} speed={260} life={0.9} g={400} color="#e8c98a" size={9} seed="dust" />
        {/* jaring ikan */}
        {net && (
          <g opacity={eo(t, tF, 0.4)}>
            <SmallBoat x={nx} y={SEA - 40} s={1.0} color="#3b7ee0" />
            <path d={`M${nx - 40},${SEA - 10} L${nx - 120},${FLOOR - 12} L${nx + 120},${FLOOR - 12} L${nx + 40},${SEA - 10}`} fill="rgba(255,255,255,0.12)" stroke="#f4f0e6" strokeWidth={6} strokeLinejoin="round" />
            {Array.from({length: 6}).map((_, i) => (
              <line key={i} x1={lerp(nx - 40, nx - 120, i / 5)} y1={lerp(SEA - 10, FLOOR - 12, i / 5)} x2={lerp(nx + 40, nx + 120, i / 5)} y2={lerp(SEA - 10, FLOOR - 12, i / 5)} stroke="#f4f0e6" strokeWidth={3} opacity={0.7} />
            ))}
          </g>
        )}
        {/* aman */}
        {t >= tJ + 0.9 && <Check x={540} y={CY - 150} s={pop(t, tJ + 0.9, 0.4)} />}
      </S>
      <Pill x={540} y={230} text="LAUT DANGKAL" at={W('laut', 1)} until={tD + 0.6} color="#8ff0ff" size={64} />
      <Pill x={540} y={1700} text="DITANAM DI BAWAH DASAR" at={tD} color="#ffb84d" size={50} />
      <Pill x={250} y={640} text="JANGKAR" at={tJ} color="#ffd45a" size={46} />
      <Pill x={830} y={640} text="JARING IKAN" at={W('penangkapan')} color="#ffd45a" size={46} />
    </>
  );
};

/* 13 ─ laut dalam: cukup diletakkan (73.32 – 76.91) */
const yD = (x: number) => 1560 + 30 * Math.sin(x / 150);
const cableDeep = (() => {
  let d = `M-40,${yD(-40).toFixed(1)}`;
  for (let x = -40; x <= 1120; x += 30) d += ` L${x},${yD(x).toFixed(1)}`;
  return d;
})();

const SceneDeep = () => {
  const t = useT();
  const tL = W('laut', 3);
  const tC = W('cukup');
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#0f4a86 0%,#082a58 45%,#030d24 100%)'}} />
      <S>
        {[180, 520, 860].map((x, i) => (
          <path key={i} d={`M${x},0 L${x + 120},0 L${x + 260},1500 L${x - 140},1500Z`} fill="url(#beam)" opacity={0.35 - i * 0.08} />
        ))}
        {Array.from({length: 24}).map((_, i) => {
          const x = random(`bx${i}`) * WIDTH;
          const y = (random(`by${i}`) * HEIGHT - t * (30 + random(`bv${i}`) * 40) + HEIGHT * 2) % HEIGHT;
          return <circle key={i} cx={x} cy={y} r={3 + random(`br${i}`) * 5} fill="#9fe6ff" opacity={0.35} />;
        })}
        <path d={`M-40,${yD(-40)} ${cableDeep.slice(cableDeep.indexOf('L'))} L1120,1960 L-40,1960Z`} fill="url(#sandDeep)" stroke={OUT} strokeWidth={6} transform="translate(0 22)" />
        <CableSVG d={cableDeep} w={32} flow={300} />
        {/* ikan lentera */}
        <g transform={`translate(${300 + Math.sin(t * 0.9) * 60} 1180)`}>
          <circle cx={70} cy={-70} r={70} fill="url(#glowYellow)" />
          <Fish x={0} y={0} s={0.9} color="#6a6ff0" />
          <path d="M20,-34 Q60,-90 74,-72" fill="none" stroke={OUT} strokeWidth={5} />
          <circle cx={74} cy={-72} r={12} fill="#ffe27a" stroke={OUT} strokeWidth={4} />
        </g>
        <Fish x={800 - Math.sin(t * 0.7) * 50} y={1020} s={0.6} flip color="#ff9a4a" />
        {/* ubur-ubur */}
        <g transform={`translate(880 ${760 + Math.sin(t * 1.4) * 24})`}>
          <path d="M-60,0 A60,56 0 0 1 60,0Z" fill="#f09ad0" stroke={OUT} strokeWidth={6} />
          {[-36, -12, 12, 36].map((dx, i) => (
            <path key={i} d={`M${dx},0 q-10,30 ${dx > 0 ? 8 : -8},60 t-6,50`} fill="none" stroke="#f09ad0" strokeWidth={7} strokeLinecap="round" />
          ))}
        </g>
        {/* panah kedalaman */}
        <g opacity={eo(t, tL, 0.4)}>
          {[0, 1, 2].map((i) => (
            <path key={i} d={`M80,${420 + i * 90 + ((t * 80) % 90)} l22,26 l22,-26`} fill="none" stroke="#fff" strokeOpacity={0.55 - i * 0.12} strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
          ))}
        </g>
      </S>
      <Pill x={540} y={330} text="LAUT DALAM" at={tL} color="#8ff0ff" size={72} until={tC} />
      <Pill x={540} y={330} text="CUKUP DILETAKKAN" at={tC} color="#ffb84d" size={60} />
    </>
  );
};

/* 14 ─ stasiun pendaratan kabel (76.91 – 83.81) */
const SceneLanding = () => {
  const t = useT();
  const lt = useLT();
  const tSt = W('stasiun');
  const tJar = W('jaringan', 0);
  const tDar = W('menyambung');
  const tPer = W('perangkat');
  const d1 = 'M60,1800 C200,1700 300,1620 360,1470 L380,1340';
  const d2 = 'M520,1290 L700,1270 L900,1180 L900,700';
  const draw1 = eo(t, W('Ujung'), 1.4);
  const draw2 = eo(t, tDar, 1.2);
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#8fd6f5 0%,#d6f1fb 38%)'}} />
      <Cam z0={1.0} z1={1.04} dur={6.9}>
        <S>
          {/* kota */}
          {[[680, 150, '#6a6ff0'], [770, 230, '#e38b3d'], [850, 120, '#4a7bb5'], [940, 190, '#7a6ae0'], [1020, 260, '#3ddc84']].map(([x, h, c], i) => (
            <g key={i}>
              <rect x={(x as number) - 40} y={1130 - (h as number)} width={80} height={h as number} fill={c as string} stroke={OUT} strokeWidth={6} />
              {Array.from({length: Math.floor((h as number) / 50)}).map((_, k) => (
                <rect key={k} x={(x as number) - 22} y={1130 - (h as number) + 16 + k * 44} width={18} height={20} fill="#ffe27a" opacity={0.9} />
              ))}
            </g>
          ))}
          <rect x={0} y={1130} width={WIDTH} height={330} fill="#6fae5a" stroke={OUT} strokeWidth={6} />
          {/* menara */}
          <g>
            <path d="M870,1180 L900,640 L930,1180" fill="none" stroke={OUT} strokeWidth={14} strokeLinejoin="round" strokeLinecap="round" />
            <path d="M870,1180 L900,640 L930,1180" fill="none" stroke="#d9dce8" strokeWidth={7} strokeLinejoin="round" strokeLinecap="round" />
            {[900, 800, 1000].map((y, i) => (
              <line key={i} x1={900 - (1180 - y) * 0.055} y1={y} x2={900 + (1180 - y) * 0.055} y2={y} stroke="#d9dce8" strokeWidth={6} />
            ))}
            <circle cx={900} cy={640} r={14} fill="#ff5a5a" stroke={OUT} strokeWidth={4} />
          </g>
          {/* pantai + laut */}
          <path d={`M0,1450 Q300,1400 560,1470 T1080,1440 L1080,1920 L0,1920Z`} fill="url(#sandGrad)" stroke={OUT} strokeWidth={6} />
          <path d={`M0,1560 ${waveLine(1560, 10, 160, t * 2.2, 0, 1080).slice(waveLine(1560, 10, 160, t * 2.2, 0, 1080).indexOf('L'))} L1080,1920 L0,1920Z`} fill="url(#seaGrad)" opacity={0.95} />
          <path d={waveLine(1560, 10, 160, t * 2.2, 0, 1080)} fill="none" stroke="#bff0ff" strokeWidth={6} />
          {/* kabel */}
          <CableSVG d={d1} w={26} flow={260} draw={draw1} />
          <CableSVG d={d2} w={14} color="#6a6ff0" flow={420} flowColor="#ffe27a" draw={draw2} />
          {[[620, 1274], [790, 1240]].map(([x, y], i) => (
            <g key={i} opacity={draw2 > 0.2 + i * 0.3 ? 1 : 0}>
              <line x1={x} y1={y} x2={x} y2={y + 70} stroke={OUT} strokeWidth={10} strokeLinecap="round" />
              <line x1={x - 26} y1={y + 12} x2={x + 26} y2={y + 12} stroke={OUT} strokeWidth={8} strokeLinecap="round" />
            </g>
          ))}
          {/* stasiun */}
          {t >= tSt && (
            <g transform={`translate(380 1340) scale(${pop(t, tSt, 0.45)})`}>
              <rect x={-150} y={-190} width={300} height={190} fill="#f4f0e6" stroke={OUT} strokeWidth={8} />
              <path d="M-176,-186 L0,-270 L176,-186Z" fill="#c94b3b" stroke={OUT} strokeWidth={8} strokeLinejoin="round" />
              <rect x={-40} y={-100} width={80} height={100} rx={8} fill="#2b2e44" stroke={OUT} strokeWidth={6} />
              {[-100, 100].map((x) => (
                <rect key={x} x={x - 22} y={-150} width={44} height={44} rx={5} fill="#7ccfff" stroke={OUT} strokeWidth={5} />
              ))}
              <circle cx={0} cy={-300} r={24} fill="#aab2c8" stroke={OUT} strokeWidth={6} />
              <line x1={0} y1={-276} x2={0} y2={-262} stroke={OUT} strokeWidth={8} />
            </g>
          )}
          {t >= tSt && <Ring x={380} y={1240} t0={tSt} max={220} color="#ffd45a" />}
          {/* perangkat */}
          {t >= tPer && (
            <g>
              <line x1={900} y1={640} x2={520} y2={420} stroke="#ffe27a" strokeWidth={8} strokeDasharray="12 16" strokeDashoffset={-t * 120} strokeLinecap="round" />
              <g transform={`translate(500 420) scale(${pop(t, tPer, 0.45)})`}>
                <Phone x={0} y={0} w={190} h={330} rot={-8} screen="#25347a">
                  <Chat x={0} y={-6} s={0.5} />
                </Phone>
              </g>
              <Ring x={500} y={420} t0={tPer + 0.1} max={200} color="#8ff0ff" />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={380} y={1010} text="STASIUN PENDARATAN" sub="CABLE LANDING STATION" at={tSt + 0.1} color="#ffb84d" size={42} />
      <Pill x={640} y={1470} text="JARINGAN DARAT" at={tJar} color="#8ff0ff" size={46} until={tPer - 0.1} />
      <Pill x={500} y={620} text="PERANGKAT KITA" at={tPer + 0.15} color="#6fe6a0" size={50} />
    </>
  );
};

/* 15 ─ kabel putus, jalur alternatif, perbaikan (83.81 – 93.25) */
const CityNode: React.FC<{x: number; y: number; label: string; color: string; at?: number}> = ({x, y, label, color, at = 0}) => {
  const t = useT();
  const p = pop(t, at, 0.5);
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      <circle r={96} fill="url(#glowWhite)" opacity={0.18} />
      <circle r={66} fill={color} stroke={OUT} strokeWidth={8} />
      <rect x={-36} y={-12} width={20} height={40} fill="#fff" stroke={OUT} strokeWidth={4} />
      <rect x={-8} y={-34} width={24} height={62} fill="#fff" stroke={OUT} strokeWidth={4} />
      <rect x={20} y={0} width={16} height={28} fill="#fff" stroke={OUT} strokeWidth={4} />
      <text x={0} y={118} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={36} fill="#fff" stroke={OUT} strokeWidth={9} paintOrder="stroke" letterSpacing={1}>
        {label}
      </text>
    </g>
  );
};

const SceneBreak = () => {
  const t = useT();
  const Y = 1400;
  const tCut = W('terputus');
  const tBukan = W('bukan', 0);
  const tKarena = W('karena', 2);
  const tJalur = W('jalur');
  const tShip = W('kapal', 2);
  const tRep = W('memperbaikinya');
  const open = t < tCut ? 0 : t < tRep ? eo(t, tCut, 0.25) : 1 - eo(t, tRep + 0.2, 0.6);
  const gap = 55 * open;
  const ok = open < 0.02;
  const dAlt = 'M200,1400 L200,1000 L880,1000 L880,1400';
  const altDraw = eo(t, tJalur - 0.1, 1.0);
  const shipX = lerp(1300, 540, easeOut(prog(t, tShip, 1.1)));
  return (
    <>
      <NavyBG />
      <Cam z0={1.0} z1={1.02} dur={9.4} shakes={[{a: tCut, d: 0.5, amp: 14}]}>
        <S>
          <rect x={150} y={900} width={780} height={600} rx={50} fill="#1668b0" opacity={0.35} />
          {/* jalur alternatif */}
          <CableSVG d={dAlt} w={14} color="#2a5a4a" draw={altDraw} flow={t >= tJalur ? 360 : undefined} flowColor="#6fe6a0" dash="18 80" />
          {/* kabel utama */}
          <CableSVG d={`M200,${Y} L${540 - gap},${Y}`} w={30} flow={ok ? 380 : undefined} />
          <CableSVG d={`M${540 + gap},${Y} L880,${Y}`} w={30} flow={ok ? 380 : undefined} />
          {open > 0.3 && (
            <g>
              <circle cx={540} cy={Y} r={80} fill="url(#glowRed)" opacity={0.6 + 0.4 * Math.sin(t * 14)} />
              <Cross x={540} y={Y - 90} s={0.9} />
            </g>
          )}
          <Sparks x={540} y={Y} t0={tCut} n={34} speed={480} life={1.0} g={500} color="#ffd45a" size={8} seed="cut" />
          <CityNode x={200} y={Y} label="INDONESIA" color="#e0524b" at={0.1} />
          <CityNode x={880} y={Y} label="AMERIKA" color="#3a7ee0" at={0.1} />
          {/* kapal perbaikan */}
          {t >= tShip && (
            <g>
              <Ship x={shipX} y={1250 + Math.sin(t * 2.2) * 6} s={0.5} t={t} spool={false} />
              {t >= tRep && (
                <g transform={`translate(540 1130) scale(${pop(t, tRep, 0.45)})`}>
                  <circle r={56} fill="#ffd45a" stroke={OUT} strokeWidth={7} />
                  <path d="M-18,22 L10,-6 M-6,-26 a22,22 0 1 1 28,28 l-8,-8 l-16,-16z" fill="none" stroke={OUT} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
                </g>
              )}
            </g>
          )}
          {t >= tRep + 0.7 && <Check x={540} y={1530} s={pop(t, tRep + 0.7, 0.45)} />}
          {t >= tRep && <Sparks x={540} y={Y} t0={tRep + 0.5} n={22} speed={320} life={0.9} g={300} color="#8ff0ff" size={8} seed="fix" />}
        </S>
      </Cam>
      <Pill x={540} y={640} text="KABEL PUTUS!" at={tCut} until={tBukan} color="#ff6a5a" size={72} />
      <Pill x={540} y={640} text="INTERNET" sub="TIDAK LANGSUNG MATI" at={tBukan} until={tKarena} color="#6fe6a0" size={64} />
      <Pill x={540} y={640} text="JALUR ALTERNATIF" at={tKarena} until={tShip - 0.1} color="#6fe6a0" size={60} />
      <Pill x={540} y={640} text="KAPAL KHUSUS" sub="MEMPERBAIKI KABEL" at={tShip} color="#ffb84d" size={60} />
    </>
  );
};

/* 16 ─ sejarah: telegraf 1866 (93.25 – 102.68) */
const SceneHistory = () => {
  const t = useT();
  const t0 = W('Teknologi');
  const tSejak = W('Sejak');
  const tYear = W('tahun');
  const tKab = W('kabel', 11);
  const tTel = W('telegraf');
  const tEro = W('Eropa');
  const tAm = W('Amerika', 1);
  const cableD = 'M340,1170 C470,1310 640,1030 760,1170';
  const cd = eo(t, W('transatlantik') - 0.2, 1.8);
  const clockO = 1 - prog(t, tSejak - 0.1, 0.3);
  const yearP = pop(t, tYear + 0.1, 0.5);
  const ul = eo(t, tYear + 0.55, 0.6);
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#4a2e1d 0%,#2e1a10 100%)'}} />
      <S>
        {Array.from({length: 8}).map((_, i) => (
          <line key={i} x1={0} y1={i * 260} x2={WIDTH} y2={i * 260} stroke="#1c0f08" strokeWidth={6} opacity={0.6} />
        ))}
        <g transform="rotate(-1.5 540 970)">
          <rect x={96} y={256} width={900} height={1470} rx={14} fill="#00000066" transform="translate(14 18)" />
          <rect x={90} y={240} width={900} height={1470} rx={14} fill="#f3e9cf" stroke={OUT} strokeWidth={7} />
          {Array.from({length: 22}).map((_, i) => (
            <line key={i} x1={96} y1={330 + i * 62} x2={984} y2={330 + i * 62} stroke="#b7c7d6" strokeWidth={3} opacity={0.65} />
          ))}
          <line x1={190} y1={246} x2={190} y2={1704} stroke="#d8736a" strokeWidth={4} opacity={0.7} />
          {/* jam mundur */}
          {clockO > 0 && (
            <g transform="translate(540 560)" opacity={clockO}>
              <circle r={170} fill="#fffaf0" stroke={OUT} strokeWidth={10} />
              {Array.from({length: 12}).map((_, i) => (
                <line key={i} x1={0} y1={-146} x2={0} y2={-128} stroke={OUT} strokeWidth={7} strokeLinecap="round" transform={`rotate(${i * 30})`} />
              ))}
              <line x1={0} y1={0} x2={0} y2={-120} stroke={OUT} strokeWidth={9} strokeLinecap="round" transform={`rotate(${-(t - t0) * 260})`} />
              <line x1={0} y1={0} x2={0} y2={-78} stroke="#a3261c" strokeWidth={11} strokeLinecap="round" transform={`rotate(${-(t - t0) * 40})`} />
              <circle r={12} fill={OUT} />
            </g>
          )}
          {/* tahun */}
          {t >= tYear && (
            <g transform={`translate(540 600) scale(${yearP})`}>
              <text x={0} y={0} textAnchor="middle" fontFamily={HAND} fontWeight={700} fontSize={300} fill="#a3261c" stroke={OUT} strokeWidth={10} paintOrder="stroke">
                1866
              </text>
              <path d="M-300,40 C-150,70 120,10 300,52" fill="none" stroke="#a3261c" strokeWidth={14} strokeLinecap="round" pathLength={1} strokeDasharray={`${ul} 2`} />
            </g>
          )}
          {/* peta Atlantik */}
          {t >= tKab - 0.6 && (
            <g opacity={eo(t, tKab - 0.6, 0.5)}>
              <rect x={130} y={860} width={820} height={620} rx={18} fill="#cde7ea" stroke={OUT} strokeWidth={6} />
              {[0, 1, 2, 3].map((i) => (
                <path key={i} d={waveLine(930 + i * 150, 7, 90, t * 1.5 + i, 150, 930)} fill="none" stroke="#8bbfc6" strokeWidth={4} opacity={0.8} />
              ))}
              <path d="M130,860 L330,860 C360,960 300,1040 340,1130 C380,1220 320,1330 350,1480 L130,1480Z" fill="#e6cf9a" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
              <path d="M950,860 L760,860 C730,950 790,1040 750,1140 C720,1230 780,1330 760,1480 L950,1480Z" fill="#e6cf9a" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
              {/* kabel + kode morse */}
              <path d={cableD} fill="none" stroke={OUT} strokeWidth={18} strokeLinecap="round" pathLength={1} strokeDasharray={`${cd} 2`} />
              <path d={cableD} fill="none" stroke="#7a4a2a" strokeWidth={10} strokeLinecap="round" pathLength={1} strokeDasharray={`${cd} 2`} />
              {cd >= 1 && <path d={cableD} fill="none" stroke="#ffe27a" strokeWidth={8} strokeLinecap="round" strokeDasharray="8 34" strokeDashoffset={-t * 120} />}
              {[[320, 1120], [780, 1120]].map(([x, y], i) => (
                <g key={i} transform={`translate(${x} ${y})`}>
                  <rect x={-34} y={-56} width={68} height={56} fill="#f4f0e6" stroke={OUT} strokeWidth={5} />
                  <path d="M-44,-54 L0,-92 L44,-54Z" fill="#c94b3b" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
                  <line x1={0} y1={-92} x2={0} y2={-130} stroke={OUT} strokeWidth={5} />
                </g>
              ))}
            </g>
          )}
        </g>
      </S>
      <Pill x={540} y={1000} text="BUKAN HAL BARU" at={t0 + 0.9} until={tSejak} color="#a3261c" size={62} bg="rgba(243,233,207,0.95)" />
      <Note x={730} y={820} text="telegraf" at={tTel} size={64} color="#7a3b1e" rot={-5} until={tEro + 0.4} />
      <Note x={820} y={1560} text="EROPA" at={tEro} size={78} color="#3a2416" rot={-3} />
      <Note x={250} y={1560} text="AMERIKA UTARA" at={tAm} size={70} color="#3a2416" rot={3} />
    </>
  );
};

/* 17 ─ penutup: fondasi di bawah laut (102.68 – akhir) */
const SceneOutro = () => {
  const t = useT();
  const lt = useLT();
  const tF = W('fondasi');
  const tB = W('bawah', 2);
  const tL = W('laut', 4);
  const SEA = 620;
  const cams = easeInOut(prog(t, tB - 0.8, 1.4));
  const links: Array<[string, number]> = [
    ['M-40,900 C200,1000 420,780 660,900 S1000,1000 1120,860', 0],
    ['M-40,1200 C260,1100 480,1340 740,1200 S1000,1160 1120,1260', 1],
    ['M-40,1500 C220,1560 520,1400 780,1520 S1000,1560 1120,1480', 2],
  ];
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#ffb06a 0%,#ffd9a0 24%)'}} />
      <Cam z0={1} z1={1} dur={7} y0={0} y1={0}>
        <div style={{position: 'absolute', inset: 0, transform: `translateY(${-90 * cams}px)`}}>
          <S>
            {/* kota di atas */}
            {[[120, 200, '#6a6ff0'], [250, 300, '#e38b3d'], [380, 170, '#4a7bb5'], [700, 240, '#7a6ae0'], [830, 330, '#3ddc84'], [960, 190, '#e0524b']].map(([x, h, c], i) => (
              <g key={i}>
                <rect x={(x as number) - 44} y={SEA - (h as number)} width={88} height={h as number} fill={c as string} stroke={OUT} strokeWidth={6} />
                {Array.from({length: Math.floor((h as number) / 54)}).map((_, k) => (
                  <rect key={k} x={(x as number) - 24} y={SEA - (h as number) + 18 + k * 48} width={20} height={22} fill="#ffe27a" opacity={0.9} />
                ))}
              </g>
            ))}
            <WifiArcs x={540} y={SEA - 110} s={1.6} t={t} color="#fff" />
            {/* laut */}
            <rect x={0} y={SEA} width={WIDTH} height={HEIGHT - SEA + 100} fill="url(#deepGrad)" />
            <path d={waveLine(SEA, 10, 180, t * 2.2)} fill="none" stroke="#bff0ff" strokeWidth={7} />
            {[160, 540, 900].map((x, i) => (
              <path key={i} d={`M${x},${SEA} L${x + 100},${SEA} L${x + 240},1700 L${x - 120},1700Z`} fill="url(#beam)" opacity={0.28} />
            ))}
            {links.map(([d, k], i) => (
              <CableSVG key={i} d={d} w={26} flow={300 + k * 40} draw={eo(t, 102.9 + k * 0.5, 1.6)} flowColor={k === 1 ? '#ffe27a' : '#8ff0ff'} />
            ))}
            <Fish x={240 + Math.sin(t * 0.7) * 50} y={780} s={0.6} />
            <Fish x={860 - Math.sin(t * 0.6) * 60} y={1700} s={0.7} flip color="#ffd45a" />
            <rect x={0} y={1760} width={WIDTH} height={300} fill="url(#sandDeep)" stroke={OUT} strokeWidth={6} />
          </S>
        </div>
      </Cam>
      <div
        style={{
          position: 'absolute',
          top: 110,
          left: 0,
          right: 0,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          opacity: eo(t, tF, 0.5) * (1 - cams),
          transform: `translateY(${(1 - eo(t, tF, 0.5)) * -30}px)`,
          textShadow: '0 6px 18px rgba(60,20,0,0.6)',
          WebkitTextStroke: '10px rgba(42,26,44,0.85)',
          paintOrder: 'stroke fill',
        }}
      >
        <div style={{fontSize: 70, letterSpacing: 6}}>FONDASI UTAMA</div>
        <div style={{fontSize: 96}}>DUNIA DIGITAL</div>
      </div>
      <Pill x={540} y={1130} text="DI BAWAH PERMUKAAN LAUT" at={tB + 0.2} color="#8ff0ff" size={50} />
      {lt > 0 && t >= tL && <Pill x={540} y={1760} text="🌊" at={tL} color="#8ff0ff" size={70} />}
    </>
  );
};

/* ═══════════════════════════ SFX ═══════════════════════════
 * [waktu (detik), nama file di public/sfx, volume 0..1]
 * Cukup edit / hapus baris untuk mengatur efek suara.
 */
const SFX_VOL = 1; // pengali volume semua efek
const SFX: Array<[number, string, number]> = [
  [W('video'), 'pop', 0.35],
  [W('game'), 'pop', 0.35],
  [W('pesan'), 'pop', 0.35],
  [W('internet', 0), 'zap', 0.3],
  [5.55, 'whoosh', 0.3],
  [W('berpindah'), 'zap', 0.3],
  [W('Indonesia'), 'pop', 0.35],
  [W('Amerika', 0), 'pop', 0.35],
  [WE('hanya'), 'ding', 0.3],
  [12.35, 'whoosh', 0.28],
  [W('satelit', 0) + 0.55, 'error', 0.3],
  [16.05, 'whoosh', 0.3],
  [W('99') - 0.1, 'riser', 0.28],
  [WE('persen') - 0.05, 'ding', 0.32],
  [W('kabel', 0), 'pop', 0.3],
  [23.35, 'whoosh', 0.25],
  [W('tulang'), 'thud', 0.4],
  [30.15, 'whoosh', 0.28],
  [W('serat', 0), 'pop', 0.35],
  [W('sinyal', 0), 'zap', 0.3],
  [W('dikirim', 1), 'blips', 0.28],
  [W('kembali'), 'blips', 0.28],
  [W('tujuan'), 'chime', 0.3],
  [W('pemantulan'), 'ding', 0.28],
  [W('repeater'), 'pop', 0.35],
  [W('repeater') + 0.28, 'pop', 0.3],
  [W('repeater') + 0.56, 'pop', 0.3],
  [W('listriknya'), 'zap', 0.32],
  [62.1, 'whoosh', 0.28],
  [W('kapal', 0), 'horn', 0.3],
  [W('laut', 1) - 0.05, 'splash', 0.28],
  [W('ditanam'), 'thud', 0.35],
  [W('jangkar') + 0.65, 'thud', 0.4],
  [W('jangkar') + 0.9, 'chime', 0.28],
  [W('laut', 3), 'sonar', 0.32],
  [76.8, 'whoosh', 0.28],
  [W('stasiun'), 'pop', 0.35],
  [W('perangkat'), 'ding', 0.3],
  [W('terputus'), 'spark', 0.45],
  [W('terputus') + 0.1, 'error', 0.25],
  [W('jalur'), 'blips', 0.28],
  [W('kapal', 2), 'horn', 0.25],
  [W('memperbaikinya') + 0.7, 'chime', 0.32],
  [93.1, 'whoosh', 0.28],
  [W('Sejak'), 'tick', 0.4],
  [W('tahun') + 0.1, 'thud', 0.35],
  [W('telegraf'), 'morse', 0.3],
  [102.55, 'whoosh', 0.3],
  [W('fondasi'), 'ding', 0.3],
  [W('bawah', 2), 'sonar', 0.25],
];

/* ═══════════════════════════ ROOT ═══════════════════════════ */
export const Kabel: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const endFade = interpolate(t, [TOTAL_SECONDS - 0.6, TOTAL_SECONDS], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <TCtx.Provider value={t}>
      <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
        {/* ───── visual ───── */}
        <Scene a={0} b={W('Tapi')} fade={0}><SceneHook /></Scene>
        <Scene a={W('Tapi')} b={W('Banyak')}><SceneRoute /></Scene>
        <Scene a={W('Banyak')} b={W('Kenyataannya')}><SceneSat /></Scene>
        <Scene a={W('Kenyataannya')} b={W('Satelit', 1)}><ScenePersen /></Scene>
        <Scene a={W('Satelit', 1)} b={W('Di', 1)}><SceneBackbone /></Scene>
        <Scene a={W('Di', 1)} b={W('Data', 2)}><SceneCross /></Scene>
        <Scene a={W('Data', 2)} b={W('Cahaya', 1)}><SceneLight /></Scene>
        <Scene a={W('Cahaya', 1)} b={W('Selama')}><SceneTIR /></Scene>
        <Scene a={W('Selama')} b={W('Karena', 1)}><SceneAtten /></Scene>
        <Scene a={W('Karena', 1)} b={W('Kabel', 4)}><SceneRepeater /></Scene>
        <Scene a={W('Kabel', 4)} b={W('Di', 5)}><SceneShip /></Scene>
        <Scene a={W('Di', 5)} b={W('sedangkan')}><SceneShallow /></Scene>
        <Scene a={W('sedangkan')} b={W('Ujung')}><SceneDeep /></Scene>
        <Scene a={W('Ujung')} b={W('Jika')}><SceneLanding /></Scene>
        <Scene a={W('Jika')} b={W('Teknologi')}><SceneBreak /></Scene>
        <Scene a={W('Teknologi')} b={W('Jadi')}><SceneHistory /></Scene>
        <Scene a={W('Jadi')} b={TOTAL_SECONDS + 1} fade={0.25}><SceneOutro /></Scene>
        <Vignette />
        <Caption />
        <AbsoluteFill style={{background: '#000', opacity: endFade, pointerEvents: 'none'}} />

        {/* ───── audio: narasi ───── */}
        <Audio src={staticFile('narration.mp3')} />

        {/* ───── audio: efek suara ───── */}
        {SFX.map(([at, name, vol], i) => (
          <Sequence key={i} from={Math.max(0, Math.round(at * FPS))} durationInFrames={Math.round(2.6 * FPS)}>
            <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol * SFX_VOL} />
          </Sequence>
        ))}
      </AbsoluteFill>
    </TCtx.Provider>
  );
};

export default Kabel;
