/**
 * SemestaKita – "Bagaimana Internet Bisa Menghubungkan Seluruh Dunia?"
 * 1080x1920 (9:16) · 60 fps · 109,7 detik (6582 frame)
 * Audio: public/audio.mp3 (voiceover + sedikit efek suara)
 * Semua waktu di file ini dalam DETIK pada audio.
 */
import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;

const FPS = 60;
const WIDTH = 1080;
const HEIGHT = 1920;
const TOTAL_SECONDS = 109.7;

const OUT = '#2a1a2c';
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;

/* ───────────────── timestamp kata [kata, mulai, selesai] ───────────────── */


/* ───────────── timestamp kata [kata, mulai, selesai] ───────────── */
const WORDS: Array<[string, number, number]> = [
  ["Hampir", 0.00, 0.45],
  ["setiap", 0.45, 0.89],
  ["hari", 0.89, 1.23],
  ["kita", 1.23, 1.56],
  ["menonton", 1.56, 2.12],
  ["video,", 2.12, 2.51],
  ["bermain", 2.69, 3.16],
  ["game,", 3.16, 3.48],
  ["dan", 3.63, 3.82],
  ["mengirim", 3.82, 4.21],
  ["pesan", 4.21, 4.48],
  ["lewat", 4.48, 4.75],
  ["internet.", 4.75, 5.13],
  ["Tapi", 5.67, 5.98],
  ["pernahkah", 5.98, 6.54],
  ["terpikir", 6.54, 7.05],
  ["bagaimana", 7.05, 7.62],
  ["data", 7.62, 7.92],
  ["bisa", 7.92, 8.23],
  ["berpindah", 8.23, 8.80],
  ["dari", 8.80, 9.10],
  ["Indonesia", 9.10, 9.67],
  ["ke", 9.67, 9.87],
  ["Amerika", 9.87, 10.33],
  ["hanya", 10.33, 10.69],
  ["dalam", 10.69, 11.05],
  ["hitungan", 11.05, 11.56],
  ["detik?", 11.56, 11.92],
  ["Banyak", 12.45, 12.83],
  ["orang", 12.83, 13.17],
  ["mengira", 13.17, 13.61],
  ["internet", 13.61, 14.09],
  ["dunia", 14.09, 14.43],
  ["dikirim", 14.43, 14.87],
  ["lewat", 14.87, 15.21],
  ["satelit.", 15.21, 15.64],
  ["Kenyataannya,", 16.20, 16.92],
  ["lebih", 17.27, 17.61],
  ["dari", 17.61, 17.91],
  ["99", 17.91, 19.14],
  ["persen", 19.14, 19.54],
  ["lalu", 19.54, 19.83],
  ["lintas", 19.83, 20.23],
  ["data", 20.23, 20.52],
  ["internasional", 20.52, 21.26],
  ["dibawa", 21.26, 21.65],
  ["oleh", 21.65, 21.95],
  ["kabel", 21.95, 22.29],
  ["bawah", 22.29, 22.64],
  ["laut.", 22.64, 22.93],
  ["Satelit", 23.46, 24.00],
  ["tetap", 24.00, 24.42],
  ["penting", 24.42, 24.96],
  ["untuk", 24.96, 25.38],
  ["wilayah", 25.38, 25.92],
  ["terpencil,", 25.92, 26.57],
  ["tapi", 26.75, 27.02],
  ["kabel", 27.02, 27.33],
  ["di", 27.33, 27.50],
  ["dasar", 27.50, 27.81],
  ["lautan", 27.81, 28.17],
  ["adalah", 28.17, 28.52],
  ["tulang", 28.52, 28.87],
  ["punggung", 28.87, 29.31],
  ["utamanya.", 29.31, 29.75],
  ["Di", 30.27, 30.49],
  ["dalam", 30.49, 30.86],
  ["kabel", 30.86, 31.24],
  ["terdapat", 31.24, 31.77],
  ["serat", 31.77, 32.15],
  ["kaca", 32.15, 32.47],
  ["yang", 32.47, 32.79],
  ["sangat", 32.79, 33.22],
  ["tipis.", 33.22, 33.60],
  ["Data", 33.90, 34.24],
  ["digital", 34.24, 34.74],
  ["diubah", 34.74, 35.19],
  ["menjadi", 35.19, 35.70],
  ["sinyal", 35.70, 36.14],
  ["cahaya,", 36.14, 36.59],
  ["dikirim", 36.88, 37.27],
  ["melalui", 37.27, 37.66],
  ["serat", 37.66, 37.96],
  ["tersebut,", 37.96, 38.40],
  ["lalu", 38.81, 39.10],
  ["diterjemahkan", 39.10, 39.84],
  ["kembali", 39.84, 40.28],
  ["menjadi", 40.28, 40.72],
  ["data", 40.72, 41.02],
  ["di", 41.02, 41.21],
  ["tujuan.", 41.21, 41.60],
  ["Cahaya", 42.10, 42.49],
  ["bisa", 42.49, 42.79],
  ["merambat", 42.79, 43.28],
  ["di", 43.28, 43.48],
  ["dalam", 43.48, 43.82],
  ["serat", 43.82, 44.16],
  ["karena", 44.16, 44.56],
  ["prinsip", 44.56, 45.00],
  ["yang", 45.00, 45.29],
  ["disebut", 45.29, 45.74],
  ["pemantulan", 45.74, 46.33],
  ["internal", 46.33, 46.82],
  ["total.", 46.82, 47.16],
  ["Selama", 47.62, 48.05],
  ["menempuh", 48.05, 48.58],
  ["ribuan", 48.58, 49.01],
  ["kilometer,", 49.01, 49.60],
  ["kekuatan", 49.84, 50.35],
  ["sinyal", 50.35, 50.76],
  ["perlahan", 50.76, 51.27],
  ["berkurang.", 51.27, 51.83],
  ["Karena", 52.20, 52.60],
  ["itu", 52.60, 52.85],
  ["dipasang", 52.85, 53.35],
  ["repeater", 53.35, 53.85],
  ["atau", 53.85, 54.15],
  ["penguat", 54.15, 54.60],
  ["optik,", 54.60, 54.95],
  ["dengan", 55.07, 55.51],
  ["jarak", 55.51, 55.90],
  ["puluhan", 55.90, 56.40],
  ["hingga", 56.40, 56.85],
  ["sekitar", 56.85, 57.35],
  ["seratus", 57.35, 57.85],
  ["kilometer,", 57.85, 58.46],
  ["dan", 58.74, 58.97],
  ["listriknya", 58.97, 59.53],
  ["dialirkan", 59.53, 60.05],
  ["lewat", 60.05, 60.37],
  ["konduktor", 60.37, 60.88],
  ["di", 60.88, 61.07],
  ["dalam", 61.07, 61.40],
  ["kabel.", 61.40, 61.72],
  ["Kabel", 62.23, 62.56],
  ["dipasang", 62.56, 63.04],
  ["oleh", 63.04, 63.33],
  ["kapal", 63.33, 63.67],
  ["khusus", 63.67, 64.05],
  ["yang", 64.05, 64.34],
  ["membawa", 64.34, 64.77],
  ["gulungan", 64.77, 65.25],
  ["kabel.", 65.25, 65.59],
  ["Di", 66.05, 66.23],
  ["laut", 66.23, 66.52],
  ["dangkal,", 66.52, 66.94],
  ["kabel", 67.18, 67.53],
  ["ditanam", 67.53, 67.98],
  ["di", 67.98, 68.19],
  ["bawah", 68.19, 68.54],
  ["dasar", 68.54, 68.89],
  ["laut", 68.89, 69.19],
  ["agar", 69.19, 69.50],
  ["terhindar", 69.50, 70.05],
  ["dari", 70.05, 70.36],
  ["jangkar", 70.36, 70.81],
  ["kapal", 70.81, 71.16],
  ["dan", 71.16, 71.42],
  ["aktivitas", 71.42, 71.97],
  ["penangkapan", 71.97, 72.63],
  ["ikan,", 72.63, 72.93],
  ["sedangkan", 73.31, 73.84],
  ["di", 73.84, 74.04],
  ["laut", 74.04, 74.33],
  ["dalam", 74.33, 74.67],
  ["kabel", 74.67, 75.02],
  ["cukup", 75.02, 75.36],
  ["diletakkan", 75.36, 75.95],
  ["di", 75.95, 76.14],
  ["dasar.", 76.14, 76.48],
  ["Ujung", 76.92, 77.26],
  ["kabel", 77.26, 77.60],
  ["terhubung", 77.60, 78.14],
  ["ke", 78.14, 78.34],
  ["stasiun", 78.34, 78.78],
  ["pendaratan", 78.78, 79.36],
  ["kabel,", 79.36, 79.71],
  ["lalu", 80.00, 80.27],
  ["menyambung", 80.27, 80.80],
  ["ke", 80.80, 80.97],
  ["jaringan", 80.97, 81.42],
  ["darat", 81.42, 81.73],
  ["hingga", 81.73, 82.08],
  ["sampai", 82.08, 82.43],
  ["ke", 82.43, 82.61],
  ["perangkat", 82.61, 83.09],
  ["kita.", 83.09, 83.36],
  ["Jika", 83.82, 84.15],
  ["kabel", 84.15, 84.54],
  ["terputus,", 84.54, 85.10],
  ["bukan", 85.26, 85.58],
  ["berarti", 85.58, 85.99],
  ["internet", 85.99, 86.44],
  ["langsung", 86.44, 86.89],
  ["mati,", 86.89, 87.16],
  ["karena", 87.56, 88.17],
  ["banyak", 88.17, 88.78],
  ["jaringan", 88.78, 89.54],
  ["punya", 89.54, 90.08],
  ["jalur", 90.08, 90.61],
  ["alternatif,", 90.61, 91.52],
  ["dan", 91.66, 91.79],
  ["kapal", 91.79, 91.97],
  ["khusus", 91.97, 92.17],
  ["akan", 92.17, 92.32],
  ["memperbaikinya.", 92.32, 92.72],
  ["Teknologi", 93.25, 93.74],
  ["ini", 93.74, 93.96],
  ["bukan", 93.96, 94.27],
  ["hal", 94.27, 94.49],
  ["baru.", 94.49, 94.76],
  ["Sejak", 95.22, 95.55],
  ["tahun", 95.55, 95.87],
  ["1866,", 95.87, 97.64],
  ["kabel", 97.92, 98.29],
  ["telegraf", 98.29, 98.82],
  ["transatlantik", 98.82, 99.61],
  ["sudah", 99.61, 99.98],
  ["menghubungkan", 99.98, 100.77],
  ["Eropa", 100.77, 101.14],
  ["dan", 101.14, 101.41],
  ["Amerika", 101.41, 101.88],
  ["Utara.", 101.88, 102.25],
  ["Jadi,", 102.71, 103.13],
  ["salah", 103.29, 103.68],
  ["satu", 103.68, 104.02],
  ["fondasi", 104.02, 104.53],
  ["utama", 104.53, 104.92],
  ["dunia", 104.92, 105.32],
  ["digital", 105.32, 105.83],
  ["modern", 105.83, 106.28],
  ["justru", 106.28, 106.73],
  ["berada", 106.73, 107.18],
  ["jauh", 107.18, 107.52],
  ["di", 107.52, 107.74],
  ["bawah", 107.74, 108.14],
  ["permukaan", 108.14, 108.76],
  ["laut.", 108.76, 109.09],
];

/* ───────────────────────── util ───────────────────────── */
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const easeIn = Easing.in(Easing.cubic);
const easeInOut = Easing.inOut(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9áéíóúñ-]/g, '');
/** waktu mulai kata ke-`nth` yang cocok dengan `text` */
const W = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, s] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return s;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};

/* ───────────────────────── konteks waktu ───────────────────────── */
const TCtx = createContext(0); // detik-audio absolut
const LCtx = createContext(0); // detik sejak scene mulai
const useT = () => useContext(TCtx);
const useLT = () => useContext(LCtx);

const Scene: React.FC<{a: number; b: number; fade?: number; children?: React.ReactNode}> = ({
  a,
  b,
  fade = 0.2,
  children,
}) => {
  const t = useT();
  if (t < a || t >= b + fade + 0.05) return null;
  const lt = t - a;
  return (
    <LCtx.Provider value={lt}>
      <AbsoluteFill style={{opacity: fade > 0 ? clamp(lt / fade) : 1, overflow: 'hidden'}}>
        {children}
      </AbsoluteFill>
    </LCtx.Provider>
  );
};

type Shake = {a: number; d: number; amp: number};
const Cam: React.FC<{
  z0?: number;
  z1?: number;
  dur?: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  r0?: number;
  r1?: number;
  shakes?: Shake[];
  children?: React.ReactNode;
}> = ({z0 = 1, z1 = 1, dur = 5, x0 = 0, x1 = 0, y0 = 0, y1 = 0, r0 = 0, r1 = 0, shakes = [], children}) => {
  const lt = useLT();
  const t = useT();
  const p = easeInOut(prog(lt, 0, dur));
  let sx = 0;
  let sy = 0;
  for (const s of shakes) {
    const q = prog(t, s.a, s.d);
    if (q > 0 && q < 1) {
      const k = (1 - q) * s.amp;
      sx += Math.sin(t * 93) * k;
      sy += Math.cos(t * 71) * k;
    }
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${lerp(x0, x1, p) + sx}px,${lerp(y0, y1, p) + sy}px) scale(${lerp(z0, z1, p)}) rotate(${lerp(r0, r1, p)}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── SVG dasar ───────────────────────── */
const Defs = () => (
  <defs>
    <radialGradient id="glowOrange">
      <stop offset="0" stopColor="#fff1b0" stopOpacity="0.95" />
      <stop offset="0.35" stopColor="#ff9a2e" stopOpacity="0.65" />
      <stop offset="1" stopColor="#ff5a1f" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowWhite">
      <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowBlue">
      <stop offset="0.72" stopColor="#7ccfff" stopOpacity="0.6" />
      <stop offset="1" stopColor="#7ccfff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowCyan">
      <stop offset="0" stopColor="#c8fbff" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#3dd6e8" stopOpacity="0.6" />
      <stop offset="1" stopColor="#3dd6e8" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowYellow">
      <stop offset="0" stopColor="#fff6c0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ffd45a" stopOpacity="0.6" />
      <stop offset="1" stopColor="#ffd45a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowGreen">
      <stop offset="0" stopColor="#7dffb0" stopOpacity="0.9" />
      <stop offset="1" stopColor="#7dffb0" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="earthShade" cx="0.35" cy="0.3" r="0.9">
      <stop offset="0.5" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#000" stopOpacity="0.5" />
    </radialGradient>
    <linearGradient id="flameGrad" x1="1" y1="0" x2="0" y2="0">
      <stop offset="0" stopColor="#fff6c0" />
      <stop offset="0.3" stopColor="#ffb02e" />
      <stop offset="1" stopColor="#ff4b1f" stopOpacity="0" />
    </linearGradient>
    <pattern id="hatch" width="16" height="16" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
      <rect width="16" height="16" fill="#2f4380" />
      <line x1="0" y1="0" x2="0" y2="16" stroke="#1d2a58" strokeWidth="7" />
    </pattern>
  </defs>
);

const S: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    width={WIDTH}
    height={HEIGHT}
    style={{position: 'absolute', left: 0, top: 0}}
  >
    <Defs />
    {children}
  </svg>
);

/* ───────────────────────── background ───────────────────────── */
const Stars: React.FC<{n?: number}> = ({n = 80}) => {
  const t = useT();
  return (
    <S>
      {Array.from({length: n}).map((_, i) => {
        const x = random(`sx${i}`) * WIDTH;
        const y = (random(`sy${i}`) * HEIGHT + t * (4 + random(`sv${i}`) * 8)) % HEIGHT;
        const r = 1.5 + random(`sr${i}`) * 3.2;
        const o = 0.45 + 0.55 * Math.abs(Math.sin(t * (0.8 + random(`sf${i}`) * 2) + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#fff" opacity={o} />;
      })}
    </S>
  );
};

const SpaceBG: React.FC<{tone?: 'blue' | 'purple' | 'black'}> = ({tone = 'blue'}) => {
  const g =
    tone === 'blue'
      ? 'radial-gradient(120% 80% at 50% 30%, #1f2570 0%, #0d123f 55%, #04061a 100%)'
      : tone === 'purple'
      ? 'radial-gradient(120% 80% at 50% 30%, #3a1d6b 0%, #1a0f40 55%, #07041a 100%)'
      : 'radial-gradient(120% 80% at 50% 30%, #101440 0%, #050722 60%, #02030e 100%)';
  return (
    <>
      <AbsoluteFill style={{background: g}} />
      <Stars />
    </>
  );
};

const SkyBG = () => (
  <AbsoluteFill
    style={{background: 'linear-gradient(180deg,#05071a 0%,#0f1f5c 42%,#2a6fc4 72%,#8fcdf5 100%)'}}
  />
);

const Vignette = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
    }}
  />
);


/* ───────────────────────── objek ───────────────────────── */
const Person: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  shirt?: string;
  pants?: string;
  hair?: string;
  hat?: boolean;
  coat?: boolean;
  glasses?: boolean;
  armL?: number;
  armR?: number;
  mouth?: 'smile' | 'o' | 'flat';
  look?: number;
}> = ({
  x,
  y,
  s = 1,
  flip = false,
  shirt = '#4a7bb5',
  pants = '#2b2f55',
  hair = '#4a2f22',
  hat = false,
  coat = false,
  glasses = false,
  armL = 15,
  armR = 15,
  mouth = 'smile',
  look = 0,
}) => {
  const arm = (ang: number, side: number) => {
    const sx = side * 36;
    const sy = -172;
    const a = (ang * side * Math.PI) / 180;
    const L = 88;
    const ex = sx + Math.sin(a) * L;
    const ey = sy + Math.cos(a) * L;
    const col = coat ? '#fff' : shirt;
    return (
      <g>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={OUT} strokeWidth={31} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={col} strokeWidth={20} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={13} fill="#f7efe4" stroke={OUT} strokeWidth={4} />
      </g>
    );
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={60} ry={10} fill="#000" opacity={0.2} />
      <rect x={-29} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <rect x={6} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <ellipse cx={-20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      <ellipse cx={20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      {arm(armL, -1)}
      <rect x={-42} y={-195} width={84} height={112} rx={28} fill={coat ? '#fff' : shirt} stroke={OUT} strokeWidth={6} />
      {coat && (
        <>
          <path d="M-14,-193 L0,-140 L14,-193" fill="none" stroke={OUT} strokeWidth={4} />
          <line x1={0} y1={-140} x2={0} y2={-86} stroke={OUT} strokeWidth={3} />
        </>
      )}
      {arm(armR, 1)}
      <circle cx={look * 5} cy={-248} r={50} fill="#f7efe4" stroke={OUT} strokeWidth={6} />
      {hair && !hat && (
        <path
          d={`M${-50 + look * 5},-252 A50,50 0 0 1 ${50 + look * 5},-252 Q${look * 5},-292 ${-50 + look * 5},-252Z`}
          fill={hair}
          stroke={OUT}
          strokeWidth={4}
        />
      )}
      {hat && (
        <g transform={`translate(${look * 5} 0)`}>
          <ellipse cx={0} cy={-286} rx={66} ry={11} fill="#1d1b2b" stroke={OUT} strokeWidth={4} />
          <path d="M-40,-286 Q-40,-336 0,-336 Q40,-336 40,-286Z" fill="#1d1b2b" stroke={OUT} strokeWidth={4} />
        </g>
      )}
      <circle cx={-17 + look * 6} cy={-250} r={6} fill={OUT} />
      <circle cx={17 + look * 6} cy={-250} r={6} fill={OUT} />
      {glasses && (
        <g fill="none" stroke={OUT} strokeWidth={4}>
          <circle cx={-17 + look * 6} cy={-250} r={14} />
          <circle cx={17 + look * 6} cy={-250} r={14} />
          <line x1={-3 + look * 6} y1={-250} x2={3 + look * 6} y2={-250} />
        </g>
      )}
      {mouth === 'smile' && (
        <path d={`M${-14 + look * 5},-226 Q${look * 5},-212 ${14 + look * 5},-226`} fill="none" stroke={OUT} strokeWidth={4} strokeLinecap="round" />
      )}
      {mouth === 'o' && <ellipse cx={look * 5} cy={-222} rx={8} ry={10} fill={OUT} />}
      {mouth === 'flat' && (
        <line x1={-12 + look * 5} y1={-222} x2={12 + look * 5} y2={-222} stroke={OUT} strokeWidth={4} strokeLinecap="round" />
      )}
    </g>
  );
};


/* ───────────────────────── efek ───────────────────────── */
const Sparks: React.FC<{
  x: number;
  y: number;
  t0: number;
  n?: number;
  speed?: number;
  life?: number;
  g?: number;
  color?: string;
  size?: number;
  seed?: string;
}> = ({x, y, t0, n = 30, speed = 500, life = 1.2, g = 600, color = '#ffc85a', size = 7, seed = 'sp'}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0 || age > life) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const v = (0.3 + random(`${seed}v${i}`) * 0.7) * speed;
        const px = x + Math.cos(a) * v * age;
        const py = y + Math.sin(a) * v * age + 0.5 * g * age * age;
        const o = 1 - age / life;
        return <circle key={i} cx={px} cy={py} r={size * (0.5 + random(`${seed}r${i}`)) * o} fill={color} opacity={o} />;
      })}
    </g>
  );
};

/* ───────────────────────── UI: label, caption ───────────────────────── */
const Pill: React.FC<{
  x: number;
  y: number;
  text: string;
  at: number;
  color?: string;
  size?: number;
  rot?: number;
  sub?: string;
  until?: number;
}> = ({x, y, text, at, color = '#ffb84d', size = 54, rot = 0, sub, until}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const p = pop(t, at, 0.4);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`,
        background: 'rgba(18,12,30,0.85)',
        border: `5px solid ${color}`,
        color: '#fff',
        padding: sub ? '12px 38px' : '14px 36px',
        borderRadius: sub ? 44 : 999,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: 2,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {text}
      {sub && <div style={{fontSize: size * 0.52, fontWeight: 600, opacity: 0.85, letterSpacing: 1}}>{sub}</div>}
    </div>
  );
};

const Caption: React.FC = () => {
  const t = useT();
  let idx = -1;
  for (let i = 0; i < WORDS.length; i++) {
    if (WORDS[i][1] <= t) idx = i;
    else break;
  }
  if (idx < 0) return null;
  const [w, s, e] = WORDS[idx];
  if (t > e + 0.28) return null;
  const sc = 0.82 + 0.18 * backOut(prog(t, s, 0.16));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '46%',
        textAlign: 'center',
        transform: `translateY(-50%) scale(${sc})`,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 92,
        color: '#fff',
        letterSpacing: -1,
        WebkitTextStroke: '12px rgba(22,12,34,0.9)',
        paintOrder: 'stroke fill',
        textShadow: '0 6px 14px rgba(0,0,0,0.55)',
        padding: '0 40px',
      }}
    >
      {w}
    </div>
  );
};

/* ═══════════════════════════ HELPER KHUSUS KABEL ═══════════════════════════ */
const mixc = (a: string, b: string, k: number) => {
  const h = (s: string) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16));
  const A = h(a);
  const B = h(b);
  return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], k))).join(',')})`;
};
type P2 = number[];
const bez = (p: P2[], u: number): P2 => {
  const m = 1 - u;
  return [
    m * m * m * p[0][0] + 3 * m * m * u * p[1][0] + 3 * m * u * u * p[2][0] + u * u * u * p[3][0],
    m * m * m * p[0][1] + 3 * m * m * u * p[1][1] + 3 * m * u * u * p[2][1] + u * u * u * p[3][1],
  ];
};
const bezD = (p: P2[]) => `M${p[0][0]},${p[0][1]} C${p[1][0]},${p[1][1]} ${p[2][0]},${p[2][1]} ${p[3][0]},${p[3][1]}`;
/** waktu kata a yang diikuti kata b */
const WP = (a: string, b: string): number => {
  const na = norm(a);
  const nb = norm(b);
  for (let i = 0; i < WORDS.length - 1; i++) {
    if (norm(WORDS[i][0]) === na && norm(WORDS[i + 1][0]) === nb) return WORDS[i][1];
  }
  throw new Error('pasangan kata tidak ditemukan: ' + a + ' ' + b);
};

const CableLine: React.FC<{d: string; w?: number; color?: string}> = ({d, w = 26, color = '#34425e'}) => (
  <g fill="none" strokeLinecap="round" strokeLinejoin="round">
    <path d={d} stroke={OUT} strokeWidth={w + 10} />
    <path d={d} stroke={color} strokeWidth={w} />
    <path d={d} stroke="#6b7fa6" strokeWidth={w * 0.22} opacity={0.75} transform={`translate(0 ${-w * 0.2})`} />
  </g>
);

const Glow: React.FC<{x: number; y: number; r?: number; o?: number; c?: 'cyan' | 'yellow' | 'orange' | 'green'}> = ({
  x,
  y,
  r = 40,
  o = 1,
  c = 'cyan',
}) => {
  const id = c === 'cyan' ? 'glowCyan' : c === 'yellow' ? 'glowYellow' : c === 'green' ? 'glowGreen' : 'glowOrange';
  return (
    <g opacity={o}>
      <circle cx={x} cy={y} r={r * 3} fill={`url(#${id})`} />
      <circle cx={x} cy={y} r={r * 0.55} fill="#fff" />
    </g>
  );
};

const OceanBG: React.FC<{depth?: number}> = ({depth = 0.4}) => {
  const t = useT();
  return (
    <>
      <AbsoluteFill
        style={{
          background: `linear-gradient(180deg, ${mixc('#2f9ad8', '#0b2f58', depth)} 0%, ${mixc('#14608f', '#061a33', depth)} 100%)`,
        }}
      />
      <S>
        {[0, 1, 2, 3].map((i) => (
          <polygon
            key={i}
            points={`${160 + i * 250},0 ${260 + i * 250},0 ${120 + i * 250 + Math.sin(t * 0.4 + i) * 40},1400`}
            fill="#fff"
            opacity={0.055 * (1 - depth)}
          />
        ))}
        {Array.from({length: 24}).map((_, i) => {
          const x = random(`bx${i}`) * 1080;
          const sp = 40 + random(`bs${i}`) * 70;
          const y = ((((random(`by${i}`) * 2200 - t * sp) % 2200) + 2200) % 2200) - 150;
          return <circle key={i} cx={x + Math.sin(t + i) * 10} cy={y} r={4 + random(`br${i}`) * 9} fill="none" stroke="#bfe9ff" strokeWidth={2.5} opacity={0.3} />;
        })}
      </S>
    </>
  );
};

const Seabed: React.FC<{y: number; color?: string; dark?: string}> = ({y, color = '#d2b06e', dark = '#a8864c'}) => (
  <>
    <path d={`M0,${y} C220,${y - 40} 420,${y + 30} 640,${y - 20} C840,${y - 60} 980,${y} 1080,${y - 25} L1080,1920 L0,1920Z`} fill={color} stroke={OUT} strokeWidth={6} />
    <path d={`M0,${y + 120} C300,${y + 80} 700,${y + 150} 1080,${y + 100} L1080,1920 L0,1920Z`} fill={dark} opacity={0.7} />
  </>
);

const Fish: React.FC<{x: number; y: number; s?: number; color?: string; flip?: boolean}> = ({x, y, s = 1, color = '#ffb347', flip = false}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
    <path d="M-50,0 Q-10,-34 40,0 Q-10,34 -50,0Z" fill={color} stroke={OUT} strokeWidth={5} />
    <path d="M38,0 L72,-26 L72,26Z" fill={color} stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
    <circle cx={-26} cy={-6} r={5} fill={OUT} />
  </g>
);

const Phone: React.FC<{x: number; y: number; s?: number; rot?: number; screen?: string; children?: React.ReactNode}> = ({
  x,
  y,
  s = 1,
  rot = 0,
  screen = '#2d6fd0',
  children,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-70} y={-130} width={140} height={260} rx={26} fill="#1d1b2b" stroke={OUT} strokeWidth={6} />
    <rect x={-58} y={-112} width={116} height={224} rx={14} fill={screen} />
    {children}
  </g>
);

const Satellite: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {[-1, 1].map((sd) => (
      <g key={sd} transform={`translate(${sd * 112} 0)`}>
        <rect x={-62} y={-32} width={124} height={64} fill="#2b4a9a" stroke={OUT} strokeWidth={5} />
        {[-31, 0, 31].map((gx) => (
          <line key={gx} x1={gx} y1={-32} x2={gx} y2={32} stroke="#8fb0ff" strokeWidth={3} />
        ))}
        <line x1={-62} y1={0} x2={62} y2={0} stroke="#8fb0ff" strokeWidth={3} />
      </g>
    ))}
    <rect x={-48} y={-52} width={96} height={104} rx={14} fill="#d7b25a" stroke={OUT} strokeWidth={6} />
    <rect x={-30} y={-30} width={60} height={30} rx={6} fill="#f3e3a8" stroke={OUT} strokeWidth={4} />
    <path d="M-30,-52 Q0,-110 30,-52Z" fill="#e8ecf5" stroke={OUT} strokeWidth={5} />
    <line x1={0} y1={-84} x2={0} y2={-120} stroke={OUT} strokeWidth={5} />
    <circle cx={0} cy={-124} r={8} fill="#ff4a3a" stroke={OUT} strokeWidth={3} />
  </g>
);

const Ship: React.FC<{x: number; y: number; s?: number; t: number; reel?: boolean}> = ({x, y, s = 1, t, reel = true}) => (
  <g transform={`translate(${x} ${y + Math.sin(t * 1.6) * 8}) rotate(${Math.sin(t * 1.2) * 1.2}) scale(${s})`}>
    <path d="M-270,0 L270,0 L215,84 L-215,84Z" fill="#c2402e" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
    <rect x={-250} y={-6} width={500} height={22} fill="#f2ede2" stroke={OUT} strokeWidth={4} />
    <rect x={-20} y={-120} width={220} height={120} fill="#f2ede2" stroke={OUT} strokeWidth={6} />
    {[0, 1, 2].map((i) => (
      <rect key={i} x={0 + i * 62} y={-96} width={40} height={36} rx={6} fill="#6db8e8" stroke={OUT} strokeWidth={4} />
    ))}
    <rect x={110} y={-190} width={54} height={72} fill="#2b4a8a" stroke={OUT} strokeWidth={6} />
    <rect x={110} y={-170} width={54} height={14} fill="#ffd45a" />
    <path d="M200,0 L230,-170 L250,0" fill="none" stroke={OUT} strokeWidth={10} strokeLinejoin="round" />
    <line x1={230} y1={-170} x2={280} y2={-60} stroke={OUT} strokeWidth={6} />
    {reel && (
      <g transform="translate(-130 -80)">
        <circle r={86} fill="#d9b36b" stroke={OUT} strokeWidth={7} />
        <g transform={`rotate(${t * 80})`}>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <line key={i} x1={0} y1={0} x2={0} y2={-78} stroke={OUT} strokeWidth={6} transform={`rotate(${i * 60})`} />
          ))}
        </g>
        <circle r={62} fill="none" stroke="#34425e" strokeWidth={22} />
        <circle r={16} fill="#8a6a30" stroke={OUT} strokeWidth={5} />
      </g>
    )}
  </g>
);

const SunsetBG: React.FC = () => (
  <AbsoluteFill style={{background: 'linear-gradient(180deg,#3a1c4a 0%,#8a2f55 26%,#f0603a 52%,#ffb347 68%)'}} />
);

/* ═══════════════════════════ SCENES ═══════════════════════════ */

/* 1 ─ sehari-hari (0 – 5.5) */
const SceneDaily = () => {
  const t = useT();
  const items = [
    {at: W('video'), x: 230, y: 520, kind: 'play'},
    {at: W('game'), x: 540, y: 380, kind: 'pad'},
    {at: W('pesan'), x: 850, y: 540, kind: 'chat'},
  ];
  const icon = (k: string) => {
    if (k === 'play')
      return (
        <g>
          <rect x={-58} y={-42} width={116} height={84} rx={20} fill="#e5402f" stroke={OUT} strokeWidth={6} />
          <polygon points="-16,-24 -16,24 28,0" fill="#fff" />
        </g>
      );
    if (k === 'pad')
      return (
        <g>
          <path d="M-62,-6 Q-66,40 -30,40 Q-12,40 -4,20 L4,20 Q12,40 30,40 Q66,40 62,-6 Q58,-36 20,-36 L-20,-36 Q-58,-36 -62,-6Z" fill="#6a5ae0" stroke={OUT} strokeWidth={6} />
          <rect x={-42} y={-12} width={30} height={9} fill="#fff" />
          <rect x={-32} y={-22} width={9} height={30} fill="#fff" />
          <circle cx={30} cy={-12} r={7} fill="#ffd45a" />
          <circle cx={46} cy={4} r={7} fill="#ff6a5a" />
        </g>
      );
    return (
      <g>
        <path d="M-60,-40 H60 Q72,-40 72,-28 V20 Q72,32 60,32 H10 L-26,62 V32 H-60 Q-72,32 -72,20 V-28 Q-72,-40 -60,-40Z" fill="#3dd68c" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
        {[-32, 0, 32].map((dx) => (
          <circle key={dx} cx={dx} cy={-4} r={8} fill="#fff" />
        ))}
      </g>
    );
  };
  const tI = W('internet');
  return (
    <>
      <SunsetBG />
      <Cam z0={1.05} z1={1} dur={5.5}>
        <S>
          <path d="M0,1500 C250,1450 520,1510 780,1470 C920,1450 1020,1470 1080,1460 L1080,1920 L0,1920Z" fill="#4a2342" stroke={OUT} strokeWidth={6} />
          <path d="M0,1640 L1080,1600 L1080,1920 L0,1920Z" fill="#35192f" />
          {items.map((it, i) => {
            const p = pop(t, it.at, 0.5);
            if (t < it.at) return null;
            return (
              <g key={i} transform={`translate(${it.x} ${it.y + Math.sin(t * 2 + i) * 10}) scale(${p * 1.3})`}>
                <circle r={96} fill="#fff" opacity={0.15} />
                {icon(it.kind)}
              </g>
            );
          })}
          <Person x={540} y={1600} s={2.2} shirt="#3a86d0" armR={95} armL={20} look={0} />
          <g transform="translate(700 1040) rotate(-10)">
            <rect x={-34} y={-58} width={68} height={116} rx={12} fill="#1d1b2b" stroke={OUT} strokeWidth={5} />
            <rect x={-27} y={-48} width={54} height={96} rx={7} fill="#6db8e8" />
          </g>
          {t >= tI && (
            <g transform={`translate(700 930) scale(${pop(t, tI, 0.4) * 1.4})`} fill="none" stroke="#fff" strokeWidth={9} strokeLinecap="round">
              <path d="M-50,-8 Q0,-52 50,-8" />
              <path d="M-30,14 Q0,-8 30,14" />
              <circle cy={38} r={6} fill="#fff" />
            </g>
          )}
        </S>
      </Cam>
    </>
  );
};

/* 2 ─ Indonesia → Amerika dalam hitungan detik (5.5 – 12.2) */
const SceneMap = () => {
  const t = useT();
  const path = [[250, 1290], [200, 720], [640, 380], [760, 700]];
  const t0 = W('berpindah');
  const t1 = W('detik') + 0.2;
  const u = easeInOut(prog(t, t0, t1 - t0));
  const arrived = t > t1;
  const secs = Math.min(9, Math.round(prog(t, t0, t1 - t0) * 9));
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #1a5a8a 0%, #0d3358 70%, #071c38 100%)'}} />
      <Cam z0={1.08} z1={1} dur={6.7}>
        <S>
          {Array.from({length: 8}).map((_, i) => (
            <line key={i} x1={0} y1={260 + i * 200} x2={1080} y2={260 + i * 200} stroke="#7cc7ff" strokeOpacity={0.1} strokeWidth={3} />
          ))}
          <path d="M-20,520 C100,470 250,520 300,620 C330,700 250,790 150,810 C60,830 -20,790 -20,720Z" fill="#4aa070" stroke={OUT} strokeWidth={6} />
          <path d="M560,430 C640,370 780,370 900,440 C1000,500 1050,610 990,710 C930,800 850,810 800,890 C770,940 710,910 700,850 C680,770 610,730 590,650 C570,570 520,490 560,430Z" fill="#4aa070" stroke={OUT} strokeWidth={6} />
          {[[170, 1290, 50, 26], [260, 1330, 70, 28], [370, 1280, 54, 24], [450, 1340, 44, 22], [110, 1370, 44, 22]].map((c, i) => (
            <ellipse key={i} cx={c[0]} cy={c[1]} rx={c[2]} ry={c[3]} fill="#4aa070" stroke={OUT} strokeWidth={5} />
          ))}
          <path d={bezD(path)} fill="none" stroke="#fff" strokeOpacity={0.4} strokeWidth={5} strokeDasharray="4 18" strokeLinecap="round" />
          {t >= t0 && !arrived && (
            <>
              {Array.from({length: 8}).map((_, i) => {
                const q = clamp(u - i * 0.018);
                const [x, y] = bez(path, q);
                return <circle key={i} cx={x} cy={y} r={18 - i * 1.6} fill="url(#glowCyan)" opacity={1 - i / 9} />;
              })}
              <Glow x={bez(path, u)[0]} y={bez(path, u)[1]} r={16} />
            </>
          )}
          {arrived && <Glow x={760} y={700} r={26 * (1 + Math.sin((t - t1) * 8) * 0.15)} o={clamp(1 - (t - t1) / 1.6)} />}
          <circle cx={250} cy={1290} r={18} fill="#ff4a3a" stroke={OUT} strokeWidth={5} />
          <circle cx={760} cy={700} r={18} fill="#ffd45a" stroke={OUT} strokeWidth={5} />
        </S>
      </Cam>
      <Pill x={270} y={1470} text="INDONESIA" at={W('Indonesia')} color="#ff6a5a" size={52} />
      <Pill x={770} y={300} text="AMERIKA" at={W('Amerika', 0)} color="#ffd45a" size={52} />
      {t >= W('hitungan') && (
        <div
          style={{
            position: 'absolute',
            left: 540,
            top: 1200,
            transform: `translate(-50%,-50%) scale(${pop(t, W('hitungan'), 0.4)})`,
            background: 'rgba(18,12,30,0.85)',
            border: '5px solid #3dd6e8',
            borderRadius: 40,
            padding: '8px 40px',
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 84,
            color: '#fff',
            textAlign: 'center',
          }}
        >
          0{secs}
          <span style={{fontSize: 42, color: '#3dd6e8', marginLeft: 10}}>detik</span>
        </div>
      )}
    </>
  );
};

/* 3 ─ satelit? (12.2 – 16.2) */
const SceneSat = () => {
  const t = useT();
  const lt = useLT();
  const tS = W('satelit');
  const sx = 540 + Math.sin(lt * 0.8) * 60;
  return (
    <>
      <SpaceBG />
      <Cam z0={1.1} z1={1} dur={4}>
        <S>
          <circle cx={540} cy={2350} r={1100} fill="#2f7fd6" stroke={OUT} strokeWidth={10} />
          <circle cx={540} cy={2350} r={1160} fill="url(#glowBlue)" />
          {[0, 1, 2].map((i) => {
            const p = ((lt * 0.7 + i / 3) % 1);
            return <circle key={i} cx={sx} cy={560} r={80 + p * 520} fill="none" stroke="#7ccfff" strokeWidth={6} strokeOpacity={(1 - p) * 0.6} strokeDasharray="30 22" />;
          })}
          <Satellite x={sx} y={560} s={1.7} rot={Math.sin(lt) * 6} />
        </S>
      </Cam>
      <Pill x={540} y={1130} text="SATELIT?" at={tS} color="#c7b0ff" size={80} />
    </>
  );
};

/* 4 ─ 99% (16.2 – 23.4) */
const SceneDonut = () => {
  const t = useT();
  const t99 = W('99');
  const R = 260;
  const C = 2 * Math.PI * R;
  const g = easeInOut(prog(t, t99 - 0.3, 1.6));
  const n = Math.round(99 * g);
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 40%, #0f4a60 0%, #082230 70%, #040f18 100%)'}} />
      <Cam z0={1.06} z1={1} dur={7.2}>
        <S>
          <g transform="translate(540 520) rotate(-90)">
            <circle r={R} fill="none" stroke="#3a4a60" strokeWidth={80} />
            <circle r={R} fill="none" stroke={OUT} strokeWidth={96} strokeDasharray={`${C * 0.99 * g} ${C}`} />
            <circle r={R} fill="none" stroke="#3dd6e8" strokeWidth={80} strokeDasharray={`${C * 0.99 * g} ${C}`} />
          </g>
        </S>
      </Cam>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 400,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 210,
          color: '#fff',
          WebkitTextStroke: '10px #1a1020',
          paintOrder: 'stroke fill',
          opacity: prog(t, t99 - 0.3, 0.3),
        }}
      >
        {n}%
      </div>
      <Pill x={540} y={1180} text="KABEL BAWAH LAUT" at={W('kabel', 0)} color="#3dd6e8" size={60} />
      <Pill x={540} y={1330} text="LALU LINTAS DATA INTERNASIONAL" at={W('data', 1)} color="#7dffb0" size={40} />
    </>
  );
};

/* 5 ─ satelit untuk terpencil, kabel tulang punggung (23.4 – 30.2) */
const SceneBackbone = () => {
  const t = useT();
  const lt = useLT();
  const tS = W('tulang');
  const dim = eo(t, 26.7, 0.6);
  const cable = 'M-60,1650 C250,1610 600,1690 1140,1620';
  return (
    <>
      <Cam z0={1} z1={1.05} dur={6.8}>
        <S>
          <rect width={1080} height={620} fill="#9bd6f5" />
          <rect y={620} width={1080} height={900} fill="#2d8fd0" />
          <rect y={620} width={1080} height={900} fill="#0b3b6e" opacity={0.35} />
          <path d="M0,1520 L1080,1520 L1080,1920 L0,1920Z" fill="#d2b06e" stroke={OUT} strokeWidth={6} />
          <path d="M0,620 Q135,590 270,620 T540,620 T810,620 T1080,620 L1080,680 L0,680Z" fill="#7cc7ff" opacity={0.8} />
          <ellipse cx={820} cy={632} rx={180} ry={40} fill="#e7c47d" stroke={OUT} strokeWidth={6} />
          <g transform="translate(850 560)">
            <line x1={0} y1={60} x2={-8} y2={-50} stroke={OUT} strokeWidth={22} strokeLinecap="round" />
            <line x1={0} y1={60} x2={-8} y2={-50} stroke="#8a5a30" strokeWidth={12} strokeLinecap="round" />
            {[-60, -20, 25, 65].map((a, i) => (
              <path key={i} d={`M-8,-50 Q${a * 1.3 - 8},${-110 + Math.abs(a) * 0.3} ${a * 2 - 8},${-40 + Math.abs(a) * 0.6}`} fill="none" stroke={OUT} strokeWidth={16} strokeLinecap="round" />
            ))}
            {[-60, -20, 25, 65].map((a, i) => (
              <path key={i} d={`M-8,-50 Q${a * 1.3 - 8},${-110 + Math.abs(a) * 0.3} ${a * 2 - 8},${-40 + Math.abs(a) * 0.6}`} fill="none" stroke="#3aa05a" strokeWidth={8} strokeLinecap="round" />
            ))}
          </g>
          <Fish x={((((300 - t * 40) % 1400) + 1400) % 1400) - 150} y={900} s={0.8} />
          <Fish x={((((900 + t * 30) % 1400) + 1400) % 1400) - 150} y={1180} s={0.7} color="#7ccfff" flip />
          <Satellite x={250} y={290} s={0.9} rot={-8} />
          <line x1={290} y1={340} x2={800} y2={560} stroke="#fff" strokeWidth={5} strokeDasharray="10 16" opacity={0.7} />
          <Glow x={lerp(290, 800, (lt * 0.5) % 1)} y={lerp(340, 560, (lt * 0.5) % 1)} r={12} />
          <CableLine d={cable} w={44} />
          {Array.from({length: 15}).map((_, i) => {
            const x = 40 + i * 72;
            const on = clamp((t - tS - i * 0.07) / 0.2);
            const y = 1650 - Math.sin((x / 1080) * 3) * 4 + (i % 2 ? 2 : -2);
            return (
              <g key={i} opacity={on}>
                <line x1={x} y1={y - 30} x2={x} y2={y + 30} stroke="#ffd45a" strokeWidth={9} strokeLinecap="round" />
              </g>
            );
          })}
          <rect width={1080} height={1400} fill="#06101f" opacity={dim * 0.55} />
          <CableLine d={cable} w={44} />
          {Array.from({length: 15}).map((_, i) => {
            const x = 40 + i * 72;
            const on = clamp((t - tS - i * 0.07) / 0.2);
            return <line key={i} x1={x} y1={1620} x2={x} y2={1680} stroke="#ffd45a" strokeWidth={9} strokeLinecap="round" opacity={on} />;
          })}
        </S>
      </Cam>
      <Pill x={800} y={330} text="WILAYAH TERPENCIL" at={W('terpencil')} color="#c7b0ff" size={44} />
      <Pill x={540} y={1330} text="TULANG PUNGGUNG" at={tS} color="#ffd45a" size={62} />
    </>
  );
};

/* 6 ─ penampang kabel, serat kaca (30.2 – 33.9) */
const SceneCross = () => {
  const t = useT();
  const lt = useLT();
  const tS = W('serat', 0);
  const layers = [
    {r: 340, c: '#1f2a40', at: 30.3},
    {r: 300, c: '#3a4a6a', at: 30.5},
    {r: 236, c: '#c2cad6', at: 30.7},
    {r: 190, c: '#d78b4a', at: 30.9},
    {r: 130, c: '#7aa6c9', at: 31.1},
  ];
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #0f4a60 0%, #082230 70%, #040f18 100%)'}} />
      <Cam z0={1} z1={1.22} dur={3.7}>
        <S>
          {layers.map((l, i) => {
            const p = pop(t, l.at, 0.4);
            return <circle key={i} cx={540} cy={800} r={l.r * p} fill={l.c} stroke={OUT} strokeWidth={7} />;
          })}
          {t > 30.7 &&
            Array.from({length: 24}).map((_, i) => {
              const a = (i / 24) * Math.PI * 2;
              return <circle key={i} cx={540 + Math.cos(a) * 268} cy={800 + Math.sin(a) * 268} r={20} fill="#e8ecf5" stroke={OUT} strokeWidth={4} />;
            })}
          {t >= tS && (
            <>
              <Glow x={540} y={800} r={22 * (1 + Math.sin(lt * 6) * 0.15)} />
              <circle cx={540} cy={800} r={14} fill="#9ff3ff" stroke={OUT} strokeWidth={4} />
            </>
          )}
        </S>
      </Cam>
      <Pill x={540} y={1330} text="SERAT KACA" sub="sangat tipis" at={tS} color="#3dd6e8" size={66} />
    </>
  );
};

/* 7 ─ data jadi cahaya (33.9 – 42.1) */
const SceneLight = () => {
  const t = useT();
  const lt = useLT();
  const tD = WP('data', 'digital');
  const tL = WP('sinyal', 'cahaya');
  const tT = W('tujuan');
  const fiberTop = 800;
  const fiberBot = 1260;
  const items = Array.from({length: 7}).map((_, i) => {
    const ph = ((lt * 0.35 + i / 7) % 1);
    const y = lerp(560, 1500, ph);
    const zone = y < 780 ? 'bit' : y < fiberBot + 20 ? 'light' : 'bit';
    return {y, zone, bit: (i * 3 + 1) % 2};
  });
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#0b1a3a 0%,#0b2a4a 100%)'}} />
      <Cam z0={1.2} z1={1.14} dur={8.2}>
        <S>
          <Phone x={540} y={430} s={0.9} screen="#2d6fd0" />
          <rect x={470} y={720} width={140} height={90} rx={16} fill="#3a4a6a" stroke={OUT} strokeWidth={6} />
          <rect x={470} y={1250} width={140} height={90} rx={16} fill="#3a4a6a" stroke={OUT} strokeWidth={6} />
          <rect x={518} y={fiberTop} width={44} height={fiberBot - fiberTop + 10} rx={10} fill="#bfefff" opacity={0.25} stroke="#7ccfff" strokeWidth={5} />
          <Phone x={540} y={1610} s={0.9} screen="#2d9d6a" />
          {items.map((it, i) =>
            it.zone === 'light' ? (
              <circle key={i} cx={540} cy={it.y} r={14} fill="#9ff3ff" opacity={t > tL - 0.2 ? 1 : 0}>
              </circle>
            ) : (
              <text key={i} x={540} y={it.y} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={46} fill={it.y < 780 ? '#ffd45a' : '#7dffb0'} opacity={t > tD - 0.2 ? 1 : 0}>
                {it.bit}
              </text>
            ),
          )}
          {items.map((it, i) =>
            it.zone === 'light' && t > tL - 0.2 ? <circle key={`g${i}`} cx={540} cy={it.y} r={40} fill="url(#glowCyan)" /> : null,
          )}
        </S>
      </Cam>
      <Pill x={820} y={430} text="DATA DIGITAL" at={tD} color="#ffd45a" size={46} />
      <Pill x={270} y={1040} text="SINYAL CAHAYA" at={tL} color="#3dd6e8" size={46} />
      <Pill x={830} y={1610} text="TUJUAN" at={tT} color="#7dffb0" size={46} />
    </>
  );
};

/* 8 ─ pemantulan internal total (42.1 – 47.6) */
const SceneTIR = () => {
  const t = useT();
  const lt = useLT();
  const tP = W('pemantulan');
  const pts: P2[] = [];
  for (let i = 0; i <= 7; i++) pts.push([i % 2 ? 665 : 415, 250 + i * 200]);
  const total = 7;
  const q = ((lt * 0.28) % 1) * total;
  const seg = Math.min(6, Math.floor(q));
  const f = q - seg;
  const hx = lerp(pts[seg][0], pts[seg + 1][0], f);
  const hy = lerp(pts[seg][1], pts[seg + 1][1], f);
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#0b1a3a 0%,#0b2a4a 100%)'}} />
      <S>
        <rect x={380} y={150} width={320} height={1560} rx={30} fill="#bfefff" opacity={0.14} stroke="#7ccfff" strokeWidth={8} />
        <rect x={380} y={150} width={320} height={1560} rx={30} fill="none" stroke="#fff" strokeOpacity={0.25} strokeWidth={2} />
        <polyline points={pts.map((p) => p.join(',')).join(' ')} fill="none" stroke="#3dd6e8" strokeWidth={10} strokeLinejoin="round" opacity={0.5} />
        {pts.slice(1, 7).map((p, i) => (
          <g key={i} opacity={t > tP ? 1 : 0.0}>
            <circle cx={p[0]} cy={p[1]} r={14} fill="#fff" />
            <path d={`M${p[0] + (i % 2 ? 40 : -40)},${p[1] - 40} Q${p[0]},${p[1] - 70} ${p[0] + (i % 2 ? -40 : 40)},${p[1] - 40}`} fill="none" stroke="#ffd45a" strokeWidth={6} strokeLinecap="round" />
          </g>
        ))}
        <Glow x={hx} y={hy} r={18} />
      </S>
      <Pill x={540} y={1760} text="PEMANTULAN INTERNAL TOTAL" at={tP} color="#3dd6e8" size={40} />
    </>
  );
};

/* 9 ─ sinyal melemah (47.6 – 52.2) */
const CABLE_LONG: P2[] = [[40, 1380], [330, 1150], [700, 1010], [1040, 640]];
const SceneWeak = () => {
  const t = useT();
  const lt = useLT();
  const tR = W('ribuan');
  const tB = W('berkurang');
  const pulse = (off: number) => {
    const u = ((lt * 0.22 + off) % 1);
    const [x, y] = bez(CABLE_LONG, u);
    const I = 1 - u * 0.92;
    return <Glow key={off} x={x} y={y} r={22 * I + 4} o={I} />;
  };
  return (
    <>
      <OceanBG depth={0.6} />
      <Cam z0={1.08} z1={1} dur={4.6}>
        <S>
          <Seabed y={1700} color="#b8975a" dark="#8d7040" />
          <CableLine d={bezD(CABLE_LONG)} w={34} />
          {pulse(0)}
          {pulse(0.5)}
          <g opacity={prog(t, tR, 0.4)} stroke="#fff" strokeWidth={6} strokeLinecap="round">
            <line x1={40} y1={1540} x2={1040} y2={1540} />
            <line x1={40} y1={1515} x2={40} y2={1565} />
            <line x1={1040} y1={1515} x2={1040} y2={1565} />
          </g>
        </S>
      </Cam>
      <Pill x={540} y={1650} text="RIBUAN KILOMETER" at={tR} color="#ffffff" size={50} />
      <Pill x={540} y={440} text="SINYAL MELEMAH" at={tB - 0.6} color="#ff7a4a" size={56} />
    </>
  );
};

/* 10 ─ repeater (52.2 – 62.2) */
const SceneRepeater = () => {
  const t = useT();
  const lt = useLT();
  const tRep = W('repeater');
  const tHund = W('seratus');
  const tPow = W('listriknya');
  const reps = [1 / 3, 2 / 3];
  const pulse = (off: number) => {
    const u = ((lt * 0.14 + off) % 1);
    const [x, y] = bez(CABLE_LONG, u);
    const frac = (u % (1 / 3)) * 3;
    const I = 1 - frac * 0.78;
    return <Glow key={off} x={x} y={y} r={22 * I + 4} o={I} />;
  };
  const showFlash = (u: number) => {
    const cur = ((lt * 0.14) % 1);
    const d = Math.abs(((cur - u + 1.5) % 1) - 0.5);
    return d < 0.03 ? 1 - d / 0.03 : 0;
  };
  return (
    <>
      <OceanBG depth={0.65} />
      <Cam z0={1} z1={1.06} dur={10}>
        <S>
          <Seabed y={1720} color="#b8975a" dark="#8d7040" />
          <CableLine d={bezD(CABLE_LONG)} w={34} />
          {t >= tPow && (
            <path d={bezD(CABLE_LONG)} fill="none" stroke="#ffd45a" strokeWidth={8} strokeDasharray="26 30" strokeDashoffset={-lt * 120} strokeLinecap="round" opacity={0.9} />
          )}
          {reps.map((u, i) => {
            const [x, y] = bez(CABLE_LONG, u);
            const p = pop(t, tRep + i * 0.3, 0.45);
            return (
              <g key={i} transform={`translate(${x} ${y}) rotate(-28) scale(${p})`}>
                <rect x={-80} y={-44} width={160} height={88} rx={22} fill="#e6b84a" stroke={OUT} strokeWidth={7} />
                <rect x={-50} y={-44} width={14} height={88} fill="#b78a2a" />
                <rect x={36} y={-44} width={14} height={88} fill="#b78a2a" />
                <circle r={10} fill="#3dd68c" stroke={OUT} strokeWidth={3} />
              </g>
            );
          })}
          {reps.map((u, i) => {
            const [x, y] = bez(CABLE_LONG, u);
            const fl = showFlash(u);
            return fl > 0 ? <circle key={i} cx={x} cy={y} r={50 + 90 * (1 - fl)} fill="none" stroke="#9ff3ff" strokeWidth={10} opacity={fl} /> : null;
          })}
          {pulse(0)}
          {pulse(0.34)}
          {pulse(0.67)}
          {t >= tHund && (
            <g opacity={prog(t, tHund, 0.4)} stroke="#fff" strokeWidth={6} strokeLinecap="round">
              <line x1={bez(CABLE_LONG, 1 / 3)[0] + 20} y1={bez(CABLE_LONG, 1 / 3)[1] + 130} x2={bez(CABLE_LONG, 2 / 3)[0] + 20} y2={bez(CABLE_LONG, 2 / 3)[1] + 130} />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={300} y={560} text="REPEATER" sub="penguat optik" at={tRep} color="#ffd45a" size={60} />
      <Pill x={(bez(CABLE_LONG, 1 / 3)[0] + bez(CABLE_LONG, 2 / 3)[0]) / 2 + 20} y={(bez(CABLE_LONG, 1 / 3)[1] + bez(CABLE_LONG, 2 / 3)[1]) / 2 + 200} text="± 100 KM" at={tHund - 0.2} color="#ffffff" size={52} />
      <Pill x={800} y={1560} text="LISTRIK" at={tPow} color="#ffd45a" size={50} />
    </>
  );
};

/* 11 ─ kapal pemasang kabel (62.2 – 66.0) */
const SceneShip = () => {
  const t = useT();
  const tK = W('kapal', 0);
  const tG = W('gulungan');
  return (
    <>
      <Cam z0={1.08} z1={1} dur={3.8}>
        <SunsetBG />
        <S>
          <circle cx={780} cy={900} r={190} fill="url(#glowOrange)" />
          <circle cx={780} cy={900} r={90} fill="#ffe9a8" />
          <rect y={1000} width={1080} height={920} fill="#1d5f9c" />
          {[0, 1, 2].map((i) => (
            <path key={i} d={`M0,${1060 + i * 150} Q135,${1030 + i * 150 + Math.sin(t * 2 + i) * 14} 270,${1060 + i * 150} T540,${1060 + i * 150} T810,${1060 + i * 150} T1080,${1060 + i * 150}`} fill="none" stroke="#7cc7ff" strokeWidth={6} opacity={0.7} />
          ))}
          <path d="M120,1040 C200,1200 320,1280 420,1500 C480,1620 560,1700 620,1800" fill="none" stroke={OUT} strokeWidth={30} strokeLinecap="round" />
          <path d="M120,1040 C200,1200 320,1280 420,1500 C480,1620 560,1700 620,1800" fill="none" stroke="#34425e" strokeWidth={18} strokeLinecap="round" />
          <Ship x={600} y={1000} s={1.35} t={t} />
          <path d="M-5,1080 L1085,1080 L1085,1100 L-5,1100Z" fill="#fff" opacity={0.15} />
        </S>
      </Cam>
      <Pill x={540} y={440} text="KAPAL KHUSUS" at={tK} color="#ffb84d" size={56} />
      <Pill x={300} y={1640} text="GULUNGAN KABEL" at={tG} color="#ffd45a" size={46} />
    </>
  );
};

/* 12 ─ laut dangkal, kabel ditanam (66.0 – 73.3) */
const SceneShallow = () => {
  const t = useT();
  const tDk = W('dangkal');
  const tBury = W('ditanam');
  const tJ = W('jangkar');
  const tF = W('penangkapan');
  const bury = eo(t, tBury, 1.0);
  const anchorP = easeIn(prog(t, tJ - 0.2, 0.9));
  const net = prog(t, tF - 0.3, 1.2);
  return (
    <>
      <Cam z0={1} z1={1.05} dur={7.3}>
        <S>
          <rect width={1080} height={520} fill="#9bd6f5" />
          <rect y={520} width={1080} height={1000} fill="#2d8fd0" />
          <rect y={520} width={1080} height={1000} fill="#0b3b6e" opacity={0.25} />
          <path d="M0,520 Q135,495 270,520 T540,520 T810,520 T1080,520 L1080,570 L0,570Z" fill="#7cc7ff" opacity={0.8} />
          <path d="M0,1250 C300,1230 700,1260 1080,1240 L1080,1920 L0,1920Z" fill="#d2b06e" stroke={OUT} strokeWidth={6} />
          <path d="M0,1450 C300,1430 700,1460 1080,1440 L1080,1920 L0,1920Z" fill="#a8864c" opacity={0.7} />
          <CableLine d="M-40,1330 C300,1320 700,1345 1120,1330" w={34} />
          <path d={`M-40,${1340 - 90 * bury} C300,${1330 - 90 * bury} 700,${1355 - 90 * bury} 1120,${1340 - 90 * bury}`} fill="none" stroke="#d2b06e" strokeWidth={0} />
          <rect x={-10} y={1270 + (1 - bury) * 80} width={1100} height={150 * bury + 1} fill="#d2b06e" opacity={bury} />
          <path d="M-40,1330 C300,1320 700,1345 1120,1330" fill="none" stroke="#fff" strokeWidth={5} strokeDasharray="14 14" opacity={0.7 * bury} />
          <Ship x={250} y={500} s={0.5} t={t} reel={false} />
          {t >= tJ - 0.2 && (
            <g>
              <line x1={170} y1={560} x2={170} y2={lerp(560, 1255, anchorP)} stroke={OUT} strokeWidth={8} strokeDasharray="12 8" />
              <g transform={`translate(170 ${lerp(560, 1255, anchorP)})`}>
                <path d="M0,0 V50 M-40,34 Q0,76 40,34 M-18,18 H18" fill="none" stroke={OUT} strokeWidth={14} strokeLinecap="round" />
                <path d="M0,0 V50 M-40,34 Q0,76 40,34 M-18,18 H18" fill="none" stroke="#b7c0cc" strokeWidth={7} strokeLinecap="round" />
              </g>
            </g>
          )}
          {t >= tF - 0.3 && (
            <g transform={`translate(${lerp(1050, 760, net)} 0)`}>
              <g transform="translate(0 500) scale(0.45)">
                <path d="M-190,0 L190,0 L150,70 L-150,70Z" fill="#2b6fb0" stroke={OUT} strokeWidth={8} />
                <rect x={-40} y={-90} width={110} height={90} fill="#f2ede2" stroke={OUT} strokeWidth={8} />
              </g>
              <line x1={0} y1={540} x2={80} y2={1260} stroke={OUT} strokeWidth={6} />
              <path d="M50,1180 Q120,1280 200,1250 L190,1180Z" fill="none" stroke="#ffd45a" strokeWidth={7} strokeDasharray="8 6" />
            </g>
          )}
          {bury > 0.8 && t > tJ + 1.0 && (
            <g stroke="#7dffb0" strokeWidth={14} strokeLinecap="round" fill="none" transform="translate(540 1200)" opacity={prog(t, tJ + 1.0, 0.3)}>
              <path d="M-40,0 L-10,32 L44,-34" />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={540} y={330} text="LAUT DANGKAL" at={tDk} color="#7cc7ff" size={56} />
      <Pill x={540} y={1560} text="DITANAM DI BAWAH DASAR LAUT" at={tBury} color="#ffd45a" size={40} />
    </>
  );
};

/* 13 ─ laut dalam (73.3 – 76.9) */
const SceneDeep = () => {
  const t = useT();
  return (
    <>
      <OceanBG depth={0.95} />
      <Cam z0={1.06} z1={1} dur={3.6}>
        <S>
          <Seabed y={1560} color="#6d5a3c" dark="#4a3c28" />
          <CableLine d="M-40,1560 C300,1520 700,1590 1120,1540" w={34} />
          {[0, 1, 2].map((i) => (
            <Fish key={i} x={((((i * 400 + 1200 - t * (60 + i * 25)) % 1500) + 1500) % 1500) - 200} y={700 + i * 220} s={0.8 + i * 0.1} color={['#ffb347', '#7ccfff', '#c7b0ff'][i]} />
          ))}
          <g transform={`translate(${900 - (t % 10) * 20} 400)`} opacity={0.9}>
            <path d="M-40,0 Q0,-60 80,0 Q0,60 -40,0Z" fill="#3a4a6a" stroke={OUT} strokeWidth={5} />
            <circle cx={-10} cy={-6} r={5} fill="#9ff3ff" />
          </g>
        </S>
      </Cam>
      <Pill x={540} y={440} text="LAUT DALAM" at={73.4} color="#7ccfff" size={64} sub="diletakkan langsung" />
    </>
  );
};

/* 14 ─ stasiun pendaratan kabel (76.9 – 83.8) */
const SceneLanding = () => {
  const t = useT();
  const tS = W('stasiun');
  const tJ = W('jaringan', 0);
  const tP = W('perangkat');
  const g = eo(t, tJ, 1.2);
  return (
    <>
      <Cam z0={1.05} z1={1} dur={6.9}>
        <SunsetBG />
        <S>
          <rect y={1280} width={1080} height={640} fill="#1d5f9c" />
          <path d="M0,1280 C200,1230 420,1270 560,1180 C700,1100 900,1120 1080,1070 L1080,1480 C800,1450 500,1500 0,1500Z" fill="#e7c47d" stroke={OUT} strokeWidth={6} />
          <path d="M-40,1700 C240,1640 400,1560 560,1450 C640,1390 700,1300 740,1190" fill="none" stroke={OUT} strokeWidth={34} strokeLinecap="round" />
          <path d="M-40,1700 C240,1640 400,1560 560,1450 C640,1390 700,1300 740,1190" fill="none" stroke="#34425e" strokeWidth={22} strokeLinecap="round" />
          <Glow x={lerp(-40, 740, (t * 0.4) % 1)} y={lerp(1700, 1190, (t * 0.4) % 1)} r={14} o={0.9} />
          <g transform="translate(760 1030)">
            <rect x={-130} y={-150} width={260} height={160} fill="#e8e1d2" stroke={OUT} strokeWidth={7} />
            <rect x={-150} y={-190} width={300} height={50} fill="#4b5d82" stroke={OUT} strokeWidth={7} />
            <rect x={-30} y={-80} width={60} height={90} fill="#3a4a6a" stroke={OUT} strokeWidth={5} />
            {[-90, 70].map((wx) => (
              <rect key={wx} x={wx} y={-110} width={36} height={36} fill="#ffd45a" stroke={OUT} strokeWidth={4} />
            ))}
            <line x1={90} y1={-190} x2={90} y2={-290} stroke={OUT} strokeWidth={8} />
            <circle cx={90} cy={-296} r={10} fill="#ff4a3a" stroke={OUT} strokeWidth={4} />
          </g>
          {t >= tJ && (
            <g>
              <path d="M760,860 C760,640 640,560 540,420" fill="none" stroke={OUT} strokeWidth={24} strokeLinecap="round" strokeDasharray={`${700 * g} 900`} />
              <path d="M760,860 C760,640 640,560 540,420" fill="none" stroke="#ffd45a" strokeWidth={12} strokeLinecap="round" strokeDasharray={`${700 * g} 900`} />
              {[[430, 260, 120, 280], [560, 200, 90, 360], [690, 280, 100, 250], [330, 330, 80, 190]].map((b, i) => (
                <rect key={i} x={b[0]} y={b[1] + (1 - g) * 200} width={b[2]} height={b[3] * g + 1} fill="#2c1634" stroke={OUT} strokeWidth={5} />
              ))}
            </g>
          )}
          {t >= tP && (
            <g transform={`translate(240 760) scale(${pop(t, tP, 0.5) * 0.8})`}>
              <Phone x={0} y={0} s={1} screen="#2d9d6a" />
              <path d="M-40,-190 Q0,-230 40,-190 M-24,-170 Q0,-190 24,-170" fill="none" stroke="#fff" strokeWidth={8} strokeLinecap="round" />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={400} y={1480} text="STASIUN PENDARATAN KABEL" at={tS} color="#ffd45a" size={38} />
    </>
  );
};

/* 15a ─ kabel terputus (83.8 – 85.3) */
const SceneCut = () => {
  const t = useT();
  const lt = useLT();
  const tC = W('terputus');
  const cut = t >= tC + 0.25;
  const gap = cut ? 70 * eo(t, tC + 0.25, 0.3) : 0;
  return (
    <>
      <OceanBG depth={0.7} />
      <Cam z0={1.08} z1={1.0} dur={1.5} shakes={[{a: tC + 0.25, d: 0.5, amp: 14}]}>
        <S>
          <Seabed y={1500} color="#8d7040" dark="#6d5430" />
          <g transform={`translate(${-gap} 0)`}>
            <CableLine d="M-40,1450 L520,1450" w={44} />
          </g>
          <g transform={`translate(${gap} 0)`}>
            <CableLine d="M560,1450 L1120,1450" w={44} />
          </g>
          {!cut && <Glow x={lerp(-40, 540, (lt * 0.9) % 1)} y={1450} r={16} />}
          {cut && <Sparks x={540} y={1450} t0={tC + 0.25} n={26} speed={380} life={0.9} g={400} color="#ffe27a" seed="cut" />}
          {cut && <Glow x={540} y={1450} r={30} o={clamp(1 - (t - tC - 0.25) / 0.4)} c="orange" />}
        </S>
      </Cam>
      <Pill x={540} y={440} text="TERPUTUS" at={tC} color="#ff4a3a" size={76} />
    </>
  );
};

/* 15b ─ jalur alternatif (85.3 – 91.7) */
const SceneNetwork = () => {
  const t = useT();
  const lt = useLT();
  const tM = W('mati');
  const tA = W('alternatif');
  const nodes: P2[] = [[200, 560], [540, 440], [880, 600], [300, 1000], [780, 1010], [200, 1450], [560, 1400], [900, 1440]];
  const links = [[0, 1], [1, 2], [0, 3], [1, 4], [2, 4], [3, 5], [3, 6], [4, 6], [4, 7], [2, 7]];
  const broken = (a: number, b: number) => (a === 1 && b === 4);
  const alt = [1, 2, 4];
  const rt = clamp((t - tA) / 1.6);
  const altPts = [nodes[1], nodes[2], nodes[4]];
  const segLen = [Math.hypot(altPts[1][0] - altPts[0][0], altPts[1][1] - altPts[0][1]), Math.hypot(altPts[2][0] - altPts[1][0], altPts[2][1] - altPts[1][1])];
  const total = segLen[0] + segLen[1];
  const d = rt * total;
  const pos: P2 = d < segLen[0]
    ? [lerp(altPts[0][0], altPts[1][0], d / segLen[0]), lerp(altPts[0][1], altPts[1][1], d / segLen[0])]
    : [lerp(altPts[1][0], altPts[2][0], (d - segLen[0]) / segLen[1]), lerp(altPts[1][1], altPts[2][1], (d - segLen[0]) / segLen[1])];
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #14423f 0%, #0a1f27 70%, #050d14 100%)'}} />
      <Cam z0={1.05} z1={1} dur={6.4}>
        <S>
          {links.map(([a, b], i) => {
            const br = broken(a, b);
            return (
              <line key={i} x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} stroke={br ? '#ff4a3a' : '#3dd68c'} strokeOpacity={br ? 0.9 : 0.55} strokeWidth={br ? 7 : 6} strokeDasharray={br ? '16 14' : undefined} />
            );
          })}
          {t >= tA && (
            <>
              <polyline points={altPts.map((p) => p.join(',')).join(' ')} fill="none" stroke="#9ff3ff" strokeWidth={12} strokeLinejoin="round" strokeLinecap="round" opacity={0.85} />
              <Glow x={pos[0]} y={pos[1]} r={18} />
            </>
          )}
          {nodes.map((n, i) => (
            <circle key={i} cx={n[0]} cy={n[1]} r={34} fill={i === 1 || i === 4 ? '#ffd45a' : '#3dd68c'} stroke={OUT} strokeWidth={6} />
          ))}
          <g transform={`translate(${(nodes[1][0] + nodes[4][0]) / 2 + 40} ${(nodes[1][1] + nodes[4][1]) / 2}) scale(${pop(t, 85.4, 0.4)})`} stroke="#ff4a3a" strokeWidth={14} strokeLinecap="round">
            <line x1={-26} y1={-26} x2={26} y2={26} />
            <line x1={26} y1={-26} x2={-26} y2={26} />
          </g>
        </S>
      </Cam>
      <Pill x={540} y={250} text="INTERNET TIDAK LANGSUNG MATI" at={tM - 0.5} color="#7dffb0" size={36} />
      <Pill x={540} y={1650} text="JALUR ALTERNATIF" at={tA} color="#9ff3ff" size={60} />
    </>
  );
};

/* 15c ─ diperbaiki (91.7 – 93.3) */
const SceneRepair = () => {
  const t = useT();
  const tR = W('memperbaikinya');
  return (
    <>
      <Cam z0={1.08} z1={1} dur={1.7}>
        <SunsetBG />
        <S>
          <rect y={1000} width={1080} height={920} fill="#1d5f9c" />
          <path d="M120,1050 L400,1010 L620,1250 L780,1500" fill="none" stroke={OUT} strokeWidth={30} strokeLinecap="round" strokeLinejoin="round" />
          <path d="M120,1050 L400,1010 L620,1250 L780,1500" fill="none" stroke="#34425e" strokeWidth={18} strokeLinecap="round" strokeLinejoin="round" />
          <Ship x={560} y={1000} s={1.25} t={t} />
          <Sparks x={620} y={1250} t0={tR} n={20} speed={200} life={1.0} g={0} color="#ffe27a" seed="rep" size={9} />
        </S>
      </Cam>
      <Pill x={540} y={430} text="DIPERBAIKI" at={tR} color="#7dffb0" size={70} />
    </>
  );
};

/* 16 ─ 1866 (93.3 – 97.9) */
const SceneOld = () => {
  const t = useT();
  const lt = useLT();
  const t66 = W('1866');
  const tap = Math.sin(lt * 14) > 0.3 ? 1 : 0;
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #e7d3a6 0%, #c9ad78 70%, #8d7040 100%)'}} />
      <Cam z0={1.05} z1={1} dur={4.6}>
        <S>
          <g transform="translate(540 540) scale(1)">
            <rect x={-250} y={-230} width={500} height={460} rx={28} fill="#f8f1de" stroke={OUT} strokeWidth={8} />
            <rect x={-250} y={-230} width={500} height={90} rx={28} fill="#8a2f2f" stroke={OUT} strokeWidth={8} />
            <text x={0} y={80} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={180} fill="#3a2a1a" opacity={prog(t, t66 - 0.1, 0.35)}>
              1866
            </text>
          </g>
          <g transform="translate(540 1280)">
            <rect x={-260} y={40} width={520} height={110} rx={20} fill="#6a4a2a" stroke={OUT} strokeWidth={8} />
            <rect x={-170} y={-10} width={340} height={50} rx={8} fill="#b08a4a" stroke={OUT} strokeWidth={6} />
            <g transform={`rotate(${tap ? 5 : -2} 150 -10)`}>
              <rect x={-190} y={-60} width={340} height={26} rx={10} fill="#d9b36b" stroke={OUT} strokeWidth={6} />
              <circle cx={-190} cy={-47} r={28} fill="#3a2a1a" stroke={OUT} strokeWidth={5} />
            </g>
            <circle cx={150} cy={-10} r={12} fill="#d9b36b" stroke={OUT} strokeWidth={4} />
          </g>
          {Array.from({length: 7}).map((_, i) => {
            const p = ((lt * 0.4 + i / 7) % 1);
            const dash = i % 3 === 1;
            return <rect key={i} x={60 + p * 960} y={1120 - Math.sin(p * Math.PI) * 120} width={dash ? 56 : 18} height={18} rx={9} fill="#3a2a1a" opacity={Math.sin(p * Math.PI)} />;
          })}
        </S>
      </Cam>
      <Pill x={540} y={1650} text="BUKAN HAL BARU" at={93.3} color="#3a2a1a" size={52} />
    </>
  );
};

/* 17 ─ transatlantik (97.9 – 102.7) */
const SceneAtlantic = () => {
  const t = useT();
  const lt = useLT();
  const tE = W('Eropa');
  const tA = W('Amerika', 1);
  const path: P2[] = [[330, 760], [480, 640], [640, 900], [760, 800]];
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #2c6f94 0%, #1a4a6e 70%, #0e2c46 100%)'}} />
      <Cam z0={1.06} z1={1} dur={4.8}>
        <S>
          <path d="M-20,380 C100,340 250,420 330,560 C380,660 360,780 300,860 C250,940 130,980 -20,960Z" fill="#c9b58a" stroke={OUT} strokeWidth={6} />
          <path d="M1100,420 C980,400 860,470 790,580 C740,660 760,780 800,860 C840,940 950,1000 1100,980Z" fill="#c9b58a" stroke={OUT} strokeWidth={6} />
          <path d={bezD(path)} fill="none" stroke={OUT} strokeWidth={22} strokeLinecap="round" />
          <path d={bezD(path)} fill="none" stroke="#34425e" strokeWidth={12} strokeLinecap="round" />
          {[0, 1, 2].map((i) => {
            const u = ((lt * 0.35 + i / 3) % 1);
            const [x, y] = bez(path, u);
            return <Glow key={i} x={x} y={y} r={13} c="yellow" />;
          })}
          <circle cx={330} cy={760} r={18} fill="#ff4a3a" stroke={OUT} strokeWidth={5} />
          <circle cx={760} cy={800} r={18} fill="#ff4a3a" stroke={OUT} strokeWidth={5} />
        </S>
      </Cam>
      <Pill x={200} y={1130} text="EROPA" at={tE} color="#ffd45a" size={50} />
      <Pill x={880} y={1130} text="AMERIKA UTARA" at={tA} color="#ffd45a" size={40} />
    </>
  );
};

/* 18 ─ penutup (102.7 – 109.7) */
const SceneEnd = () => {
  const t = useT();
  const lt = useLT();
  const cam = easeInOut(prog(t, 105.2, 3.6));
  const out = prog(t, 109.2, 0.5);
  return (
    <>
      <AbsoluteFill style={{background: '#06101f'}} />
      <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 2800, transform: `translateY(${-880 * cam}px)`}}>
        <svg viewBox="0 0 1080 2800" width={1080} height={2800} style={{position: 'absolute', left: 0, top: 0}}>
          <Defs />
          <defs>
            <linearGradient id="skyEnd" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#3a1c4a" />
              <stop offset="0.6" stopColor="#f0603a" />
              <stop offset="1" stopColor="#ffb347" />
            </linearGradient>
            <linearGradient id="waterEnd" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#2d8fd0" />
              <stop offset="0.45" stopColor="#0f4a80" />
              <stop offset="1" stopColor="#051428" />
            </linearGradient>
          </defs>
          <rect width={1080} height={900} fill="url(#skyEnd)" />
          <rect y={900} width={1080} height={1900} fill="url(#waterEnd)" />
          {[[60, 520, 120, 380], [200, 400, 100, 500], [330, 560, 140, 340], [500, 300, 130, 600], [660, 480, 110, 420], [800, 380, 120, 520], [940, 540, 120, 360]].map((b, i) => (
            <g key={i}>
              <rect x={b[0]} y={b[1]} width={b[2]} height={b[3]} fill="#2c1634" stroke={OUT} strokeWidth={5} />
              {[0, 1, 2, 3].map((r) => (
                <rect key={r} x={b[0] + 20} y={b[1] + 40 + r * 70} width={22} height={22} fill="#ffd45a" opacity={(r + i) % 3 === 0 ? 0.3 : 0.9} />
              ))}
            </g>
          ))}
          <path d="M0,900 Q135,870 270,900 T540,900 T810,900 T1080,900 L1080,950 L0,950Z" fill="#7cc7ff" opacity={0.8} />
          {Array.from({length: 18}).map((_, i) => (
            <circle key={i} cx={random(`ex${i}`) * 1080} cy={1000 + ((random(`ey${i}`) * 1700 - lt * 40) % 1700 + 1700) % 1700} r={4 + random(`er${i}`) * 8} fill="none" stroke="#bfe9ff" strokeWidth={2.5} opacity={0.3} />
          ))}
          <path d="M0,2540 C220,2500 420,2570 640,2520 C840,2480 980,2540 1080,2515 L1080,2800 L0,2800Z" fill="#6d5a3c" stroke={OUT} strokeWidth={6} />
          <path d="M-40,2560 C300,2510 700,2580 1120,2530" fill="none" stroke="#9ff3ff" strokeWidth={46} opacity={0.18} />
          <CableLine d="M-40,2560 C300,2510 700,2580 1120,2530" w={36} />
          {Array.from({length: 3}).map((_, i) => {
            const u = ((lt * 0.2 + i / 3) % 1);
            return <Glow key={i} x={lerp(-40, 1120, u)} y={2552 - Math.sin(u * 3) * 6} r={15} />;
          })}
        </svg>
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 330,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 120,
          color: '#fff',
          letterSpacing: 2,
          opacity: eo(t, 107.8, 0.8),
          textShadow: '0 0 30px rgba(124,207,255,0.9), 0 6px 14px rgba(0,0,0,0.6)',
        }}
      >
        <span style={{color: '#ffc85a'}}>Semesta</span>Kita
      </div>
      <AbsoluteFill style={{background: '#000', opacity: out}} />
    </>
  );
};

/* ═══════════════════════════ ROOT ═══════════════════════════ */
export const Kabel: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <TCtx.Provider value={t}>
      <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
        <Scene a={0} b={5.5} fade={0}><SceneDaily /></Scene>
        <Scene a={5.5} b={12.2}><SceneMap /></Scene>
        <Scene a={12.2} b={16.2}><SceneSat /></Scene>
        <Scene a={16.2} b={23.4}><SceneDonut /></Scene>
        <Scene a={23.4} b={30.2}><SceneBackbone /></Scene>
        <Scene a={30.2} b={33.9}><SceneCross /></Scene>
        <Scene a={33.9} b={42.1}><SceneLight /></Scene>
        <Scene a={42.1} b={47.6}><SceneTIR /></Scene>
        <Scene a={47.6} b={52.2}><SceneWeak /></Scene>
        <Scene a={52.2} b={62.2}><SceneRepeater /></Scene>
        <Scene a={62.2} b={66.0}><SceneShip /></Scene>
        <Scene a={66.0} b={73.3}><SceneShallow /></Scene>
        <Scene a={73.3} b={76.9}><SceneDeep /></Scene>
        <Scene a={76.9} b={83.8}><SceneLanding /></Scene>
        <Scene a={83.8} b={85.3}><SceneCut /></Scene>
        <Scene a={85.3} b={91.7}><SceneNetwork /></Scene>
        <Scene a={91.7} b={93.3}><SceneRepair /></Scene>
        <Scene a={93.3} b={97.9}><SceneOld /></Scene>
        <Scene a={97.9} b={102.7}><SceneAtlantic /></Scene>
        <Scene a={102.7} b={TOTAL_SECONDS + 1} fade={0.25}><SceneEnd /></Scene>
        <Vignette />
        <Caption />
        <Audio src={staticFile('audio.mp3')} />
      </AbsoluteFill>
    </TCtx.Provider>
  );
};

export default Kabel;
