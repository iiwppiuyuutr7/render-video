Taruh Kabel.tsx & Root.tsx di src/ (ganti Root.tsx lama), folder public/ digabung ke public/ proyekmu.
Butuh: remotion, @remotion/google-fonts (sama seperti contoh asteroid).
Preview : npx remotion studio   (composition id: Kabel)
Render  : npx remotion render Kabel out/kabel.mp4
Durasi 6582 frame (109,7 dtk) @60fps 1080x1920 - mengikuti panjang narasi (109,2 dtk).
Atur efek suara di array SFX (bagian bawah Kabel.tsx); volume global: SFX_VOL.
