import {loadFont as loadHead} from "@remotion/google-fonts/ArchivoBlack";
import {loadFont as loadBody} from "@remotion/google-fonts/SpaceGrotesk";

const head = loadHead("normal", {weights: ["400"], subsets: ["latin"]});
const body = loadBody("normal", {weights: ["500", "700"], subsets: ["latin"]});

export const HEAD: string = head.fontFamily; // judul tebal (Archivo Black)
export const BODY: string = body.fontFamily; // teks isi (Space Grotesk)
