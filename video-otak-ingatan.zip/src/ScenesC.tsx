import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {HEIGHT, INK, P, PAPER, SOFT, WIDTH, pop, prog, useT} from "./config";
import {Arrow, Brain, IconLock, IconMagnifier, IconMoon, IconPlay, IconSun, WobbleDefs} from "./art";
import {Body, Card, Head, Marker, Sticker} from "./ui";
import {HEAD} from "./fonts";

// ---------- Scene 9: tidur ----------
const PATTERN = [0, 3, 5, 6, 9, 10];

const PatternGrid: React.FC<{cx: number; cy: number; lit: (idx: number) => number; color: string}> = ({cx, cy, lit, color}) => (
  <g>
    {Array.from({length: 12}).map((_, i) => {
      const col = i % 4;
      const row = Math.floor(i / 4);
      const on = PATTERN.includes(i) ? lit(PATTERN.indexOf(i)) : 0;
      return (
        <circle
          key={i}
          cx={cx + (col - 1.5) * 62}
          cy={cy + (row - 1) * 62}
          r={20 + 4 * on}
          fill={on > 0.5 ? color : PAPER}
          stroke={INK}
          strokeWidth={5}
          opacity={on > 0.5 ? 1 : 0.6}
        />
      );
    })}
  </g>
);

export const Scene9: React.FC = () => {
  const t = useT();
  const head = pop(t, 57.8, 0.5);
  const waveP = pop(t, 58.7, 0.5);
  const phaseA = prog(t, 60.5, 60.9) * (1 - prog(t, 64.3, 64.5));
  const phaseB = prog(t, 64.4, 64.7) * (1 - prog(t, 68.9, 69.2) * 0.65);
  const wavePath = (() => {
    let d = "";
    for (let x = 30; x <= 870; x += 10) {
      const y = 115 + 62 * Math.sin(((x - t * 110) / 420) * Math.PI * 2);
      d += `${x === 30 ? "M" : "L"}${x} ${y.toFixed(1)} `;
    }
    return d;
  })();
  const shuttle = (i: number): number => (t * 0.9 + i * 0.5) % 1;
  return (
    <AbsoluteFill>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        {[0, 1, 2, 3, 4].map((i) => (
          <circle key={i} cx={[90, 330, 120, 340, 250][i]} cy={[330, 300, 600, 580, 255][i] + Math.sin(t * 2 + i) * 6} r={[7, 6, 8, 5, 6][i]} fill={P.yellow} opacity={Math.min(1, head)} />
        ))}
        <g filter="url(#wobble)" opacity={Math.min(1, head * 2)} transform={`translate(0 ${Math.sin(t * 2) * 6})`}>
          <IconMoon x={205} y={470} s={1.35} />
        </g>
      </svg>
      <Head y={330} size={108} x={400} w={620} align="left" color={PAPER} opacity={Math.min(1, head * 2)}>
        SAAT
      </Head>
      <Head y={440} size={140} x={400} w={620} align="left" color={PAPER} opacity={Math.min(1, head * 2)} scale={0.85 + 0.15 * Math.min(1, head)}>
        TIDUR
      </Head>

      <Card x={80} y={680} w={920} h={230} color={PAPER} p={waveP} rot={-0.6}>
        <svg width={908} height={218} style={{position: "absolute", left: 0, top: 0}}>
          <path d={wavePath} fill="none" stroke={INK} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </Card>
      <Sticker cx={690} cy={680} color={P.pink} p={pop(t, 58.8, 0.5)} size={36} rot={3}>
        SLOW-WAVE SLEEP
      </Sticker>

      <Card x={80} y={970} w={920} h={520} color={PAPER} p={pop(t, 60.5, 0.5)} rot={0.6}>
        <div style={{opacity: phaseA}}>
          <svg width={908} height={508} style={{position: "absolute", left: 0, top: 0}}>
            <g filter="url(#wobble)">
              <ellipse cx={190} cy={190} rx={150} ry={92} fill={P.pink} stroke={INK} strokeWidth={7} />
              <ellipse cx={720} cy={190} rx={150} ry={92} fill={P.blue} stroke={INK} strokeWidth={7} />
            </g>
            <Arrow x1={350} y1={160} x2={560} y2={160} w={8} />
            <Arrow x1={560} y1={226} x2={350} y2={226} w={8} />
            {[0, 1, 2, 3].map((i) => {
              const u = shuttle(i);
              const dir = i % 2 === 0 ? u : 1 - u;
              return <circle key={i} cx={360 + 190 * dir} cy={i % 2 === 0 ? 160 : 226} r={9} fill={P.yellow} stroke={INK} strokeWidth={4} />;
            })}
          </svg>
          <div style={{position: "absolute", left: 40, top: 168, width: 300, textAlign: "center", fontFamily: HEAD, fontSize: 32, color: INK}}>HIPPOCAMPUS</div>
          <div style={{position: "absolute", left: 570, top: 166, width: 300, textAlign: "center", fontFamily: HEAD, fontSize: 38, color: PAPER}}>KORTEKS</div>
        </div>
        <div style={{opacity: phaseB}}>
          <svg width={908} height={508} style={{position: "absolute", left: 0, top: 0}}>
            <IconSun x={190} y={90} s={0.6} />
            <IconMoon x={720} y={90} s={0.5} />
            <PatternGrid cx={190} cy={290} color={P.pink} lit={(i) => prog(t, 64.8 + i * 0.08, 65.1 + i * 0.08)} />
            <PatternGrid cx={720} cy={290} color={P.pink} lit={(i) => prog(t, 66.0 + i * 0.35, 66.25 + i * 0.35)} />
            <Arrow x1={350} y1={290} x2={560} y2={290} w={8} />
          </svg>
          <div style={{position: "absolute", left: 40, top: 430, width: 300, textAlign: "center", fontFamily: HEAD, fontSize: 36, color: INK}}>TERJAGA</div>
          <div style={{position: "absolute", left: 570, top: 430, width: 300, textAlign: "center", fontFamily: HEAD, fontSize: 36, color: INK}}>TIDUR</div>
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: 380, display: "flex", justifyContent: "center", opacity: pop(t, 62.6, 0.4) * (1 - prog(t, 64.3, 64.5))}}>
          <div style={{fontFamily: HEAD, fontSize: 40, background: P.yellow, border: `6px solid ${INK}`, borderRadius: 18, padding: "6px 24px", color: INK}}>KONSOLIDASI MEMORI</div>
        </div>
      </Card>
      <Sticker cx={540} cy={1230} color={P.pink} p={pop(t, 69.7, 0.5)} size={76} rot={-3}>
        MEMORY REPLAY
      </Sticker>
    </AbsoluteFill>
  );
};

// ---------- Scene 10: melupakan ----------
export const Scene10: React.FC = () => {
  const t = useT();
  const head = pop(t, 71.3, 0.5);
  const cards = [
    {lines: ["TIDAK TERSIMPAN", "KUAT"], t0: 73.28, color: P.mint, kind: 0},
    {lines: ["TERGANGGU", "INFORMASI BARU"], t0: 75.71, color: P.pink, kind: 1},
    {lines: ["SULIT DIAMBIL", "KEMBALI"], t0: 77.32, color: P.lilac, kind: 2},
  ];
  return (
    <AbsoluteFill>
      <Head y={310} size={124} opacity={Math.min(1, head * 2)} scale={0.85 + 0.15 * Math.min(1, head)}>
        MELUPAKAN
      </Head>
      <Head y={440} size={100} opacity={Math.min(1, head * 2)}>
        <Marker p={prog(t, 71.8, 72.5)} color={P.orange}>
          ITU NORMAL
        </Marker>
      </Head>
      {cards.map((c, i) => {
        const p = pop(t, c.t0, 0.5);
        return (
          <Card key={c.kind} x={80} y={640 + i * 260} w={920} h={225} color={c.color} p={p} rot={i === 1 ? 1 : -1}>
            <svg width={230} height={213} style={{position: "absolute", left: 0, top: 0}}>
              {c.kind === 0 ? (
                <g>
                  <circle cx={115} cy={106} r={58} fill={PAPER} fillOpacity={0.55} stroke={INK} strokeWidth={7} strokeDasharray="10 14" strokeLinecap="round" />
                  <text x={115} y={134} fontFamily={HEAD} fontSize={80} textAnchor="middle" fill={INK} opacity={0.6}>
                    ?
                  </text>
                </g>
              ) : null}
              {c.kind === 1 ? (
                <g>
                  <rect x={52} y={44} width={96} height={96} rx={10} fill={PAPER} fillOpacity={0.5} stroke={INK} strokeWidth={6} strokeDasharray="8 10" />
                  <rect x={88} y={80} width={96} height={96} rx={10} fill={P.yellow} stroke={INK} strokeWidth={7} />
                </g>
              ) : null}
              {c.kind === 2 ? <IconLock x={115} y={104} s={1.15} /> : null}
            </svg>
            <div
              style={{
                position: "absolute",
                left: 230,
                right: 16,
                top: 0,
                bottom: 0,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                fontFamily: HEAD,
                fontSize: 52,
                lineHeight: 1.05,
                color: INK,
              }}
            >
              {c.lines.map((l) => (
                <div key={l}>{l}</div>
              ))}
            </div>
          </Card>
        );
      })}
    </AbsoluteFill>
  );
};

// ---------- Scene 11: ingatan bisa berubah ----------
const Pic: React.FC<{variant: number}> = ({variant}) => (
  <g>
    <rect width={560} height={420} fill={SOFT.blue} />
    <circle cx={450} cy={92} r={variant === 0 ? 52 : 66} fill={variant === 0 ? P.yellow : P.pink} stroke={INK} strokeWidth={7} />
    {variant === 1 ? <ellipse cx={330} cy={80} rx={70} ry={30} fill={PAPER} stroke={INK} strokeWidth={6} /> : null}
    <path d="M0 330 C120 270 230 300 330 280 C420 262 500 290 560 300 L560 420 L0 420 Z" fill={P.mint} stroke={INK} strokeWidth={7} />
    <rect x={120} y={190} width={150} height={120} fill={PAPER} stroke={INK} strokeWidth={7} />
    <path d="M100 196 L195 120 L290 196 Z" fill={P.orange} stroke={INK} strokeWidth={7} strokeLinejoin="round" />
    <rect x={172} y={238} width={46} height={72} fill={P.blue} stroke={INK} strokeWidth={6} />
  </g>
);

export const Scene11: React.FC = () => {
  const t = useT();
  const part1 = prog(t, 79.3, 79.7) * (1 - prog(t, 81.6, 81.95));
  const x = prog(t, 80.4, 81.0, Easing.inOut(Easing.cubic));
  const part2 = prog(t, 81.9, 82.3);
  const e = prog(t, 82.95, 83.5) * (1 - prog(t, 83.6, 84.3));
  const swap = t > 83.6 ? 1 : 0;
  const chips = [
    {w: "DIAKTIFKAN", t0: 85.0, color: P.yellow},
    {w: "BERUBAH", t0: 85.9, color: P.pink},
    {w: "DISTABILKAN", t0: 86.8, color: P.mint},
  ];
  return (
    <AbsoluteFill>
      <div style={{opacity: part1}}>
        <Body y={320} size={46} w={900} x={90}>
          Ingatan = rekaman sempurna?
        </Body>
        <Card x={190} y={430} w={700} h={430} color={PAPER} rot={-1}>
          <Head y={320} size={46} w={688}>
            REKAMAN SEMPURNA
          </Head>
        </Card>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <IconPlay x={540} y={600} s={1.5} />
          <g fill="none" strokeLinecap="round">
            <path d="M240 480 L840 820" stroke={INK} strokeWidth={54} pathLength={1} strokeDasharray={`${x} 1`} />
            <path d="M840 480 L240 820" stroke={INK} strokeWidth={54} pathLength={1} strokeDasharray={`${Math.max(0, x * 1.4 - 0.4)} 1`} />
            <path d="M240 480 L840 820" stroke={P.pink} strokeWidth={40} pathLength={1} strokeDasharray={`${x} 1`} />
            <path d="M840 480 L240 820" stroke={P.pink} strokeWidth={40} pathLength={1} strokeDasharray={`${Math.max(0, x * 1.4 - 0.4)} 1`} />
          </g>
        </svg>
        <Sticker cx={820} cy={440} color={P.pink} p={pop(t, 80.5, 0.5)} size={60} rot={8}>
          BUKAN
        </Sticker>
      </div>

      <div style={{opacity: part2}}>
        <Sticker cx={540} cy={340} color={P.blue} textColor={PAPER} p={pop(t, 81.9, 0.4)} size={48} rot={-2}>
          SAAT DIINGAT
        </Sticker>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <defs>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <clipPath key={i} id={`tile-${i}`}>
                <rect x={(i % 3) * (560 / 3)} y={Math.floor(i / 3) * 210} width={560 / 3 + 0.5} height={210.5} />
              </clipPath>
            ))}
          </defs>
          <g transform="translate(260 440)">
            {[0, 1, 2, 3, 4, 5].map((i) => {
              const col = i % 3;
              const row = Math.floor(i / 3);
              const dx = (col - 1) * 54 * e + (i % 2 === 0 ? -14 : 14) * e;
              const dy = (row - 0.5) * 70 * e;
              const rot = (i % 2 === 0 ? -7 : 7) * e;
              const cx = (col + 0.5) * (560 / 3);
              const cy = (row + 0.5) * 210;
              return (
                <g key={i} transform={`translate(${dx} ${dy}) rotate(${rot} ${cx} ${cy})`}>
                  <g clipPath={`url(#tile-${i})`}>
                    <Pic variant={i === 1 || i === 2 ? swap : 0} />
                  </g>
                  <rect x={col * (560 / 3)} y={row * 210} width={560 / 3} height={210} fill="none" stroke={INK} strokeWidth={e > 0.05 ? 6 : 0} />
                </g>
              );
            })}
            <rect width={560} height={420} fill="none" stroke={INK} strokeWidth={8} opacity={1 - Math.min(1, e * 4)} />
          </g>
        </svg>
        <Head y={940} size={96} opacity={Math.min(1, pop(t, 85.1, 0.5) * 2)}>
          MEMORY
        </Head>
        <Head y={1045} size={66} opacity={Math.min(1, pop(t, 85.5, 0.5) * 2)}>
          <Marker p={prog(t, 85.6, 86.2)} color={P.yellow}>
            RECONSOLIDATION
          </Marker>
        </Head>
        {chips.map((c, i) => (
          <Card key={c.w} x={95 + i * 305} y={1210} w={280} h={110} color={c.color} p={pop(t, c.t0, 0.45)} radius={22} shadow={8}>
            <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: HEAD, fontSize: 28, color: INK}}>{c.w}</div>
          </Card>
        ))}
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          {[0, 1].map((i) => (
            <g key={i} opacity={Math.min(1, pop(t, chips[i + 1].t0 - 0.15, 0.3) * 2)}>
              <Arrow x1={375 + i * 305} y1={1265} x2={400 + i * 305} y2={1265} w={7} />
            </g>
          ))}
        </svg>
      </div>
    </AbsoluteFill>
  );
};

// ---------- Scene 12: penutup ----------
export const Scene12: React.FC = () => {
  const t = useT();
  const mx = 540 + 150 * Math.sin(t * 0.9);
  const my = 1090 + 55 * Math.cos(t * 1.3);
  const bp = pop(t, 88.3, 0.7);
  return (
    <AbsoluteFill>
      <Head y={300} size={88} color={PAPER} opacity={Math.min(1, pop(t, 88.05, 0.5) * 2)}>
        PARA ILMUWAN
      </Head>
      <Head y={410} size={100} color={PAPER} opacity={Math.min(1, pop(t, 89.0, 0.5) * 2)}>
        <Marker p={prog(t, 89.1, 89.7)} color={P.pink} h={100}>
          <span style={{color: INK}}>MASIH TERUS</span>
        </Marker>
      </Head>
      <Head y={525} size={130} color={PAPER} opacity={Math.min(1, pop(t, 89.9, 0.5) * 2)}>
        <Marker p={prog(t, 90.0, 90.6)} color={P.yellow} h={100}>
          <span style={{color: INK}}>MENELITI</span>
        </Marker>
      </Head>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g filter="url(#wobble)" opacity={Math.min(1, bp * 2)}>
          <Brain x={540} y={1090} s={0.8 * (0.8 + 0.2 * Math.min(1, bp))} fill="#FFB3C8" />
        </g>
        <g opacity={Math.min(1, bp * 2)}>
          <IconMagnifier x={mx} y={my} s={2.6} color={P.yellow} />
        </g>
      </svg>
      <Sticker cx={540} cy={1365} color={P.pink} p={pop(t, 91.2, 0.5)} size={56} rot={-2}>
        OTAK & INGATAN
      </Sticker>
      <Body y={1435} size={26} w={940} x={70} weight={500} color={PAPER} opacity={0.8 * prog(t, 90.5, 91.1)}>
        Sumber: University of Queensland · NCBI · NIH/PMC · Physiological Reviews
      </Body>
    </AbsoluteFill>
  );
};
