import React from "react";
import {AbsoluteFill, Easing, random} from "remotion";
import {HEIGHT, INK, P, PAPER, SOFT, WIDTH, pop, prog, useT} from "./config";
import {Arrow, Brain, HIPPO_POS, IconBook, IconEar, IconEye, IconHeart, IconPin, IconWarehouse, Neuron, WobbleDefs} from "./art";
import {Body, Card, Head, Marker, Sticker} from "./ui";
import {BODY} from "./fonts";

const lerp = (a: number, b: number, u: number): number => a + (b - a) * u;

// ---------- Scene 5: belajar ----------
const N5: ReadonlyArray<readonly [number, number]> = [
  [200, 950], [420, 830], [660, 860], [880, 980],
  [300, 1180], [560, 1120], [800, 1260], [480, 1360],
];
const E5: ReadonlyArray<readonly [number, number]> = [
  [0, 1], [1, 2], [2, 3], [0, 4], [1, 5], [2, 5], [3, 6], [4, 5], [5, 6], [5, 7], [4, 7], [6, 7],
];
const STRONG: ReadonlyArray<readonly [number, number]> = [[1, 5], [2, 5], [5, 6], [5, 7]];
const SET1 = [0, 2, 5, 6];
const SET2 = [1, 3, 4, 7];

export const Scene5: React.FC = () => {
  const t = useT();
  const h = pop(t, 20.6, 0.5);
  const activity = t >= 22.1 && t < 24.1;
  const phase = Math.floor((t - 22.1) / 0.45) % 2;
  const lit = activity ? (phase === 0 ? SET1 : SET2) : [];
  const litColor = phase === 0 ? P.pink : P.blue;
  const strongP = prog(t, 24.3, 26.0, Easing.inOut(Easing.cubic));
  const chip1 = pop(t, 22.1, 0.4) * (1 - prog(t, 24.1, 24.3));
  const chip2 = pop(t, 24.3, 0.4);
  return (
    <AbsoluteFill>
      <Head y={300} size={88} x={60} w={700} align="left" opacity={Math.min(1, h * 2)}>
        SAAT KITA
      </Head>
      <Head y={385} size={150} x={60} w={900} align="left" opacity={Math.min(1, h * 2)} scale={0.85 + 0.15 * Math.min(1, h)}>
        <Marker p={prog(t, 20.8, 21.5)} color={P.yellow}>
          BELAJAR
        </Marker>
      </Head>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g opacity={Math.min(1, h * 2)} transform={`translate(0 ${Math.sin(t * 3) * 6})`}>
          <IconBook x={900} y={350} s={1.1} />
        </g>
        <g filter="url(#wobble)">
          {E5.map(([a, b], k) => {
            const strong = STRONG.some((s) => s[0] === a && s[1] === b);
            const w = strong ? 6 + 14 * strongP : 5;
            return (
              <g key={k}>
                {strong && strongP > 0 ? (
                  <line x1={N5[a][0]} y1={N5[a][1]} x2={N5[b][0]} y2={N5[b][1]} stroke={INK} strokeWidth={w + 10} strokeLinecap="round" />
                ) : null}
                <line
                  x1={N5[a][0]}
                  y1={N5[a][1]}
                  x2={N5[b][0]}
                  y2={N5[b][1]}
                  stroke={strong && strongP > 0 ? P.pink : INK}
                  strokeWidth={w}
                  strokeLinecap="round"
                  strokeDasharray={strong ? undefined : "2 14"}
                  opacity={strong ? 1 : 0.7}
                />
              </g>
            );
          })}
          {N5.map(([x, y], i) => {
            const on = lit.includes(i);
            const hub = strongP > 0.5 && [1, 2, 5, 6, 7].includes(i);
            return <circle key={i} cx={x} cy={y} r={on ? 44 : 36} fill={on ? litColor : hub ? P.pink : PAPER} stroke={INK} strokeWidth={7} />;
          })}
        </g>
      </svg>
      <Sticker cx={540} cy={690} color={P.blue} textColor={PAPER} p={chip1} size={42} rot={-2}>
        POLA AKTIVITAS BERUBAH
      </Sticker>
      <Sticker cx={540} cy={690} color={P.mint} p={chip2} size={42} rot={2}>
        HUBUNGAN MENGUAT
      </Sticker>
      <Sticker cx={540} cy={1500} color={P.yellow} p={pop(t, 26.2, 0.5)} size={46} rot={-1.5}>
        DASAR BIOLOGIS INGATAN
      </Sticker>
    </AbsoluteFill>
  );
};

// ---------- Scene 6: hippocampus ----------
export const Scene6: React.FC = () => {
  const t = useT();
  const bx = 540;
  const by = 830;
  const bs = 0.95;
  const hipWorld = {x: bx + HIPPO_POS.x * bs, y: by + HIPPO_POS.y * bs};
  const hip = prog(t, 27.9, 28.7, Easing.inOut(Easing.quad));
  const pulse = t > 28.7 ? 0.5 + 0.5 * Math.sin(t * 6) : 0;
  const temporal = prog(t, 29.0, 29.6);
  const head = pop(t, 27.9, 0.5);
  const sp1 = pop(t, 30.5, 0.5) * (1 - prog(t, 32.2, 32.5));
  const sp2 = pop(t, 34.0, 0.5);
  const spark = prog(t, 30.5, 31.3);
  const icons: Array<{x: number; y: number; k: number}> = [
    {x: 130, y: 720, k: 0},
    {x: 950, y: 720, k: 1},
    {x: 130, y: 1010, k: 2},
    {x: 950, y: 1010, k: 3},
  ];
  return (
    <AbsoluteFill>
      <Head y={300} size={100} opacity={Math.min(1, head * 2)} scale={0.8 + 0.2 * Math.min(1, head)}>
        HIPPOCAMPUS
      </Head>
      <Sticker cx={540} cy={500} color={P.blue} textColor={PAPER} p={pop(t, 29.0, 0.5)} size={38} rot={-2}>
        DI DALAM LOBUS TEMPORAL
      </Sticker>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g filter="url(#wobble)">
          <Brain x={bx} y={by} s={bs} hip={hip} hipPulse={pulse} temporal={temporal} />
        </g>
        {spark > 0 && spark < 1
          ? Array.from({length: 8}).map((_, i) => {
              const a = (i / 8) * Math.PI * 2;
              const r1 = 60 + 60 * spark;
              const r2 = r1 + 36 * (1 - spark);
              return (
                <line
                  key={i}
                  x1={hipWorld.x + Math.cos(a) * r1}
                  y1={hipWorld.y + Math.sin(a) * r1}
                  x2={hipWorld.x + Math.cos(a) * r2}
                  y2={hipWorld.y + Math.sin(a) * r2}
                  stroke={INK}
                  strokeWidth={8}
                  strokeLinecap="round"
                />
              );
            })
          : null}
        {icons.map((ic, i) => {
          const q = prog(t, 32.5 + i * 0.15, 33.8 + i * 0.15, Easing.inOut(Easing.cubic));
          const vis = prog(t, 32.2, 32.6) * (1 - prog(q, 0.85, 1));
          const x = lerp(ic.x, hipWorld.x, q);
          const y = lerp(ic.y, hipWorld.y, q);
          const s = 0.95 - 0.55 * q;
          return (
            <g key={i} opacity={vis}>
              {ic.k === 0 ? <IconEye x={x} y={y} s={s} /> : null}
              {ic.k === 1 ? <IconEar x={x} y={y} s={s} /> : null}
              {ic.k === 2 ? <IconHeart x={x} y={y} s={s} /> : null}
              {ic.k === 3 ? <IconPin x={x} y={y} s={s} /> : null}
            </g>
          );
        })}
      </svg>
      <Sticker cx={540} cy={1280} color={P.yellow} p={sp1} size={62} rot={-2}>
        + INGATAN BARU
      </Sticker>
      <Sticker cx={540} cy={1280} color={P.mint} p={sp2} size={56} rot={2}>
        SATU PENGALAMAN
      </Sticker>
    </AbsoluteFill>
  );
};

// ---------- Scene 7: bukan gudang ----------
const DOTS: Array<{x: number; y: number}> = Array.from({length: 26}).map((_, i) => {
  const a = random(`d${i}a`) * Math.PI * 2;
  const r = Math.sqrt(random(`d${i}r`)) * 0.82;
  return {x: Math.cos(a) * 250 * r, y: Math.sin(a) * 165 * r - 10};
});

export const Scene7: React.FC = () => {
  const t = useT();
  const part1 = prog(t, 35.5, 35.9) * (1 - prog(t, 39.3, 39.8));
  const x = prog(t, 36.5, 37.2, Easing.inOut(Easing.cubic));
  const brainP = pop(t, 39.8, 0.6);
  const cortex = prog(t, 40.0, 40.8);
  return (
    <AbsoluteFill>
      <div style={{opacity: part1}}>
        <Body y={310} size={46} w={900} x={90} weight={700}>
          Hippocampus = tempat menyimpan semua ingatan?
        </Body>
        <Card x={110} y={470} w={860} h={640} color={SOFT.yellow} rot={-1}>
          <Head y={470} size={80} w={848}>
            HIPPOCAMPUS
          </Head>
        </Card>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <WobbleDefs t={t} />
          <g filter="url(#wobble)">
            <IconWarehouse x={540} y={760} s={2.5} />
          </g>
          <g stroke={P.pink} strokeWidth={40} strokeLinecap="round" fill="none" opacity={x > 0 ? 1 : 0}>
            <path d="M190 520 L890 1060" stroke={INK} strokeWidth={54} pathLength={1} strokeDasharray={`${x} 1`} />
            <path d="M890 520 L190 1060" stroke={INK} strokeWidth={54} pathLength={1} strokeDasharray={`${Math.max(0, x * 1.4 - 0.4)} 1`} />
            <path d="M190 520 L890 1060" pathLength={1} strokeDasharray={`${x} 1`} />
            <path d="M890 520 L190 1060" pathLength={1} strokeDasharray={`${Math.max(0, x * 1.4 - 0.4)} 1`} />
          </g>
        </svg>
        <Sticker cx={820} cy={500} color={P.pink} p={pop(t, 36.6, 0.5)} size={64} rot={8}>
          BUKAN!
        </Sticker>
      </div>

      <Head y={290} size={100} opacity={prog(t, 39.9, 40.4)}>
        INGATAN
      </Head>
      <Head y={400} size={70} opacity={prog(t, 40.1, 40.6)}>
        JANGKA PANJANG
      </Head>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g opacity={Math.min(1, brainP * 2)} transform={`translate(0 ${(1 - Math.min(1, brainP)) * 40})`}>
          <g filter="url(#wobble)">
            <Brain x={540} y={910} s={0.95} fill={PAPER} cortex={cortex}>
              {DOTS.map((d, i) => {
                const p = pop(t, 40.3 + i * 0.07, 0.35);
                return (
                  <circle
                    key={i}
                    cx={d.x}
                    cy={d.y}
                    r={16 * Math.min(1.2, p)}
                    fill={[P.pink, P.yellow, P.mint, P.orange, P.lilac][i % 5]}
                    stroke={INK}
                    strokeWidth={5}
                    opacity={Math.min(1, p * 2)}
                  />
                );
              })}
            </Brain>
          </g>
        </g>
      </svg>
      <Sticker cx={820} cy={640} color={P.pink} p={pop(t, 41.0, 0.5)} size={46} rot={6}>
        TERSEBAR
      </Sticker>
      <Sticker cx={540} cy={1310} color={P.blue} textColor={PAPER} p={pop(t, 41.6, 0.5)} size={50} rot={-2}>
        KORTEKS SEREBRAL
      </Sticker>
    </AbsoluteFill>
  );
};

// ---------- Scene 8: synaptic plasticity dan LTP ----------
export const Scene8: React.FC = () => {
  const t = useT();
  const phase2 = prog(t, 46.9, 47.3) * (1 - prog(t, 52.4, 52.9));
  const titleOut = 1 - prog(t, 52.4, 52.9);
  const glow = t >= 47.3 && t < 49.9 ? 0.5 + 0.5 * Math.sin(t * 8) : 0;
  const bridge = 6 + 26 * prog(t, 49.9, 52.0, Easing.inOut(Easing.cubic));
  const cardP = pop(t, 53.0, 0.5);
  const draw = prog(t, 53.2, 55.6, Easing.inOut(Easing.quad));
  const wave = Math.sin(t * 4) * 6;
  // Grafik di dalam kartu (koordinat lokal 0..900 x 0..440)
  const chart = `M70 340 L330 340 C360 340 365 130 400 130 C470 ${130 + wave} 560 ${126 - wave} 640 ${130 + wave} S780 ${126} 840 128`;
  return (
    <AbsoluteFill>
      <Sticker cx={540} cy={330} color={P.yellow} p={pop(t, 43.9, 0.4) * titleOut} size={36} rot={-2}>
        MEKANISME PENTING
      </Sticker>
      <Head y={375} size={130} opacity={Math.min(1, pop(t, 45.4, 0.5) * 2) * titleOut}>
        <Marker p={prog(t, 45.5, 46.1)} color={P.yellow}>
          SYNAPTIC
        </Marker>
      </Head>
      <Head y={515} size={108} opacity={Math.min(1, pop(t, 45.95, 0.5) * 2) * titleOut}>
        <Marker p={prog(t, 46.05, 46.7)} color={P.mint}>
          PLASTICITY
        </Marker>
      </Head>

      <div style={{opacity: phase2}}>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <WobbleDefs t={t} />
          <g filter="url(#wobble)">
            <line x1={395} y1={1006} x2={685} y2={1006} stroke={INK} strokeWidth={bridge + 12} strokeLinecap="round" />
            <line x1={395} y1={1006} x2={685} y2={1006} stroke={P.pink} strokeWidth={bridge} strokeLinecap="round" />
            <Neuron x={150} y={1000} s={0.95} color={P.yellow} t={t} glow={glow} />
            <Neuron x={930} y={1000} s={0.95} color={P.mint} t={t} glow={glow} flip />
          </g>
          {[0, 1, 2, 3].map((i) => {
            const u = (t * 0.8 + i * 0.25) % 1;
            const dir = i % 2 === 0 ? u : 1 - u;
            return <circle key={i} cx={420 + 240 * dir} cy={1006 + (i % 2) * 0} r={9} fill={PAPER} stroke={INK} strokeWidth={4} />;
          })}
          <g opacity={Math.min(1, pop(t, 50.6, 0.4) * 2)}>
            <Arrow x1={540} y1={1180} x2={540} y2={1070} w={10} />
          </g>
        </svg>
        <Sticker cx={540} cy={810} color={P.orange} p={pop(t, 47.4, 0.5)} size={46} rot={-2}>
          AKTIF BERSAMA
        </Sticker>
        <Sticker cx={540} cy={1240} color={P.mint} p={pop(t, 50.6, 0.5)} size={56} rot={2}>
          LEBIH KUAT
        </Sticker>
      </div>

      <Body y={330} size={42} weight={500} opacity={prog(t, 52.8, 53.3) * (1 - prog(t, 54.1, 54.3))}>
        Salah satu bentuknya:
      </Body>
      <Head y={385} size={120} opacity={Math.min(1, pop(t, 54.2, 0.5) * 2)}>
        LONG-TERM
      </Head>
      <Head y={515} size={92} opacity={Math.min(1, pop(t, 54.9, 0.5) * 2)}>
        POTENTIATION
      </Head>
      <Card x={90} y={730} w={900} h={470} color={PAPER} p={cardP} rot={-0.6}>
        <div style={{position: "absolute", left: 28, top: 18, fontFamily: BODY, fontWeight: 700, fontSize: 30, color: INK, letterSpacing: 1}}>
          KEKUATAN SINAPSIS
        </div>
        <svg width={888} height={458} style={{position: "absolute", left: 0, top: 0}}>
          <path d="M60 80 L60 380 L860 380" fill="none" stroke={INK} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" opacity={0.7} />
          <path d={chart} fill="none" stroke={INK} strokeWidth={26} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${draw} 1`} transform="translate(0 40)" />
          <path d={chart} fill="none" stroke={P.pink} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${draw} 1`} transform="translate(0 40)" />
          <path d="M350 88 L322 150 L352 150 L326 216" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" opacity={prog(t, 53.9, 54.2)} />
        </svg>
        <div style={{position: "absolute", left: 420, top: 392, fontFamily: BODY, fontWeight: 700, fontSize: 28, color: INK, opacity: prog(t, 55.5, 56.0)}}>
          berlangsung jangka panjang
        </div>
      </Card>
      <Sticker cx={820} cy={730} color={P.pink} p={pop(t, 55.95, 0.5)} size={110} rot={6}>
        LTP
      </Sticker>
    </AbsoluteFill>
  );
};
