import React from "react";
import {AbsoluteFill, Audio, staticFile} from "remotion";
import {INK, P, PAPER, SOFT, T} from "./config";
import {Scene, Watermark} from "./ui";
import {Subtitles} from "./Subtitles";
import {Scene1, Scene2, Scene3, Scene4} from "./ScenesA";
import {Scene5, Scene6, Scene7, Scene8} from "./ScenesB";
import {Scene9, Scene10, Scene11, Scene12} from "./ScenesC";

export const MainVideo: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: INK}}>
    <Audio src={staticFile("narasi.mp3")} />

    <Scene name="1 Hook" start={T.s1[0]} end={T.s1[1]} bg={P.yellow} accent={P.pink} first>
      <Scene1 />
    </Scene>
    <Scene name="2 Apa itu ingatan" start={T.s2[0]} end={T.s2[1]} bg={PAPER} accent={P.yellow} num={1} chapter="Apa itu ingatan?">
      <Scene2 />
    </Scene>
    <Scene name="3 Tiga tahap" start={T.s3[0]} end={T.s3[1]} bg={SOFT.blue} accent={P.blue} num={2} chapter="Tiga tahap">
      <Scene3 />
    </Scene>
    <Scene name="4 Neuron" start={T.s4[0]} end={T.s4[1]} bg={PAPER} accent={P.pink} num={3} chapter="Neuron">
      <Scene4 />
    </Scene>
    <Scene name="5 Belajar" start={T.s5[0]} end={T.s5[1]} bg={SOFT.pink} accent={P.pink} num={4} chapter="Saat belajar">
      <Scene5 />
    </Scene>
    <Scene name="6 Hippocampus" start={T.s6[0]} end={T.s6[1]} bg={SOFT.mint} accent={P.mint} num={5} chapter="Hippocampus">
      <Scene6 />
    </Scene>
    <Scene name="7 Bukan gudang" start={T.s7[0]} end={T.s7[1]} bg={PAPER} accent={P.orange} num={6} chapter="Bukan gudang">
      <Scene7 />
    </Scene>
    <Scene name="8 Synaptic plasticity" start={T.s8[0]} end={T.s8[1]} bg={SOFT.lilac} accent={P.lilac} num={7} chapter="Synaptic plasticity">
      <Scene8 />
    </Scene>
    <Scene name="9 Tidur" start={T.s9[0]} end={T.s9[1]} bg={P.indigo} accent={P.yellow} num={8} chapter="Tidur" dark>
      <Scene9 />
    </Scene>
    <Scene name="10 Melupakan" start={T.s10[0]} end={T.s10[1]} bg={SOFT.yellow} accent={P.orange} num={9} chapter="Melupakan">
      <Scene10 />
    </Scene>
    <Scene name="11 Ingatan berubah" start={T.s11[0]} end={T.s11[1]} bg={SOFT.blue} accent={P.blue} num={10} chapter="Ingatan bisa berubah">
      <Scene11 />
    </Scene>
    <Scene name="12 Penutup" start={T.s12[0]} end={T.s12[1]} bg={INK} accent={P.yellow} last dark>
      <Scene12 />
    </Scene>

    <Subtitles />
    <Watermark />
  </AbsoluteFill>
);
