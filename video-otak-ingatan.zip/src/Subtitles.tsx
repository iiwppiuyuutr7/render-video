import React from "react";
import {INK, P, PAPER, prog, useT} from "./config";
import {BODY} from "./fonts";

// [mulai, selesai, teks] dalam detik pada audio narasi (dipecah mengikuti jeda napas).
const CUES: ReadonlyArray<readonly [number, number, string]> = [
  [0.0, 2.55, "Bagaimana otak manusia menyimpan ingatan?"],
  [3.16, 5.91, "Ingatan adalah kemampuan otak untuk memperoleh,"],
  [6.23, 6.89, "menyimpan,"],
  [7.08, 8.82, "dan mengambil kembali informasi."],
  [9.53, 11.01, "Prosesnya punya tiga tahap:"],
  [11.63, 12.26, "encoding,"],
  [12.58, 13.22, "storage,"],
  [13.41, 14.27, "dan retrieval."],
  [14.9, 20.04, "Otak punya sekitar 86 miliar neuron yang saling terhubung lewat sinapsis."],
  [20.63, 21.7, "Saat kita belajar,"],
  [22.1, 23.76, "pola aktivitas neuron berubah,"],
  [24.16, 27.32, "dan perubahan hubungan itulah dasar biologis ingatan."],
  [27.84, 30.16, "Hippocampus, di dalam lobus temporal,"],
  [30.41, 32.19, "membantu membentuk ingatan baru"],
  [32.19, 35.22, "dan menghubungkan informasi menjadi satu pengalaman."],
  [35.68, 39.21, "Tapi hippocampus bukan tempat penyimpanan seluruh ingatan."],
  [39.79, 43.19, "Ingatan jangka panjang tersebar di jaringan korteks serebral."],
  [43.71, 46.65, "Mekanisme pentingnya disebut synaptic plasticity:"],
  [47.22, 49.5, "ketika dua neuron sering aktif bersama,"],
  [49.89, 52.02, "hubungan di antara keduanya bisa menguat."],
  [52.66, 55.62, "Salah satu bentuknya adalah long-term potentiation,"],
  [55.91, 57.16, "atau LTP."],
  [57.76, 58.54, "Saat tidur,"],
  [58.72, 60.13, "terutama slow-wave sleep,"],
  [60.56, 64.24, "hippocampus dan korteks berinteraksi untuk konsolidasi memori,"],
  [64.48, 68.49, "dan pola aktivitas neuron dari pengalaman sebelumnya bisa muncul kembali,"],
  [68.87, 69.42, "yang disebut"],
  [69.66, 70.66, "memory replay."],
  [71.23, 72.77, "Melupakan itu normal:"],
  [73.28, 75.26, "informasi bisa tidak tersimpan kuat,"],
  [75.71, 77.12, "terganggu informasi baru,"],
  [77.32, 78.85, "atau sulit diambil kembali."],
  [79.41, 81.38, "Ingatan juga bukan rekaman sempurna."],
  [81.88, 82.58, "Saat diingat,"],
  [82.94, 84.31, "ia bisa direkonstruksi,"],
  [84.65, 87.45, "bahkan berubah lewat memory reconsolidation."],
  [88.02, 92.02, "Para ilmuwan masih terus meneliti bagaimana otak menyimpan ingatan."],
];

// Subtitle karaoke: kata yang sedang diucapkan disorot kuning (waktu per kata dihitung dari panjang huruf).
export const Subtitles: React.FC = () => {
  const t = useT();
  const cue = CUES.find((c) => t >= c[0] - 0.08 && t < c[1] + 0.15);
  if (!cue) return null;
  const [start, end, text] = cue;
  const words = text.split(" ");
  const weights = words.map((w) => w.length + 1.5);
  const total = weights.reduce((a, b) => a + b, 0);
  let acc = 0;
  const spans = words.map((w, i) => {
    const a = start + ((end - start) * acc) / total;
    acc += weights[i];
    const b = start + ((end - start) * acc) / total;
    const active = t >= a && t < b;
    const past = t >= b;
    return (
      <span
        key={i}
        style={{
          display: "inline-block",
          margin: "0 6px",
          padding: "0 10px",
          borderRadius: 12,
          background: active ? P.yellow : "transparent",
          color: active ? INK : PAPER,
          opacity: active || past ? 1 : 0.6,
          transform: active ? "scale(1.06)" : "none",
        }}
      >
        {w}
      </span>
    );
  });
  const o = Math.min(prog(t, start - 0.08, start + 0.04), 1 - prog(t, end, end + 0.15));
  return (
    <div style={{position: "absolute", left: 70, width: 940, bottom: 205, display: "flex", justifyContent: "center", opacity: o}}>
      <div
        style={{
          fontFamily: BODY,
          fontWeight: 700,
          fontSize: 42,
          lineHeight: 1.3,
          textAlign: "center",
          background: INK,
          padding: "10px 26px",
          borderRadius: 28,
        }}
      >
        {spans}
      </div>
    </div>
  );
};
