import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {HEIGHT, INK, P, PAPER, WIDTH, pop, prog, useT} from "./config";
import {BODY, HEAD} from "./fonts";
import {Arrow, Brain, IconArrowIn, IconBox, IconMagnifier, WobbleDefs} from "./art";
import {Body, Card, Head, Marker, Sticker} from "./ui";

// ---------- Scene 1: pembuka ----------
export const Scene1: React.FC = () => {
  const t = useT();
  const lines = [
    {w: "BAGAIMANA", size: 124, t0: 0.05, bg: "transparent", color: INK, rot: -2},
    {w: "OTAK", size: 230, t0: 0.75, bg: P.pink, color: INK, rot: 1.5},
    {w: "MANUSIA", size: 176, t0: 1.15, bg: "transparent", color: INK, rot: -1},
    {w: "MENYIMPAN", size: 124, t0: 1.75, bg: P.blue, color: PAPER, rot: 1},
    {w: "INGATAN?", size: 150, t0: 2.2, bg: PAPER, color: INK, rot: -1.5},
  ];
  const brainP = pop(t, 1.0, 0.7);
  const qs = [
    {x: 230, y: 1290, r: -14, c: P.pink, d: 0},
    {x: 840, y: 1250, r: 12, c: P.blue, d: 1.3},
    {x: 760, y: 1500, r: 8, c: P.orange, d: 2.4},
  ];
  return (
    <AbsoluteFill>
      <div style={{position: "absolute", top: 290, left: 0, width: WIDTH, display: "flex", flexDirection: "column", alignItems: "center", gap: 14}}>
        {lines.map((l) => {
          const p = prog(t, l.t0, l.t0 + 0.3, Easing.out(Easing.back(2.2)));
          const boxed = l.bg !== "transparent";
          return (
            <div
              key={l.w}
              style={{
                fontFamily: HEAD,
                fontWeight: 400,
                fontSize: l.size,
                lineHeight: 1,
                color: l.color,
                background: l.bg,
                border: boxed ? `6px solid ${INK}` : "none",
                boxShadow: boxed ? `10px 10px 0 ${INK}` : "none",
                padding: boxed ? "4px 28px" : 0,
                borderRadius: 20,
                opacity: Math.min(1, p * 2.5),
                transform: `scale(${1.5 - 0.5 * p}) rotate(${l.rot * p}deg)`,
              }}
            >
              {l.w}
            </div>
          );
        })}
      </div>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g filter="url(#wobble)" opacity={Math.min(1, brainP)}>
          <Brain x={540} y={1310} s={0.6 * (0.7 + 0.3 * Math.min(1, brainP))} />
        </g>
        {qs.map((q, i) => (
          <text
            key={i}
            x={q.x}
            y={q.y + Math.sin(t * 3 + q.d) * 10}
            fontFamily={HEAD}
            fontSize={130}
            fill={q.c}
            stroke={INK}
            strokeWidth={6}
            textAnchor="middle"
            transform={`rotate(${q.r} ${q.x} ${q.y})`}
            opacity={Math.min(1, pop(t, 1.6 + i * 0.25, 0.4))}
          >
            ?
          </text>
        ))}
      </svg>
    </AbsoluteFill>
  );
};

// ---------- Scene 2: apa itu ingatan ----------
export const Scene2: React.FC = () => {
  const t = useT();
  const items = [
    {w: ["MEMPEROLEH"], size: 76, t0: 5.2, color: P.yellow, kind: 0},
    {w: ["MENYIMPAN"], size: 76, t0: 6.2, color: P.pink, kind: 1},
    {w: ["MENGAMBIL", "KEMBALI"], size: 62, t0: 7.2, color: P.mint, kind: 2},
  ];
  const head = prog(t, 3.2, 3.8);
  return (
    <AbsoluteFill>
      <Body y={310} size={50} w={920} x={80} opacity={head} dy={(1 - head) * 24}>
        Ingatan adalah kemampuan otak untuk:
      </Body>
      {items.map((it, i) => {
        const p = pop(t, it.t0, 0.55);
        return (
          <Card key={it.w[0]} x={80} y={470 + i * 270} w={920} h={230} color={it.color} p={p} rot={i === 1 ? 1.2 : -1.2}>
            <svg width={230} height={218} style={{position: "absolute", left: 0, top: 0}}>
              {it.kind === 0 ? <IconArrowIn x={115} y={109} s={1} color={PAPER} /> : null}
              {it.kind === 1 ? <IconBox x={115} y={109} s={1.15} color={PAPER} /> : null}
              {it.kind === 2 ? <IconMagnifier x={105} y={100} s={1} color={PAPER} /> : null}
            </svg>
            <div
              style={{
                position: "absolute",
                left: 230,
                top: 0,
                bottom: 0,
                right: 20,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                fontFamily: HEAD,
                fontSize: it.size,
                lineHeight: 1.02,
                color: INK,
              }}
            >
              {it.w.map((line) => (
                <div key={line}>{line}</div>
              ))}
            </div>
          </Card>
        );
      })}
      <Head y={1310} size={100} opacity={Math.min(1, pop(t, 8.3, 0.4) * 2)}>
        <Marker p={prog(t, 8.35, 8.9)} color={P.yellow}>
          INFORMASI
        </Marker>
      </Head>
    </AbsoluteFill>
  );
};

// ---------- Scene 3: tiga tahap ----------
export const Scene3: React.FC = () => {
  const t = useT();
  const steps = [
    {n: 1, term: "ENCODING", desc: "Mengubah informasi menjadi representasi yang dapat diproses otak", t0: 11.55, color: P.yellow},
    {n: 2, term: "STORAGE", desc: "Mempertahankan informasi dalam sistem memori", t0: 12.5, color: P.pink},
    {n: 3, term: "RETRIEVAL", desc: "Mengambil kembali informasi yang telah dipelajari atau dialami", t0: 13.35, color: P.mint},
  ];
  const h = pop(t, 9.6, 0.5);
  return (
    <AbsoluteFill>
      <Head y={310} size={112} opacity={Math.min(1, h * 2)} scale={0.8 + 0.2 * Math.min(1, h)}>
        3 TAHAP
      </Head>
      <Body y={435} size={38} weight={500} opacity={prog(t, 9.9, 10.5)}>
        dalam proses memori
      </Body>
      {steps.map((s, i) => {
        const p = pop(t, s.t0, 0.5);
        const y = 520 + i * 300;
        return (
          <Card key={s.term} x={80} y={y} w={920} h={250} color={s.color} p={p} rot={i === 1 ? 1 : -1}>
            <div
              style={{
                position: "absolute",
                left: 24,
                top: 59,
                width: 110,
                height: 110,
                borderRadius: 55,
                background: INK,
                color: PAPER,
                fontFamily: HEAD,
                fontSize: 64,
                lineHeight: "110px",
                textAlign: "center",
              }}
            >
              {s.n}
            </div>
            <div style={{position: "absolute", left: 160, right: 24, top: 22, fontFamily: HEAD, fontSize: 66, lineHeight: 1.05, color: INK}}>{s.term}</div>
            <div style={{position: "absolute", left: 160, right: 24, top: 100, fontFamily: BODY, fontWeight: 500, fontSize: 34, lineHeight: 1.22, color: INK}}>{s.desc}</div>
          </Card>
        );
      })}
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        {[0, 1].map((i) => (
          <g key={i} opacity={pop(t, steps[i + 1].t0 - 0.2, 0.3)}>
            <Arrow x1={540} y1={778 + i * 300} x2={540} y2={806 + i * 300} w={9} />
          </g>
        ))}
      </svg>
    </AbsoluteFill>
  );
};

// ---------- Scene 4: 86 miliar neuron ----------
const NODES: ReadonlyArray<readonly [number, number]> = [
  [140, 900], [330, 860], [520, 930], [720, 870], [930, 920],
  [210, 1060], [420, 1090], [630, 1050], [850, 1080],
  [120, 1230], [310, 1250], [520, 1220], [740, 1260], [940, 1230],
  [260, 1410], [470, 1400], [690, 1420], [880, 1400],
];
const NODE_COLORS = [P.yellow, P.pink, P.mint, P.blue, P.orange, P.lilac];
const EDGES: Array<[number, number]> = [];
for (let i = 0; i < NODES.length; i++) {
  for (let j = i + 1; j < NODES.length; j++) {
    const dx = NODES[i][0] - NODES[j][0];
    const dy = NODES[i][1] - NODES[j][1];
    if (Math.sqrt(dx * dx + dy * dy) < 270) EDGES.push([i, j]);
  }
}

export const Scene4: React.FC = () => {
  const t = useT();
  const count = Math.round(86 * prog(t, 15.0, 17.4, Easing.inOut(Easing.cubic)));
  const numP = pop(t, 14.9, 0.5);
  const nodeP = NODES.map((_, i) => pop(t, 15.2 + i * 0.13, 0.4));
  const hi = prog(t, 18.3, 18.9);
  const sin = pop(t, 19.0, 0.5);
  return (
    <AbsoluteFill>
      <Head y={270} size={330} color={P.pink} opacity={Math.min(1, numP * 2)} scale={0.8 + 0.2 * Math.min(1, numP)} lh={1}>
        <span style={{textShadow: `10px 10px 0 ${INK}`}}>{count}</span>
      </Head>
      <Head y={610} size={84} opacity={prog(t, 15.5, 16.0)}>
        MILIAR NEURON
      </Head>
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <WobbleDefs t={t} />
        <g filter="url(#wobble)">
          {EDGES.map(([a, b], k) => {
            const v = Math.min(1, nodeP[a], nodeP[b]);
            if (v <= 0) return null;
            const isSyn = a === 6 && b === 7;
            const w = isSyn ? 6 + 10 * hi : 5;
            return (
              <line
                key={k}
                x1={NODES[a][0]}
                y1={NODES[a][1]}
                x2={NODES[b][0]}
                y2={NODES[b][1]}
                stroke={isSyn && hi > 0 ? P.pink : INK}
                strokeWidth={w}
                strokeLinecap="round"
                opacity={isSyn ? 1 : 0.55 * v}
              />
            );
          })}
          {NODES.map(([x, y], i) => (
            <circle key={i} cx={x} cy={y} r={26 * Math.min(1.1, nodeP[i])} fill={NODE_COLORS[i % 6]} stroke={INK} strokeWidth={6} opacity={Math.min(1, nodeP[i] * 2)} />
          ))}
        </g>
        {EDGES.map(([a, b], k) => {
          const v = Math.min(1, nodeP[a], nodeP[b]);
          if (v < 1) return null;
          const u = (t * 0.5 + k * 0.37) % 1;
          return (
            <circle
              key={`p${k}`}
              cx={NODES[a][0] + (NODES[b][0] - NODES[a][0]) * u}
              cy={NODES[a][1] + (NODES[b][1] - NODES[a][1]) * u}
              r={8}
              fill={PAPER}
              stroke={INK}
              strokeWidth={4}
            />
          );
        })}
        <g opacity={Math.min(1, sin * 2)}>
          <Arrow x1={525} y1={1128} x2={525} y2={1082} w={8} />
        </g>
      </svg>
      <Sticker cx={525} cy={1175} color={P.pink} p={sin} size={52} rot={-3}>
        SINAPSIS
      </Sticker>
    </AbsoluteFill>
  );
};
