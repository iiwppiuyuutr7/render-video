import React from "react";
import {AbsoluteFill, Easing, Sequence, interpolate, useCurrentFrame} from "remotion";
import {INK, PAPER, SceneContext, WIDTH, sec} from "./config";
import {BODY, HEAD} from "./fonts";

const WIPE = 0.45;

const ChapterTag: React.FC<{num: number; label: string; accent: string; dark: boolean}> = ({num, label, accent, dark}) => (
  <div
    style={{
      position: "absolute",
      left: 52,
      top: 205,
      display: "flex",
      alignItems: "center",
      gap: 14,
      fontFamily: BODY,
      fontWeight: 700,
      fontSize: 30,
      letterSpacing: 1.5,
      color: dark ? INK : PAPER,
      background: dark ? PAPER : INK,
      padding: "8px 22px 8px 8px",
      borderRadius: 40,
    }}
  >
    <span
      style={{
        background: accent,
        color: INK,
        borderRadius: 30,
        padding: "2px 14px",
        fontFamily: HEAD,
        fontSize: 28,
        fontWeight: 400,
      }}
    >
      {String(num).padStart(2, "0")}
    </span>
    {label.toUpperCase()}
  </div>
);

const SceneBody: React.FC<{
  bg: string;
  accent: string;
  first: boolean;
  dark: boolean;
  num?: number;
  chapter?: string;
  children: React.ReactNode;
}> = ({bg, accent, first, dark, num, chapter, children}) => {
  const frame = useCurrentFrame();
  const p = first
    ? 1
    : interpolate(frame, [0, sec(WIPE)], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
        easing: Easing.inOut(Easing.cubic),
      });
  const dot = dark ? "rgba(255,255,255,0.10)" : "rgba(20,17,15,0.16)";
  return (
    <AbsoluteFill style={{background: bg, clipPath: p < 1 ? `inset(0 ${(1 - p) * 100}% 0 0)` : "none"}}>
      <AbsoluteFill style={{backgroundImage: `radial-gradient(${dot} 2.2px, transparent 2.6px)`, backgroundSize: "42px 42px"}} />
      {children}
      {chapter && num !== undefined ? <ChapterTag num={num} label={chapter} accent={accent} dark={dark} /> : null}
      {p < 1 ? (
        <div
          style={{
            position: "absolute",
            top: 0,
            bottom: 0,
            left: p * WIDTH - 54,
            width: 54,
            background: accent,
            borderLeft: `6px solid ${INK}`,
            borderRight: `6px solid ${INK}`,
            boxSizing: "border-box",
          }}
        />
      ) : null}
    </AbsoluteFill>
  );
};

// Scene baru "menyapu" masuk dari kiri; scene sebelumnya tetap tampil di bawahnya selama sapuan.
export const Scene: React.FC<{
  name: string;
  start: number;
  end: number;
  bg: string;
  accent: string;
  num?: number;
  chapter?: string;
  first?: boolean;
  last?: boolean;
  dark?: boolean;
  children: React.ReactNode;
}> = ({name, start, end, bg, accent, num, chapter, first = false, last = false, dark = false, children}) => (
  <Sequence name={name} from={sec(start)} durationInFrames={sec(end) - sec(start) + (last ? 0 : sec(WIPE))}>
    <SceneContext.Provider value={{offset: start}}>
      <SceneBody bg={bg} accent={accent} first={first} dark={dark} num={num} chapter={chapter}>
        {children}
      </SceneBody>
    </SceneContext.Provider>
  </Sequence>
);

export const Watermark: React.FC = () => {
  const frame = useCurrentFrame();
  const o = Math.min(1, frame / 30);
  return (
    <div
      style={{
        position: "absolute",
        left: 52,
        bottom: 108,
        display: "flex",
        alignItems: "center",
        gap: 12,
        fontFamily: BODY,
        fontWeight: 700,
        fontSize: 36,
        color: PAPER,
        background: INK,
        padding: "8px 24px 8px 18px",
        borderRadius: 40,
        opacity: 0.92 * o,
        letterSpacing: 0.5,
      }}
    >
      <div style={{width: 14, height: 14, borderRadius: 7, background: "#FFD23F"}} />
      @semestakita
    </div>
  );
};

// ---------- Elemen dasar ----------

export const Card: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  p?: number;
  rot?: number;
  radius?: number;
  shadow?: number;
  children?: React.ReactNode;
}> = ({x, y, w, h, color, p = 1, rot = 0, radius = 30, shadow = 12, children}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      height: h,
      background: color,
      border: `6px solid ${INK}`,
      borderRadius: radius,
      boxShadow: `${shadow}px ${shadow}px 0 ${INK}`,
      boxSizing: "border-box",
      opacity: Math.min(1, p * 2.2),
      transform: `scale(${0.6 + 0.4 * p}) rotate(${rot}deg)`,
      transformOrigin: "50% 50%",
    }}
  >
    {children}
  </div>
);

// Teks judul tebal. x,y = pojok kiri-atas kotak teks.
export const Head: React.FC<{
  y: number;
  size: number;
  children: React.ReactNode;
  x?: number;
  w?: number;
  color?: string;
  align?: "left" | "center" | "right";
  opacity?: number;
  dy?: number;
  rot?: number;
  scale?: number;
  lh?: number;
}> = ({y, size, children, x = 0, w = WIDTH, color = INK, align = "center", opacity = 1, dy = 0, rot = 0, scale = 1, lh = 1}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      textAlign: align,
      fontFamily: HEAD,
      fontWeight: 400,
      fontSize: size,
      lineHeight: lh,
      color,
      opacity,
      transform: `translateY(${dy}px) rotate(${rot}deg) scale(${scale})`,
    }}
  >
    {children}
  </div>
);

export const Body: React.FC<{
  y: number;
  size: number;
  children: React.ReactNode;
  x?: number;
  w?: number;
  color?: string;
  align?: "left" | "center" | "right";
  opacity?: number;
  dy?: number;
  weight?: 500 | 700;
  lh?: number;
}> = ({y, size, children, x = 0, w = WIDTH, color = INK, align = "center", opacity = 1, dy = 0, weight = 700, lh = 1.25}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: w,
      textAlign: align,
      fontFamily: BODY,
      fontWeight: weight,
      fontSize: size,
      lineHeight: lh,
      color,
      opacity,
      transform: `translateY(${dy}px)`,
    }}
  >
    {children}
  </div>
);

// Stiker bertepi tebal, posisi berdasarkan titik tengah.
export const Sticker: React.FC<{
  cx: number;
  cy: number;
  color: string;
  p: number;
  size?: number;
  rot?: number;
  textColor?: string;
  shadow?: number;
  children: React.ReactNode;
}> = ({cx, cy, color, p, size = 56, rot = -3, textColor = INK, shadow = 10, children}) => (
  <div
    style={{
      position: "absolute",
      left: cx,
      top: cy,
      transform: `translate(-50%, -50%) scale(${0.5 + 0.5 * p}) rotate(${rot}deg)`,
      opacity: Math.min(1, p * 2.2),
      background: color,
      border: `6px solid ${INK}`,
      borderRadius: 22,
      boxShadow: `${shadow}px ${shadow}px 0 ${INK}`,
      padding: "10px 26px",
      fontFamily: HEAD,
      fontWeight: 400,
      fontSize: size,
      lineHeight: 1.05,
      color: textColor,
      whiteSpace: "nowrap",
      textAlign: "center",
    }}
  >
    {children}
  </div>
);

// Stabilo di belakang kata.
export const Marker: React.FC<{p: number; color: string; h?: number; children: React.ReactNode}> = ({p, color, h = 64, children}) => (
  <span
    style={{
      backgroundImage: `linear-gradient(${color}, ${color})`,
      backgroundRepeat: "no-repeat",
      backgroundSize: `${Math.max(0, Math.min(1, p)) * 100}% ${h}%`,
      backgroundPosition: h >= 100 ? "0 50%" : "0 90%",
      padding: "0 12px",
    }}
  >
    {children}
  </span>
);
