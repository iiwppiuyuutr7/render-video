import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";

// ---- Pengaturan utama (satu sumber kebenaran untuk waktu) ----
export const COMPOSITION_ID = "OtakIngatan";
export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 93; // audio 92,29 dtk + jeda singkat di akhir
export const DURATION_FRAMES = DURATION_SEC * FPS;

export const sec = (s: number): number => Math.round(s * FPS);

// ---- Palet neo-brutalist: kertas krem, tinta hitam, warna jenuh ----
export const INK = "#14110F";
export const PAPER = "#F6F0E4";
export const P = {
  yellow: "#FFD23F",
  pink: "#FF5D8F",
  blue: "#3D6BFF",
  mint: "#35E0A1",
  orange: "#FF8A3D",
  lilac: "#B79CFF",
  indigo: "#23277A",
};
export const SOFT = {
  yellow: "#FFE58A",
  blue: "#D6E2FF",
  pink: "#FFD3E1",
  mint: "#CDF4E4",
  lilac: "#E3D8FF",
  orange: "#FFD9B8",
};

// Batas scene (detik), dipetakan ke jeda napas pada audio narasi.
export const T = {
  s1: [0, 3.0],
  s2: [3.0, 9.2],
  s3: [9.2, 14.6],
  s4: [14.6, 20.3],
  s5: [20.3, 27.6],
  s6: [27.6, 35.4],
  s7: [35.4, 43.5],
  s8: [43.5, 57.4],
  s9: [57.4, 71.0],
  s10: [71.0, 79.1],
  s11: [79.1, 87.7],
  s12: [87.7, DURATION_SEC],
} as const;

type EasingFn = (t: number) => number;

// Progres 0..1 antara detik a dan b (a harus < b).
export const prog = (
  t: number,
  a: number,
  b: number,
  easing: EasingFn = Easing.out(Easing.cubic),
): number =>
  interpolate(t, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing,
  });

// Muncul dengan sedikit memantul (boleh > 1 sesaat).
export const pop = (t: number, a: number, d = 0.5): number => prog(t, a, a + d, Easing.out(Easing.back(1.8)));

export const SceneContext = React.createContext<{offset: number}>({offset: 0});

// Waktu absolut (detik dari awal video) di dalam sebuah scene.
export const useT = (): number => {
  const frame = useCurrentFrame();
  const {offset} = React.useContext(SceneContext);
  return frame / FPS + offset;
};
