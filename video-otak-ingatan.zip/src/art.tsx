import React from "react";
import {INK, P, PAPER} from "./config";

// Garis tinta "bergetar" ala gambar tangan: filter hanya dipakai pada ilustrasi, bukan teks.
export const WobbleDefs: React.FC<{t: number}> = ({t}) => (
  <defs>
    <filter id="wobble" x="-5%" y="-5%" width="110%" height="110%">
      <feTurbulence type="fractalNoise" baseFrequency="0.025" numOctaves={2} seed={Math.floor(t * 8) % 6} result="n" />
      <feDisplacementMap in="SourceGraphic" in2="n" scale={5} xChannelSelector="R" yChannelSelector="G" />
    </filter>
  </defs>
);

export const ink = {
  stroke: INK,
  strokeWidth: 7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

// ---------- Blob "otak" ----------
const blob = (rx: number, ry: number, amp: number, k: number, phase: number, n = 140): string => {
  let d = "";
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    const r = 1 + amp * Math.sin(k * a + phase) + amp * 0.45 * Math.sin(2.7 * k * a + phase * 1.7);
    const x = rx * r * Math.cos(a);
    const y = ry * r * Math.sin(a);
    d += `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)} `;
  }
  return `${d}Z`;
};

const CEREBRUM = blob(300, 215, 0.045, 9, 0.5);
const CEREBELLUM = blob(115, 72, 0.06, 8, 1.0);
const FOLDS = [
  "M-210 -60 C-170 -120 -110 -100 -90 -50 S-30 -20 10 -70",
  "M-120 -150 C-60 -180 0 -150 20 -110 S90 -90 130 -140",
  "M60 -40 C110 -90 170 -70 190 -20 S230 20 250 -30",
  "M-250 20 C-210 -20 -160 10 -140 40 S-90 70 -50 30",
  "M20 20 C70 -10 120 20 140 60 S190 90 230 50",
];
const HIPPO = "M-120 110 C-70 55 20 60 70 115 C95 145 70 175 45 155";

// Posisi hippocampus di koordinat lokal otak.
export const HIPPO_POS = {x: -25, y: 112};

export const Brain: React.FC<{
  x: number;
  y: number;
  s?: number;
  fill?: string;
  hip?: number; // 0..1 gambar hippocampus
  hipPulse?: number; // 0..1 denyut
  temporal?: number; // 0..1 sorotan lobus temporal
  cortex?: number; // 0..1 sorotan korteks
  children?: React.ReactNode;
}> = ({x, y, s = 1, fill = "#FFB3C8", hip = 0, hipPulse = 0, temporal = 0, cortex = 0, children}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M40 190 C40 260 60 300 110 330 L170 330 C150 290 150 240 150 190 Z" fill="#FF8FB0" {...ink} />
    <g transform="translate(150 170)">
      <path d={CEREBELLUM} fill="#FF8FB0" {...ink} />
      <path d="M-70 -10 C-30 10 30 10 70 -10 M-80 20 C-30 40 30 40 80 20" fill="none" {...ink} strokeWidth={5} opacity={0.55} />
    </g>
    <path d={CEREBRUM} fill={fill} {...ink} />
    {cortex > 0 ? <path d={CEREBRUM} fill="none" stroke={P.blue} strokeWidth={30} opacity={0.5 * cortex} strokeLinejoin="round" /> : null}
    {FOLDS.map((d, i) => (
      <path key={i} d={d} fill="none" {...ink} strokeWidth={6} opacity={0.5} />
    ))}
    {temporal > 0 ? (
      <ellipse cx={-10} cy={118} rx={190} ry={68} transform="rotate(-6 -10 118)" fill={P.blue} opacity={0.42 * temporal} stroke={INK} strokeWidth={5} strokeDasharray="14 12" />
    ) : null}
    {hip > 0 ? (
      <g>
        <path d={HIPPO} fill="none" stroke={INK} strokeWidth={46 + 8 * hipPulse} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${hip} 1`} />
        <path d={HIPPO} fill="none" stroke={P.pink} strokeWidth={28 + 8 * hipPulse} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={`${hip} 1`} />
      </g>
    ) : null}
    {children}
  </g>
);

// ---------- Neuron ----------
const DENDRITES: ReadonlyArray<readonly [number, number]> = [
  [150, 120],
  [185, 100],
  [215, 125],
  [250, 105],
  [120, 90],
  [285, 95],
];

const bez = (u: number, p0: number[], p1: number[], p2: number[], p3: number[]): [number, number] => {
  const v = 1 - u;
  const x = v * v * v * p0[0] + 3 * v * v * u * p1[0] + 3 * v * u * u * p2[0] + u * u * u * p3[0];
  const y = v * v * v * p0[1] + 3 * v * v * u * p1[1] + 3 * v * u * u * p2[1] + u * u * u * p3[1];
  return [x, y];
};

export const Neuron: React.FC<{
  x: number;
  y: number;
  s?: number;
  color: string;
  t: number;
  flip?: boolean;
  pulse?: boolean;
  glow?: number; // 0..1 menyala
}> = ({x, y, s = 1, color, t, flip = false, pulse = true, glow = 0}) => {
  const u = (t * 0.7) % 1;
  const [px, py] = bez(u, [44, 0], [120, -30], [180, 30], [250, 5]);
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      {DENDRITES.map(([ang, len], i) => {
        const a = (ang * Math.PI) / 180;
        const x1 = Math.cos(a) * 40;
        const y1 = Math.sin(a) * 40;
        const x2 = Math.cos(a) * len;
        const y2 = Math.sin(a) * len;
        const f1 = a + 0.55;
        const f2 = a - 0.55;
        const mx = Math.cos(a) * len * 0.6;
        const my = Math.sin(a) * len * 0.6;
        return (
          <path
            key={i}
            d={`M${x1} ${y1} L${x2} ${y2} M${mx} ${my} L${mx + Math.cos(f1) * 40} ${my + Math.sin(f1) * 40} M${mx} ${my} L${mx + Math.cos(f2) * 40} ${my + Math.sin(f2) * 40}`}
            fill="none"
            {...ink}
            strokeWidth={6}
          />
        );
      })}
      <path d="M44 0 C120 -30 180 30 250 5" fill="none" {...ink} strokeWidth={6} />
      <circle cx={256} cy={5} r={12} fill={color} {...ink} strokeWidth={5} />
      <path d="M250 5 L282 -22 M250 5 L284 24" fill="none" {...ink} strokeWidth={5} />
      {glow > 0 ? <circle r={44 + 40 * glow} fill={color} opacity={0.35 * glow} /> : null}
      <circle r={44} fill={color} {...ink} />
      <circle cx={-8} cy={-6} r={14} fill={INK} opacity={0.75} />
      {pulse ? <circle cx={px} cy={py} r={9} fill={PAPER} stroke={INK} strokeWidth={4} /> : null}
    </g>
  );
};

// ---------- Ikon ----------
type IconProps = {x: number; y: number; s?: number; color?: string};
const G: React.FC<IconProps & {children: React.ReactNode}> = ({x, y, s = 1, children}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>{children}</g>
);

export const IconEye: React.FC<IconProps> = ({x, y, s, color = P.blue}) => (
  <G x={x} y={y} s={s}>
    <path d="M-62 0 Q0 -54 62 0 Q0 54 -62 0 Z" fill={PAPER} {...ink} />
    <circle r={22} fill={color} {...ink} />
    <circle cx={-6} cy={-6} r={6} fill={PAPER} />
  </G>
);

export const IconEar: React.FC<IconProps> = ({x, y, s, color = P.orange}) => (
  <G x={x} y={y} s={s}>
    <path d="M-14 -56 C44 -66 62 2 28 34 C12 52 28 70 6 78 C-24 84 -36 56 -26 36" fill={color} {...ink} />
    <path d="M-6 -30 C22 -34 32 -6 14 12 C2 24 10 36 0 42" fill="none" {...ink} strokeWidth={5} />
  </G>
);

export const IconHeart: React.FC<IconProps> = ({x, y, s, color = P.pink}) => (
  <G x={x} y={y} s={s}>
    <path d="M0 44 C-78 -8 -50 -66 0 -28 C50 -66 78 -8 0 44 Z" fill={color} {...ink} />
  </G>
);

export const IconPin: React.FC<IconProps> = ({x, y, s, color = P.mint}) => (
  <G x={x} y={y} s={s}>
    <path d="M0 62 C-44 12 -44 -8 -44 -22 A44 44 0 1 1 44 -22 C44 -8 44 12 0 62 Z" fill={color} {...ink} />
    <circle cy={-22} r={15} fill={PAPER} {...ink} strokeWidth={5} />
  </G>
);

export const IconMoon: React.FC<IconProps> = ({x, y, s, color = P.yellow}) => (
  <G x={x} y={y} s={s}>
    <path d="M-1.1 -80 A80 80 0 1 0 75.3 27 A66 66 0 0 1 -1.1 -80 Z" fill={color} {...ink} />
  </G>
);

export const IconSun: React.FC<IconProps> = ({x, y, s, color = P.yellow}) => (
  <G x={x} y={y} s={s}>
    {Array.from({length: 10}).map((_, i) => {
      const a = (i / 10) * Math.PI * 2;
      return <line key={i} x1={Math.cos(a) * 56} y1={Math.sin(a) * 56} x2={Math.cos(a) * 84} y2={Math.sin(a) * 84} {...ink} strokeWidth={8} />;
    })}
    <circle r={42} fill={color} {...ink} />
  </G>
);

export const IconBook: React.FC<IconProps> = ({x, y, s, color = P.blue}) => (
  <G x={x} y={y} s={s}>
    <path d="M-4 -44 C-30 -58 -62 -54 -72 -44 L-72 44 C-62 34 -30 30 -4 44 Z" fill={color} {...ink} />
    <path d="M4 -44 C30 -58 62 -54 72 -44 L72 44 C62 34 30 30 4 44 Z" fill={PAPER} {...ink} />
    <path d="M18 -22 L56 -26 M18 -2 L56 -6 M18 18 L56 14" fill="none" {...ink} strokeWidth={5} />
  </G>
);

export const IconLock: React.FC<IconProps> = ({x, y, s, color = P.yellow}) => (
  <G x={x} y={y} s={s}>
    <path d="M-28 -12 L-28 -34 A28 28 0 0 1 28 -34 L28 -12" fill="none" {...ink} strokeWidth={9} />
    <rect x={-46} y={-14} width={92} height={70} rx={14} fill={color} {...ink} />
    <circle cy={18} r={9} fill={INK} />
  </G>
);

export const IconMagnifier: React.FC<IconProps> = ({x, y, s, color = P.blue}) => (
  <G x={x} y={y} s={s}>
    <line x1={26} y1={26} x2={76} y2={76} {...ink} strokeWidth={20} />
    <circle cx={-6} cy={-6} r={44} fill={color} fillOpacity={0.28} {...ink} strokeWidth={9} />
    <path d="M-30 -14 A28 28 0 0 1 -12 -32" fill="none" stroke={PAPER} strokeWidth={7} strokeLinecap="round" />
  </G>
);

export const IconWarehouse: React.FC<IconProps> = ({x, y, s, color = P.orange}) => (
  <G x={x} y={y} s={s}>
    <path d="M-90 -20 L0 -84 L90 -20 L90 70 L-90 70 Z" fill={color} {...ink} />
    <rect x={-34} y={8} width={68} height={62} fill={PAPER} {...ink} />
    <path d="M-34 8 L34 70 M34 8 L-34 70" fill="none" {...ink} strokeWidth={5} />
  </G>
);

export const IconPlay: React.FC<IconProps> = ({x, y, s, color = P.blue}) => (
  <G x={x} y={y} s={s}>
    <rect x={-92} y={-62} width={184} height={124} rx={22} fill={color} {...ink} />
    <path d="M-24 -34 L40 0 L-24 34 Z" fill={PAPER} {...ink} strokeWidth={6} />
  </G>
);

export const IconArrowIn: React.FC<IconProps & {up?: boolean}> = ({x, y, s, color = P.blue, up = false}) => (
  <G x={x} y={y} s={s}>
    <circle r={60} fill={color} {...ink} />
    <g transform={up ? "rotate(180)" : undefined}>
      <path d="M0 -30 L0 26 M-24 2 L0 28 L24 2" fill="none" {...ink} strokeWidth={9} />
    </g>
  </G>
);

export const IconBox: React.FC<IconProps> = ({x, y, s, color = P.pink}) => (
  <G x={x} y={y} s={s}>
    <rect x={-58} y={-40} width={116} height={92} rx={12} fill={color} {...ink} />
    <path d="M-58 -10 L58 -10" fill="none" {...ink} strokeWidth={6} />
    <rect x={-18} y={-18} width={36} height={22} rx={6} fill={PAPER} {...ink} strokeWidth={5} />
  </G>
);

export const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; w?: number; color?: string}> = ({x1, y1, x2, y2, w = 8, color = INK}) => {
  const a = Math.atan2(y2 - y1, x2 - x1);
  const h = 22;
  return (
    <g stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" fill="none">
      <line x1={x1} y1={y1} x2={x2} y2={y2} />
      <path d={`M${x2 - Math.cos(a - 0.5) * h} ${y2 - Math.sin(a - 0.5) * h} L${x2} ${y2} L${x2 - Math.cos(a + 0.5) * h} ${y2 - Math.sin(a + 0.5) * h}`} />
    </g>
  );
};
