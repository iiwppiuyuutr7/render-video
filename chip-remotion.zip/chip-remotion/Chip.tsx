// @ts-nocheck
import React, {useLayoutEffect, useRef} from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

/**
 * Video 3D "Bagaimana manusia membuat komponen komputer sekecil debu?"
 * Gaya infografis isometrik terang, 1080x1920, 60 fps, 5850 frame (97,5 detik).
 * 3D WebGL asli (engine sendiri, tanpa library tambahan) dalam satu file.
 * Semua dihitung dari nomor frame, jadi aman dirender Remotion.
 * Audio: public/audio.mp3 (narasi + SFX + musik, sudah dimix).
 */
function createEngine(outc) {
  const ENGINE = {};
'use strict';
/* Mesin 3D WebGL minimal (tanpa library). Dipakai untuk render video lewat Chromium. */
const CW = window.OUT_W || 1080, CH = window.OUT_H || 1920;
const glc = document.createElement('canvas'); glc.width = CW; glc.height = CH;
const gl = glc.getContext('webgl', {antialias: true, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance'});
outc.width = CW; outc.height = CH;
const ctx = outc.getContext('2d');
const SC = CH / 1920; // skala UI relatif ke desain 1080x1920

/* ---------- util ---------- */
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, k) => a + (b - a) * k;
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const eio = (t) => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const eout = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
const ein = (t) => Math.pow(clamp(t, 0, 1), 3);
const eoutB = (t) => { t = clamp(t, 0, 1); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const ramp = (t, a, b) => clamp((t - a) / (b - a), 0, 1);
const win = (t, a, b, f = .3) => clamp((t - a) / f, 0, 1) * clamp((b - t) / f, 0, 1);
function hash(n) { n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n ^= n >>> 16; return (n >>> 0) / 4294967296; }
const R = (i, s = 0) => hash((i * 7919 + s * 104729) | 0);
function noise2(x, y, s = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const a = R(xi * 73856093 ^ yi * 19349663, s), b = R((xi + 1) * 73856093 ^ yi * 19349663, s), c = R(xi * 73856093 ^ (yi + 1) * 19349663, s), d = R((xi + 1) * 73856093 ^ (yi + 1) * 19349663, s);
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
const fbm = (x, y, s = 0) => noise2(x, y, s) * .55 + noise2(x * 2.1, y * 2.1, s + 1) * .28 + noise2(x * 4.3, y * 4.3, s + 2) * .17;
const hexc = (h) => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
const mixc = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const scl = (a, k) => [a[0] * k, a[1] * k, a[2] * k];

/* ---------- vektor & matriks ---------- */
const vadd = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const vsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const vmul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const vdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const vcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const vlen = (a) => Math.hypot(a[0], a[1], a[2]);
const vnorm = (a) => { const l = vlen(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const vlerp = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const ident = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
function mmul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
const mT = (x, y, z) => { const m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; };
const mS = (x, y = x, z = x) => { const m = ident(); m[0] = x; m[5] = y; m[10] = z; return m; };
const mRx = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; };
const mRy = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; };
const mRz = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; };
function mPersp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), m = new Float32Array(16); m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m; }
function mLook(e, t, up) { const z = vnorm(vsub(e, t)), x = vnorm(vcross(up, z)), y = vcross(z, x); const m = ident(); m[0] = x[0]; m[4] = x[1]; m[8] = x[2]; m[1] = y[0]; m[5] = y[1]; m[9] = y[2]; m[2] = z[0]; m[6] = z[1]; m[10] = z[2]; m[12] = -vdot(x, e); m[13] = -vdot(y, e); m[14] = -vdot(z, e); return m; }
function mApply(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; }
function mApplyN(m, n) { return vnorm([m[0] * n[0] + m[4] * n[1] + m[8] * n[2], m[1] * n[0] + m[5] * n[1] + m[9] * n[2], m[2] * n[0] + m[6] * n[1] + m[10] * n[2]]); }
function normalMat(m) { // inverse transpose 3x3
  const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
  const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
  const det = a * A + b * B + c * C || 1;
  return new Float32Array([A / det, B / det, C / det, -(b * i - c * h) / det, (a * i - c * g) / det, -(a * h - b * g) / det, (b * f - c * e) / det, -(a * f - c * d) / det, (a * e - b * d) / det]);
}
const TRS = (p, r = [0, 0, 0], s = [1, 1, 1]) => mmul(mT(p[0], p[1], p[2]), mmul(mRy(r[1]), mmul(mRx(r[0]), mmul(mRz(r[2]), mS(s[0], s[1], s[2])))));

/* ---------- mesh builder ---------- */
class B {
  constructor() { this.p = []; this.n = []; this.c = []; this.m = ident(); this.st = []; }
  push() { this.st.push(this.m); return this; }
  pop() { this.m = this.st.pop(); return this; }
  T(x, y, z) { this.m = mmul(this.m, mT(x, y, z)); return this; }
  S(x, y, z) { this.m = mmul(this.m, mS(x, y === undefined ? x : y, z === undefined ? x : z)); return this; }
  Rx(a) { this.m = mmul(this.m, mRx(a)); return this; }
  Ry(a) { this.m = mmul(this.m, mRy(a)); return this; }
  Rz(a) { this.m = mmul(this.m, mRz(a)); return this; }
  v(p, n, c) { const q = mApply(this.m, p), nn = mApplyN(this.m, n); this.p.push(q[0], q[1], q[2]); this.n.push(nn[0], nn[1], nn[2]); this.c.push(c[0], c[1], c[2]); }
  tri(a, b, c, ca, cb = ca, cc = ca, n) { n = n || vnorm(vcross(vsub(b, a), vsub(c, a))); this.v(a, n, ca); this.v(b, n, cb); this.v(c, n, cc); }
  quad(a, b, c, d, ca, cb = ca, cc = ca, cd = ca) { const n = vnorm(vcross(vsub(b, a), vsub(d, a))); this.tri(a, b, c, ca, cb, cc, n); this.tri(a, c, d, ca, cc, cd, n); }
  build() { return mkMesh(this.p, this.n, this.c); }
}
function mkMesh(p, n, c) {
  const mk = (arr) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STATIC_DRAW); return b; };
  return {bp: mk(p), bn: mk(n), bc: mk(c), count: p.length / 3};
}
function box(b, x, y, z, sx, sy, sz, col, jit = 0, seed = 0) {
  const hx = sx / 2, hy = sy / 2, hz = sz / 2;
  const P = [[x - hx, y - hy, z - hz], [x + hx, y - hy, z - hz], [x + hx, y + hy, z - hz], [x - hx, y + hy, z - hz], [x - hx, y - hy, z + hz], [x + hx, y - hy, z + hz], [x + hx, y + hy, z + hz], [x - hx, y + hy, z + hz]];
  const F = [[4, 5, 6, 7], [1, 0, 3, 2], [5, 1, 2, 6], [0, 4, 7, 3], [7, 6, 2, 3], [0, 1, 5, 4]];
  F.forEach((f, i) => { const k = 1 + (R(i + seed * 13, seed) - .5) * jit; const cc = scl(col, k); b.quad(P[f[0]], P[f[1]], P[f[2]], P[f[3]], cc); });
}
function cyl(b, p0, p1, r0, r1, seg, col, caps = true, col1) {
  const ax = vsub(p1, p0), L = vlen(ax); if (L < 1e-6) return;
  const a = vnorm(ax); const t = Math.abs(a[1]) < .9 ? [0, 1, 0] : [1, 0, 0];
  const u = vnorm(vcross(a, t)), v = vcross(a, u); col1 = col1 || col;
  const dir = (i) => vadd(vmul(u, Math.cos(i / seg * 6.2832)), vmul(v, Math.sin(i / seg * 6.2832)));
  const sl = (r0 - r1) / L;
  for (let i = 0; i < seg; i++) {
    const d0 = dir(i), d1 = dir(i + 1);
    const a0 = vadd(p0, vmul(d0, r0)), a1 = vadd(p0, vmul(d1, r0)), b0 = vadd(p1, vmul(d0, r1)), b1 = vadd(p1, vmul(d1, r1));
    const n0 = vnorm(vadd(d0, vmul(a, sl))), n1 = vnorm(vadd(d1, vmul(a, sl)));
    b.v(a0, n0, col); b.v(a1, n1, col); b.v(b1, n1, col1);
    b.v(a0, n0, col); b.v(b1, n1, col1); b.v(b0, n0, col1);
    if (caps) {
      if (r1 > 0) { b.v(p1, a, col1); b.v(b0, a, col1); b.v(b1, a, col1); }
      if (r0 > 0) { const na = vmul(a, -1); b.v(p0, na, col); b.v(a1, na, col); b.v(a0, na, col); }
    }
  }
}
function sphere(b, c, r, col, lat = 10, lon = 14, sy = 1) {
  for (let i = 0; i < lat; i++) {
    const t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
    for (let j = 0; j < lon; j++) {
      const p0 = 6.2832 * j / lon, p1 = 6.2832 * (j + 1) / lon;
      const P = (t, p) => [Math.sin(t) * Math.cos(p), Math.cos(t), Math.sin(t) * Math.sin(p)];
      const A = P(t0, p0), Bq = P(t0, p1), C = P(t1, p1), D = P(t1, p0);
      const pt = (n) => [c[0] + n[0] * r, c[1] + n[1] * r * sy, c[2] + n[2] * r];
      b.v(pt(A), A, col); b.v(pt(D), D, col); b.v(pt(C), C, col);
      b.v(pt(A), A, col); b.v(pt(C), C, col); b.v(pt(Bq), Bq, col);
    }
  }
}
function torus(b, R0, r0, segs, sides, col) {
  const P = (i, j) => { const u = 6.2832 * i / segs, v = 6.2832 * j / sides; const cx = Math.cos(u) * R0, cy = Math.sin(u) * R0; const nx = Math.cos(u) * Math.cos(v), ny = Math.sin(u) * Math.cos(v), nz = Math.sin(v); return [[cx + nx * r0, cy + ny * r0, nz * r0], [nx, ny, nz]]; };
  for (let i = 0; i < segs; i++) for (let j = 0; j < sides; j++) {
    const a = P(i, j), c = P(i + 1, j), d = P(i + 1, j + 1), e = P(i, j + 1);
    b.v(a[0], a[1], col); b.v(c[0], c[1], col); b.v(d[0], d[1], col); b.v(a[0], a[1], col); b.v(d[0], d[1], col); b.v(e[0], e[1], col);
  }
}
// permukaan grid dengan warna per-vertex bergoyang (tekstur batu murah)
function grid(b, o, u, v, nu, nv, col, jit, seed, flip) {
  const n = vnorm(vcross(u, v)); const nn = flip ? vmul(n, -1) : n;
  const P = (i, j) => vadd(o, vadd(vmul(u, i / nu), vmul(v, j / nv)));
  const C = (i, j) => scl(col, 1 + (fbm(i * .55 + seed, j * .9 + seed * 3, seed) - .5) * jit * 2 + (R(i * 131 + j * 17 + seed, seed) - .5) * jit * .5);
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), d = P(i, j + 1);
    const ca = C(i, j), cb = C(i + 1, j), cc = C(i + 1, j + 1), cd = C(i, j + 1);
    if (!flip) { b.v(a, nn, ca); b.v(bb, nn, cb); b.v(c, nn, cc); b.v(a, nn, ca); b.v(c, nn, cc); b.v(d, nn, cd); }
    else { b.v(a, nn, ca); b.v(c, nn, cc); b.v(bb, nn, cb); b.v(a, nn, ca); b.v(d, nn, cd); b.v(c, nn, cc); }
  }
}
function hfield(b, x0, z0, w, d, nx, nz, fh, fc) {
  const H_ = (i, j) => fh(x0 + w * i / nx, z0 + d * j / nz);
  const P = (i, j) => [x0 + w * i / nx, H_(i, j), z0 + d * j / nz];
  const N = (i, j) => { const e = .5; const hx = fh(x0 + w * i / nx + e, z0 + d * j / nz) - fh(x0 + w * i / nx - e, z0 + d * j / nz); const hz = fh(x0 + w * i / nx, z0 + d * j / nz + e) - fh(x0 + w * i / nx, z0 + d * j / nz - e); return vnorm([-hx / (2 * e), 1, -hz / (2 * e)]); };
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), dd = P(i, j + 1);
    const na = N(i, j), nb = N(i + 1, j), nc = N(i + 1, j + 1), nd = N(i, j + 1);
    b.v(a, na, fc(a)); b.v(c, nc, fc(c)); b.v(bb, nb, fc(bb)); b.v(a, na, fc(a)); b.v(dd, nd, fc(dd)); b.v(c, nc, fc(c));
  }
}

/* ---------- shader ---------- */
function prog(vs, fs) {
  const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
  const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const inf = gl.getActiveUniform(p, i); u[inf.name] = gl.getUniformLocation(p, inf.name); }
  return {p, u};
}
const MESH = prog(`
attribute vec3 aP; attribute vec3 aN; attribute vec3 aC;
uniform mat4 uVP; uniform mat4 uM; uniform mat3 uNM;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
void main(){ vec4 w=uM*vec4(aP,1.0); vW=w.xyz; vN=normalize(uNM*aN); vC=aC; gl_Position=uVP*w; }`, `
precision highp float;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
uniform vec3 uLD; uniform vec3 uLC; uniform vec3 uAT; uniform vec3 uAB; uniform vec3 uCam; uniform vec3 uFog; uniform float uFD;
uniform vec3 uTint; uniform float uEm; uniform float uAl; uniform float uSp; uniform float uRim; uniform vec3 uRC; uniform vec3 uL2D; uniform vec3 uL2C; uniform float uClip;
void main(){
  if(uClip>-900.0 && vW.y>uClip) discard;
  vec3 n=normalize(vN); vec3 v=normalize(uCam-vW);
  float d=max(dot(n,-uLD),0.0); float d2=max(dot(n,-uL2D),0.0);
  vec3 hemi=mix(uAB,uAT,n.y*0.5+0.5);
  vec3 base=vC*uTint;
  vec3 h=normalize(v-uLD); float s=pow(max(dot(n,h),0.0),28.0)*uSp;
  float rim=pow(1.0-max(dot(n,v),0.0),3.0)*uRim;
  vec3 col=base*(hemi+uLC*d+uL2C*d2)+uLC*s+uRC*rim+base*uEm;
  float dist=length(uCam-vW); float f=1.0-exp(-dist*uFD*0.12-dist*dist*uFD*0.004);
  col=mix(col,uFog,clamp(f,0.0,1.0));
  gl_FragColor=vec4(col,uAl);
}`);
const PART = prog(`
attribute vec3 aP; attribute vec2 aU; attribute vec4 aC; attribute float aS;
uniform mat4 uVP; varying vec2 vU; varying vec4 vC; varying float vS;
void main(){ vU=aU; vC=aC; vS=aS; gl_Position=uVP*vec4(aP,1.0); }`, `
precision highp float;
varying vec2 vU; varying vec4 vC; varying float vS;
void main(){
  float a;
  if(vS<0.5){ float r=length(vU); a=smoothstep(1.0,0.0,r); a=a*a*(3.0-2.0*a); }
  else if(vS<1.5){ float r=length(vU); a=smoothstep(1.0,0.78,r)*smoothstep(0.0,0.15,r+0.0); a=min(1.0,a)*(1.0-0.45*smoothstep(0.5,1.0,r)); }
  else { a=smoothstep(1.0,0.0,abs(vU.x)); a=a*a; a*=smoothstep(1.0,0.85,abs(vU.y)); }
  gl_FragColor=vec4(vC.rgb*vC.a*a, vC.a*a);
}`);
function attr(p, name, buf, size) { const l = gl.getAttribLocation(p, name); if (l < 0) return; gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0); }

/* ---------- scene state ---------- */
const LT = {ld: vnorm([-.4, -.8, -.45]), lc: [1, .95, .85], at: [.35, .38, .45], ab: [.12, .1, .1], fog: [.03, .03, .05], fd: .02, rc: [.2, .3, .5], l2d: [.5, -.2, .6], l2c: [0, 0, 0], clip: -1000};
const CAM = {eye: [0, 3, 10], tgt: [0, 1, 0], fov: 50, roll: 0, up: [0, 1, 0]};
let VP = ident(), VIEW = ident(), PRJ = ident(), CR = [1, 0, 0], CU = [0, 1, 0], CF = [0, 0, -1];
function setCam() {
  const e = CAM.eye, t = CAM.tgt;
  let up = CAM.up; if (CAM.roll) { const f = vnorm(vsub(t, e)); const r = vnorm(vcross(f, [0, 1, 0])); up = vadd(vmul([0, 1, 0], Math.cos(CAM.roll)), vmul(r, Math.sin(CAM.roll))); }
  VIEW = mLook(e, t, up); PRJ = mPersp(CAM.fov * Math.PI / 180, CW / CH, .1, 600); VP = mmul(PRJ, VIEW);
  CF = vnorm(vsub(t, e)); CR = vnorm(vcross(CF, up)); CU = vcross(CR, CF);
}
function useMesh() { gl.useProgram(MESH.p); const u = MESH.u; gl.uniformMatrix4fv(u.uVP, false, VP); gl.uniform3fv(u.uLD, LT.ld); gl.uniform3fv(u.uLC, LT.lc); gl.uniform3fv(u.uAT, LT.at); gl.uniform3fv(u.uAB, LT.ab); gl.uniform3fv(u.uCam, CAM.eye); gl.uniform3fv(u.uFog, LT.fog); gl.uniform1f(u.uFD, LT.fd); gl.uniform3fv(u.uRC, LT.rc); gl.uniform3fv(u.uL2D, LT.l2d); gl.uniform3fv(u.uL2C, LT.l2c); }
function draw(mesh, M, o = {}) {
  const u = MESH.u; if (!mesh || !mesh.count) return;
  gl.uniformMatrix4fv(u.uM, false, M || ident()); gl.uniformMatrix3fv(u.uNM, false, normalMat(M || ident()));
  gl.uniform3fv(u.uTint, o.tint || [1, 1, 1]); gl.uniform1f(u.uEm, o.em || 0); gl.uniform1f(u.uAl, o.al === undefined ? 1 : o.al); gl.uniform1f(u.uSp, o.sp === undefined ? .15 : o.sp); gl.uniform1f(u.uRim, o.rim === undefined ? .25 : o.rim);
  gl.uniform1f(u.uClip, o.clip === undefined ? LT.clip : o.clip);
  attr(MESH.p, 'aP', mesh.bp, 3); attr(MESH.p, 'aN', mesh.bn, 3); attr(MESH.p, 'aC', mesh.bc, 3);
  if (o.al !== undefined && o.al < 1) { gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(o.dw === true); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
  gl.drawArrays(gl.TRIANGLES, 0, mesh.count);
}
/* partikel / billboard */
const PB = {add: [], alp: []};
function pt(list, p, size, col, a = 1, shape = 0) { // lingkaran billboard
  const r = vmul(CR, size), u = vmul(CU, size);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(vsub(p, r), u), Bq = vsub(vadd(p, r), u), C_ = vadd(vadd(p, r), u), D = vadd(vsub(p, r), u);
  list.push([A, -1, -1, c, shape], [Bq, 1, -1, c, shape], [C_, 1, 1, c, shape], [A, -1, -1, c, shape], [C_, 1, 1, c, shape], [D, -1, 1, c, shape]);
}
function beam(list, p0, p1, w, col, a = 1) {
  const d = vsub(p1, p0), mid = vmul(vadd(p0, p1), .5); const toC = vsub(CAM.eye, mid); let s = vcross(d, toC); s = vnorm(s); s = vmul(s, w);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(p0, s), Bq = vadd(p0, s), C_ = vadd(p1, s), D = vsub(p1, s);
  list.push([A, -1, -1, c, 2], [Bq, 1, -1, c, 2], [C_, 1, 1, c, 2], [A, -1, -1, c, 2], [C_, 1, 1, c, 2], [D, -1, 1, c, 2]);
}
const pbuf = {p: gl.createBuffer(), u: gl.createBuffer(), c: gl.createBuffer(), s: gl.createBuffer()};
function flushList(list, additive) {
  if (!list.length) return;
  const P = new Float32Array(list.length * 3), U = new Float32Array(list.length * 2), Cc = new Float32Array(list.length * 4), S = new Float32Array(list.length);
  list.forEach((v, i) => { P[i * 3] = v[0][0]; P[i * 3 + 1] = v[0][1]; P[i * 3 + 2] = v[0][2]; U[i * 2] = v[1]; U[i * 2 + 1] = v[2]; Cc.set(v[3], i * 4); S[i] = v[4]; });
  gl.useProgram(PART.p); gl.uniformMatrix4fv(PART.u.uVP, false, VP);
  const up = (b, d) => { gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, d, gl.DYNAMIC_DRAW); };
  up(pbuf.p, P); attr(PART.p, 'aP', pbuf.p, 3); up(pbuf.u, U); attr(PART.p, 'aU', pbuf.u, 2); up(pbuf.c, Cc); attr(PART.p, 'aC', pbuf.c, 4); up(pbuf.s, S); attr(PART.p, 'aS', pbuf.s, 1);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
  gl.drawArrays(gl.TRIANGLES, 0, list.length); gl.depthMask(true);
  list.length = 0;
}
function flushParticles() { flushList(PB.alp, false); flushList(PB.add, true); }
function beginFrame() { gl.depthMask(true); gl.disable(gl.BLEND); gl.viewport(0, 0, CW, CH); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.disable(gl.CULL_FACE); setCam(); useMesh(); }
function proj(p) { // dunia -> layar (px output)
  const c = mApply(VIEW, p); const w = -c[2]; if (w < .05) return {x: 0, y: 0, z: w, vis: false, s: 0};
  const t = 1 / Math.tan(CAM.fov * Math.PI / 360);
  const x = (c[0] * t / (CW / CH)) / w, y = (c[1] * t) / w;
  return {x: (x * .5 + .5) * CW, y: (1 - (y * .5 + .5)) * CH, z: w, vis: Math.abs(x) < 1.3 && Math.abs(y) < 1.3, s: (CH / 2) * t / w};
}

const WORDS=[{"w": "Ada", "a": 0.05, "e": 0.398, "b": null}, {"w": "chip", "a": 0.398, "e": 0.571, "b": null}, {"w": "di", "a": 0.571, "e": 0.745, "b": null}, {"w": "HP-mu", "a": 0.745, "e": 1.266, "b": null}, {"w": "yang", "a": 1.266, "e": 1.44, "b": null}, {"w": "berisi", "a": 1.44, "e": 1.961, "b": null}, {"w": "puluhan", "a": 1.961, "e": 2.482, "b": null}, {"w": "miliar", "a": 2.482, "e": 3.004, "b": null}, {"w": "komponen,", "a": 3.004, "e": 3.525, "b": "weak"}, {"w": "masing-masing", "a": 3.853, "e": 4.531, "b": null}, {"w": "lebih", "a": 4.531, "e": 4.87, "b": null}, {"w": "kecil", "a": 4.87, "e": 5.209, "b": null}, {"w": "dari", "a": 5.209, "e": 5.548, "b": null}, {"w": "debu.", "a": 5.548, "e": 5.887, "b": "strong"}, {"w": "Bagaimana", "a": 6.37, "e": 6.875, "b": null}, {"w": "manusia", "a": 6.875, "e": 7.38, "b": null}, {"w": "bisa", "a": 7.38, "e": 7.632, "b": null}, {"w": "membuatnya?", "a": 7.632, "e": 8.137, "b": "strong"}, {"w": "Ceritanya", "a": 8.662, "e": 9.235, "b": null}, {"w": "dimulai", "a": 9.235, "e": 9.664, "b": null}, {"w": "tahun", "a": 9.664, "e": 9.95, "b": null}, {"w": "1946,", "a": 9.95, "e": 11.954, "b": "weak"}, {"w": "dengan", "a": 12.202, "e": 12.604, "b": null}, {"w": "komputer", "a": 12.604, "e": 13.208, "b": null}, {"w": "ENIAC.", "a": 13.208, "e": 13.812, "b": "strong"}, {"w": "Beratnya", "a": 14.205, "e": 14.718, "b": null}, {"w": "sekitar", "a": 14.718, "e": 15.231, "b": null}, {"w": "30", "a": 15.231, "e": 15.915, "b": null}, {"w": "ton,", "a": 15.915, "e": 16.086, "b": "weak"}, {"w": "memakai", "a": 16.355, "e": 16.844, "b": null}, {"w": "sekitar", "a": 16.844, "e": 17.333, "b": null}, {"w": "18.000", "a": 17.333, "e": 18.475, "b": null}, {"w": "tabung", "a": 18.475, "e": 18.801, "b": null}, {"w": "vakum", "a": 18.801, "e": 19.127, "b": null}, {"w": "yang", "a": 19.127, "e": 19.29, "b": null}, {"w": "besar,", "a": 19.29, "e": 19.616, "b": "weak"}, {"w": "panas,", "a": 19.982, "e": 20.453, "b": "weak"}, {"w": "dan", "a": 20.625, "e": 20.865, "b": null}, {"w": "gampang", "a": 20.865, "e": 21.344, "b": null}, {"w": "rusak.", "a": 21.344, "e": 21.823, "b": "strong"}, {"w": "Lalu", "a": 22.237, "e": 22.515, "b": null}, {"w": "pada", "a": 22.515, "e": 22.793, "b": null}, {"w": "1947,", "a": 22.793, "e": 24.739, "b": "weak"}, {"w": "peneliti", "a": 24.976, "e": 25.725, "b": null}, {"w": "Bell", "a": 25.725, "e": 25.913, "b": null}, {"w": "Labs", "a": 25.913, "e": 26.1, "b": null}, {"w": "menemukan", "a": 26.1, "e": 26.849, "b": null}, {"w": "transistor.", "a": 26.849, "e": 27.411, "b": "strong"}, {"w": "Ia", "a": 27.82, "e": 28.114, "b": null}, {"w": "bekerja", "a": 28.114, "e": 28.554, "b": null}, {"w": "seperti", "a": 28.554, "e": 28.994, "b": null}, {"w": "sakelar", "a": 28.994, "e": 29.435, "b": null}, {"w": "yang", "a": 29.435, "e": 29.581, "b": null}, {"w": "menyala", "a": 29.581, "e": 30.022, "b": null}, {"w": "dan", "a": 30.022, "e": 30.168, "b": null}, {"w": "mati,", "a": 30.168, "e": 30.462, "b": "weak"}, {"w": "mewakili", "a": 30.742, "e": 31.384, "b": null}, {"w": "angka", "a": 31.384, "e": 31.705, "b": null}, {"w": "1", "a": 31.705, "e": 32.026, "b": null}, {"w": "dan", "a": 32.026, "e": 32.186, "b": null}, {"w": "0,", "a": 32.186, "e": 32.507, "b": "weak"}, {"w": "tapi", "a": 32.845, "e": 33.266, "b": null}, {"w": "jauh", "a": 33.266, "e": 33.477, "b": null}, {"w": "lebih", "a": 33.477, "e": 33.899, "b": null}, {"w": "kecil,", "a": 33.899, "e": 34.32, "b": "weak"}, {"w": "hemat", "a": 34.582, "e": 34.896, "b": null}, {"w": "energi,", "a": 34.896, "e": 35.367, "b": "weak"}, {"w": "dan", "a": 35.515, "e": 35.686, "b": null}, {"w": "awet.", "a": 35.686, "e": 36.028, "b": "strong"}, {"w": "Tahun", "a": 36.498, "e": 36.77, "b": null}, {"w": "1958,", "a": 36.77, "e": 38.807, "b": "weak"}, {"w": "Jack", "a": 39.006, "e": 39.2, "b": null}, {"w": "Kilby", "a": 39.2, "e": 39.394, "b": null}, {"w": "memperagakan", "a": 39.394, "e": 40.363, "b": null}, {"w": "rangkaian", "a": 40.363, "e": 40.945, "b": null}, {"w": "terpadu,", "a": 40.945, "e": 41.527, "b": "weak"}, {"w": "dan", "a": 41.756, "e": 41.934, "b": null}, {"w": "Robert", "a": 41.934, "e": 42.289, "b": null}, {"w": "Noyce", "a": 42.289, "e": 42.645, "b": null}, {"w": "mengembangkannya", "a": 42.645, "e": 43.534, "b": null}, {"w": "berbasis", "a": 43.534, "e": 44.067, "b": null}, {"w": "silikon.", "a": 44.067, "e": 44.6, "b": "strong"}, {"w": "Hasilnya,", "a": 44.947, "e": 45.562, "b": "weak"}, {"w": "banyak", "a": 45.794, "e": 46.129, "b": null}, {"w": "transistor", "a": 46.129, "e": 46.631, "b": null}, {"w": "bisa", "a": 46.631, "e": 46.966, "b": null}, {"w": "dibuat", "a": 46.966, "e": 47.469, "b": null}, {"w": "dalam", "a": 47.469, "e": 47.804, "b": null}, {"w": "satu", "a": 47.804, "e": 48.139, "b": null}, {"w": "keping:", "a": 48.139, "e": 48.474, "b": "weak"}, {"w": "chip.", "a": 48.94, "e": 49.292, "b": "strong"}, {"w": "Rahasianya", "a": 49.737, "e": 50.534, "b": null}, {"w": "fotolitografi.", "a": 50.534, "e": 51.491, "b": "strong"}, {"w": "Wafer", "a": 51.918, "e": 52.242, "b": null}, {"w": "silikon", "a": 52.242, "e": 52.728, "b": null}, {"w": "dilapisi", "a": 52.728, "e": 53.377, "b": null}, {"w": "bahan", "a": 53.377, "e": 53.701, "b": null}, {"w": "peka", "a": 53.701, "e": 54.025, "b": null}, {"w": "cahaya,", "a": 54.025, "e": 54.511, "b": "weak"}, {"w": "lalu", "a": 54.808, "e": 55.118, "b": null}, {"w": "disinari", "a": 55.118, "e": 55.738, "b": null}, {"w": "lewat", "a": 55.738, "e": 56.047, "b": null}, {"w": "cetakan", "a": 56.047, "e": 56.512, "b": null}, {"w": "pola", "a": 56.512, "e": 56.822, "b": null}, {"w": "rangkaian.", "a": 56.822, "e": 57.287, "b": "strong"}, {"w": "Bagian", "a": 57.635, "e": 58.121, "b": null}, {"w": "yang", "a": 58.121, "e": 58.283, "b": null}, {"w": "terkena", "a": 58.283, "e": 58.769, "b": null}, {"w": "cahaya", "a": 58.769, "e": 59.255, "b": null}, {"w": "berubah", "a": 59.255, "e": 59.74, "b": null}, {"w": "sifat", "a": 59.74, "e": 60.064, "b": null}, {"w": "dan", "a": 60.064, "e": 60.226, "b": null}, {"w": "bisa", "a": 60.226, "e": 60.55, "b": null}, {"w": "dihilangkan,", "a": 60.55, "e": 61.198, "b": "weak"}, {"w": "lalu", "a": 61.436, "e": 61.803, "b": null}, {"w": "dietsa.", "a": 61.803, "e": 62.353, "b": "strong"}, {"w": "Proses", "a": 62.758, "e": 63.131, "b": null}, {"w": "ini", "a": 63.131, "e": 63.504, "b": null}, {"w": "diulang", "a": 63.504, "e": 64.064, "b": null}, {"w": "lapis", "a": 64.064, "e": 64.438, "b": null}, {"w": "demi", "a": 64.438, "e": 64.811, "b": null}, {"w": "lapis.", "a": 64.811, "e": 65.184, "b": "strong"}, {"w": "Pada", "a": 65.484, "e": 65.751, "b": null}, {"w": "1965,", "a": 65.751, "e": 67.619, "b": "weak"}, {"w": "Gordon", "a": 67.824, "e": 68.151, "b": null}, {"w": "Moore", "a": 68.151, "e": 68.642, "b": null}, {"w": "mengamati", "a": 68.642, "e": 69.297, "b": null}, {"w": "jumlah", "a": 69.297, "e": 69.624, "b": null}, {"w": "komponen", "a": 69.624, "e": 70.115, "b": null}, {"w": "dalam", "a": 70.115, "e": 70.443, "b": null}, {"w": "chip", "a": 70.443, "e": 70.606, "b": null}, {"w": "terus", "a": 70.606, "e": 70.934, "b": null}, {"w": "berlipat", "a": 70.934, "e": 71.425, "b": null}, {"w": "ganda,", "a": 71.425, "e": 71.752, "b": "weak"}, {"w": "dikenal", "a": 71.999, "e": 72.432, "b": null}, {"w": "sebagai", "a": 72.432, "e": 72.864, "b": null}, {"w": "Hukum", "a": 72.864, "e": 73.152, "b": null}, {"w": "Moore.", "a": 73.152, "e": 73.585, "b": "strong"}, {"w": "Kini", "a": 73.974, "e": 74.304, "b": null}, {"w": "pabrik", "a": 74.304, "e": 74.634, "b": null}, {"w": "memakai", "a": 74.634, "e": 75.129, "b": null}, {"w": "cahaya", "a": 75.129, "e": 75.624, "b": null}, {"w": "ultraviolet", "a": 75.624, "e": 76.449, "b": null}, {"w": "ekstrem", "a": 76.449, "e": 76.779, "b": null}, {"w": "dengan", "a": 76.779, "e": 77.109, "b": null}, {"w": "panjang", "a": 77.109, "e": 77.439, "b": null}, {"w": "gelombang", "a": 77.439, "e": 77.934, "b": null}, {"w": "13,5", "a": 77.934, "e": 79.254, "b": null}, {"w": "nanometer.", "a": 79.254, "e": 79.914, "b": "strong"}, {"w": "Tapi", "a": 80.308, "e": 80.62, "b": null}, {"w": "angka", "a": 80.62, "e": 80.932, "b": null}, {"w": "3", "a": 80.932, "e": 81.244, "b": null}, {"w": "nm", "a": 81.244, "e": 81.868, "b": null}, {"w": "pada", "a": 81.868, "e": 82.18, "b": null}, {"w": "nama", "a": 82.18, "e": 82.492, "b": null}, {"w": "prosesor", "a": 82.492, "e": 82.961, "b": null}, {"w": "adalah", "a": 82.961, "e": 83.429, "b": null}, {"w": "nama", "a": 83.429, "e": 83.741, "b": null}, {"w": "generasi", "a": 83.741, "e": 84.365, "b": null}, {"w": "teknologi,", "a": 84.365, "e": 84.989, "b": "weak"}, {"w": "bukan", "a": 85.257, "e": 85.605, "b": null}, {"w": "ukuran", "a": 85.605, "e": 86.127, "b": null}, {"w": "pasti", "a": 86.127, "e": 86.474, "b": null}, {"w": "transistornya.", "a": 86.474, "e": 87.17, "b": "strong"}, {"w": "Jadi", "a": 87.553, "e": 87.884, "b": null}, {"w": "chip", "a": 87.884, "e": 88.05, "b": null}, {"w": "sekecil", "a": 88.05, "e": 88.547, "b": null}, {"w": "itu", "a": 88.547, "e": 88.878, "b": null}, {"w": "bukan", "a": 88.878, "e": 89.21, "b": null}, {"w": "sulap,", "a": 89.21, "e": 89.541, "b": "weak"}, {"w": "tapi", "a": 89.7, "e": 89.7, "b": null}, {"w": "hasil", "a": 89.7, "e": 89.7, "b": null}, {"w": "puluhan", "a": 89.7, "e": 89.7, "b": null}, {"w": "tahun", "a": 89.7, "e": 89.7, "b": null}, {"w": "fisika,", "a": 89.7, "e": 89.7, "b": "weak"}, {"w": "kimia,", "a": 89.931, "e": 91.91, "b": "weak"}, {"w": "dan", "a": 92.18, "e": 92.492, "b": null}, {"w": "rekayasa.", "a": 92.492, "e": 93.742, "b": "strong"}];const NARR_DUR=94.0408125;

/* Chip: bagaimana manusia membuat komponen sekecil debu — 1080x1920, gaya infografis isometrik terang */
(function () {
const OFF = .5, DUR = 97.5; window.OFF = OFF; window.DUR = DUR;
const SB = [-9, 6.37, 8.66, 14.21, 22.24, 27.82, 36.5, 44.95, 51.92, 65.48, 73.97, 80.31, 87.55, 999];
const NEND = 94.04;
const EVL = []; const E = (t, ty, v = 1) => EVL.push([+t.toFixed(3), ty, v]); window.EV = EVL;
let n = 0, HUD = () => {};
const BGC = [.957, .953, .933];
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9\-\.]/g, '').replace(/\.$/, '');
function W(w, k = 0) { let c = 0; for (const t of WORDS) if (norm(t.w) === w) { if (c++ === k) return t.a; } return 0; }
const P2 = (p) => { const q = proj(p); q.x /= SC; q.y /= SC; q.s /= SC; return q; };
const col = hexc;
const INK = '#14161c', CYAN = '#12b5d8', CYAN_D = '#0a8fae';

/* ---------- primitif ---------- */
const mk = (f) => { const b = new B(); f(b); return b.build(); };
const UB = mk((b) => box(b, 0, 0, 0, 1, 1, 1, [1, 1, 1]));
const CY = mk((b) => cyl(b, [0, 0, 0], [0, 1, 0], 1, 1, 30, [1, 1, 1]));
const CONE = mk((b) => cyl(b, [0, 0, 0], [0, 1, 0], 1, 0, 30, [1, 1, 1], false));
const FRUS = mk((b) => cyl(b, [0, 0, 0], [0, 1, 0], 1, .35, 30, [1, 1, 1], false));
const SP = mk((b) => sphere(b, [0, 0, 0], 1, [1, 1, 1], 12, 18));
const TOR = mk((b) => torus(b, 1, .09, 40, 8, [1, 1, 1]));
const O = (o) => Object.assign({sp: .12, rim: 0}, o);
function cube(p, s, tint, o) { draw(UB, TRS(p, [0, 0, 0], s), O(Object.assign({tint}, o))); }
function cylr(p, r, h, tint, o, rot = [0, 0, 0]) { draw(CY, TRS(p, rot, [r, h, r]), O(Object.assign({tint}, o))); }
function ball(p, r, tint, o, sy = 1) { draw(SP, TRS(p, [0, 0, 0], [r, r * sy, r]), O(Object.assign({tint}, o))); }
function segM(p0, p1, w) { const d = vsub(p1, p0), L = vlen(d); if (L < 1e-5) return ident(); const a = vnorm(d), t = Math.abs(a[1]) < .9 ? [0, 1, 0] : [1, 0, 0]; const u = vnorm(vcross(a, t)), v = vcross(a, u), mid = vmul(vadd(p0, p1), .5); const m = ident(); m[0] = u[0] * w; m[1] = u[1] * w; m[2] = u[2] * w; m[4] = a[0] * L; m[5] = a[1] * L; m[6] = a[2] * L; m[8] = v[0] * w; m[9] = v[1] * w; m[10] = v[2] * w; m[12] = mid[0]; m[13] = mid[1]; m[14] = mid[2]; return m; }
function seg(p0, p1, w, tint, o) { draw(UB, segM(p0, p1, w), O(Object.assign({tint}, o))); }
function shadow(x, z, r, al = .16, y = .01) { for (let i = 0; i < 3; i++) draw(CY, TRS([x, y, z], [0, 0, 0], [r * (1 - i * .2), .005, r * (1 - i * .2)]), {tint: [.12, .13, .18], al: al * .45, sp: 0, rim: 0, dw: false}); }

/* ---------- kamera & cahaya ---------- */
const SHK = []; const shake = (t, a, d) => SHK.push([t, a, d]);
function camShake() { let o = [0, 0, 0]; for (const [t0, a, d] of SHK) { const t = n - t0; if (t >= 0 && t < d) { const k = Math.pow(1 - t / d, 2) * a; o = [o[0] + Math.sin(n * 83 + t0) * k, o[1] + Math.cos(n * 97 + t0) * k, 0]; } } return o; }
function iso(az, el, dist, tgt, fov = 30, up = .13) {
  const a = az * Math.PI / 180, e = el * Math.PI / 180; let eye = [tgt[0] + Math.cos(e) * Math.sin(a) * dist, tgt[1] + Math.sin(e) * dist, tgt[2] + Math.cos(e) * Math.cos(a) * dist], t = tgt.slice();
  const H = 2 * dist * Math.tan(fov * Math.PI / 360), f = vnorm(vsub(t, eye)), r = vnorm(vcross(f, [0, 1, 0])), u = vcross(r, f), s = vmul(u, -up * H), k = camShake();
  eye = vadd(vadd(eye, s), k); t = vadd(vadd(t, s), vmul(k, .5)); CAM.eye = eye; CAM.tgt = t; CAM.fov = fov; CAM.roll = 0;
}
function lights() { Object.assign(LT, {ld: vnorm([-.5, -.85, -.42]), lc: [.58, .56, .52], at: [.56, .58, .63], ab: [.4, .39, .38], l2d: [.5, -.2, .6], l2c: [0, 0, 0], rc: [0, 0, 0], fog: BGC, fd: .006, clip: -1000}); }
const sceneT = (i) => n - SB[i];

/* ---------- 2D util ---------- */
const FONT = 'Inter, "Plus Jakarta Sans", "Arial Black", Arial, sans-serif', MONO = '"DejaVu Sans Mono", "Courier New", monospace';
const popK = (t, d = .32) => ({sc: eoutB(clamp(t / d, 0, 1)), al: clamp(t / .1, 0, 1)});
function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
function txt(s, x, y, size, c, o = {}) {
  ctx.save(); ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, sc); ctx.globalAlpha = o.al === undefined ? 1 : o.al;
  ctx.font = `${o.w || 800} ${size}px ${o.font || FONT}`; ctx.textAlign = o.align || 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  const lines = String(s).split('\n'), lh = size * 1.12, y0 = -(lines.length - 1) * lh / 2;
  lines.forEach((ln, i) => { if (o.stroke) { ctx.lineWidth = o.sw || 8; ctx.strokeStyle = o.stroke; ctx.strokeText(ln, 0, y0 + i * lh); } ctx.fillStyle = c; ctx.fillText(ln, 0, y0 + i * lh); });
  ctx.restore();
}
function tag(s, x, y, o = {}) {
  ctx.save(); ctx.translate(x, y); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, sc); ctx.globalAlpha = o.al === undefined ? 1 : o.al; const size = o.size || 26;
  ctx.font = `800 ${size}px ${FONT}`; const w = ctx.measureText(s).width + size * 1.3, h = size * 1.8;
  ctx.shadowColor = 'rgba(20,22,28,.18)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 5; ctx.fillStyle = o.bg || '#fff'; rr(-w / 2, -h / 2, w, h, h * .32); ctx.fill(); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;
  ctx.lineWidth = 2.5; ctx.strokeStyle = o.border || '#d6d3c8'; ctx.stroke(); ctx.fillStyle = o.fg || INK; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, 0, size * .05); ctx.restore();
}
function note(text, wp, dx, dy, t0, t1 = 1e9, o = {}) {
  if (n < t0 || n > t1) return; const q = P2(wp), p = popK(n - t0, .3), fo = clamp((t1 - n) / .2, 0, 1), x = clamp(q.x + dx, 170, 910), y = q.y + dy;
  ctx.save(); ctx.globalAlpha = p.al * fo; ctx.strokeStyle = INK; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(q.x, q.y); ctx.lineTo(x, y); ctx.stroke(); ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(q.x, q.y, 8, 0, 6.283); ctx.fill(); ctx.restore();
  tag(text, x, y, Object.assign({sc: p.sc, al: p.al * fo}, o));
}
function head(s, t0, t1 = 1e9) {
  if (n < t0 || n > t1) return; const t = n - t0, a = clamp(t / .3, 0, 1) * clamp((t1 - n) / .2, 0, 1), lines = s.split('\n'); ctx.save(); ctx.globalAlpha = a; ctx.font = `800 52px ${FONT}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
  lines.forEach((ln, li) => { let x = 60; const y = 105 + li * 64 + (1 - eout(t / .3)) * 22; ln.split('*').forEach((p, i) => { ctx.fillStyle = i % 2 ? CYAN_D : INK; ctx.fillText(p, x, y); x += ctx.measureText(p).width; }); }); ctx.restore();
}
function glow(x, y, r, c, a) { const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${c},${a})`); g.addColorStop(1, `rgba(${c},0)`); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
function fmt(v) { return String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function yearChip(y, t0, t1 = 1e9) { if (n < t0 || n > t1) return; const p = popK(n - t0, .4); tag(y, 930, 260, {sc: p.sc, al: p.al * clamp((t1 - n) / .2, 0, 1), bg: INK, fg: '#fff', border: INK, size: 40}); }

/* ---------- model merged ---------- */
function buildGridMesh(nx, nz, pitch, size, hgt, cf) { const b = new B(); for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) { const c = cf(i, j); if (!c) continue; box(b, (i - (nx - 1) / 2) * pitch, hgt / 2, (j - (nz - 1) / 2) * pitch, size, hgt, size, c); } return b.build(); }
const DIE = buildGridMesh(34, 34, .24, .17, .1, (i, j) => { const v = R(i * 77 + j, 5); return v < .12 ? col('#55687d') : mixc(col('#7d8fa6'), col('#a9b9cc'), R(i + j * 31, 6)); });
function buildTube(b, x, y, z, s = 1, glass = [.84, .93, .96], dead = false) {
  cyl(b, [x, y, z], [x, y + .16 * s, z], .3 * s, .3 * s, 10, dead ? [.18, .18, .2] : [.22, .2, .2]);
  cyl(b, [x, y + .16 * s, z], [x, y + .95 * s, z], .27 * s, .27 * s, 10, dead ? [.45, .45, .47] : glass, false);
  sphere(b, [x, y + .95 * s, z], .27 * s, dead ? [.45, .45, .47] : glass, 5, 10, .9);
  cyl(b, [x, y + .2 * s, z], [x, y + .75 * s, z], .06 * s, .06 * s, 6, dead ? [.25, .25, .27] : [1, .62, .2], false);
}
const TW_C = 14, TW_R = 14; // dinding tabung
const TWALL = mk((b) => { for (let r = 0; r < TW_R; r++) for (let c = 0; c < TW_C; c++) buildTube(b, (c - (TW_C - 1) / 2) * .78, r * 1.25, 0, .85); });
const TDEAD = mk((b) => { for (let r = 0; r < TW_R; r++) for (let c = 0; c < TW_C; c++) if (R(r * 29 + c, 11) < .34) buildTube(b, (c - (TW_C - 1) / 2) * .78, r * 1.25, .001, .86, null, true); });
const TUBE1 = mk((b) => buildTube(b, 0, 0, 0, 3));
const TRANS1 = mk((b) => { cyl(b, [0, 0, 0], [0, .9, 0], .55, .55, 16, [.16, .17, .2]); sphere(b, [0, .9, 0], .55, [.16, .17, .2], 6, 16, .45); for (const dx of [-.3, 0, .3]) cyl(b, [dx, -.9, 0], [dx, 0, 0], .06, .06, 6, [.85, .7, .3], false); });
const CHIPP = mk((b) => { box(b, 0, .15, 0, 3, .3, 3, [.17, .18, .22]); box(b, 0, .31, 0, 2.2, .04, 2.2, [.28, .3, .36]); for (let i = 0; i < 9; i++) for (const s of [-1, 1]) { const o = (i - 4) * .3; box(b, s * 1.62, .1, o, .26, .06, .14, [.85, .7, .3]); box(b, o, .1, s * 1.62, .14, .06, .26, [.85, .7, .3]); } });
const WAFER = mk((b) => cyl(b, [0, 0, 0], [0, .22, 0], 3.3, 3.3, 48, [.62, .68, .78]));
function waferCells(f) { return buildGridMesh(13, 13, .5, .42, .06, (i, j) => { const x = (i - 6) * .5, z = (j - 6) * .5; if (Math.hypot(x, z) > 2.95) return null; return f(i, j); }); }
const WCELLS = waferCells((i, j) => mixc(col('#7e8da3'), col('#9db0c6'), R(i * 13 + j, 3)));
const WEXP = waferCells((i, j) => (R(i * 17 + j, 8) < .5 ? col('#8a5cff') : null));
const WETCH = waferCells((i, j) => (R(i * 17 + j, 8) < .5 ? col('#3b4a63') : null));
function pcbMesh() { const b = new B(); box(b, 0, 0, 0, 6.6, .22, 4.8, [.2, .55, .36]); for (let i = 0; i < 14; i++) { const x = (R(i, 21) - .5) * 5.4, z = (R(i, 22) - .5) * 3.8; if (Math.abs(x) < 1.4 && Math.abs(z) < 1.4) continue; box(b, x, .2, z, .2 + R(i, 23) * .5, .18, .2 + R(i, 24) * .4, [.12 + R(i, 25) * .2, .13, .16]); } for (let i = 0; i < 9; i++) box(b, -3.1, .13, -1.8 + i * .45, .5, .05, .2, [.85, .7, .3]); return b.build(); }
const PCB = pcbMesh();
const CAB = mk((b) => { box(b, 0, 1.6, 0, 1.3, 3.2, .95, [.55, .59, .66]); box(b, 0, 1.75, .49, 1.1, 2.4, .04, [.78, .81, .86]); for (let r = 0; r < 6; r++) for (let c = 0; c < 3; c++) box(b, (c - 1) * .3, 1.05 + r * .33, .53, .12, .12, .04, [.25, .27, .32]); });
const GEAR = mk((b) => { cyl(b, [0, 0, 0], [0, .35, 0], .75, .75, 20, [.62, .66, .74]); for (let i = 0; i < 10; i++) { const a = i / 10 * 6.2832; box(b, Math.cos(a) * .88, .175, Math.sin(a) * .88, .3, .35, .3, [.62, .66, .74]); } });

/* ---------- SFX ---------- */
SB.slice(1, -1).forEach((t) => { E(t - .12, 'whoosh', .5); });
[1.9, 5.4, 5.9, 13.2, 15.23, 17.33, 19.8, 20.9, 26.85, 31.7, 33.2, 34.4, 35.5, 39.2, 42.3, 44.07, 48.94, 52.73, 55.1, 62.35, 63, 63.6, 64.2].forEach((t) => E(t, 'pop', .8));
[2.9, 48.94, 63.2, 72.9, 86.6].forEach((t) => E(t, 'ding', .7)); E(50.53, 'impact', .9); E(55.9, 'zap', .8); E(58.2, 'zap', .6); E(77.9, 'zap', .7); E(29.58, 'tick', 1); E(30.17, 'tick', 1); E(32.2, 'tick', 1); E(21.0, 'rumble', .5);
for (let k = 0; k < 8; k++) E(66.8 + k * .55, 'pop', .6); E(71.4, 'riser', .8); E(84.0, 'stamp', .8); E(85.3, 'zap', .7);
for (let i = 0; i < 40; i++) E(.7 + i * .15 + R(i, 4) * .1, 'tick', .25);

/* ================= A: hook ================= */
const SPRK = []; for (let i = 0; i < 300; i++) SPRK.push([R(i, 1), R(i, 2)]);
function sA() {
  lights(); const big = n > 3.7;
  if (!big) {
    const dist = lerp(34, 10, eio(ramp(n, 2.2, 3.7))), az = 38 + n * 6, lift = eoutB(ramp(n, 1.5, 2.5)) * 2.4;
    iso(az, 36, dist, [0, .6 + lift * .6, 0], 30, lerp(.13, .0, ramp(n, 2.2, 3.7)));
    beginFrame(); shadow(0, 0, 4, .2); draw(PCB, ident(), O({})); const fade = 1 - sstep(2.9, 3.5, n);
    draw(CHIPP, mT(0, .2 + lift, 0), O({al: fade < 1 ? Math.max(.001, fade) : undefined, tint: [1, 1, 1]})); if (lift > .2) shadow(0, 0, 1.8, .1 * lift / 2.4, .2);
    draw(DIE, mmul(mT(0, .24 + lift, 0), mS(.17)), O({al: sstep(2.7, 3.2, n) * (1 - sstep(3.4, 3.7, n)) + .0}));
  } else {
    const tt = n - 3.7, az = 30 + tt * 5, dist = lerp(29, 34, ramp(n, 3.7, 6.3));
    iso(az, 40, dist, [0, .3, 0], 30, .1); beginFrame(); draw(DIE, mT(0, 0, 0), O({sp: .05})); cube([0, -.15, 0], [8.7, .3, 8.7], col('#4c5b70'));
    for (let k = 0; k < 150; k++) { const i = Math.floor(R(k, 31) * 34), j = Math.floor(R(k, 32) * 34), on = Math.sin(n * (2 + R(k, 33) * 3) + k) > .35; if (!on) continue; cube([(i - 16.5) * .24, .11, (j - 16.5) * .24], [.15, .07, .15], col('#14c6ea'), {em: .9}); }
    const dd = popK(n - 4.7, .45).sc; if (dd > 0) { const dp = [1.6, 2.0 + Math.sin(n * 2) * .1, .4]; shadow(dp[0], dp[2], .7 * dd, .2, .01); ball(dp, .55 * dd, col('#b7a487'), {sp: .1}); ball([dp[0] + .3, dp[1] + .2, dp[2] + .1], .2 * dd, col('#9d8b6f')); }
  }
  flushParticles();
  HUD = () => {
    head('Chip di HP-mu:\n*puluhan miliar* komponen', -.4, 6.3);
    if (!big) { note('CHIP', [0, 2.8, 0], 150, -80, 1.9, 3.4); }
    else { note('TRANSISTOR', [-1.7, .12, 1.4], -170, 220, 5.9, 8.6); note('DEBU', [1.6, 2.0, .4], 180, -120, 5.4, 8.6, {bg: '#fff3d6'}); }
  };
}

/* ================= B: pertanyaan ================= */
function sB() {
  lights(); const t = n - SB[1]; iso(35 + t * 14, 34, 17, [0, .6, 0], 30, .1); beginFrame(); const b = Math.sin(t * 2.2) * .12;
  shadow(0, 0, 2.6, .18); draw(CHIPP, mmul(mT(0, 1 + b + .3, 0), mRy(t * .9)), O({})); draw(DIE, mmul(mT(0, 1.32 + b + .3, 0), mmul(mRy(t * .9), mS(.2))), O({}));
  flushParticles(); HUD = () => { head('*Bagaimana* manusia\nbisa membuatnya?', SB[1] + .02, SB[2] - .05); const p = popK(t - .2, .5); txt('?', 540, 760, 460, CYAN, {sc: p.sc, al: p.al * clamp((SB[2] - n) / .2, 0, 1), rot: Math.sin(t * 3) * .05, stroke: '#fff', sw: 30}); };
}

/* ================= C: ENIAC ================= */
function cabRow(side) { return [0, 1, 2, 3, 4, 5].map((i) => side); }
function sC() {
  lights(); const t = n - SB[2]; iso(32 + t * 5, 34, 42, [0, 1.3, 0], 30, .1); beginFrame();
  const cabs = []; for (let i = 0; i < 7; i++) { cabs.push([-4.2 + i * 1.4, -4.7, 0]); } for (let i = 0; i < 5; i++) { cabs.push([-5.1, -3.2 + i * 1.4 + 1.4, Math.PI / 2]); cabs.push([5.1, -3.2 + i * 1.4 + 1.4, -Math.PI / 2]); }
  cabs.forEach((c, i) => { const m = mmul(mT(c[0], 0, c[1]), mRy(c[2] || 0)); draw(CAB, m, O({})); });
  cabs.forEach((c, i) => { const m = mmul(mT(c[0], 0, c[1]), mRy(c[2] || 0)); for (let k = 0; k < 6; k++) { const on = Math.sin(n * 5 + i * 3 + k * 2) > .1; if (!on) continue; const p = mApply(m, [(k % 3 - 1) * .3, 1.05 + Math.floor(k / 3) * .33 + (i % 3) * .66, .56]); cube(p, [.13, .13, .05], col(k % 2 ? '#ffb23a' : '#35c8ee'), {em: .8}); } });
  cylr([0, 0, 1.2], .28, 1.3, col('#f3a23a')); ball([0, 1.55, 1.2], .3, col('#f0c9a0')); shadow(0, 1.2, .5, .25, .22);
  flushParticles();
  HUD = () => { head('*1946*: komputer ENIAC', SB[2] + .02, SB[3]); yearChip('1946', SB[2] + .2, SB[3]); note('ORANG', [0, 1.9, 1.2], 190, -170, 12.0, SB[3] - .1); note('ENIAC', [0, 3.3, -4.7], 180, -110, 13.2, SB[3] - .1); };
}

/* ================= D: tabung vakum ================= */
function sD() {
  lights(); const t = n - SB[3];
  if (n < 17.2) { // 30 ton
    iso(30 + t * 6, 30, 42, [0, 1.5, 0], 30, .1); beginFrame(); 
    const sq = 1 - .06 * Math.exp(-Math.max(0, n - 15.23) * 6) * Math.cos(Math.max(0, n - 15.23) * 25);
    for (let i = 0; i < 7; i++) draw(CAB, mmul(mT(-4.2 + i * 1.4, 0, -4.7), mS(1, sq, 1)), O({}));
    const dr = 1 - ein(ramp(n, 15.0, 15.4)); cube([0, 1.2 + dr * 9, 0], [5, 2.4, 3], col('#4a505c')); shadow(0, 0, 3.2, .22, .13);
    if (n > 15.5) cube([0, 1.2 + 0, 0], [5, 2.4, 3], col('#4a505c'));
    flushParticles(); HUD = () => { head('*30 ton*,\n*18.000* tabung vakum', SB[3] + .02, 17.2); if (n > 15.23) { const p = popK(n - 15.23, .4); txt('≈ 30 TON', 540, 960, 112, INK, {sc: p.sc, al: p.al, stroke: '#fff', sw: 20}); } };
    return;
  }
  const u = ramp(n, 17.2, 19.8), rows = u * TW_R; iso(0, 6, 36, [0, 8.3, 0], 30, .08); beginFrame();
  const heat = sstep(20.0, 21.0, n), jit = n > 21.3 ? sstep(21.2, 22.1, n) : 0;
  LT.clip = (rows * 1.25) - .3; draw(TWALL, ident(), O({tint: [1, 1 - heat * .25, 1 - heat * .5], em: heat * .25 + .05 * Math.sin(n * 20) * jit})); LT.clip = -1000;
  if (n > 20.9) draw(TDEAD, ident(), O({al: sstep(20.9, 21.8, n)}));
  if (heat > 0) for (let i = 0; i < 40; i++) { const x = (R(i, 41) - .5) * 10, z = .6, y = 6 + ((R(i, 42) * 18 + n * 3) % 18); pt(PB.alp, [x, y, z], .55, [1, .45, .2], .1 * heat, 0); }
  flushParticles();
  HUD = () => {
    head('*30 ton*,\n*18.000* tabung vakum', 17.2); const cnt = Math.round(18000 * u);
    txt(fmt(cnt), 540, 980, 108, INK, {font: MONO, w: 800, stroke: '#fff', sw: 20, al: clamp((n - 17.3) / .3, 0, 1)}); txt('TABUNG VAKUM', 540, 1070, 40, CYAN_D, {w: 800, stroke: '#fff', sw: 10, al: clamp((n - 17.3) / .3, 0, 1)});
    if (n > 19.8 && n < 20.9) tag('BESAR', 540, 360, {sc: popK(n - 19.8).sc, al: popK(n - 19.8).al, size: 34}); if (n > 20.2 && n < 21.7) tag('PANAS 🔥', 800, 480, {sc: popK(n - 20.2).sc, al: popK(n - 20.2).al, bg: '#ffe0d2', size: 34});
    if (n > 20.9) tag('GAMPANG RUSAK ✕', 540, 600, {sc: popK(n - 20.9).sc, al: popK(n - 20.9).al, bg: '#ffd6d6', fg: '#a00', border: '#f2a0a0', size: 34});
  };
}

/* ================= E: transistor lahir ================= */
function sE() {
  lights(); const t = n - SB[4]; iso(30 + t * 6, 30, 25, [0, 1.6, 0], 30, .1); beginFrame();
  shadow(-2.6, 0, 1.6, .18); draw(TUBE1, mT(-2.6, 0, 0), O({})); const s = 1 + .12 * Math.exp(-Math.max(0, n - 26.85) * 4) * 3;
  shadow(2.4, 0, .8 * s, .2); draw(TRANS1, mmul(mT(2.4, .95 * s, 0), mS(s * 1.3)), O({em: n > 26.85 ? .25 : 0})); cube([0, -.1, 0], [10, .2, 6], col('#e7e5dc'), {al: .0001});
  flushParticles();
  HUD = () => { head('*1947*: Bell Labs\nmenemukan transistor', SB[4] + .02, SB[5]); yearChip('1947', SB[4] + .2, SB[5]); note('TABUNG VAKUM', [-2.6, 3.1, 0], -40, -180, 23.6, SB[5] - .1); note('TRANSISTOR', [2.4, 1.7, 0], 70, -240, 26.4, SB[5] - .1, {bg: INK, fg: '#fff', border: INK}); if (n > 24.8 && n < 26.4) tag('LEBIH KECIL', 540, 1000, {sc: popK(n - 24.8).sc, al: popK(n - 24.8).al}); };
}

/* ================= F: sakelar 1 / 0 ================= */
function sF() {
  lights(); const t = n - SB[5]; iso(28 + Math.sin(t * .5) * 8, 32, 23, [0, 1.2, 0], 30, .1); beginFrame();
  const on = (n > 29.58 && n < 30.17) || (n >= 31.7 && n < 33.0 && (Math.floor((n - 31.7) / .35) % 2 === 0)) || (n >= 33 && n < 34); const ang = on ? -.55 : .55; const tm = on ? 1 : 0;
  shadow(0, 0, 3, .2); cube([0, .25, 0], [4.6, .5, 3], col('#d9dce3')); cube([0, .55, 0], [3.6, .1, 2.2], col('#a9b0be'));
  const scl2 = n > 32.6 ? 1 - .55 * sstep(32.6, 33.6, n) : 1; cylr([0, .6, 0], .26, .5, col('#4a505c'), {}); const lv = mmul(mT(0, 1.05, 0), mRz(ang)); draw(CY, mmul(lv, mmul(mT(0, 0, 0), mS(.17, 1.6, .17))), O({tint: col('#e5484d')})); ball(mApply(lv, [0, 1.6, 0]), .3, col('#e5484d'));
  const lamp = on ? 1 : .0; ball([0, 3.6, -.9], .6, mixc(col('#cfd3da'), col('#ffd24a'), lamp), {em: lamp * .8}); if (lamp) pt(PB.alp, [0, 3.6, -.9], 3, [1, .82, .3], .12, 0);
  cylr([0, 2.6, -.9], .06, 1, col('#7a808c'));
  flushParticles();
  HUD = () => { head('Transistor = *sakelar*\nmenyala (1) & mati (0)', SB[5] + .02, SB[6]); tag(on ? 'MENYALA = 1' : 'MATI = 0', 540, 1030, {size: 42, bg: on ? CYAN : INK, fg: on ? '#04222b' : '#fff', border: on ? CYAN : INK, sc: 1 + .04 * Math.exp(-((n - 29.58) % .6) * 8)});
    if (n > 31.7) { const bits = '1 0 1 1 0 1 0 0 1'.split(' '); const x0 = 540 - 4 * 62; bits.forEach((bv, i) => { const p = popK(n - 31.7 - i * .05, .25); txt(bv, x0 + i * 62, 900, 70, bv === '1' ? CYAN_D : '#9a9a92', {font: MONO, sc: p.sc, al: p.al}); }); }
    const kc = W('kecil'), kh = W('hemat'), ka = W('awet'); [['KECIL', kc, '#ffe9a8'], ['HEMAT ENERGI', kh, '#c8f2d8'], ['AWET', ka, '#d6e4ff']].forEach(([s, t0, bg], i) => { if (t0 && n > t0 - .15) { const p = popK(n - t0 + .15, .3); tag(s, 540 + (i - 1) * 270, 1090 + (i === 1 ? 0 : 0), {sc: p.sc, al: p.al, bg, size: 28}); } }); };
}

/* ================= G: rangkaian terpadu ================= */
function sG() {
  lights(); const t = n - SB[6]; iso(30 + t * 3, 32, 30, [0, .6, 0], 30, .1); beginFrame();
  const merge = ramp(n, 38.2, 39.2);
  for (let i = 0; i < 6; i++) { const a = i * 1.05, px = lerp(Math.cos(a) * 4.2 - 2.2, -2.6 + i * .5 - .6, eio(merge)), pz = lerp(Math.sin(a) * 3.0 - 1, 0, eio(merge)); if (i % 3 === 0) cylr([px, .35, pz], .22, .6, col('#e2a24a'), {}, [0, 0, 1.5708]); else if (i % 3 === 1) cube([px, .3, pz], [.5, .4, .35], col('#3f4655')); else ball([px, .35, pz], .3, col('#5a8fd8')); }
  shadow(-2.4, 0, 3, .16); cube([-2.4, .1, 0], [4.6, .3, 1.7], col('#b7bcc6')); for (let i = 0; i < 4; i++) cube([-3.5 + i * .75, .38, 0], [.4, .2, .5], col('#3f4655'));
  for (let i = 0; i < 3; i++) seg([-3.5 + i * .75, .5, 0], [-3.1 + i * .75, .7, .9], .05, col('#d9b04a')); if (n > 42.3 - .3) { /* noyce */ }
  const nz = popK(n - 42.0, .5).sc; shadow(2.8, 0, 2.5 * nz, .16); cube([2.8, .15, 0], [3.4 * nz, .3, 3.4 * nz], col('#58708f')); for (let i = 0; i < 9; i++) { cube([2.8 + (i % 3 - 1) * .9 * nz, .35, (Math.floor(i / 3) - 1) * .9 * nz], [.5 * nz, .12, .5 * nz], col('#c8d6ea')); } for (let i = 0; i < 6; i++) { seg([2.8 - 1.4 * nz, .32, (i - 2.5) * .5 * nz], [2.8 + 1.4 * nz, .32, (i - 2.5) * .5 * nz], .03, col('#d9b04a')); }
  flushParticles();
  HUD = () => { head('*1958*: rangkaian terpadu\n(IC)', SB[6] + .02, SB[7]); yearChip('1958', SB[6] + .2, SB[7]); note('JACK KILBY', [-3.4, .6, 0], -60, -250, 39.2, SB[7] - .1); note('ROBERT NOYCE', [2.8, .5, 1.5], 40, -260, 42.2, SB[7] - .1); note('BERBASIS SILIKON', [4.0, .4, 0], -30, 280, 43.5, SB[7] - .1, {bg: INK, fg: '#fff', border: INK}); };
}

/* ================= H: jadi satu chip ================= */
function sH() {
  lights(); const t = n - SB[7], gather = ramp(n, 45.0, 47.6), pack = ramp(n, 47.8, 48.9);
  iso(34 + t * 5, 36, 26, [0, .8, 0], 30, .1); beginFrame(); shadow(0, 0, 3.6, .18);
  const cells = 36; for (let k = 0; k < cells; k++) { const gi = k % 6, gj = Math.floor(k / 6), tx = (gi - 2.5) * .62, tz = (gj - 2.5) * .62; const a = R(k, 61) * 6.283, rr2 = 4 + R(k, 62) * 4, sx = Math.cos(a) * rr2, sz = Math.sin(a) * rr2, sy = 3 + R(k, 63) * 4; const e = eio(clamp(gather * 1.25 - R(k, 64) * .25, 0, 1)); const p = [lerp(sx, tx, e), lerp(sy, .55, e) + Math.sin(e * 3.14) * 1.5, lerp(sz, tz, e)]; cube(p, [.5, .24, .5], mixc(col('#2f3a4d'), col('#4aa9d8'), R(k, 65)), {em: e > .98 ? .5 : 0}); }
  cube([0, .15, 0], [4.2, .3, 4.2], col('#aab4c3'), {al: sstep(46.8, 47.6, n) * (1 - pack * .0)});
  if (pack > 0) draw(CHIPP, mT(0, 3 * (1 - eoutB(pack)) + .35, 0), O({al: Math.max(.001, pack)}));
  flushParticles();
  HUD = () => { head(n < 49.7 ? 'Banyak transistor\ndalam satu *keping*' : 'Rahasianya:\n*fotolitografi*', SB[7] + .02, SB[8]); if (n > 48.94) { const p = popK(n - 48.94, .4); txt('CHIP', 540, 950, 150, INK, {sc: p.sc, al: p.al * clamp((50.4 - n) / .3, 0, 1), stroke: '#fff', sw: 26}); } if (n > 50.53) { const p = popK(n - 50.53, .4); tag('FOTOLITOGRAFI', 540, 900, {sc: p.sc * 1.5, al: p.al, bg: INK, fg: '#fff', border: INK, size: 40}); } };
}

/* ================= J: fotolitografi ================= */
function sJ() {
  lights(); const t = n - SB[8]; iso(34 + t * 2.5, 32, 29, [0, 2.2, 0], 30, .11); beginFrame();
  const lift = n > 62.76 ? 0 : 0; shadow(0, 0, 4.2, .2);
  const spin = n < 55 ? n * 2 : 0; draw(WAFER, mmul(mT(0, 0, 0), mRy(spin)), O({sp: .4, tint: [1, 1, 1]})); draw(WCELLS, mT(0, .22, 0), O({}));
  const coat = ramp(n, 52.73, 53.8); if (coat > 0 && n < 61.2) draw(CY, TRS([0, .3, 0], [0, 0, 0], [3.25 * eout(coat), .1, 3.25 * eout(coat)]), O({tint: col('#ff9ec0'), al: .72, sp: 0}));
  const mY = 3.2 + 3.2 * (1 - eoutB(ramp(n, 54.2, 55.2))) , expo = ramp(n, 55.1, 57.6);
  if (n > 54.1 && n < 59.5) { cube([0, mY, 0], [5.2, .1, 5.2], col('#bfe7f0'), {al: .55, sp: .4}); draw(WEXP, mT(0, mY + .06, 0), O({tint: [.15, .18, .26], al: .95})); for (let i = 0; i < 4; i++) { cube([(i < 2 ? -1 : 1) * 2.7, mY, (i % 2 ? -1 : 1) * 2.7], [.2, .22, .2], col('#2b303b')); } }
  if (n > 55.1 && n < 58.6) { const a = clamp(expo * 3, 0, 1) * (1 - sstep(57.8, 58.6, n)); draw(FRUS, mmul(mT(0, mY + .1, 0), mmul(mS(3.1, -(mY - .3), 3.1), mT(0, -1, 0))), O({tint: col('#9a6bff'), em: .8, al: .22 * a, sp: 0})); cylr([0, 9.6, 0], .9, .9, col('#2b303b')); ball([0, 9.5, 0], .45, col('#9a6bff'), {em: 1}); }
  if (n > 55.6 && n < 61) draw(WEXP, mT(0, .36, 0), O({tint: [1, 1, 1], em: .6 * (1 - sstep(57.6, 58.2, n)) + .2, al: sstep(55.6, 56.4, n) * (1 - sstep(59.0, 60.6, n))}));
  if (n > 60.8) draw(WETCH, mT(0, .2, 0), O({al: sstep(60.8, 61.6, n)}));
  const lay = n > 62.76 ? Math.floor((n - 62.76) / .62) + 1 : 0; for (let k = 0; k < Math.min(lay, 4); k++) { const e = eoutB(clamp((n - 62.76 - k * .62) / .4, 0, 1)); cube([0, .46 + k * .26 + (1 - e) * 2.4, 0], [4.2 - k * .3, .2, 4.2 - k * .3], mixc(col('#7fa6d6'), col('#f0a35c'), k / 3), {al: e < 1 ? Math.max(.001, e) : undefined}); }
  flushParticles();
  HUD = () => {
    head(n < 55 ? 'Wafer silikon\n+ bahan *peka cahaya*' : n < 57.6 ? 'Disinari lewat *cetakan*\npola rangkaian' : n < 62.76 ? 'Bagian terkena cahaya\n*dihilangkan*, lalu *dietsa*' : 'Diulang *lapis*\n*demi lapis*', SB[8] + .02, SB[9]);
    note('WAFER SILIKON', [3.0, .15, 0], 120, 300, 52.1, 52.7); note('PHOTORESIST', [2.4, .35, 1.5], 100, 260, 52.9, 55); note('MASK / RETICLE', [2.6, 3.2, 2.6], 60, -160, 55.0, 57.6); note('CAHAYA UV', [0, 7.5, 0], 220, -60, 55.6, 57.6, {bg: '#e9defe'}); note('BERUBAH SIFAT', [-1, .4, 1.6], -120, 340, 58.2, 60.7); note('ETSA', [1.2, .25, -1.5], 150, 300, 61.0, 62.7);
    if (n > 62.76) { const k = Math.min(4, Math.floor((n - 62.76) / .62) + 1); tag('LAPIS KE-' + k, 540, 1020, {size: 38, bg: INK, fg: '#fff', border: INK}); }
  };
}

/* ================= K: Hukum Moore ================= */
function sK() {
  lights(); const t = n - SB[9]; iso(25 + t * 2, 28, 36, [0, 3.2, 0], 30, .1); beginFrame();
  cube([0, -.1, 0], [9, .2, 3.2], col('#e0ddd2')); const NB = 8;
  for (let i = 0; i < NB; i++) { const t0 = 66.8 + i * .55, e = eoutB(clamp((n - t0) / .45, 0, 1)); const h = .25 * Math.pow(1.62, i) * e + .01; const pul = n > 71.4 ? 1 + .04 * Math.sin((n - 71.4) * 10 + i) : 1; const x = (i - 3.5) * 1.1; shadow(x, 0, .6, .12); cube([x, h * pul / 2, 0], [.8, h * pul, .8], mixc(col('#7fd3ea'), col('#12b5d8'), i / 7), {sp: .25}); }
  flushParticles();
  HUD = () => { head('*1965*: Gordon Moore\n*Hukum Moore*', SB[9] + .02, SB[10]); yearChip('1965', SB[9] + .2, SB[10]); for (let i = 1; i < 8; i++) { const t0 = 66.8 + i * .55; if (n > t0 + .3 && n < 71.4) { const q = P2([(i - 3.5) * 1.1 - .55, .25 * Math.pow(1.62, i) + .9, 0]); tag('×2', q.x, q.y - 20, {size: 26, sc: popK(n - t0 - .3).sc, al: popK(n - t0 - .3).al, bg: '#fff3d6'}); } } if (n > 71.4) { const p = popK(n - 71.4, .4); txt('2×', 540, 1040, 150, CYAN_D, {sc: p.sc, al: p.al, stroke: '#fff', sw: 26}); txt('jumlah komponen berlipat ganda', 540, 1150, 36, INK, {w: 700, al: p.al, stroke: '#fff', sw: 8}); } tag('ILUSTRASI', 930, 1010, {size: 20, bg: '#fff', al: .8}); };
}

/* ================= L: EUV ================= */
function sL() {
  lights(); const t = n - SB[10]; iso(36 + t * 3, 30, 30, [0, 3.5, 0], 30, .1); beginFrame();
  shadow(0, 0, 5, .12); cube([0, -.1, 0], [10, .2, 8], col('#e3e0d6'), {al: .0001});
  const src = [-3.4, 1.0, -2], m1 = [-3.4, 5.8, -2], m2 = [0.6, 5.8, 0], m3 = [0.6, 3.4, 1.6], tgt = [0.6, .4, 1.6];
  cube([-3.4, .35, -2], [2.4, .7, 2.4], col('#4a505c')); ball(src, .55, col('#bda0ff'), {em: 1}); pt(PB.alp, src, 2.4, [.65, .45, 1], .16, 0);
  [[m1, 0], [m2, 0], [m3, 0]].forEach((m) => { cylr(m[0], .8, .12, col('#cfd6e2'), {sp: .7}, [.7, 0, .5]); });
  const flow = clamp((n - 76.5) / .5, 0, 1); [[src, m1], [m1, m2], [m2, m3], [m3, tgt]].forEach((s, i) => { if (flow > 0) seg(s[0], s[1], .07, col('#8a5cff'), {em: .9}); });
  cylr([.6, .1, 1.6], 1.6, .2, col('#aab4c3'), {sp: .5}); ball(tgt, .3, col('#8a5cff'), {em: 1});
  flushParticles();
  HUD = () => { head('Cahaya *ultraviolet ekstrem*\n(EUV)', SB[10] + .02, SB[11]); note('SUMBER CAHAYA', src, 160, 300, 74.6, SB[11] - .1); note('CERMIN', m2, 150, -140, 75.6, SB[11] - .1); note('WAFER', tgt, 150, 260, 76.2, SB[11] - .1);
    if (n > 77.9) { const p = popK(n - 77.9, .4); tag('13,5 nm', 540, 1040, {size: 56, bg: '#e9defe', border: '#b8a2f0', sc: p.sc, al: p.al}); ctx.save(); ctx.globalAlpha = p.al; ctx.strokeStyle = '#7a4dff'; ctx.lineWidth = 6; ctx.beginPath(); for (let x = 160; x <= 920; x += 4) { const y = 1130 + Math.sin((x - n * 140) / 18) * 30; x === 160 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); } ctx.stroke(); ctx.restore(); } };
}

/* ================= M: 3 nm ================= */
function sM() {
  lights(); const t = n - SB[11]; iso(30 + t * 4, 30, 18, [0, 1.2, 0], 30, .12); beginFrame();
  shadow(0, 0, 3.2, .16); cube([0, .15, 0], [5, .3, 4.2], col('#aab4c3'));
  for (let i = 0; i < 3; i++) cube([(i - 1) * 1.1, .85, 0], [.55, 1.2, 3], col('#6aa6d8'), {sp: .25}); cube([0, 1.0, 0], [4, .4, .6], col('#d9b04a'), {sp: .5});
  flushParticles();
  HUD = () => { head(n < 83.7 ? 'Angka *3 nm*\npada nama prosesor' : 'Nama *generasi* teknologi,\nbukan ukuran pasti', SB[11] + .02, SB[12]);
    const p = popK(n - 80.9, .4), fl = clamp((n - 83.74) / .4, 0, 1), sx = Math.abs(Math.cos(fl * Math.PI)), back = fl > .5;
    ctx.save(); ctx.translate(540, 560); ctx.scale(sx || .01, 1); ctx.globalAlpha = p.al; ctx.shadowColor = 'rgba(20,22,28,.2)'; ctx.shadowBlur = 24; ctx.shadowOffsetY = 8; ctx.fillStyle = back ? INK : '#fff'; rr(-290, -150, 580, 300, 40); ctx.fill(); ctx.shadowBlur = 0; ctx.shadowOffsetY = 0; ctx.fillStyle = back ? '#fff' : INK; ctx.font = `800 ${back ? 70 : 150}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(back ? 'NAMA\nGENERASI'.split('\n')[0] : '3 nm', 0, back ? -40 : 0); if (back) ctx.fillText('GENERASI', 0, 50); ctx.restore();
    if (n > 85.0) { const q = popK(n - 85.0, .4); ctx.save(); ctx.globalAlpha = q.al; ctx.fillStyle = '#e5484d'; ctx.translate(540, 900); ctx.scale(q.sc, q.sc); rr(-330, -52, 660, 104, 52); ctx.fill(); ctx.fillStyle = '#fff'; ctx.font = `800 40px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('≠ UKURAN PASTI TRANSISTOR', 0, 3); ctx.restore(); } };
}

/* ================= N: penutup ================= */
function sN() {
  lights(); const t = n - SB[12]; iso(30 + t * 8, 34, 24, [0, 1.2, 0], 30, .1); beginFrame(); shadow(0, 0, 3, .16);
  draw(CHIPP, mmul(mT(0, .3, 0), mRy(t * .7)), O({})); const fi = W('fisika'), ki = W('kimia'), re = W('rekayasa');
  [[fi, 0], [ki, 1], [re, 2]].forEach(([t0, i]) => { const e = eoutB(clamp((n - t0 + .3) / .5, 0, 1)); if (e <= 0) return; const ang = t * .8 + i * 2.094, p = [Math.cos(ang) * 3 * e, 2.4 + Math.sin(t * 2 + i) * .3, Math.sin(ang) * 3 * e];
    if (i === 0) { ball(p, .3 * e, col('#e5484d')); draw(TOR, mmul(mT(p[0], p[1], p[2]), mmul(mRx(1.2 + t), mS(1.1 * e))), O({tint: col('#12b5d8')})); draw(TOR, mmul(mT(p[0], p[1], p[2]), mmul(mRy(1 + t), mS(1.1 * e))), O({tint: col('#12b5d8')})); }
    if (i === 1) { cylr([p[0], p[1] - .4, p[2]], .2 * e, .8 * e, col('#cfe9f0'), {al: .85}); ball([p[0], p[1] - .6 * e, p[2]], .6 * e, col('#7ee0a8'), {}); }
    if (i === 2) draw(GEAR, mmul(mT(p[0], p[1] - .2, p[2]), mmul(mRz(1.5708), mmul(mRx(t * 2), mS(.9 * e)))), O({})); });
  flushParticles();
  HUD = () => { head('Chip sekecil itu *bukan sulap*', SB[12] + .02, NEND);
    [['FISIKA', fi], ['KIMIA', ki], ['REKAYASA', re]].forEach(([s, t0], i) => { if (n > t0 - .1) { const p = popK(n - t0 + .1, .3); tag(s, 540 + (i - 1) * 290, 1040, {size: 34, sc: p.sc, al: p.al, bg: [CYAN, '#7ee0a8', '#ffd24a'][i], border: '#fff'}); } });
    if (n > 89.21 - .1) { const p = popK(n - 89.1, .3); ctx.save(); ctx.globalAlpha = p.al; ctx.translate(540, 800); ctx.rotate(-.04); ctx.fillStyle = '#fff'; ctx.shadowColor = 'rgba(0,0,0,.15)'; ctx.shadowBlur = 20; rr(-230, -64, 460, 128, 30); ctx.fill(); ctx.shadowBlur = 0; ctx.font = `800 80px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#9a9a92'; ctx.fillText('SULAP', 0, 4); ctx.strokeStyle = '#e5484d'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(-190 * p.sc, 0); ctx.lineTo(190 * p.sc, 0); ctx.stroke(); ctx.restore(); }
    if (n > NEND) { const k = n - NEND, a = clamp(k / .4, 0, 1); ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = '#f4f3ee'; ctx.fillRect(0, 0, 1080, 1920); ctx.restore(); const p = popK(k - .1, .5);
      txt('Semesta', 540, 560, 150, INK, {sc: p.sc, al: p.al}); txt('Kita', 540, 700, 170, CYAN_D, {sc: popK(k - .25, .5).sc, al: popK(k - .25, .5).al}); txt('Ikuti untuk sains yang asyik & jelas', 540, 860, 44, INK, {w: 700, al: clamp((k - .6) / .4, 0, 1)});
      tag('Kirim ke teman yang masih bingung 👇', 540, 990, {size: 34, bg: INK, fg: '#fff', border: INK, al: clamp((k - 1) / .4, 0, 1)}); txt('Sumber: Tokyo Electron • Computer History Museum •\nIntel • ASML • IEEE • National Academies', 540, 1140, 26, '#6b6b66', {w: 600, al: clamp((k - 1.3) / .5, 0, 1)}); } };
  const fi2 = fi, ki2 = ki, re2 = re;
}

/* ================= caption & watermark ================= */
const CHUNKS = (() => { const out = []; let cur = []; const flush = () => { if (cur.length) out.push(cur); cur = []; }; WORDS.forEach((w) => { const len = cur.reduce((a, c) => a + c.w.length + 1, 0); if (cur.length && (len + w.w.length > 30 || cur.length >= 5)) flush(); cur.push(w); if (w.b) flush(); }); flush(); return out.map((c, i) => ({ws: c, a: c[0].a, e: out[i + 1] ? Math.min(out[i + 1][0].a, c[c.length - 1].e + .4) : c[c.length - 1].e + .3})); })();
function captions() {
  if (n >= NEND - .1) return; const ch = CHUNKS.find((c) => n >= c.a - .02 && n < c.e); if (!ch) return; const size = 46, y = 1235;
  ctx.save(); ctx.font = `700 ${size}px ${FONT}`; const sp = size * .3, ws = ch.ws.map((w) => ctx.measureText(w.w.replace(/[,\.\?:]+$/, '')).width); const tot = ws.reduce((a, b) => a + b, 0) + sp * (ws.length - 1);
  let lines = [[...ch.ws.keys()]]; if (tot > 860) { let acc = 0, split = 0; for (let i = 0; i < ws.length; i++) { acc += ws[i] + sp; if (acc > tot / 2) { split = i + 1; break; } } lines = [[...ch.ws.keys()].slice(0, split), [...ch.ws.keys()].slice(split)]; }
  const lw = lines.map((l) => l.reduce((a, i) => a + ws[i], 0) + sp * (l.length - 1)), pw = Math.max(...lw) + 70, ph = lines.length * size * 1.4 + 26, py = y - ph / 2;
  const pop = clamp((n - ch.a) / .1, 0, 1); ctx.globalAlpha = pop; ctx.fillStyle = 'rgba(32,36,44,.92)'; rr(540 - pw / 2, py, pw, ph, 30); ctx.fill();
  lines.forEach((l, li) => { let x = 540 - lw[li] / 2; const yy = py + 13 + size * .7 + li * size * 1.4; l.forEach((i) => { const w = ch.ws[i], act = n >= w.a - .02 && n < w.e + .04 || (i === ch.ws.length - 1 && n >= w.a); if (act) { ctx.fillStyle = '#2ac7e8'; rr(x - 12, yy - size * .62, ws[i] + 24, size * 1.24, 12); ctx.fill(); } ctx.fillStyle = act ? '#06232b' : '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(w.w.replace(/[,\.\?:]+$/, ''), x, yy); x += ws[i] + sp; }); }); ctx.restore();
}
function watermark() { ctx.save(); ctx.globalAlpha = .8; const x = 1030, y = 1445; ctx.font = `800 34px ${FONT}`; const wk = ctx.measureText('Kita').width, ws = ctx.measureText('Semesta').width; ctx.textBaseline = 'middle'; ctx.textAlign = 'right'; ctx.fillStyle = INK; ctx.fillText('Semesta', x - wk, y); ctx.fillStyle = CYAN_D; ctx.fillText('Kita', x, y); ctx.fillStyle = CYAN; ctx.beginPath(); ctx.arc(x - wk - ws - 28, y, 14, 0, 6.283); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x - wk - ws - 28, y, 14, 5, -.5, 0, 6.283); ctx.stroke(); ctx.restore(); }
function transitions() { SB.slice(1, -1).forEach((b) => { const t = n - b; if (t > -.1 && t < .3) { const a = t < 0 ? (1 + t / .1) * .55 : Math.pow(1 - t / .3, 2) * .9; ctx.save(); ctx.globalAlpha = clamp(a, 0, 1); ctx.fillStyle = '#f4f3ee'; ctx.fillRect(0, 0, 1080, 1920); ctx.restore(); } }); }

const SCN = [sA, sB, sC, sD, sE, sF, sG, sH, sJ, sK, sL, sM, sN];
ENGINE.renderFrame = function (T) {
  n = T - OFF; let i = 0; while (i < SCN.length - 1 && n >= SB[i + 1]) i++; SCN[i]();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.fillStyle = '#f4f3ee'; ctx.fillRect(0, 0, CW, CH); const g = ctx.createRadialGradient(CW / 2, CH * .45, CW * .2, CW / 2, CH * .45, CH * .75); g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(210,208,196,.0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, CW, CH);
  ctx.drawImage(glc, 0, 0); ctx.save(); ctx.scale(SC, SC); HUD(); transitions(); captions(); watermark(); ctx.restore();
};
ENGINE.grab = () => outc.toDataURL('image/jpeg', .92);
})();

  return ENGINE;
}

export const Chip: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<any>(null);

  useLayoutEffect(() => {
    if (!engineRef.current) engineRef.current = createEngine(canvasRef.current!);
    engineRef.current.renderFrame(frame / fps);
  }, [frame, fps]);

  return (
    <AbsoluteFill style={{backgroundColor: '#f4f3ee'}}>
      <canvas ref={canvasRef} style={{width: 1080, height: 1920, display: 'block'}} />
      <Audio src={staticFile('audio.mp3')} />
    </AbsoluteFill>
  );
};
