import React from 'react';
import {Composition} from 'remotion';
import {Chip} from './Chip';

// 97,5 detik x 60 fps = 5850 frame, 1080x1920 (9:16)
export const RemotionRoot: React.FC = () => (
  <Composition id="Chip" component={Chip} durationInFrames={5850} fps={60} width={1080} height={1920} />
);
