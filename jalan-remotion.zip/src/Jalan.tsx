import React from 'react';
import {AbsoluteFill, useCurrentFrame, random} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Poppins';

/* ===== PENGATURAN ===== */
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_SECONDS = 30;
export const TOTAL_FRAMES = TOTAL_SECONDS * FPS;

const font = loadFont('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;

// Dialog: siapa yang bicara (A = Andi biru, B = Sari oranye), mulai, selesai (detik), teks. Ganti sesuka hati.
type Line = {who: 'A' | 'B'; t0: number; t1: number; text: string};
const DIALOG: Line[] = [
  {who: 'B', t0: 8.2, t1: 10.6, text: 'Eh, Andi! Lagi jalan-jalan juga?'},
  {who: 'A', t0: 10.8, t1: 13.2, text: 'Iya nih, lagi cari udara segar.'},
  {who: 'B', t0: 13.4, t1: 15.4, text: 'Bareng aja yuk, sambil ngobrol!'},
  {who: 'A', t0: 15.8, t1: 18.6, text: 'Boleh banget. Kamu habis dari mana?'},
  {who: 'B', t0: 18.9, t1: 21.4, text: 'Habis dari pasar, beli buah.'},
  {who: 'A', t0: 21.6, t1: 23.6, text: 'Wah, enak banget tuh!'},
  {who: 'B', t0: 23.8, t1: 25.9, text: 'Nanti mampir ke rumah ya.'},
  {who: 'A', t0: 26.2, t1: 28.1, text: 'Siap! Sampai ketemu lagi!'},
  {who: 'B', t0: 28.1, t1: 29.4, text: 'Dadah, hati-hati!'},
];

/* ===== UTIL ===== */
const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const smooth = (t: number) => {
  const c = clamp(t);
  return c * c * (3 - 2 * c);
};
const seg = (t: number, a: number, b: number) => smooth((t - a) / (b - a)); // 0..1 di antara a dan b
const mod = (n: number, m: number) => ((n % m) + m) % m;

// Kecepatan gulir latar (px/detik): jalan sendiri -> berhenti ngobrol -> jalan bareng -> berhenti pamit
const SPEED = 240;
const speedAt = (t: number) =>
  SPEED * (seg(t, 0.2, 1.2) * (1 - seg(t, 7, 8.2)) + seg(t, 14.2, 15.2) * (1 - seg(t, 25.5, 26.5)));

// Jarak tempuh (integral kecepatan), dihitung sekali
const DIST: number[] = (() => {
  const a = [0];
  for (let f = 1; f <= TOTAL_FRAMES; f++) a.push(a[f - 1] + speedAt(f / FPS) / FPS);
  return a;
})();

// Ayunan jalan tiap orang (0..1) dan fasenya (integral supaya langkah mulus)
const ampA = (t: number) => clamp(Math.max(speedAt(t) / SPEED, seg(t, 0, 0.4) * (1 - seg(t, 2.4, 2.8))));
const ampB = (t: number) => (t < 8.2 ? seg(t, 3, 3.5) * (1 - seg(t, 7.4, 8.2)) : speedAt(t) / SPEED);
const CADENCE = 5.3; // radian/detik
const phases = (fn: (t: number) => number) => {
  const a = [0];
  for (let f = 1; f <= TOTAL_FRAMES; f++) a.push(a[f - 1] + (fn(f / FPS) * CADENCE) / FPS);
  return a;
};
const PHASE_A = phases(ampA);
const PHASE_B = phases(ampB);

/* ===== LATAR ===== */
const TILE = 1920;

const Hills: React.FC<{offset: number; base: number; amp: number; color: string; k1: number; k2: number}> = ({offset, base, amp, color, k1, k2}) => {
  const pts: string[] = [];
  for (let x = -40; x <= WIDTH + 40; x += 40) {
    const u = ((x + offset) / TILE) * Math.PI * 2;
    pts.push(`${x},${base - amp * (0.6 * Math.sin(u * k1) + 0.4 * Math.sin(u * k2 + 1))}`);
  }
  return <polygon points={`-40,${HEIGHT} ${pts.join(' ')} ${WIDTH + 40},${HEIGHT}`} fill={color} />;
};

const Tree: React.FC<{x: number; base: number; s: number; tone: number}> = ({x, base, s, tone}) => (
  <g transform={`translate(${x},${base}) scale(${s})`}>
    <rect x={-14} y={-150} width={28} height={150} rx={8} fill="#7a5238" />
    <circle cx={0} cy={-200} r={92} fill={`hsl(${112 + tone * 14},42%,${34 + tone * 5}%)`} />
    <circle cx={-62} cy={-150} r={62} fill={`hsl(${108 + tone * 14},44%,${31 + tone * 5}%)`} />
    <circle cx={64} cy={-155} r={64} fill={`hsl(${116 + tone * 14},40%,${36 + tone * 5}%)`} />
  </g>
);

const TREE_X = [90, 420, 760, 1150, 1480, 1790];
const Trees: React.FC<{offset: number; base: number; s: number}> = ({offset, base, s}) => {
  const o = mod(offset, TILE);
  return (
    <>
      {[-1, 0, 1].flatMap((c) =>
        TREE_X.map((x, i) => (
          <Tree key={`${c}_${i}`} x={x + c * TILE - o} base={base} s={s * (0.85 + random(`t${i}`) * 0.3)} tone={random(`c${i}`)} />
        )),
      )}
    </>
  );
};

const Lamp: React.FC<{x: number}> = ({x}) => (
  <g transform={`translate(${x},880)`}>
    <rect x={-7} y={-330} width={14} height={330} rx={5} fill="#3c4450" />
    <rect x={-7} y={-330} width={70} height={12} rx={5} fill="#3c4450" />
    <ellipse cx={58} cy={-308} rx={22} ry={14} fill="#ffe08a" />
  </g>
);
const Bush: React.FC<{x: number; s: number}> = ({x, s}) => (
  <g transform={`translate(${x},860) scale(${s})`}>
    <circle cx={-40} cy={-30} r={44} fill="#3f8a45" />
    <circle cx={10} cy={-46} r={56} fill="#4a9a50" />
    <circle cx={62} cy={-28} r={42} fill="#3f8a45" />
    <circle cx={30} cy={-64} r={10} fill="#ff7aa8" />
    <circle cx={-34} cy={-52} r={9} fill="#ffd45a" />
  </g>
);

const Near: React.FC<{offset: number}> = ({offset}) => {
  const o = mod(offset, TILE);
  return (
    <>
      {[-1, 0, 1].map((c) => (
        <g key={c}>
          <Lamp x={300 + c * TILE - o} />
          <Lamp x={1260 + c * TILE - o} />
          <Bush x={640 + c * TILE - o} s={1} />
          <Bush x={1620 + c * TILE - o} s={1.2} />
        </g>
      ))}
    </>
  );
};

const Cloud: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill="#ffffff" opacity={0.85}>
    <ellipse cx={0} cy={0} rx={90} ry={34} />
    <ellipse cx={-50} cy={-20} rx={50} ry={34} />
    <ellipse cx={30} cy={-30} rx={60} ry={40} />
  </g>
);

/* ===== ORANG ===== */
type PersonProps = {
  x: number;
  face: number; // 1 = hadap kanan, -1 = hadap kiri (nilai antara = sedang berbalik)
  phase: number;
  amp: number; // 0..1 ayunan jalan
  shirt: string;
  pants: string;
  hair: string;
  skin: string;
  talking: boolean;
  frame: number;
  wave: number; // 0..1 melambai
  long?: boolean;
};

const Person: React.FC<PersonProps> = ({x, face, phase, amp, shirt, pants, hair, skin, talking, frame, wave, long}) => {
  const sw = Math.sin(phase) * 28 * amp;
  const bob = -Math.abs(Math.sin(phase)) * 9 * amp;
  const mouthOpen = talking ? 3 + 7 * Math.abs(Math.sin(frame * 0.8)) : 0;
  const waveAng = -140 + Math.sin(frame * 0.5) * 18;
  const armBack = wave > 0.01 ? 8 : -sw;
  return (
    <g transform={`translate(${x},900)`}>
      <ellipse cx={0} cy={4} rx={78} ry={14} fill="#000" opacity={0.2} />
      <g transform={`scale(${face},1) translate(0,${bob})`}>
        {/* kaki belakang */}
        <g transform={`translate(0,-170) rotate(${-sw})`}>
          <rect x={-15} y={0} width={30} height={166} rx={12} fill={pants} opacity={0.8} />
          <ellipse cx={10} cy={168} rx={32} ry={12} fill="#2b2b33" />
        </g>
        {/* lengan belakang */}
        <g transform={`translate(0,-306) rotate(${armBack})`}>
          <rect x={-11} y={0} width={22} height={140} rx={11} fill={shirt} opacity={0.75} />
          <circle cx={0} cy={142} r={14} fill={skin} />
        </g>
        {/* badan */}
        <rect x={-48} y={-335} width={96} height={175} rx={34} fill={shirt} />
        <rect x={-48} y={-200} width={96} height={42} rx={16} fill={pants} />
        {/* kaki depan */}
        <g transform={`translate(0,-170) rotate(${sw})`}>
          <rect x={-15} y={0} width={30} height={166} rx={12} fill={pants} />
          <ellipse cx={10} cy={168} rx={32} ry={12} fill="#2b2b33" />
        </g>
        {/* leher dan kepala */}
        <rect x={-12} y={-352} width={24} height={26} fill={skin} />
        <circle cx={0} cy={-392} r={52} fill={skin} />
        {long ? (
          <>
            <path d="M-56,-380 Q-60,-452 0,-452 Q60,-452 56,-380 L56,-300 Q40,-296 40,-340 L40,-392 Q0,-420 -40,-392 L-40,-340 Q-40,-296 -56,-300 Z" fill={hair} />
          </>
        ) : (
          <path d="M-54,-392 Q-58,-452 0,-450 Q58,-452 54,-392 Q40,-424 0,-424 Q-40,-424 -54,-392 Z" fill={hair} />
        )}
        <circle cx={20} cy={-394} r={5.5} fill="#222" />
        <circle cx={-6} cy={-394} r={5.5} fill="#222" />
        {mouthOpen > 0 ? (
          <ellipse cx={13} cy={-372} rx={9} ry={mouthOpen} fill="#8a2f3a" />
        ) : (
          <path d="M4,-374 Q13,-366 24,-374" stroke="#8a2f3a" strokeWidth={4} fill="none" strokeLinecap="round" />
        )}
        {/* lengan depan */}
        {wave > 0.01 ? (
          <g transform={`translate(0,-306) rotate(${waveAng * wave})`}>
            <rect x={-11} y={0} width={22} height={140} rx={11} fill={shirt} />
            <circle cx={0} cy={142} r={14} fill={skin} />
          </g>
        ) : (
          <g transform={`translate(0,-306) rotate(${sw})`}>
            <rect x={-11} y={0} width={22} height={140} rx={11} fill={shirt} />
            <circle cx={0} cy={142} r={14} fill={skin} />
          </g>
        )}
      </g>
    </g>
  );
};

/* ===== BALON KATA ===== */
const Bubble: React.FC<{line: Line; t: number; sx: number}> = ({line, t, sx}) => {
  const k = t - line.t0;
  const pop = seg(k, 0, 0.25);
  const out = 1 - seg(t, line.t1 - 0.2, line.t1);
  const chars = Math.floor(clamp(k / 0.7) * line.text.length);
  const half = 290;
  const cx = clamp(sx, half + 30, WIDTH - half - 30);
  return (
    <div
      style={{
        position: 'absolute',
        left: cx,
        top: 410,
        transform: `translate(-50%,-100%) scale(${0.6 + 0.4 * pop})`,
        transformOrigin: `${50 + ((sx - cx) / (half * 2)) * 100}% 100%`,
        opacity: pop * out,
      }}
    >
      <div
        style={{
          position: 'relative',
          maxWidth: half * 2,
          background: '#ffffff',
          color: '#1f2430',
          fontFamily: font,
          fontWeight: 600,
          fontSize: 46,
          lineHeight: 1.25,
          padding: '24px 38px',
          borderRadius: 38,
          boxShadow: '0 10px 30px rgba(0,0,0,0.25)',
          textAlign: 'center',
        }}
      >
        <span>{line.text.slice(0, chars)}</span>
        <span style={{opacity: 0}}>{line.text.slice(chars)}</span>
        <div
          style={{
            position: 'absolute',
            bottom: -16,
            left: `calc(50% + ${clamp(sx - cx, -half + 60, half - 60)}px)`,
            width: 36,
            height: 36,
            background: '#ffffff',
            transform: 'translateX(-50%) rotate(45deg)',
            borderRadius: 6,
          }}
        />
      </div>
    </div>
  );
};

/* ===== KOMPOSISI ===== */
export const Jalan: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const dist = DIST[Math.min(frame, TOTAL_FRAMES)];
  const fi = Math.min(frame, TOTAL_FRAMES);

  // Andi (A): masuk dari kiri, lalu tetap di kiri-tengah
  const ax = -220 + (780 + 220) * seg(t, 0, 2.6);
  const aAmp = ampA(t);
  const aPhase = PHASE_A[fi];

  // Sari (B): datang dari kanan (3-8 dtk), berdiri, balik badan jalan bareng (14 dtk), balik lagi pamit (26 dtk)
  const bx = t < 14 ? 2200 - (2200 - 1170) * seg(t, 3, 8) : 1170 - 130 * seg(t, 14, 15.2);
  const bAmp = ampB(t);
  const bPhase = PHASE_B[fi];
  const bFace = t < 26 ? -1 + 2 * seg(t, 13.9, 14.2) : 1 - 2 * seg(t, 26.1, 26.4);

  const wave = seg(t, 26.6, 27.0) * (1 - seg(t, 29.2, 29.5));
  const active = DIALOG.find((l) => t >= l.t0 && t <= l.t1);

  const fadeIn = 1 - seg(t, 0, 0.5);
  const fadeOut = seg(t, 29.2, 30);
  const black = Math.max(fadeIn, fadeOut);

  return (
    <AbsoluteFill style={{background: '#000', fontFamily: font}}>
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#7fc8ff" />
            <stop offset="0.7" stopColor="#d9efff" />
            <stop offset="1" stopColor="#ffe9c7" />
          </linearGradient>
          <radialGradient id="sun" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#fff6c9" stopOpacity="1" />
            <stop offset="1" stopColor="#fff6c9" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="grass" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#6fb35a" />
            <stop offset="1" stopColor="#4f9a47" />
          </linearGradient>
        </defs>
        <rect width={WIDTH} height={HEIGHT} fill="url(#sky)" />
        <circle cx={1480} cy={210} r={220} fill="url(#sun)" />
        <circle cx={1480} cy={210} r={78} fill="#fff1b0" />
        <Cloud x={mod(300 + t * 14, WIDTH + 400) - 200} y={150} s={1.2} />
        <Cloud x={mod(1100 + t * 9, WIDTH + 400) - 200} y={260} s={0.9} />
        <Cloud x={mod(1700 + t * 11, WIDTH + 400) - 200} y={110} s={0.7} />
        <Hills offset={dist * 0.06} base={640} amp={70} color="#a9d3b4" k1={1} k2={3} />
        <Hills offset={dist * 0.15} base={700} amp={60} color="#86bf8f" k1={2} k2={5} />
        <Trees offset={dist * 0.35} base={770} s={0.7} />
        <rect x={0} y={770} width={WIDTH} height={130} fill="url(#grass)" />
        <Trees offset={dist * 0.6} base={820} s={0.95} />
        <rect x={0} y={835} width={WIDTH} height={HEIGHT - 835} fill="#d8c3a0" />
        <rect x={0} y={835} width={WIDTH} height={10} fill="#bfa982" />
        {[-1, 0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <rect key={i} x={i * 240 - mod(dist, 240) + 10} y={985} width={120} height={10} rx={5} fill="#c4ac84" />
        ))}
        <Near offset={dist} />
        <Person x={ax} face={1} phase={aPhase} amp={aAmp} shirt="#3f7be0" pants="#2f3a56" hair="#2a1f1a" skin="#e8b48a" talking={!!active && active.who === 'A'} frame={frame} wave={wave} />
        <Person x={bx} face={bFace} phase={bPhase} amp={bAmp} shirt="#f08a3c" pants="#6b4a7a" hair="#3a2418" skin="#d99c74" talking={!!active && active.who === 'B'} frame={frame + 7} wave={wave} long />
      </svg>
      {DIALOG.filter((l) => t >= l.t0 - 0.01 && t <= l.t1).map((l, i) => (
        <Bubble key={i} line={l} t={t} sx={l.who === 'A' ? ax : bx} />
      ))}
      <AbsoluteFill style={{background: '#000', opacity: black}} />
    </AbsoluteFill>
  );
};
