import React from 'react';
import {Composition} from 'remotion';
import {Jalan, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Jalan';

export const RemotionRoot: React.FC = () => (
  <Composition id="Jalan" component={Jalan} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
