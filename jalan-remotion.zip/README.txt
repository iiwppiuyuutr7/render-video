Jalan Sore - animasi 2D tes (dua orang jalan, ketemu, ngobrol, pisah)
Isi: src/Root.tsx, src/Jalan.tsx  (tanpa aset luar, tanpa audio)
Composition id: Jalan | 1920x1080 | 30 fps | 30 detik (900 frame)
Dialog: array DIALOG di atas Jalan.tsx ([siapa A/B, mulai, selesai (detik), teks]).
Butuh: remotion, @remotion/google-fonts
Render: npx remotion render Jalan out/jalan.mp4
