import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  BAGAIMANA JIKA ASTEROID RAKSASA MENABRAK BUMI?  (animasi kartun 2D)
  129,5 detik, vertikal 1080x1920, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Semua karakter dan latar digambar dengan SVG (orisinal). Waktu kata ada di WD (sinkron dengan voice asli, tanpa dipercepat).
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '700', '800'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;
const HZ = 1120; // garis horizon kota
const DUR = 129.5;
const WM_BOTTOM = 270; // jarak watermark dari bawah (naikkan/turunkan di sini)
const OUT = '#2b1b17';

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  cyan: '#5ad1ff',
  red: '#ff4d4d',
  green: '#6ee7a0',
  ink: '#5a3d22',
  bone: '#f4e8cf',
};

const WD: [string, number, number][] = [
  ["Bayangkan", 0.00, 0.59],
  ["sebuah", 0.59, 1.02],
  ["batu", 1.02, 1.33],
  ["seukuran", 1.33, 1.86],
  ["gunung", 1.86, 2.29],
  ["melesat", 2.29, 2.77],
  ["ke", 2.77, 2.96],
  ["arah", 2.96, 3.27],
  ["Bumi", 3.27, 3.58],
  ["dengan", 3.58, 4.01],
  ["kecepatan", 4.01, 4.60],
  ["puluhan", 4.60, 5.08],
  ["kilometer", 5.08, 5.67],
  ["per", 5.67, 5.93],
  ["detik.", 5.93, 6.29],
  ["Apa", 6.74, 6.98],
  ["yang", 6.98, 7.27],
  ["sebenarnya", 7.27, 7.87],
  ["terjadi", 7.87, 8.32],
  ["kalau", 8.32, 8.66],
  ["ia", 8.66, 8.84],
  ["menabrak", 8.84, 9.34],
  ["planet", 9.34, 9.74],
  ["kita?", 9.74, 10.03],
  ["Asteroid", 10.60, 11.13],
  ["adalah", 11.13, 11.55],
  ["benda", 11.55, 11.91],
  ["langit", 11.91, 12.33],
  ["berbatu", 12.33, 12.80],
  ["yang", 12.80, 13.11],
  ["mengorbit", 13.11, 13.70],
  ["Matahari.", 13.70, 14.22],
  ["Saat", 14.61, 14.94],
  ["memasuki", 14.94, 15.52],
  ["atmosfer,", 15.52, 16.09],
  ["udara", 16.39, 16.75],
  ["di", 16.75, 16.94],
  ["depannya", 16.94, 17.47],
  ["terkompresi", 17.47, 18.16],
  ["dan", 18.16, 18.41],
  ["memanas", 18.41, 18.88],
  ["ekstrem.", 18.88, 19.35],
  ["Benda", 19.71, 20.06],
  ["kecil", 20.06, 20.41],
  ["biasanya", 20.41, 20.92],
  ["hancur", 20.92, 21.33],
  ["sebelum", 21.33, 21.79],
  ["mencapai", 21.79, 22.30],
  ["tanah.", 22.30, 22.65],
  ["Cahayanya", 23.01, 23.68],
  ["kita", 23.68, 24.03],
  ["sebut", 24.03, 24.45],
  ["meteor,", 24.45, 24.93],
  ["dan", 25.22, 25.48],
  ["sisa", 25.48, 25.80],
  ["yang", 25.80, 26.11],
  ["sampai", 26.11, 26.55],
  ["ke", 26.55, 26.75],
  ["permukaan", 26.75, 27.35],
  ["disebut", 27.35, 27.84],
  ["meteorit.", 27.84, 28.39],
  ["Tapi", 28.76, 29.09],
  ["asteroid", 29.09, 29.66],
  ["yang", 29.66, 29.99],
  ["cukup", 29.99, 30.38],
  ["besar", 30.38, 30.76],
  ["bisa", 30.76, 31.09],
  ["menembus", 31.09, 31.66],
  ["atmosfer", 31.66, 32.23],
  ["dan", 32.23, 32.50],
  ["menghantam", 32.50, 33.19],
  ["Bumi.", 33.19, 33.52],
  ["Saat", 33.90, 34.23],
  ["menumbuk,", 34.23, 34.80],
  ["seluruh", 34.80, 35.31],
  ["energinya", 35.31, 35.95],
  ["dilepas", 35.95, 36.46],
  ["dalam", 36.46, 36.85],
  ["sekejap:", 36.85, 37.36],
  ["kawah,", 37.63, 38.16],
  ["gelombang", 38.43, 38.89],
  ["kejut,", 38.89, 39.17],
  ["panas", 39.60, 40.04],
  ["ekstrem,", 40.04, 40.60],
  ["dan", 40.60, 40.90],
  ["gempa.", 40.90, 41.33],
  ["Jika", 41.70, 41.95],
  ["jatuh", 41.95, 42.25],
  ["di", 42.25, 42.41],
  ["laut,", 42.41, 42.67],
  ["bisa", 42.93, 43.26],
  ["memicu", 43.26, 43.70],
  ["tsunami.", 43.70, 44.21],
  ["Tapi", 44.60, 44.92],
  ["tidak", 44.92, 45.29],
  ["semuanya", 45.29, 45.83],
  ["sama.", 45.83, 46.15],
  ["Asteroid", 46.53, 47.07],
  ["10", 47.07, 47.46],
  ["meter", 47.46, 47.83],
  ["cukup", 47.83, 48.21],
  ["menghasilkan", 48.21, 48.98],
  ["bola", 48.98, 49.30],
  ["api,", 49.30, 49.56],
  ["1", 49.92, 50.18],
  ["kilometer", 50.18, 50.83],
  ["bisa", 50.83, 51.18],
  ["berdampak", 51.18, 51.84],
  ["global,", 51.84, 52.31],
  ["dan", 52.60, 52.88],
  ["10", 52.88, 53.30],
  ["kilometer", 53.30, 53.97],
  ["berpotensi", 53.97, 54.70],
  ["menyebabkan", 54.70, 55.49],
  ["kepunahan", 55.49, 56.15],
  ["massal.", 56.15, 56.62],
  ["Ini", 56.99, 57.28],
  ["bukan", 57.28, 57.70],
  ["sekadar", 57.70, 58.24],
  ["teori.", 58.24, 58.66],
  ["Sekitar", 58.97, 59.54],
  ["66", 59.54, 59.99],
  ["juta", 59.99, 60.37],
  ["tahun", 60.37, 60.80],
  ["lalu,", 60.80, 61.17],
  ["asteroid", 61.42, 61.96],
  ["selebar", 61.96, 62.45],
  ["10", 62.45, 62.84],
  ["kilometer", 62.84, 63.44],
  ["menghantam", 63.44, 64.09],
  ["Semenanjung", 64.09, 64.81],
  ["Yucatán", 64.81, 65.30],
  ["di", 65.30, 65.50],
  ["Meksiko,", 65.50, 65.98],
  ["membentuk", 66.23, 66.81],
  ["kawah", 66.81, 67.17],
  ["Chicxulub", 67.17, 67.75],
  ["berdiameter", 67.75, 68.44],
  ["sekitar", 68.44, 68.91],
  ["200", 68.91, 69.43],
  ["kilometer.", 69.43, 70.01],
  ["Debu,", 70.36, 70.74],
  ["jelaga,", 70.74, 71.27],
  ["dan", 71.27, 71.59],
  ["aerosol", 71.59, 72.18],
  ["sulfur", 72.18, 72.71],
  ["terlempar", 72.71, 73.45],
  ["ke", 73.45, 73.69],
  ["atmosfer,", 73.69, 74.36],
  ["menghalangi", 74.62, 75.33],
  ["sinar", 75.33, 75.70],
  ["Matahari", 75.70, 76.24],
  ["dan", 76.24, 76.49],
  ["menghambat", 76.49, 77.14],
  ["fotosintesis.", 77.14, 77.91],
  ["Rantai", 78.19, 78.60],
  ["makanan", 78.60, 79.06],
  ["pun", 79.06, 79.31],
  ["runtuh.", 79.31, 79.72],
  ["Sekitar", 80.04, 80.63],
  ["75", 80.63, 81.09],
  ["persen", 81.09, 81.60],
  ["spesies", 81.60, 82.19],
  ["punah,", 82.19, 82.63],
  ["termasuk", 82.88, 83.51],
  ["seluruh", 83.51, 84.06],
  ["dinosaurus", 84.06, 84.82],
  ["non-unggas.", 84.82, 85.58],
  ["Kabar", 85.95, 86.32],
  ["baiknya,", 86.32, 86.81],
  ["manusia", 86.81, 87.30],
  ["mulai", 87.30, 87.67],
  ["punya", 87.67, 88.05],
  ["jawabannya.", 88.05, 88.71],
  ["Pada", 89.08, 89.49],
  ["26", 89.49, 89.99],
  ["September", 89.99, 90.77],
  ["2022,", 90.77, 91.66],
  ["pesawat", 91.89, 92.42],
  ["DART", 92.42, 92.77],
  ["milik", 92.77, 93.18],
  ["NASA", 93.18, 93.53],
  ["sengaja", 93.53, 94.07],
  ["menabrak", 94.07, 94.67],
  ["Dimorphos,", 94.67, 95.33],
  ["asteroid", 95.33, 95.93],
  ["kecil", 95.93, 96.34],
  ["yang", 96.34, 96.69],
  ["mengorbit", 96.69, 97.36],
  ["Didymos.", 97.36, 97.89],
  ["Hasilnya,", 98.19, 98.82],
  ["periode", 99.02, 99.49],
  ["orbitnya", 99.49, 100.02],
  ["berubah.", 100.02, 100.49],
  ["Teknik", 100.82, 101.26],
  ["ini", 101.26, 101.52],
  ["disebut", 101.52, 102.02],
  ["penumbuk", 102.02, 102.57],
  ["kinetik.", 102.57, 103.07],
  ["Meski", 103.46, 103.83],
  ["begitu,", 103.83, 104.25],
  ["tidak", 104.25, 104.62],
  ["semua", 104.62, 104.99],
  ["asteroid", 104.99, 105.53],
  ["bisa", 105.53, 105.85],
  ["dialihkan", 105.85, 106.45],
  ["semudah", 106.45, 106.93],
  ["itu.", 106.93, 107.19],
  ["Jadi,", 107.56, 107.86],
  ["adakah", 107.86, 108.27],
  ["yang", 108.27, 108.57],
  ["mengarah", 108.57, 109.09],
  ["ke", 109.09, 109.28],
  ["kita?", 109.28, 109.58],
  ["Menurut", 109.95, 110.43],
  ["NASA,", 110.43, 110.74],
  ["belum", 110.74, 111.11],
  ["ada", 111.11, 111.37],
  ["asteroid", 111.37, 111.91],
  ["di", 111.91, 112.11],
  ["atas", 112.11, 112.42],
  ["140", 112.42, 112.95],
  ["meter", 112.95, 113.32],
  ["yang", 113.32, 113.63],
  ["diketahui", 113.63, 114.23],
  ["berpeluang", 114.23, 114.89],
  ["signifikan", 114.89, 115.54],
  ["menabrak", 115.54, 116.08],
  ["Bumi", 116.08, 116.39],
  ["dalam", 116.39, 116.76],
  ["100", 116.76, 117.29],
  ["tahun", 117.29, 117.66],
  ["ke", 117.66, 117.86],
  ["depan.", 117.86, 118.23],
  ["Ancamannya", 118.57, 119.27],
  ["nyata,", 119.27, 119.66],
  ["tapi", 119.89, 120.21],
  ["bukan", 120.21, 120.59],
  ["sesuatu", 120.59, 121.08],
  ["yang", 121.08, 121.40],
  ["pasti", 121.40, 121.78],
  ["terjadi.", 121.78, 122.28],
  ["Dan", 122.65, 122.92],
  ["para", 122.92, 123.26],
  ["ilmuwan", 123.26, 123.79],
  ["terus", 123.79, 124.19],
  ["mengawasi", 124.19, 124.84],
  ["langit", 124.84, 125.30],
  ["untuk", 125.30, 125.70],
  ["kita.", 125.70, 126.04],
];

/* ---------- util ---------- */
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (t: number, a: number, b: number, from = 0, to = 1, easing: (x: number) => number = Easing.inOut(Easing.cubic)) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.4) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const pop = (t: number, a: number, d = 0.5) => {
  const p = Math.min(1, Math.max(0, (t - a) / d));
  const c1 = 1.70158;
  return p <= 0 ? 0 : 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};
const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const hexMix = (a: string, b: string, k: number) => {
  const A = hex(a);
  const B = hex(b);
  const kk = Math.max(0, Math.min(1, k));
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * kk).toString(16).padStart(2, '0')).join('');
};
const rnd = (() => {
  const r = mulberry32(123);
  return Array.from({length: 600}, () => r());
})();
const R = (i: number) => rnd[((i % 600) + 600) % 600];
const shake = (t: number, t0: number, amp = 14, d = 0.8): [number, number] => {
  const k = t - t0;
  if (k < 0 || k > d) return [0, 0];
  const f = 1 - k / d;
  return [Math.sin(k * 80) * amp * f, Math.cos(k * 67) * amp * f];
};
// waktu kata pertama yang cocok (setelah indeks from)
const at = (w: string, nth = 0): number => {
  let n = 0;
  for (const x of WD) {
    if (x[0].toLowerCase().replace(/[.,?:]/g, '') === w.toLowerCase()) {
      if (n === nth) return x[1];
      n++;
    }
  }
  return 0;
};

/* ---------- maskot Fosi + meme ---------- */

type Mood = 'confused' | 'brow' | 'tired';

const Fosi: React.FC<{x: number; y: number; s?: number; mood: Mood; t: number}> = ({x, y, s = 1, mood, t}) => {
  const bob = Math.sin(t * 9) * 4;
  const body = '#f2dcae';
  const pup = mood === 'confused' ? [[-30, -18], [46, -28]] : mood === 'brow' ? [[-26, -20], [26, -20]] : [[-36, -8], [34, -8]];
  return (
    <g transform={`translate(${x},${y + bob}) scale(${s}) rotate(${mood === 'confused' ? Math.sin(t * 5) * 3 : 0})`}>
      <ellipse cx={0} cy={96} rx={92} ry={12} fill="#000" opacity={0.35} />
      <ellipse cx={-104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(25 -104 20)" />
      <ellipse cx={104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(-25 104 20)" />
      <ellipse cx={0} cy={0} rx={100} ry={90} fill={body} stroke={C.ink} strokeWidth={7} />
      <path d="M -78 30 Q 0 56 78 30" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      <path d="M -62 56 Q 0 78 62 56" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      {[-38, 38].map((ex, i) => (
        <g key={i}>
          <circle cx={ex} cy={-22} r={30} fill="#fff" stroke={C.ink} strokeWidth={5} />
          <circle cx={ex + pup[i][0] * 0.35 + (i ? 0 : 0)} cy={-22 + pup[i][1] * 0.35} r={11} fill="#2a1a0e" />
          {mood === 'tired' && <path d={`M ${ex - 30} -22 A 30 30 0 0 1 ${ex + 30} -22 Z`} fill={body} stroke={C.ink} strokeWidth={5} />}
        </g>
      ))}
      {mood === 'confused' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -66 L -16 -56" />
          <path d="M 66 -76 L 16 -62" />
        </g>
      )}
      {mood === 'brow' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -62 -50 L -14 -52" />
          <path d="M 14 -78 Q 40 -90 64 -70" />
        </g>
      )}
      {mood === 'tired' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -62 L -14 -52" />
          <path d="M 66 -62 L 14 -52" />
        </g>
      )}
      {mood === 'confused' && <path d="M -34 46 q 17 -16 34 0 t 34 0" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'brow' && <path d="M -24 48 L 24 48" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' && <path d="M -32 58 Q 0 30 32 58" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' &&
        [0, 1].map((k) => {
          const p = (t * 1.3 + k * 0.5) % 1;
          return <path key={k} d="M 0 -12 Q 12 8 0 16 Q -12 8 0 -12 Z" transform={`translate(${96 + k * 20},${-60 + p * 90})`} fill={C.cyan} opacity={1 - p} />;
        })}
      {mood === 'confused' &&
        [[-130, -110, 0], [140, -90, 1.3], [-40, -150, 2.4]].map(([qx, qy, ph], i) => (
          <text key={i} x={qx} y={qy + Math.sin(t * 4 + ph) * 8} fontFamily={cond} fontWeight={700} fontSize={84} fill={C.amber} stroke="#000" strokeWidth={8} paintOrder="stroke" textAnchor="middle">
            ?
          </text>
        ))}
    </g>
  );
};

const MemeText: React.FC<{lines: string[]; y: number; size: number; t: number; a: number}> = ({lines, y, size, t, a}) => {
  const p = pop(t, a + 0.05, 0.45);
  const sh = t - a < 0.5 ? Math.sin(t * 60) * 5 * (1 - (t - a) / 0.5) : 0;
  return (
    <g transform={`translate(${CX + sh},${y}) scale(${Math.max(0.01, p)})`}>
      {lines.map((ln, i) => (
        <text key={i} x={0} y={i * size * 0.98} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill="#fff" stroke="#000" strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke" letterSpacing="0.02em">
          {ln}
        </text>
      ))}
    </g>
  );
};

const Meme: React.FC<{t: number; a: number; b: number; mood: Mood; lines: string[]; ty: number; size?: number; fx?: number; fy?: number; fs?: number}> = ({
  t,
  a,
  b,
  mood,
  lines,
  ty,
  size = 112,
  fx = CX,
  fy = 1110,
  fs = 1.15,
}) => {
  if (t < a - 0.05 || t > b + 0.05) return null;
  const o = win(t, a, b, 0.25);
  const flash = ramp(t, a, a + 0.12, 0.55, 0, lin);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: '#000', opacity: 0.5 * o}} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: o}}>
        <g transform={`translate(${fx},${fy}) scale(${Math.max(0.01, pop(t, a, 0.5))}) translate(${-fx},${-fy})`}>
          <Fosi x={fx} y={fy} s={fs} mood={mood} t={t} />
        </g>
        <MemeText lines={lines} y={ty} size={size} t={t} a={a} />
      </svg>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </AbsoluteFill>
  );
};

/* ---------- subtitle per kata ---------- */
const CHUNKS = (() => {
  const out: {a: number; b: number; ws: {w: string; a: number; b: number}[]}[] = [];
  let cur: {w: string; a: number; b: number}[] = [];
  const flush = () => {
    if (cur.length) out.push({a: cur[0].a, b: cur[cur.length - 1].b, ws: cur});
    cur = [];
  };
  for (const x of WD) {
    cur.push({w: x[0], a: x[1], b: x[2]});
    const chars = cur.reduce((s, q) => s + q.w.length, 0);
    if (/[.,?:]$/.test(x[0]) || cur.length >= 3 || chars > 20) flush();
  }
  flush();
  return out;
})();

const Caption: React.FC<{t: number}> = ({t}) => {
  let ci = -1;
  CHUNKS.forEach((c, i) => {
    if (c.a <= t + 0.02) ci = i;
  });
  if (ci < 0) return null;
  const c = CHUNKS[ci];
  if (t > c.b + 0.35) return null;
  const chars = c.ws.reduce((s, q) => s + q.w.length + 1, 0);
  const size = Math.max(60, Math.min(104, 980 / (chars * 0.56)));
  const p = pop(t, c.a, 0.22);
  return (
    <div style={{position: 'absolute', left: 30, right: 30, top: 1360, height: 160, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.9 + 0.1 * Math.min(1, p)})`, fontFamily: sans, fontWeight: 800, fontSize: size, lineHeight: 1.1, textAlign: 'center'}}>
      <span style={{WebkitTextStroke: `${size * 0.16}px #1a1210`, paintOrder: 'stroke fill', textShadow: '0 6px 0 rgba(0,0,0,0.35)'} as React.CSSProperties}>
        {c.ws.map((w, i) => (
          <span key={i} style={{color: t >= w.a && t < w.b ? '#ffd23a' : '#ffffff', margin: '0 0.14em'}}>
            {w.w}
          </span>
        ))}
      </span>
    </div>
  );
};

/* ---------- label pill ---------- */
const Tag: React.FC<{t: number; a: number; b?: number; x: number; y: number; text: string; size?: number; bg?: string; fg?: string; rot?: number}> = ({t, a, b = 9999, x, y, text, size = 50, bg = '#ffffff', fg = OUT, rot = 0}) => {
  if (t < a || t > b + 0.3) return null;
  const p = pop(t, a, 0.45) * (1 - ramp(t, b, b + 0.25, 0, 1, lin));
  const w = text.length * size * 0.52 + 64;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${Math.max(0.001, p) * Math.min(1, 960 / w)})`}>
      <rect x={-w / 2 + 5} y={-size * 0.95 + 7} width={w} height={size * 1.7} rx={size * 0.5} fill="#000" opacity={0.3} />
      <rect x={-w / 2} y={-size * 0.95} width={w} height={size * 1.7} rx={size * 0.5} fill={bg} stroke={OUT} strokeWidth={6} />
      <text textAnchor="middle" y={size * 0.28} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.04em" fill={fg}>
        {text}
      </text>
    </g>
  );
};
const Big: React.FC<{x: number; y: number; text: string; size?: number; fill?: string; rot?: number; sc?: number}> = ({x, y, text, size = 140, fill = '#fff', rot = 0, sc = 1}) => (
  <text transform={`translate(${x},${y}) rotate(${rot}) scale(${Math.max(0.001, sc)})`} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill={fill} stroke={OUT} strokeWidth={size * 0.13} paintOrder="stroke" strokeLinejoin="round" letterSpacing="0.03em">
    {text}
  </text>
);

/* ---------- orang kartun ---------- */
type Face = 'calm' | 'scared' | 'wow' | 'happy' | 'sad';
type Pose = 'idle' | 'walk' | 'run' | 'panic' | 'cheer' | 'point' | 'look';
const limb = (x1: number, y1: number, x2: number, y2: number, w: number, col: string) => (
  <g>
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={OUT} strokeWidth={w + 9} strokeLinecap="round" />
    <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={col} strokeWidth={w} strokeLinecap="round" />
  </g>
);
const Person: React.FC<{x: number; y: number; s?: number; face?: Face; pose?: Pose; ph?: number; shirt?: string; pants?: string; hair?: string; skin?: string; flip?: boolean; rot?: number; coat?: boolean; hairStyle?: number; eyeDx?: number}> = ({
  x, y, s = 1, face = 'calm', pose = 'idle', ph = 0, shirt = '#e5484d', pants = '#3b4a7a', hair = '#2b1b17', skin = '#f2c9a0', flip = false, rot = 0, coat = false, hairStyle = 0, eyeDx = 0,
}) => {
  const sw = Math.sin(ph);
  let aL = 0.12;
  let aR = -0.12;
  let lL = 0;
  let lR = 0;
  let bob = 0;
  const P = Math.PI;
  if (pose === 'walk') {
    aL = 0.7 * sw; aR = -0.7 * sw; lL = 0.55 * sw; lR = -0.55 * sw; bob = Math.abs(sw) * 3;
  } else if (pose === 'run') {
    aL = 1.1 * sw; aR = -1.1 * sw; lL = 0.95 * sw; lR = -0.95 * sw; bob = Math.abs(sw) * 9;
  } else if (pose === 'panic') {
    aL = -(P - 0.45) + 0.5 * Math.sin(ph * 1.3); aR = P - 0.45 + 0.5 * Math.sin(ph * 1.3 + 1.6); lL = 0.95 * sw; lR = -0.95 * sw; bob = Math.abs(sw) * 9;
  } else if (pose === 'cheer') {
    aL = -(P - 0.5) + 0.35 * Math.sin(ph * 2); aR = P - 0.5 - 0.35 * Math.sin(ph * 2 + 1); bob = Math.abs(Math.sin(ph * 2)) * 12;
  } else if (pose === 'point') {
    aR = P - 0.3; aL = 0.15;
  } else if (pose === 'look') {
    aL = 0.1; aR = -0.1; bob = Math.sin(ph * 0.7) * 2;
  }
  const sh = (side: number, a: number) => [side * 24 + Math.sin(a) * 62, -125 + Math.cos(a) * 62];
  const hL = sh(-1, aL);
  const hR = sh(1, aR);
  const ft = (side: number, a: number) => [side * 13 + Math.sin(a) * 66, -62 + Math.cos(a) * 64];
  const fL = ft(-1, lL);
  const fR = ft(1, lR);
  const sleeve = coat ? '#f4f6fa' : shirt;
  const eye = face === 'scared' || face === 'wow';
  return (
    <g transform={`translate(${x},${y - bob * s}) scale(${flip ? -s : s},${s}) rotate(${rot})`}>
      <ellipse cx={0} cy={bob} rx={52} ry={9} fill="#000" opacity={0.22} />
      {limb(-13, -64, fL[0], fL[1], 17, pants)}
      {limb(13, -64, fR[0], fR[1], 17, pants)}
      <ellipse cx={fL[0] - 4} cy={fL[1] + 2} rx={16} ry={8} fill="#3a2a2a" stroke={OUT} strokeWidth={5} />
      <ellipse cx={fR[0] + 4} cy={fR[1] + 2} rx={16} ry={8} fill="#3a2a2a" stroke={OUT} strokeWidth={5} />
      <rect x={-31} y={-138} width={62} height={80} rx={20} fill={sleeve} stroke={OUT} strokeWidth={6} />
      {coat && <path d="M 0 -138 L 0 -58" stroke={OUT} strokeWidth={4} />}
      {limb(-26, -124, hL[0], hL[1], 15, sleeve)}
      {limb(26, -124, hR[0], hR[1], 15, sleeve)}
      <circle cx={hL[0]} cy={hL[1]} r={10} fill={skin} stroke={OUT} strokeWidth={5} />
      <circle cx={hR[0]} cy={hR[1]} r={10} fill={skin} stroke={OUT} strokeWidth={5} />
      <circle cx={0} cy={-172} r={38} fill={skin} stroke={OUT} strokeWidth={6} />
      {hairStyle === 0 && <path d="M -37 -176 A 38 38 0 0 1 37 -176 Q 8 -196 -37 -176 Z" fill={hair} stroke={OUT} strokeWidth={5} />}
      {hairStyle === 1 && <path d="M -38 -170 A 38 38 0 0 1 38 -170 L 38 -190 Q 0 -222 -38 -190 Z" fill={hair} stroke={OUT} strokeWidth={5} />}
      {hairStyle === 2 && (
        <g>
          <circle cx={0} cy={-216} r={16} fill={hair} stroke={OUT} strokeWidth={5} />
          <path d="M -37 -176 A 38 38 0 0 1 37 -176 Q 0 -200 -37 -176 Z" fill={hair} stroke={OUT} strokeWidth={5} />
        </g>
      )}
      {hairStyle === 3 && (
        <g>
          <path d="M -40 -184 A 40 36 0 0 1 40 -184 Z" fill="#ffd23a" stroke={OUT} strokeWidth={5} />
          <rect x={-46} y={-190} width={92} height={12} rx={6} fill="#ffd23a" stroke={OUT} strokeWidth={5} />
        </g>
      )}
      {eye ? (
        <g>
          <circle cx={-14 + eyeDx} cy={-172} r={12} fill="#fff" stroke={OUT} strokeWidth={4} />
          <circle cx={14 + eyeDx} cy={-172} r={12} fill="#fff" stroke={OUT} strokeWidth={4} />
          <circle cx={-14 + eyeDx * 1.3} cy={-172} r={4.5} fill={OUT} />
          <circle cx={14 + eyeDx * 1.3} cy={-172} r={4.5} fill={OUT} />
        </g>
      ) : (
        <g>
          <circle cx={-13 + eyeDx} cy={-172} r={5} fill={OUT} />
          <circle cx={13 + eyeDx} cy={-172} r={5} fill={OUT} />
        </g>
      )}
      {face === 'scared' && (
        <g stroke={OUT} strokeWidth={5} strokeLinecap="round" fill="none">
          <path d="M -26 -194 L -6 -186" />
          <path d="M 26 -194 L 6 -186" />
        </g>
      )}
      {face === 'sad' && (
        <g stroke={OUT} strokeWidth={5} strokeLinecap="round" fill="none">
          <path d="M -26 -186 L -6 -192" />
          <path d="M 26 -186 L 6 -192" />
        </g>
      )}
      {face === 'calm' && <path d="M -8 -153 L 8 -153" stroke={OUT} strokeWidth={5} strokeLinecap="round" />}
      {face === 'happy' && <path d="M -14 -157 Q 0 -143 14 -157" stroke={OUT} strokeWidth={5} strokeLinecap="round" fill="none" />}
      {face === 'sad' && <path d="M -12 -149 Q 0 -161 12 -149" stroke={OUT} strokeWidth={5} strokeLinecap="round" fill="none" />}
      {(face === 'scared' || face === 'wow') && <ellipse cx={0} cy={-150} rx={9} ry={face === 'scared' ? 13 : 10} fill="#7a1f1f" stroke={OUT} strokeWidth={4} />}
      {face === 'scared' && <path d={`M 42 -190 q 9 14 0 22 q -9 -8 0 -22 Z`} fill={C.cyan} stroke={OUT} strokeWidth={3} transform={`translate(0,${(ph * 6) % 14})`} />}
    </g>
  );
};

/* ---------- dinosaurus orisinal ---------- */
const Dino: React.FC<{x: number; y: number; s?: number; face?: 'calm' | 'shock'; flip?: boolean; col?: string; ph?: number; rot?: number; o?: number}> = ({x, y, s = 1, face = 'calm', flip = false, col = '#5cb85c', ph = 0, rot = 0, o = 1}) => {
  const sw = Math.sin(ph) * 8;
  return (
    <g transform={`translate(${x},${y}) scale(${flip ? -s : s},${s}) rotate(${rot})`} opacity={o}>
      <ellipse cx={0} cy={4} rx={90} ry={10} fill="#000" opacity={0.22} />
      <path d="M -60 -70 Q -150 -60 -170 -20 Q -120 -50 -60 -40 Z" fill={col} stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
      <rect x={-34 + sw} y={-50} width={26} height={50} rx={12} fill={hexMix(col, '#000000', 0.15)} stroke={OUT} strokeWidth={6} />
      <rect x={14 - sw} y={-50} width={26} height={50} rx={12} fill={hexMix(col, '#000000', 0.15)} stroke={OUT} strokeWidth={6} />
      <ellipse cx={0} cy={-80} rx={80} ry={56} fill={col} stroke={OUT} strokeWidth={6} />
      <ellipse cx={12} cy={-62} rx={48} ry={30} fill={hexMix(col, '#fffbd0', 0.5)} />
      <path d="M -30 -128 l 10 -22 l 12 20 M 4 -134 l 10 -24 l 12 22 M 36 -128 l 10 -22 l 10 20" fill="#8bd26a" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
      <ellipse cx={86} cy={-122} rx={50} ry={36} fill={col} stroke={OUT} strokeWidth={6} />
      <circle cx={100} cy={-134} r={face === 'shock' ? 13 : 9} fill="#fff" stroke={OUT} strokeWidth={4} />
      <circle cx={102} cy={-134} r={4} fill={OUT} />
      {face === 'shock' ? <ellipse cx={116} cy={-108} rx={10} ry={13} fill="#7a1f1f" stroke={OUT} strokeWidth={4} /> : <path d="M 88 -108 Q 108 -98 126 -110" fill="none" stroke={OUT} strokeWidth={5} strokeLinecap="round" />}
      <path d="M 30 -78 l 22 8 l -6 -16" fill="none" stroke={OUT} strokeWidth={5} strokeLinecap="round" />
    </g>
  );
};

/* ---------- batu asteroid ---------- */
const ROCKS = [0, 1, 2].map((k) => {
  const r = mulberry32(40 + k * 7);
  return Array.from({length: 12}, (_, i) => {
    const a = (i / 12) * Math.PI * 2;
    const rr = 0.78 + r() * 0.3;
    return [Math.cos(a) * rr, Math.sin(a) * rr] as [number, number];
  });
});
const Rock: React.FC<{x: number; y: number; r: number; k?: number; rot?: number; glow?: number; col?: string}> = ({x, y, r, k = 0, rot = 0, glow = 0, col = '#8f7f6f'}) => {
  const pts = ROCKS[k % 3].map((p) => `${(p[0] * r).toFixed(1)},${(p[1] * r).toFixed(1)}`).join(' ');
  return (
    <g transform={`translate(${x},${y}) rotate(${rot})`}>
      {glow > 0 && <circle r={r * 1.5} fill="#ff7a1a" opacity={0.28 * glow} />}
      <polygon points={pts} fill={col} stroke={OUT} strokeWidth={Math.max(4, r * 0.06)} strokeLinejoin="round" />
      <polygon points={ROCKS[k % 3].slice(3, 9).map((p) => `${(p[0] * r * 0.92).toFixed(1)},${(p[1] * r * 0.92).toFixed(1)}`).join(' ')} fill={hexMix(col, '#000000', 0.22)} opacity={0.55} />
      <circle cx={-r * 0.3} cy={-r * 0.25} r={r * 0.2} fill={hexMix(col, '#000000', 0.3)} stroke={OUT} strokeWidth={Math.max(2, r * 0.03)} />
      <circle cx={r * 0.3} cy={r * 0.2} r={r * 0.14} fill={hexMix(col, '#000000', 0.3)} stroke={OUT} strokeWidth={Math.max(2, r * 0.03)} />
      <circle cx={-r * 0.1} cy={r * 0.42} r={r * 0.1} fill={hexMix(col, '#000000', 0.3)} />
      <ellipse cx={-r * 0.45} cy={-r * 0.5} rx={r * 0.2} ry={r * 0.1} fill="#fff" opacity={0.25} transform="rotate(-30)" />
    </g>
  );
};
// api di belakang benda yang bergerak (ang = arah gerak, radian)
const Fire: React.FC<{x: number; y: number; ang: number; len: number; w: number; t: number; o?: number}> = ({x, y, ang, len, w, t, o = 1}) => {
  const layers: [string, number, number][] = [['#e5484d', 1, 1], ['#ff7a1a', 0.78, 0.85], ['#ffd23a', 0.5, 0.65], ['#fff6c0', 0.26, 0.4]];
  return (
    <g transform={`translate(${x},${y}) rotate(${(ang * 180) / Math.PI + 180})`} opacity={o}>
      {layers.map(([c, ws, ls], i) => {
        const L = len * ls * (0.92 + 0.08 * Math.sin(t * 22 + i));
        const ww = w * ws;
        const wob = Math.sin(t * 18 + i * 2) * ww * 0.25;
        return <path key={i} d={`M 0 ${-ww} Q ${L * 0.5} ${-ww * 1.1 + wob} ${L} ${wob} Q ${L * 0.5} ${ww * 1.1 + wob} 0 ${ww} Z`} fill={c} stroke={i === 0 ? OUT : 'none'} strokeWidth={5} strokeLinejoin="round" />;
      })}
    </g>
  );
};

/* ---------- latar ---------- */
const Sky: React.FC<{id: string; top: string; bot: string; h?: number}> = ({id, top, bot, h = HZ + 20}) => (
  <g>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={top} />
        <stop offset="1" stopColor={bot} />
      </linearGradient>
    </defs>
    <rect width={W} height={h} fill={`url(#${id})`} />
  </g>
);
const Stars: React.FC<{t: number; n?: number; h?: number; seed?: number}> = ({t, n = 70, h = H, seed = 0}) => (
  <g>
    {Array.from({length: n}).map((_, i) => (
      <circle key={i} cx={R(i * 3 + seed) * W} cy={R(i * 3 + 1 + seed) * h} r={1.5 + R(i * 3 + 2 + seed) * 3.2} fill="#fff" opacity={0.4 + 0.6 * Math.abs(Math.sin(t * (0.8 + R(i + seed)) + i))} />
    ))}
  </g>
);
const Cloud: React.FC<{x: number; y: number; s?: number; col?: string}> = ({x, y, s = 1, col = '#ffffff'}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={col} stroke={OUT} strokeWidth={5}>
    <path d="M -90 20 Q -110 -20 -60 -22 Q -50 -64 0 -50 Q 40 -78 70 -34 Q 120 -34 110 20 Z" />
  </g>
);
const Skyline: React.FC<{y?: number; tint?: number; tilt?: number; seedo?: number; night?: boolean; t?: number}> = ({y = HZ, tint = 0, tilt = 0, seedo = 0, night = false, t = 0}) => {
  const cols = ['#7aa6d8', '#e0a35a', '#8fbf8f', '#d68a8a', '#a99ad6', '#7ec4c4'];
  const out: React.ReactNode[] = [];
  let x = -40;
  let i = 0;
  while (x < W + 40) {
    const w = 110 + R(i + seedo) * 90;
    const h = 260 + R(i + 20 + seedo) * 360;
    const c = hexMix(cols[i % cols.length], night ? '#0b1030' : '#6a7a9a', night ? 0.62 : tint);
    const tl = Math.sin(t * 40 + i) * tilt;
    out.push(
      <g key={i} transform={`rotate(${tl} ${x + w / 2} ${y})`}>
        <rect x={x} y={y - h} width={w} height={h} fill={c} stroke={OUT} strokeWidth={6} />
        <rect x={x} y={y - h} width={w} height={14} fill={hexMix(c, '#ffffff', 0.25)} stroke={OUT} strokeWidth={6} />
        {Array.from({length: Math.floor(h / 70)}).map((_, r) =>
          Array.from({length: Math.floor(w / 40)}).map((__, q) => (
            <rect key={r * 10 + q} x={x + 14 + q * 40} y={y - h + 34 + r * 70} width={22} height={34} rx={4} fill={night ? (R(i * 31 + r * 7 + q) > 0.4 ? '#ffd23a' : '#243055') : '#cfe6ff'} stroke={OUT} strokeWidth={3} />
          )),
        )}
      </g>,
    );
    x += w - 6;
    i++;
  }
  return <g>{out}</g>;
};
const Street: React.FC<{y?: number; col?: string}> = ({y = HZ, col = '#5b6270'}) => (
  <g>
    <rect x={0} y={y} width={W} height={H - y} fill={col} />
    <rect x={0} y={y} width={W} height={50} fill={hexMix(col, '#ffffff', 0.3)} stroke={OUT} strokeWidth={6} />
    {Array.from({length: 7}).map((_, i) => (
      <rect key={i} x={i * 170 + 20} y={y + 330} width={110} height={16} rx={6} fill="#f4e8cf" />
    ))}
  </g>
);
const EarthBall: React.FC<{x: number; y: number; r: number; rot?: number}> = ({x, y, r, rot = 0}) => (
  <g transform={`translate(${x},${y})`}>
    <circle r={r * 1.1} fill="#5ad1ff" opacity={0.18} />
    <circle r={r} fill="#3b82d6" stroke={OUT} strokeWidth={8} />
    <g transform={`rotate(${rot})`}>
      <path d={`M ${-r * 0.6} ${-r * 0.3} Q ${-r * 0.3} ${-r * 0.7} ${r * 0.1} ${-r * 0.5} Q ${r * 0.3} ${-r * 0.2} ${-r * 0.1} ${r * 0.1} Q ${-r * 0.4} ${r * 0.2} ${-r * 0.6} ${-r * 0.3} Z`} fill="#5fbf5f" stroke={OUT} strokeWidth={5} />
      <path d={`M ${r * 0.3} ${r * 0.2} Q ${r * 0.7} ${r * 0.1} ${r * 0.65} ${r * 0.5} Q ${r * 0.4} ${r * 0.8} ${r * 0.2} ${r * 0.5} Z`} fill="#5fbf5f" stroke={OUT} strokeWidth={5} />
    </g>
    <ellipse cx={-r * 0.35} cy={-r * 0.45} rx={r * 0.25} ry={r * 0.1} fill="#fff" opacity={0.3} transform="rotate(-30)" />
  </g>
);
const Burst: React.FC<{x: number; y: number; t: number; a: number; r: number; o?: number}> = ({x, y, t, a, r, o = 1}) => {
  const k = t - a;
  if (k < 0 || k > 1.4) return null;
  const e = Math.min(1, k / 0.5);
  const f = 1 - Math.min(1, k / 1.4);
  return (
    <g transform={`translate(${x},${y})`} opacity={o}>
      <circle r={r * e * 1.2} fill="#fff6c0" opacity={f} />
      <circle r={r * e} fill="#ffd23a" stroke={OUT} strokeWidth={8} opacity={f} />
      <circle r={r * e * 0.65} fill="#ff7a1a" opacity={f} />
      <circle r={r * e * 0.3} fill="#fff6c0" opacity={f} />
      {Array.from({length: 12}).map((_, i) => {
        const an = (i / 12) * Math.PI * 2;
        return <line key={i} x1={Math.cos(an) * r * e * 0.9} y1={Math.sin(an) * r * e * 0.9} x2={Math.cos(an) * r * e * (1.2 + 0.4 * R(i))} y2={Math.sin(an) * r * e * (1.2 + 0.4 * R(i))} stroke="#ffd23a" strokeWidth={10} strokeLinecap="round" opacity={f} />;
      })}
    </g>
  );
};
const Smoke: React.FC<{x: number; y: number; t: number; a: number; w?: number; col?: string}> = ({x, y, t, a, w = 1, col = '#6b625a'}) => {
  const k = t - a;
  if (k < 0) return null;
  return (
    <g transform={`translate(${x},${y})`}>
      {Array.from({length: 9}).map((_, i) => {
        const e = Math.min(1, k / 2.5);
        return <circle key={i} cx={(R(i) - 0.5) * 220 * w * e} cy={-e * (160 + R(i + 4) * 220) - i * 12} r={(50 + R(i + 9) * 50) * (0.4 + e) * w} fill={hexMix(col, '#000000', R(i + 2) * 0.3)} stroke={OUT} strokeWidth={5} opacity={0.92 - 0.3 * e} />;
      })}
    </g>
  );
};

/* ================= scene ================= */
const lerpN = (a: number, b: number, k: number) => a + (b - a) * k;
const SB = [0, 6.5, 10.3, 14.4, 19.5, 22.8, 28.6, 33.7, 41.5, 44.4, 56.8, 70.2, 78.0, 79.9, 85.8, 89.0, 103.3, 107.4, 118.4, 126.3];
const Space: React.FC<{id: string; t: number; top?: string; bot?: string; n?: number}> = ({id, t, top = '#0b1030', bot = '#3a1a5a', n = 70}) => (
  <g>
    <Sky id={id} top={top} bot={bot} h={H} />
    <Stars t={t} n={n} />
  </g>
);

const S0: React.FC<{t: number}> = ({t}) => {
  const k = ramp(t, 0, 6.3, 0, 1, Easing.in(Easing.quad));
  const ax = lerpN(780, 430, k);
  const ay = lerpN(230, 960, k);
  const r = lerpN(44, 330, k);
  const ang = Math.atan2(960 - 230, 430 - 780);
  const [sx, sy] = shake(t, 4.0, 10 * k, 2.4);
  return (
    <g transform={`translate(${sx},${sy})`}>
      <Space id="sp0" t={t} />
      <EarthBall x={540} y={1850} r={780} rot={t * 2} />
      {Array.from({length: 18}).map((_, i) => {
        const a = (i / 18) * Math.PI * 2 + 0.2;
        const d0 = 260 + R(i) * 260 + k * 200;
        return <line key={i} x1={ax + Math.cos(a) * d0} y1={ay + Math.sin(a) * d0} x2={ax + Math.cos(a) * (d0 + 70 + 160 * k)} y2={ay + Math.sin(a) * (d0 + 70 + 160 * k)} stroke="#fff" strokeWidth={5} opacity={0.15 + 0.35 * k} strokeLinecap="round" />;
      })}
      <Fire x={ax} y={ay} ang={ang} len={r * 3.6} w={r * 0.8} t={t} />
      <Rock x={ax} y={ay} r={r} k={0} rot={t * 14} glow={1} />
      <Tag t={t} a={1.1} b={4.2} x={CX} y={380} text="SEUKURAN GUNUNG" size={58} bg="#ffd23a" />
      <Tag t={t} a={at('kecepatan') - 0.1} x={CX} y={500} text="PULUHAN KM / DETIK" size={58} bg="#ff7a1a" fg="#fff" />
    </g>
  );
};

const FOLK = [
  {sh: '#e5484d', pa: '#3b4a7a', hr: '#2b1b17', hs: 0},
  {sh: '#3b82d6', pa: '#4a3a2a', hr: '#8a5a2b', hs: 1},
  {sh: '#4cbf6a', pa: '#2f3b5a', hr: '#2b1b17', hs: 2},
  {sh: '#ffb020', pa: '#5a3b3b', hr: '#5a3a1a', hs: 0},
  {sh: '#9b6bd6', pa: '#2b3a4a', hr: '#2b1b17', hs: 3},
  {sh: '#f06aa8', pa: '#3b4a7a', hr: '#d9a05a', hs: 1},
  {sh: '#2fb5b5', pa: '#4a3a2a', hr: '#2b1b17', hs: 2},
  {sh: '#e86b2a', pa: '#2f3b5a', hr: '#6b3a1a', hs: 0},
];

const S1: React.FC<{t: number}> = ({t}) => {
  const dot = ramp(t, 6.5, 10.2, 0.2, 1, lin);
  return (
    <g>
      <Sky id="sk1" top="#7fd0ff" bot="#e6f6ff" />
      <Cloud x={200 + Math.sin(t * 0.3) * 20} y={260} s={1.4} />
      <Cloud x={820 - Math.sin(t * 0.25) * 20} y={420} s={1.1} />
      <Skyline tint={0.45} seedo={3} />
      <Street />
      {FOLK.slice(0, 5).map((f, i) => {
        const x = ((i * 230 + t * (i % 2 ? -34 : 34) + 90) % 1300) - 110;
        return <Person key={i} x={x} y={1180 + (i % 3) * 36} s={1.4} pose={i === 2 ? 'point' : 'walk'} face={i === 2 ? 'wow' : 'happy'} ph={t * 6 + i * 1.3} shirt={f.sh} pants={f.pa} hair={f.hr} hairStyle={f.hs} flip={i % 2 === 1} />;
      })}
      <g>
        <circle cx={800} cy={300} r={10 + 22 * dot} fill="#8f7f6f" stroke={OUT} strokeWidth={5} />
        <Fire x={800} y={300} ang={Math.PI * 0.62} len={90 * dot + 20} w={10 + 14 * dot} t={t} />
      </g>
      <Big x={CX} y={640} text="?" size={380} fill="#ffd23a" sc={pop(t, 8.0, 0.6)} rot={Math.sin(t * 4) * 5} />
    </g>
  );
};

const S2: React.FC<{t: number}> = ({t}) => {
  const a = t * 0.9;
  const ex = 540 + Math.cos(a) * 380;
  const ey = 800 + Math.sin(a) * 250;
  const ea = t * 0.5 + 2;
  return (
    <g>
      <Space id="sp2" t={t} top="#070a22" bot="#1c1450" />
      <ellipse cx={540} cy={800} rx={380} ry={250} fill="none" stroke="#fff" strokeWidth={5} strokeDasharray="18 16" opacity={0.7} />
      <ellipse cx={540} cy={800} rx={190} ry={125} fill="none" stroke="#5ad1ff" strokeWidth={3} strokeDasharray="10 14" opacity={0.4} />
      <g transform={`translate(540,800)`}>
        {Array.from({length: 14}).map((_, i) => {
          const an = (i / 14) * Math.PI * 2 + t * 0.4;
          return <line key={i} x1={Math.cos(an) * 150} y1={Math.sin(an) * 150} x2={Math.cos(an) * (185 + 20 * Math.sin(t * 5 + i))} y2={Math.sin(an) * (185 + 20 * Math.sin(t * 5 + i))} stroke="#ffd23a" strokeWidth={14} strokeLinecap="round" />;
        })}
        <circle r={135} fill="#ffd23a" stroke={OUT} strokeWidth={8} />
        <circle r={95} fill="#ffe680" />
        <circle cx={-34} cy={-10} r={9} fill={OUT} />
        <circle cx={34} cy={-10} r={9} fill={OUT} />
        <path d="M -30 34 Q 0 58 30 34" stroke={OUT} strokeWidth={7} fill="none" strokeLinecap="round" />
      </g>
      <EarthBall x={540 + Math.cos(ea) * 190} y={800 + Math.sin(ea) * 125} r={26} rot={t * 30} />
      {Array.from({length: 10}).map((_, i) => {
        const aa = a - i * 0.07;
        return <circle key={i} cx={540 + Math.cos(aa) * 380} cy={800 + Math.sin(aa) * 250} r={9 - i * 0.7} fill="#c9b8a6" opacity={0.6 - i * 0.05} />;
      })}
      <Rock x={ex} y={ey} r={46} k={1} rot={t * 40} />
      <Tag t={t} a={10.7} x={CX} y={400} text="ASTEROID" size={62} bg="#ffffff" />
      <Tag t={t} a={at('berbatu') - 0.1} x={CX} y={1130} text="BENDA BERBATU" size={54} bg="#c9b8a6" />
      <Tag t={t} a={at('Matahari') - 0.1} x={CX} y={1040} text="MENGORBIT MATAHARI" size={50} bg="#ffd23a" />
    </g>
  );
};

const S3: React.FC<{t: number}> = ({t}) => {
  const k = ramp(t, 14.5, 19.3, 0, 1, Easing.in(Easing.quad));
  const ax = lerpN(160, 780, k);
  const ay = lerpN(120, 1000, k);
  const ang = Math.atan2(880, 620);
  const heat = ramp(t, 15.5, 18.5, 0, 1, lin);
  const bs = 0.3 + 0.7 * heat;
  return (
    <g>
      <Sky id="sk3a" top="#05061a" bot="#12206a" h={560} />
      <Stars t={t} n={40} h={520} />
      <Sky id="sk3b" top="#12206a" bot="#7fd0ff" h={1120} />
      <rect y={0} width={W} height={560} fill="url(#sk3a)" />
      <rect y={560} width={W} height={560} fill={hexMix('#12206a', '#7fd0ff', 0.4)} opacity={0.0} />
      <Sky id="sk3c" top="#14226e" bot="#8fd8ff" h={1140} />
      <rect width={W} height={560} fill="url(#sk3a)" />
      <Stars t={t} n={40} h={520} />
      <line x1={0} y1={560} x2={W} y2={560} stroke="#5ad1ff" strokeWidth={4} strokeDasharray="14 12" opacity={0.7} />
      <Skyline y={1180} tint={0.5} seedo={9} />
      <Street y={1180} />
      {[0, 1, 2].map((i) => {
        const rr = 150 + i * 70;
        return <path key={i} d={`M ${ax + Math.cos(ang - 0.9) * rr} ${ay + Math.sin(ang - 0.9) * rr} A ${rr} ${rr} 0 0 1 ${ax + Math.cos(ang + 0.9) * rr} ${ay + Math.sin(ang + 0.9) * rr}`} fill="none" stroke={['#ffd23a', '#ff7a1a', '#e5484d'][i]} strokeWidth={14 - i * 3} strokeLinecap="round" opacity={bs * (0.9 - i * 0.2)} />;
      })}
      <Fire x={ax} y={ay} ang={ang} len={420} w={86 * bs} t={t} o={bs} />
      <Rock x={ax} y={ay} r={96} k={2} rot={t * 20} glow={heat} col={hexMix('#8f7f6f', '#d9482a', heat * 0.6)} />
      <Tag t={t} a={14.7} x={200} y={650} text="ATMOSFER" size={52} bg="#7fd0ff" />
      <Tag t={t} a={at('terkompresi') - 0.2} x={CX} y={880} text="UDARA TERKOMPRESI" size={52} bg="#ffd23a" />
      <Tag t={t} a={at('memanas') - 0.1} x={CX} y={1010} text="PANAS EKSTREM" size={52} bg="#e5484d" fg="#fff" />
    </g>
  );
};

const S4: React.FC<{t: number}> = ({t}) => {
  const rocks = Array.from({length: 6}).map((_, i) => {
    const t0 = 19.6 + i * 0.5;
    const k = ramp(t, t0, t0 + 0.9, 0, 1, lin);
    const x0 = 120 + i * 150;
    return {k, t0, x0, i};
  });
  return (
    <g>
      <Space id="sp4" t={t} top="#070a22" bot="#2a2060" />
      <Skyline y={HZ} night seedo={5} />
      <Street y={HZ} col="#2c3042" />
      {rocks.map(({k, t0, x0, i}) => {
        if (k <= 0) return null;
        const x = x0 + 220 * k;
        const y = 120 + 700 * k;
        return (
          <g key={i}>
            {k < 1 && (
              <g>
                <Fire x={x} y={y} ang={Math.atan2(700, 220)} len={170} w={14} t={t + i} />
                <Rock x={x} y={y} r={lerpN(26, 8, k)} k={i} glow={1} />
              </g>
            )}
            <Burst x={x0 + 220} y={820} t={t} a={t0 + 0.9} r={60} />
          </g>
        );
      })}
      {[0, 1, 2].map((i) => (
        <Person key={i} x={220 + i * 300} y={1230 + (i % 2) * 40} s={1.4} pose={i === 1 ? 'point' : 'look'} face="wow" ph={t * 3 + i} shirt={FOLK[i + 2].sh} pants={FOLK[i + 2].pa} hair={FOLK[i + 2].hr} hairStyle={FOLK[i + 2].hs} eyeDx={0} />
      ))}
      <Tag t={t} a={20.2} x={CX} y={360} text="BENDA KECIL HANCUR" size={58} bg="#ffd23a" />
      <Tag t={t} a={21.4} x={CX} y={470} text="SEBELUM SAMPAI TANAH" size={50} bg="#ffffff" />
    </g>
  );
};

const S5: React.FC<{t: number}> = ({t}) => {
  const m = ramp(t, 23.0, 24.9, 0, 1, lin);
  const fallK = ramp(t, 25.2, 26.1, 0, 1, Easing.in(Easing.quad));
  const [sx, sy] = shake(t, 26.1, 18, 0.5);
  const poke = Math.sin(t * 7) * 0.2;
  return (
    <g transform={`translate(${sx},${sy})`}>
      <Space id="sp5" t={t} top="#070a22" bot="#2a2060" />
      <Skyline y={HZ} night seedo={11} />
      <Street y={HZ} col="#2c3042" />
      {m > 0 && m < 1 && (
        <g>
          <Fire x={lerpN(100, 760, m)} y={lerpN(160, 520, m)} ang={Math.atan2(360, 660)} len={380} w={22} t={t} />
          <circle cx={lerpN(100, 760, m)} cy={lerpN(160, 520, m)} r={22} fill="#fff6c0" stroke={OUT} strokeWidth={5} />
        </g>
      )}
      {fallK > 0 && fallK < 1 && (
        <g>
          <Fire x={700} y={lerpN(100, 1190, fallK)} ang={Math.PI / 2} len={260} w={14} t={t} />
          <Rock x={700} y={lerpN(100, 1190, fallK)} r={26} k={1} glow={1} />
        </g>
      )}
      {t >= 26.1 && (
        <g>
          <Burst x={700} y={1180} t={t} a={26.1} r={90} />
          <ellipse cx={700} cy={1220} rx={58} ry={14} fill="#1a1210" opacity={0.6} />
          <Rock x={700} y={1190} r={30} k={1} />
        </g>
      )}
      <Person x={400} y={1230} s={1.5} pose="walk" face="wow" ph={t * 3} shirt="#3b82d6" pants="#4a3a2a" hairStyle={1} hair="#8a5a2b" />
      {t > 26.3 && <line x1={440} y1={1130} x2={690} y2={1195 + poke * 30} stroke="#8a5a2b" strokeWidth={10} strokeLinecap="round" />}
      <Tag t={t} a={at('meteor') - 0.1} x={380} y={470} text="METEOR" size={70} bg="#ffd23a" rot={-4} />
      <Tag t={t} a={at('meteorit') - 0.1} x={700} y={980} text="METEORIT" size={70} bg="#ffffff" rot={3} />
      <Tag t={t} a={at('permukaan') - 0.1} x={700} y={1080} text="DI PERMUKAAN" size={44} bg="#c9b8a6" />
    </g>
  );
};

const S6: React.FC<{t: number}> = ({t}) => {
  const k = ramp(t, 28.6, 33.6, 0, 1, Easing.in(Easing.quad));
  const dark = 0.45 * k;
  const run = t > 30.4;
  const [sx, sy] = shake(t, 30.4, 16 * k, 3.4);
  return (
    <g transform={`translate(${sx},${sy})`}>
      <Sky id="sk6" top="#7fd0ff" bot="#e6f6ff" />
      <Cloud x={220} y={300} s={1.2} />
      <Skyline tint={0.45} seedo={3} />
      <Street />
      <Fire x={540} y={lerpN(60, 380, k)} ang={Math.PI / 2 + 0.08} len={lerpN(300, 900, k)} w={lerpN(80, 240, k)} t={t} />
      <Rock x={540} y={lerpN(60, 380, k)} r={lerpN(110, 380, k)} k={0} glow={1} rot={t * 8} />
      {FOLK.slice(0, 7).map((f, i) => {
        const dir = i % 2 ? 1 : -1;
        const base = 90 + i * 150;
        const x = run ? base + dir * (t - 30.4) * (210 + i * 14) * (i % 3 === 0 ? 1.2 : 1) : base;
        const y = 1170 + (i % 3) * 40;
        return <Person key={i} x={x} y={y} s={1.4} pose={run ? 'panic' : 'point'} face={run ? 'scared' : 'wow'} ph={t * 9 + i} shirt={f.sh} pants={f.pa} hair={f.hr} hairStyle={f.hs} flip={dir > 0 && run} />;
      })}
      <rect width={W} height={H} fill="#2a0f0a" opacity={dark} />
      <Tag t={t} a={29.0} x={CX} y={1030} text="CUKUP BESAR" size={56} bg="#e5484d" fg="#fff" />
    </g>
  );
};

const S7: React.FC<{t: number}> = ({t}) => {
  const hit = 34.6;
  const k = ramp(t, 33.7, hit, 0, 1, Easing.in(Easing.quad));
  const after = t - hit;
  const tilt = t > 39.6 ? Math.sin(t * 40) * 0.8 : 0;
  const [sx, sy] = shake(t, hit, 40, 3.5);
  const [qx, qy] = t > 39.6 ? shake(t, 39.6, 14, 1.7) : [0, 0];
  const heat = ramp(t, 39.6, 41.2, 0, 1, lin);
  const flash = t < hit ? 0 : ramp(t, hit, hit + 0.9, 1, 0, lin);
  const ring = (a: number) => ramp(t, a, a + 1.6, 0, 1, outC);
  return (
    <g transform={`translate(${sx + qx},${sy + qy})`}>
      <Sky id="sk7" top={hexMix('#7fd0ff', '#ff7a1a', after > 0 ? Math.min(0.7, after * 0.4) : 0)} bot={hexMix('#e6f6ff', '#ffd23a', after > 0 ? Math.min(0.7, after * 0.4) : 0)} />
      <Skyline tint={0.4} tilt={tilt} seedo={3} />
      <Street />
      {t < hit && (
        <g>
          <Fire x={540} y={lerpN(200, 1120, k)} ang={Math.PI / 2} len={lerpN(500, 900, k)} w={lerpN(160, 300, k)} t={t} />
          <Rock x={540} y={lerpN(200, 1120, k)} r={lerpN(230, 330, k)} k={0} glow={1} rot={t * 6} />
        </g>
      )}
      {after > 0 && (
        <g>
          <Burst x={540} y={1150} t={t} a={hit} r={520} />
          <ellipse cx={540} cy={1200} rx={ramp(t, 37.63, 38.4, 0, 330, outC)} ry={ramp(t, 37.63, 38.4, 0, 70, outC)} fill="#3a2a22" stroke={OUT} strokeWidth={8} opacity={ramp(t, 37.6, 37.7, 0, 1, lin)} />
          <ellipse cx={540} cy={1204} rx={ramp(t, 37.63, 38.4, 0, 250, outC)} ry={ramp(t, 37.63, 38.4, 0, 46, outC)} fill="#1a1210" opacity={ramp(t, 37.6, 37.7, 0, 1, lin)} />
          {[38.43, 38.75, 39.07].map((a, i) => (
            <ellipse key={i} cx={540} cy={1200} rx={ring(a) * 620} ry={ring(a) * 150} fill="none" stroke="#ffffff" strokeWidth={14 - i * 3} opacity={(1 - ring(a)) * 0.9} />
          ))}
          <Smoke x={540} y={1190} t={t} a={hit + 0.3} w={1.6} />
        </g>
      )}
      {t > 39.6 && (
        <g>
          <rect width={W} height={H} fill="#ff4a1a" opacity={0.18 * heat * (0.8 + 0.2 * Math.sin(t * 16))} />
          <path d="M 120 1290 L 260 1250 L 330 1300 L 420 1245" stroke={OUT} strokeWidth={8} fill="none" strokeLinecap="round" opacity={ramp(t, 40.4, 40.7, 0, 1, lin)} />
          <path d="M 940 1290 L 820 1250 L 740 1310 L 650 1250" stroke={OUT} strokeWidth={8} fill="none" strokeLinecap="round" opacity={ramp(t, 40.4, 40.7, 0, 1, lin)} />
        </g>
      )}
      {[0, 1, 2, 3, 4].map((i) => {
        const f = FOLK[i];
        const x0 = 110 + i * 220;
        const blow = after > 0.5 ? ramp(t, hit + 0.5, hit + 2.2, 0, 1, outC) : 0;
        const dir = x0 < 540 ? -1 : 1;
        const x = x0 + dir * blow * 220 * (1 + R(i));
        const y = 1210 + (i % 2) * 40 - blow * 280 * Math.sin(Math.min(1, blow) * Math.PI) * (0.6 + R(i + 3));
        const rot = blow * dir * 300 * (1 - 0.6 * (t > hit + 2.4 ? 1 : 0));
        const sweat = t > 39.6 ? 'sad' : 'scared';
        return <Person key={i} x={x} y={y} s={1.4} rot={rot} pose={after > 0.5 && t < hit + 2.4 ? 'panic' : after > 2.4 ? 'idle' : 'point'} face={after > 0 ? (t > 39.6 ? 'sad' : 'scared') : 'wow'} ph={t * 8 + i} shirt={f.sh} pants={f.pa} hair={f.hr} hairStyle={f.hs} flip={dir > 0} />;
      })}
      <rect width={W} height={H} fill="#fff" opacity={flash} />
      <Tag t={t} a={at('kawah') - 0.1} b={38.4} x={300} y={1440} text="KAWAH" size={64} bg="#ffd23a" rot={-3} />
      <Tag t={t} a={at('gelombang') - 0.1} b={39.4} x={700} y={1440} text="GELOMBANG KEJUT" size={50} bg="#ffffff" rot={3} />
      <Tag t={t} a={at('panas', 1) - 0.1} b={41.5} x={300} y={1440} text="PANAS EKSTREM" size={54} bg="#e5484d" fg="#fff" rot={-2} />
      <Tag t={t} a={at('gempa') - 0.1} b={41.5} x={760} y={1440} text="GEMPA" size={64} bg="#c9b8a6" rot={3} />
    </g>
  );
};

const S8: React.FC<{t: number}> = ({t}) => {
  const hit = 42.0;
  const wave = ramp(t, hit + 0.5, 44.3, 0, 1, Easing.in(Easing.quad));
  const rr = ramp(t, hit, hit + 1.2, 0, 1, outC);
  const bob = Math.sin(t * 3) * 8;
  const sc = t > 43.2 ? Math.sin(t * 40) * 4 : 0;
  return (
    <g>
      <Sky id="sk8" top="#7fd0ff" bot="#e6f6ff" h={900} />
      <Cloud x={200} y={240} s={1.2} />
      <rect y={900} width={W} height={1020} fill="#1f8fd0" />
      <rect y={900} width={W} height={14} fill="#bfe9ff" />
      {[0, 1, 2, 3].map((i) => (
        <path key={i} d={`M 0 ${980 + i * 70} ${Array.from({length: 9}).map((_, j) => `Q ${j * 135 + 68} ${960 + i * 70 + Math.sin(t * 2 + i + j) * 14} ${(j + 1) * 135} ${980 + i * 70}`).join(' ')}`} fill="none" stroke="#bfe9ff" strokeWidth={6} opacity={0.5} />
      ))}
      <g transform={`translate(${lerpN(160, 0, 0)},${bob})`}>
        <path d="M 620 920 L 1080 920 L 1080 1010 Q 900 1060 620 1010 Z" fill="#e9c98f" stroke={OUT} strokeWidth={7} />
        {[0, 1, 2].map((i) => (
          <g key={i} transform={`translate(${690 + i * 120 + sc},${860})`}>
            <rect width={84} height={70} fill={['#e5484d', '#ffd23a', '#f4f4f4'][i]} stroke={OUT} strokeWidth={6} />
            <path d="M -8 0 L 42 -42 L 92 0 Z" fill="#9b4a2a" stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
            <rect x={30} y={26} width={24} height={44} fill="#fff6c0" stroke={OUT} strokeWidth={4} />
          </g>
        ))}
      </g>
      {t < hit && (
        <g>
          <Fire x={300} y={lerpN(100, 900, ramp(t, 41.5, hit, 0, 1, Easing.in(Easing.quad)))} ang={Math.PI / 2} len={600} w={100} t={t} />
          <Rock x={300} y={lerpN(100, 900, ramp(t, 41.5, hit, 0, 1, Easing.in(Easing.quad)))} r={170} k={1} glow={1} rot={t * 12} />
        </g>
      )}
      {t >= hit && (
        <g>
          <Burst x={300} y={900} t={t} a={hit} r={360} />
          <path d={`M ${300 - rr * 150} 920 Q 300 ${920 - rr * 800} ${300 + rr * 150} 920 Z`} fill="#bfe9ff" stroke={OUT} strokeWidth={8} opacity={1 - ramp(t, hit + 1, hit + 2.2, 0, 1, lin)} />
        </g>
      )}
      {t > hit + 0.5 && (
        <g transform={`translate(${lerpN(300, 760, wave)},${920})`}>
          <path d={`M -200 0 Q -170 ${-170 - 140 * wave} -60 ${-260 - 220 * wave} Q 60 ${-300 - 260 * wave} 120 ${-180 - 130 * wave} Q 170 -60 230 0 Z`} fill="#2ea8e8" stroke={OUT} strokeWidth={9} strokeLinejoin="round" />
          <path d={`M -90 ${-210 - 160 * wave} Q 0 ${-290 - 240 * wave} 90 ${-190 - 120 * wave}`} fill="none" stroke="#fff" strokeWidth={10} strokeLinecap="round" />
        </g>
      )}
      <Person x={230} y={1560} s={1.7} pose="panic" face="scared" ph={t * 8} shirt="#e86b2a" pants="#2f3b5a" hairStyle={2} hair="#2b1b17" />
      <Tag t={t} a={at('laut') - 0.2} x={CX} y={1380} text="JATUH DI LAUT" size={54} bg="#ffffff" />
      <Tag t={t} a={at('tsunami') - 0.1} x={CX} y={1500} text="TSUNAMI!" size={84} bg="#e5484d" fg="#fff" rot={-3} />
    </g>
  );
};

const S9: React.FC<{t: number}> = ({t}) => {
  const rows = [
    {a: 46.5, y: 520, label: '10 METER', sub: 'BOLA API', col: '#ffd23a', r: 34, side: 'bus'},
    {a: 49.9, y: 1000, label: '1 KILOMETER', sub: 'DAMPAK GLOBAL', col: '#ff7a1a', r: 90, side: 'city'},
    {a: 52.6, y: 1480, label: '10 KILOMETER', sub: 'KEPUNAHAN MASSAL', col: '#e5484d', r: 190, side: 'mount'},
  ];
  return (
    <g>
      <rect width={W} height={H} fill="#1c1d3a" />
      <rect width={W} height={H} fill="#fff" opacity={0.04} />
      {rows.map((o, i) => {
        const e = pop(t, o.a, 0.55);
        const y = o.y;
        return (
          <g key={i} opacity={Math.min(1, e * 2)}>
            <rect x={40} y={y - 215} width={W - 80} height={430} rx={34} fill={['#2f6fb3', '#7a3fa8', '#a8352f'][i]} stroke={OUT} strokeWidth={8} opacity={0.95} />
            <g transform={`translate(260,${y - 40}) scale(${e})`}>
              <circle r={o.r * 1.4} fill={o.col} opacity={0.35} />
              <Rock x={0} y={0} r={o.r} k={i} glow={1} rot={t * 20} />
            </g>
            <g transform={`translate(${800},${y + 120})`}>
              {o.side === 'bus' && (
                <g>
                  <rect x={-120} y={-80} width={240} height={90} rx={16} fill="#ffd23a" stroke={OUT} strokeWidth={7} />
                  {[-80, -20, 40, 90].map((q) => <rect key={q} x={q - 18} y={-64} width={34} height={30} fill="#9fe0ff" stroke={OUT} strokeWidth={4} />)}
                  <circle cx={-70} cy={14} r={22} fill="#333" stroke={OUT} strokeWidth={6} />
                  <circle cx={70} cy={14} r={22} fill="#333" stroke={OUT} strokeWidth={6} />
                </g>
              )}
              {o.side === 'city' && [-100, -30, 40, 110].map((q, j) => (
                <g key={j}>
                  <rect x={q - 28} y={-90 - j * 28 - 60} width={56} height={90 + j * 28 + 60} fill={['#6d8fd0', '#8f6fd0', '#4aa3a3', '#d08f6f'][j]} stroke={OUT} strokeWidth={6} />
                  {[0, 1, 2].map((w) => <rect key={w} x={q - 14} y={-130 - j * 28 + w * 34} width={28} height={16} fill="#fff6c0" />)}
                </g>
              ))}
              {o.side === 'mount' && (
                <g>
                  <path d="M -230 10 L -60 -250 L 20 -150 L 90 -280 L 240 10 Z" fill="#7a8f5a" stroke={OUT} strokeWidth={8} strokeLinejoin="round" />
                  <path d="M 90 -280 L 55 -210 L 100 -190 L 130 -215 Z" fill="#fff" stroke={OUT} strokeWidth={5} />
                </g>
              )}
              <Person x={-190} y={0} s={0.9} pose="idle" face="wow" shirt="#e5484d" pants="#2f3b5a" hairStyle={i} ph={t * 3} />
            </g>
            <Tag t={t} a={o.a} x={CX} y={y - 150} text={o.label} size={60} bg="#ffffff" />
            <Tag t={t} a={o.a + 0.5} x={CX} y={y + 170} text={o.sub} size={58} bg={o.col} fg={i === 2 ? '#fff' : OUT} />
          </g>
        );
      })}
      <Tag t={t} a={44.7} b={46.4} x={CX} y={700} text="TIDAK SEMUANYA SAMA" size={70} bg="#ffd23a" rot={-2} />
    </g>
  );
};

const S10: React.FC<{t: number}> = ({t}) => {
  const clockK = ramp(t, 58.9, 61.2, 0, 1, Easing.inOut(Easing.cubic));
  const hit = 65.0;
  const phase1 = t < 61.4;
  const rock = ramp(t, 62.6, hit, 0, 1, Easing.in(Easing.quad));
  const [sx, sy] = shake(t, hit, 36, 2.5);
  const crater = ramp(t, 66.3, 68.4, 0, 1, outC);
  const ring = ramp(t, 68.2, 69.4, 0, 1, outC);
  return (
    <g transform={`translate(${sx},${sy})`}>
      {t < 61.4 && (
        <g>
          <Sky id="sk10a" top="#f2e0b0" bot="#e5f0d0" />
          <rect width={W} height={H} fill="#fbf1d6" opacity={0.0} />
          <rect y={HZ} width={W} height={H - HZ} fill="#d9c58a" />
          <Big x={CX} y={460} text="BUKAN SEKADAR TEORI" size={84} fill="#fff" rot={-3} sc={pop(t, 57.0, 0.5)} />
          <g transform={`translate(${CX},${900})`}>
            <circle r={230} fill="#fff" stroke={OUT} strokeWidth={14} />
            {Array.from({length: 12}).map((_, i) => <line key={i} x1={0} y1={-200} x2={0} y2={-218} stroke={OUT} strokeWidth={8} transform={`rotate(${i * 30})`} />)}
            <line x1={0} y1={0} x2={0} y2={-150} stroke={OUT} strokeWidth={14} strokeLinecap="round" transform={`rotate(${-clockK * 1440})`} />
            <line x1={0} y1={0} x2={0} y2={-100} stroke={'#e5484d'} strokeWidth={18} strokeLinecap="round" transform={`rotate(${-clockK * 120})`} />
            <circle r={16} fill={OUT} />
          </g>
          <Tag t={t} a={58.9} x={CX} y={1240} text="66 JUTA TAHUN LALU" size={70} bg="#ffd23a" />
        </g>
      )}
      {t >= 61.4 && (
        <g>
          <Sky id="sk10b" top={hexMix('#7fd0ff', '#ff9a4a', t > hit ? 0.7 : 0)} bot={hexMix('#e6f6ff', '#ffd23a', t > hit ? 0.7 : 0)} />
          <Cloud x={250} y={260} s={1.3} />
          <path d={`M 0 ${HZ - 80} Q 200 ${HZ - 260} 420 ${HZ - 80} Q 600 ${HZ - 330} 860 ${HZ - 60} L 1080 ${HZ - 100} L 1080 ${HZ} L 0 ${HZ} Z`} fill="#5ea05a" stroke={OUT} strokeWidth={7} opacity={0.9} />
          <rect y={HZ} width={W} height={H - HZ} fill="#7ab55a" />
          <rect y={HZ} width={W} height={16} fill="#4a8a3a" />
          {[0, 1, 2].map((i) => <Dino key={i} x={200 + i * 300} y={1230 + (i % 2) * 40} s={1.15} face={t > 63.0 ? 'shock' : 'calm'} flip={i === 1} col={['#5cb85c', '#e0884a', '#5aa9d6'][i]} ph={t * 3 + i} />)}
          {t < hit && (
            <g>
              <Fire x={lerpN(900, 540, rock)} y={lerpN(60, 1160, rock)} ang={Math.atan2(1100, -360)} len={600} w={110} t={t} />
              <Rock x={lerpN(900, 540, rock)} y={lerpN(60, 1160, rock)} r={lerpN(80, 260, rock)} k={2} glow={1} rot={t * 10} />
            </g>
          )}
          {t >= hit && <Burst x={540} y={1180} t={t} a={hit} r={500} />}
          {t >= hit && <Smoke x={540} y={1200} t={t} a={hit + 0.3} w={1.6} />}
          {t >= hit && <rect width={W} height={H} fill="#fff" opacity={ramp(t, hit, hit + 0.8, 1, 0, lin)} />}
        </g>
      )}
      {t > 61.4 && t < 66.0 && (
        <g>
          <Tag t={t} a={61.6} x={CX} y={1450} text="SEMENANJUNG YUCATÁN" size={52} bg="#ffffff" />
          <Tag t={t} a={62.4} x={CX} y={1550} text="MEKSIKO" size={52} bg="#4cbf6a" />
          <Tag t={t} a={at('selebar') - 0.1} x={CX} y={400} text="SELEBAR ±10 KM" size={60} bg="#ffd23a" />
        </g>
      )}
      {t >= 66.0 && (
        <g>
          <rect width={W} height={H} fill="#2a1a2e" opacity={ramp(t, 66.0, 66.6, 0, 0.9, lin)} />
          <g transform={`translate(${CX},900)`}>
            <circle r={crater * 400} fill="#3a2a22" stroke={OUT} strokeWidth={10} />
            <circle r={crater * 300} fill="#1a1210" />
            <circle r={crater * 400 + ring * 60} fill="none" stroke="#e5484d" strokeWidth={10} strokeDasharray="22 14" opacity={ring} />
            <circle r={9} fill="#ffd23a" stroke={OUT} strokeWidth={3} opacity={crater} cx={0} cy={0} />
          </g>
          <Tag t={t} a={66.3} x={CX} y={400} text="KAWAH CHICXULUB" size={72} bg="#ffd23a" />
          <Tag t={t} a={at('berdiameter') || 67.5} x={CX} y={1380} text="±200 KM" size={110} bg="#ffffff" />
          <Tag t={t} a={68.4} x={CX} y={1500} text="DIAMETER KAWAH" size={50} bg="#ff7a1a" fg="#fff" />
        </g>
      )}
    </g>
  );
};

const S11: React.FC<{t: number}> = ({t}) => {
  const dark = ramp(t, 70.4, 75.5, 0, 1, lin);
  const sun = ramp(t, 74.8, 76.5, 1, 0.12, lin);
  const wilt = ramp(t, 75.5, 77.5, 0, 1, lin);
  return (
    <g>
      <Sky id="sk11" top={hexMix('#7fd0ff', '#2a2430', dark)} bot={hexMix('#e6f6ff', '#5a4a44', dark)} />
      <g opacity={sun}>
        <circle cx={850} cy={330} r={120} fill="#ffd23a" stroke={OUT} strokeWidth={8} />
        {Array.from({length: 10}).map((_, i) => <line key={i} x1={850 + Math.cos(i * 0.628) * 150} y1={330 + Math.sin(i * 0.628) * 150} x2={850 + Math.cos(i * 0.628) * 195} y2={330 + Math.sin(i * 0.628) * 195} stroke="#ffd23a" strokeWidth={12} strokeLinecap="round" />)}
      </g>
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((i) => {
        const a = 70.4 + (i % 4) * 1.0;
        const k = ramp(t, a, a + 2.5, 0, 1, outC);
        const col = i % 3 === 0 ? '#5a5048' : i % 3 === 1 ? '#2b2420' : '#d9c25a';
        return <circle key={i} cx={60 + i * 90 + Math.sin(t * 1.2 + i) * 30} cy={lerpN(1000, 120 + (i % 5) * 150, k)} r={70 + R(i) * 60} fill={col} stroke={OUT} strokeWidth={6} opacity={0.88 * Math.min(1, k * 3)} />;
      })}
      <path d={`M 0 ${HZ - 40} Q 270 ${HZ - 120} 540 ${HZ - 40} T 1080 ${HZ - 50} L 1080 ${HZ} L 0 ${HZ} Z`} fill={hexMix('#5ea05a', '#4a4a3a', dark)} stroke={OUT} strokeWidth={7} />
      <rect y={HZ} width={W} height={H - HZ} fill={hexMix('#7ab55a', '#6a6a48', dark)} />
      {[0, 1, 2, 3].map((i) => {
        const x = 150 + i * 250;
        const bend = wilt * 0.9;
        return (
          <g key={i} transform={`translate(${x},1300)`}>
            <path d={`M 0 0 Q ${bend * 30} -70 ${bend * 90} ${-150 + bend * 90}`} stroke={hexMix('#3d9a3d', '#8a7a3a', wilt)} strokeWidth={16} fill="none" strokeLinecap="round" />
            <ellipse cx={bend * 90 - 38} cy={-160 + bend * 100} rx={48} ry={22} fill={hexMix('#4cbf6a', '#9a8a3a', wilt)} stroke={OUT} strokeWidth={6} transform={`rotate(${-20 + bend * 80} ${bend * 90} ${-150 + bend * 90})`} />
            <ellipse cx={bend * 90 + 38} cy={-160 + bend * 100} rx={48} ry={22} fill={hexMix('#4cbf6a', '#9a8a3a', wilt)} stroke={OUT} strokeWidth={6} transform={`rotate(${20 + bend * 80} ${bend * 90} ${-150 + bend * 90})`} />
          </g>
        );
      })}
      <rect width={W} height={H} fill="#000" opacity={0.22 * dark} />
      <Tag t={t} a={at('Debu') - 0.1} x={260} y={560} text="DEBU" size={60} bg="#c9b8a6" rot={-4} />
      <Tag t={t} a={at('jelaga') - 0.1} x={720} y={700} text="JELAGA" size={60} bg="#8a8078" fg="#fff" rot={3} />
      <Tag t={t} a={at('aerosol') - 0.1} x={CX} y={860} text="AEROSOL SULFUR" size={56} bg="#d9c25a" />
      <Tag t={t} a={at('menghalangi') - 0.1} x={CX} y={1450} text="SINAR MATAHARI TERHALANG" size={48} bg="#ffd23a" />
      <Tag t={t} a={at('fotosintesis') - 0.2} x={CX} y={1550} text="FOTOSINTESIS TERHAMBAT" size={48} bg="#4cbf6a" />
    </g>
  );
};

const S12: React.FC<{t: number}> = ({t}) => {
  const fall = ramp(t, 78.4, 79.6, 0, 1, Easing.in(Easing.quad));
  const nodes = [
    {x: 540, y: 1250, n: 'TUMBUHAN', c: '#4cbf6a'},
    {x: 540, y: 880, n: 'PEMAKAN TUMBUHAN', c: '#ffd23a'},
    {x: 540, y: 510, n: 'PEMANGSA', c: '#e5484d'},
  ];
  return (
    <g>
      <rect width={W} height={H} fill="#2b2a3a" />
      {nodes.map((o, i) => {
        const gone = i === 0 ? fall : i === 1 ? ramp(t, 78.8, 79.7, 0, 1, lin) : ramp(t, 79.1, 79.8, 0, 1, lin);
        const rot = (1 - Math.cos(gone * Math.PI)) * (i % 2 ? 40 : -40) * 0.3;
        return (
          <g key={i} transform={`translate(${o.x},${o.y + gone * 120}) rotate(${rot})`} opacity={1 - gone * 0.8}>
            <rect x={-300} y={-130} width={600} height={260} rx={40} fill={o.c} stroke={OUT} strokeWidth={9} />
            {i === 0 ? (
              <g transform="translate(0,-10)">
                <path d="M 0 50 Q 5 -10 0 -60" stroke="#1f6a2a" strokeWidth={12} fill="none" strokeLinecap="round" />
                <ellipse cx={-34} cy={-30} rx={38} ry={17} fill="#2f9a4a" stroke={OUT} strokeWidth={5} transform="rotate(-25 -34 -30)" />
                <ellipse cx={34} cy={-10} rx={38} ry={17} fill="#2f9a4a" stroke={OUT} strokeWidth={5} transform="rotate(25 34 -10)" />
                <ellipse cx={0} cy={-70} rx={30} ry={15} fill="#4cbf6a" stroke={OUT} strokeWidth={5} />
              </g>
            ) : (
              <g transform="translate(0,20) scale(0.55)"><Dino x={0} y={0} s={1} col={i === 1 ? '#5cb85c' : '#d9482a'} face="calm" /></g>
            )}
            <text x={0} y={90} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={54} fill={OUT}>{o.n}</text>
          </g>
        );
      })}
      {[0, 1].map((i) => (
        <g key={i} transform={`translate(540,${1065 - i * 370})`} opacity={1 - ramp(t, 78.6 + i * 0.3, 79.3 + i * 0.3, 0, 1, lin)}>
          <path d="M 0 90 L 0 -90 M -40 -50 L 0 -100 L 40 -50" stroke="#fff" strokeWidth={16} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      ))}
      <Tag t={t} a={78.2} x={CX} y={230} text="RANTAI MAKANAN" size={72} bg="#ffffff" />
    </g>
  );
};

const S13: React.FC<{t: number}> = ({t}) => {
  const gray = ramp(t, 80.6, 82.4, 0, 1, lin);
  const N = 16;
  const gone = (i: number) => (i * 7) % N < 15; // 15/20 = 75%
  const dinoOut = ramp(t, 83.0, 83.6, 0, 1, lin);
  return (
    <g>
      <rect width={W} height={H} fill={hexMix('#2f6fb3', '#3a3a44', gray * 0.6)} />
      {Array.from({length: N}).map((_, i) => {
        const col = i % 4, row = Math.floor(i / 4);
        const g = gone(i) ? gray : 0;
        return (
          <g key={i} transform={`translate(${170 + col * 245},${440 + row * 175})`} opacity={1 - 0.75 * g} style={{filter: `grayscale(${g})`}}>
            <circle r={78} fill="#fff" stroke={OUT} strokeWidth={7} />
            <g transform={`scale(${i % 2 ? -1 : 1},1)`}>
              <path d="M -52 0 L -82 -26 L -82 26 Z" fill={['#ff7a1a', '#3b82d6', '#9b6bd6', '#4cbf6a', '#f06aa8'][i % 5]} stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
              <ellipse rx={54} ry={32} fill={['#ffb020', '#5ad1ff', '#c9a6f0', '#6ee7a0', '#ffa6cf'][i % 5]} stroke={OUT} strokeWidth={6} />
              <circle cx={28} cy={-6} r={7} fill="#fff" stroke={OUT} strokeWidth={3} />
              <circle cx={30} cy={-6} r={3} fill={OUT} />
            </g>
            {g > 0.6 && <g stroke="#e5484d" strokeWidth={12} strokeLinecap="round"><line x1={-60} y1={-60} x2={60} y2={60} /><line x1={60} y1={-60} x2={-60} y2={60} /></g>}
          </g>
        );
      })}
      <Big x={300} y={1240} text="75%" size={210} fill="#ffd23a" sc={pop(t, 80.3, 0.6)} />
      <Tag t={t} a={80.0} x={CX} y={300} text="SPESIES PUNAH" size={64} bg="#ffffff" />
      <g opacity={ramp(t, 82.9, 83.3, 0, 1, lin)} transform={`translate(780,1250)`}>
        <Dino x={0} y={0} s={0.55} col="#7a8a7a" face="shock" />
        <g stroke="#e5484d" strokeWidth={16} strokeLinecap="round" opacity={dinoOut}><line x1={-90} y1={-150} x2={90} y2={40} /><line x1={90} y1={-150} x2={-90} y2={40} /></g>
      </g>
      <Tag t={t} a={at('non-unggas') - 0.1 || 84.4} x={CX} y={1600} text="DINOSAURUS NON-UNGGAS" size={50} bg="#e5484d" fg="#fff" />
    </g>
  );
};

const S14: React.FC<{t: number}> = ({t}) => {
  const up = ramp(t, 85.8, 87.4, 0, 1, outC);
  return (
    <g>
      <Sky id="sk14" top="#ffb866" bot="#fff3c0" />
      <circle cx={CX} cy={lerpN(1200, 760, up)} r={190} fill="#ffd23a" stroke={OUT} strokeWidth={9} />
      {Array.from({length: 14}).map((_, i) => <line key={i} x1={CX + Math.cos(i * 0.449) * 230} y1={lerpN(1200, 760, up) + Math.sin(i * 0.449) * 230} x2={CX + Math.cos(i * 0.449) * 290} y2={lerpN(1200, 760, up) + Math.sin(i * 0.449) * 290} stroke="#ffd23a" strokeWidth={14} strokeLinecap="round" />)}
      <path d={`M 0 ${HZ + 80} Q 270 ${HZ} 540 ${HZ + 60} T 1080 ${HZ + 40} L 1080 ${H} L 0 ${H} Z`} fill="#6fbf5a" stroke={OUT} strokeWidth={8} />
      {[0, 1, 2, 3].map((i) => {
        const f = FOLK[i + 3];
        return <Person key={i} x={170 + i * 250} y={1320 + (i % 2) * 40} s={1.5} coat pose="cheer" face="happy" ph={t * 8 + i} shirt="#ffffff" pants={f.pa} hair={f.hr} hairStyle={f.hs} />;
      })}
      <Tag t={t} a={85.95} x={CX} y={300} text="KABAR BAIKNYA" size={84} bg="#ffffff" rot={-2} />
      <Tag t={t} a={87.4} x={CX} y={430} text="MANUSIA PUNYA JAWABANNYA" size={52} bg="#4cbf6a" />
    </g>
  );
};

const S15: React.FC<{t: number}> = ({t}) => {
  const hit = 96.9;
  const ap = ramp(t, 92.0, hit, 0, 1, Easing.inOut(Easing.quad));
  const dx = lerpN(120, 500, ap), dy = lerpN(300, 760, ap);
  const orbA = t * 1.6;
  const rBefore = 200, rAfter = 170;
  const rr = t < hit ? rBefore : rAfter;
  const mx = 640 + Math.cos(orbA * (t < hit ? 1 : 1.25)) * rr;
  const my = 800 + Math.sin(orbA * (t < hit ? 1 : 1.25)) * rr * 0.65;
  const [sx, sy] = shake(t, hit, 18, 0.7);
  return (
    <g transform={`translate(${sx},${sy})`}>
      <Space id="sp15" t={t} top="#070a22" bot="#1c1450" />
      <g opacity={ramp(t, 89.0, 89.6, 0, 1, lin) * (1 - ramp(t, 91.8, 92.2, 0, 1, lin))} transform={`translate(${CX},800)`}>
        <rect x={-300} y={-330} width={600} height={620} rx={44} fill="#fff" stroke={OUT} strokeWidth={10} />
        <rect x={-300} y={-330} width={600} height={160} rx={44} fill="#e5484d" stroke={OUT} strokeWidth={10} />
        <text y={-215} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={80} fill="#fff">SEPTEMBER 2022</text>
        <text y={80} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={300} fill={OUT}>26</text>
      </g>
      {t > 91.8 && (
        <g>
          <ellipse cx={640} cy={800} rx={rBefore} ry={rBefore * 0.65} fill="none" stroke="#fff" strokeWidth={4} strokeDasharray="12 12" opacity={t < hit ? 0.8 : 0.3} />
          {t >= hit && <ellipse cx={640} cy={800} rx={rAfter} ry={rAfter * 0.65} fill="none" stroke="#ffd23a" strokeWidth={6} strokeDasharray="12 12" />}
          <Rock x={640} y={800} r={62} k={1} rot={t * 8} />
          <Rock x={mx} y={my} r={t < hit + 0.2 ? 28 : 28} k={2} rot={t * 30} col="#b3a392" />
          {t < hit && (
            <g transform={`translate(${dx},${dy}) rotate(${(Math.atan2(my - dy, mx - dx) * 180) / Math.PI})`}>
              <rect x={-44} y={-22} width={88} height={44} rx={8} fill="#d9d9e0" stroke={OUT} strokeWidth={6} />
              <rect x={-44} y={-90} width={30} height={180} fill="#3b82d6" stroke={OUT} strokeWidth={5} />
              <rect x={44} y={-4} width={26} height={8} fill="#ffd23a" stroke={OUT} strokeWidth={3} />
            </g>
          )}
          {t >= hit && <Burst x={mx} y={my} t={t} a={hit} r={130} />}
        </g>
      )}
      <Tag t={t} a={91.9} x={CX} y={300} text="PESAWAT DART (NASA)" size={54} bg="#ffffff" />
      <Tag t={t} a={at('Dimorphos') - 0.1} x={820} y={1010} text="DIMORPHOS" size={46} bg="#c9b8a6" />
      <Tag t={t} a={at('Didymos') - 0.1} x={470} y={650} text="DIDYMOS" size={46} bg="#ffffff" />
      <Tag t={t} a={99.0} x={CX} y={1130} text="ORBIT BERUBAH!" size={72} bg="#ffd23a" rot={-2} />
      <Tag t={t} a={100.9} x={CX} y={1250} text="PENUMBUK KINETIK" size={64} bg="#5ad1ff" />
    </g>
  );
};

const S16: React.FC<{t: number}> = ({t}) => {
  const push = Math.sin(t * 5) * 14;
  return (
    <g>
      <Sky id="sk16" top="#7fd0ff" bot="#e6f6ff" />
      <Cloud x={200} y={300} s={1.3} />
      <rect y={HZ} width={W} height={H - HZ} fill="#7ab55a" />
      <rect y={HZ} width={W} height={16} fill="#4a8a3a" />
      <Rock x={640 + push * 0.4} y={1040} r={300} k={0} />
      <g transform={`translate(${380 + push * 0.5},1330) scale(1.4)`}>
        <Fosi x={0} y={0} s={1} mood="tired" t={t} />
      </g>
      <Tag t={t} a={103.5} x={CX} y={330} text="TIDAK SEMUDAH ITU" size={80} bg="#ffffff" rot={-2} />
    </g>
  );
};

const S17: React.FC<{t: number}> = ({t}) => {
  const sweep = t * 2.2;
  const ph2 = t > 109.9;
  return (
    <g>
      <rect width={W} height={H} fill="#0c1f2a" />
      {!ph2 && (
        <g transform={`translate(${CX},800)`}>
          {[130, 260, 390].map((r) => <circle key={r} r={r} fill="none" stroke="#4cbf6a" strokeWidth={5} opacity={0.6} />)}
          <line x1={-400} y1={0} x2={400} y2={0} stroke="#4cbf6a" strokeWidth={3} opacity={0.4} />
          <line x1={0} y1={-400} x2={0} y2={400} stroke="#4cbf6a" strokeWidth={3} opacity={0.4} />
          <path d={`M 0 0 L ${Math.cos(sweep) * 400} ${Math.sin(sweep) * 400} A 400 400 0 0 0 ${Math.cos(sweep - 0.7) * 400} ${Math.sin(sweep - 0.7) * 400} Z`} fill="#4cbf6a" opacity={0.35} />
          <Big x={0} y={-30} text="?" size={260} fill="#ffd23a" sc={pop(t, 107.9, 0.5)} />
        </g>
      )}
      {!ph2 && <Tag t={t} a={107.6} x={CX} y={300} text="ADAKAH YANG MENGARAH KE KITA?" size={52} bg="#ffffff" />}
      {ph2 && (
        <g>
          <g transform={`translate(${CX},720)`}>
            <path d="M -200 200 L -120 -60 L 120 -60 L 200 200 Z" fill="#d9d9e0" stroke={OUT} strokeWidth={9} />
            <ellipse cx={0} cy={-60} rx={150} ry={42} fill="#9fe0ff" stroke={OUT} strokeWidth={9} />
            <rect x={-60} y={200} width={120} height={80} fill="#8a8a96" stroke={OUT} strokeWidth={9} />
            <text y={150} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={70} fill={OUT}>NASA</text>
          </g>
          <Tag t={t} a={110.0} x={CX} y={330} text="MENURUT NASA" size={64} bg="#ffffff" />
          <Tag t={t} a={at('140') - 0.2 || 112.0} x={CX} y={1160} text=">140 METER" size={100} bg="#ffd23a" />
          <Tag t={t} a={113.5} x={CX} y={1310} text="BELUM ADA YANG BERPELUANG" size={50} bg="#4cbf6a" />
          <Tag t={t} a={at('100') - 0.2 || 116.0} x={CX} y={1430} text="100 TAHUN KE DEPAN" size={56} bg="#ffffff" />
        </g>
      )}
    </g>
  );
};

const S18: React.FC<{t: number}> = ({t}) => {
  return (
    <g>
      <Space id="sp18" t={t} top="#05061a" bot="#2a2060" n={110} />
      <path d={`M 0 ${HZ} Q 270 ${HZ - 110} 540 ${HZ - 30} T 1080 ${HZ - 70} L 1080 ${H} L 0 ${H} Z`} fill="#16213a" stroke={OUT} strokeWidth={8} />
      <g transform={`translate(760,${HZ - 60})`}>
        <path d="M -140 0 L -110 -150 L 110 -150 L 140 0 Z" fill="#d9d9e0" stroke={OUT} strokeWidth={8} />
        <path d="M -120 -150 A 120 120 0 0 1 120 -150 Z" fill="#c9c9d6" stroke={OUT} strokeWidth={8} />
        <rect x={-18} y={-270} width={36} height={120} fill="#7fd0ff" stroke={OUT} strokeWidth={5} opacity={0.9} />
      </g>
      {[0, 1, 2].map((i) => <Person key={i} x={170 + i * 170} y={1290 + (i % 2) * 30} s={1.5} coat pose="look" face="calm" ph={t * 2 + i} shirt="#ffffff" pants="#2f3b5a" hair={FOLK[i].hr} hairStyle={FOLK[i].hs} flip={false} />)}
      {[0, 1, 2].map((i) => <circle key={i} cx={780 + i * 40} cy={500 - i * 60} r={5} fill="#ffd23a" opacity={0.4 + 0.6 * Math.sin(t * 4 + i) ** 2} />)}
      <Tag t={t} a={118.6} x={CX} y={330} text="ANCAMANNYA NYATA" size={78} bg="#e5484d" fg="#fff" rot={-2} />
      <Tag t={t} a={119.9} x={CX} y={470} text="TAPI BUKAN PASTI TERJADI" size={56} bg="#ffd23a" />
      <Tag t={t} a={122.7} x={CX} y={610} text="ILMUWAN TERUS MENGAWASI" size={52} bg="#ffffff" />
    </g>
  );
};

/* ================= main ================= */
const SCENES: React.FC<{t: number}>[] = [S0, S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15, S16, S17, S18];
const SB2 = [...SB, 126.4];

const Stage: React.FC<{i: number; t: number}> = ({i, t}) => {
  const a = SB2[i], b = SB2[i + 1];
  const o = ramp(t, a - 0.01, a + 0.3, i === 0 ? 1 : 0, 1, lin) * (i === SCENES.length - 1 ? 1 : ramp(t, b - 0.01, b + 0.3, 1, 0, lin));
  if (t < a - 0.02 || t > b + 0.32 || o <= 0.001) return null;
  const Sc = SCENES[i];
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', inset: 0, opacity: o}}>
      <Sc t={t} />
    </svg>
  );
};

const Watermark: React.FC = () => (
  <div style={{position: 'absolute', right: 52, bottom: WM_BOTTOM, fontFamily: cond, fontWeight: 700, fontSize: 46, color: '#fff', opacity: 0.85, letterSpacing: '0.03em', textShadow: '0 3px 8px rgba(0,0,0,0.6)'}}>
    Semesta<span style={{color: '#ffd23a'}}>Kita</span>
  </div>
);

const EndCard: React.FC<{t: number}> = ({t}) => {
  const a = 126.3;
  if (t < a) return null;
  const o = ramp(t, a, a + 0.5, 0, 1, lin);
  const p = pop(t, a + 0.2, 0.6);
  return (
    <AbsoluteFill style={{background: 'linear-gradient(#0b1030,#3a1a5a)', opacity: o, alignItems: 'center', justifyContent: 'center'}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <Stars t={t} n={90} />
        <g transform={`translate(${CX},800) scale(${p})`}>
          <EarthBall x={0} y={0} r={190} rot={t * 6} />
        </g>
      </svg>
      <div style={{position: 'absolute', top: 1090, width: '100%', textAlign: 'center', fontFamily: cond, fontWeight: 700, fontSize: 150, color: '#fff', transform: `scale(${p})`, WebkitTextStroke: '10px #1a1210', paintOrder: 'stroke fill'} as React.CSSProperties}>
        Semesta<span style={{color: '#ffd23a'}}>Kita</span>
      </div>
      <div style={{position: 'absolute', top: 1320, width: '100%', textAlign: 'center', fontFamily: sans, fontWeight: 700, fontSize: 44, color: '#fff', opacity: ramp(t, a + 0.9, a + 1.4, 0, 1, lin)}}>
        Follow untuk sains seru lainnya
      </div>
    </AbsoluteFill>
  );
};

export const Asteroid: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const fadeIn = ramp(t, 0, 0.3, 0, 1, lin);
  const fadeOut = ramp(t, DUR - 0.6, DUR, 1, 0, lin);
  return (
    <AbsoluteFill style={{background: '#000', opacity: Math.min(fadeIn, fadeOut)}}>
      <Audio src={staticFile('audio.mp3')} />
      {SCENES.map((_, i) => (
        <Stage key={i} i={i} t={t} />
      ))}
      <Meme t={t} a={8.9} b={10.2} mood="confused" lines={['HAH?', 'APA TUH?']} ty={560} />
      <Meme t={t} a={31.4} b={32.9} mood="brow" lines={['WADUH!', 'KEGEDEAN']} ty={560} />
      <Meme t={t} a={55.1} b={56.6} mood="brow" lines={['SERAM', 'JUGA YA']} ty={560} />
      <Meme t={t} a={78.3} b={79.7} mood="tired" lines={['YAHH...', 'RUNTUH']} ty={560} />
      <Meme t={t} a={105.0} b={106.6} mood="tired" lines={['NGGAK KUAT', 'BOS']} ty={560} />
      {t < 126.3 && <Caption t={t} />}
      {t < 126.3 && <Watermark />}
      <EndCard t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 60%, rgba(0,0,0,0.35) 100%)', pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
