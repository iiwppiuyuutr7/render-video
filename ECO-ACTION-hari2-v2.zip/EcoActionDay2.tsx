/**
 * ECO-ACTION 4 DAYS – Hari Kedua: Aksi Nyata dan Eksekusi Tamanisasi
 * 1920x1080 (16:9) · 60 fps · ±61 detik
 *
 * Sambungan dari Hari 1: mulai dari layar hijau akhir Hari 1 (iris membuka ke klip pertama),
 * tanpa pembuka program dan tanpa ending. Hanya ada tulisan "Hari 2" di awal.
 * Backsound melanjutkan musik dari detik ke-105,87 (akhir Hari 1), volumenya turun setiap ada SFX.
 * Logo tamanisasi (kiri atas) dan logo SMA 1 Doro (kanan atas) tampil sepanjang video.
 *
 * Semua waktu dalam DETIK, diubah ke frame sesuai fps composition (useVideoConfig).
 * Pastikan durationInFrames di Root = ECO2_TOTAL_SECONDS x fps.
 * Klip memakai frame rate aslinya (30 dan 60 fps).
 * Aset: public/eco2/clips, public/eco2/sfx, public/eco2/music.mp3, public/eco2/logo-*.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

/* ───────────────────────── konfigurasi ───────────────────────── */
const WITH_MUSIC = true; // false = tanpa backsound (kalau mau dipasang sendiri)

const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const WHITE = '#ffffff';
const BEIGE = '#efe5cf';
const GREEN = '#9fcf86';
const DEEP = '#0f2e1c';

const OVERLAP_S = 0.5; // durasi dissolve antar klip

/* ───────────────────────── urutan klip (detik) ───────────────────────── */
type Seg = {id: string; src: string; sec: number; zoom: 'in' | 'out'};

const SEGS: Seg[] = [
  {id: 'a', src: 'a-persiapan', sec: 13.6, zoom: 'in'}, // suasana sekolah → siswa mengecat wadah daur ulang
  {id: 'b', src: 'b-media-tanam', sec: 8.0, zoom: 'in'}, // memotong galon bekas
  {id: 'c', src: 'c-kolaborasi', sec: 8.0, zoom: 'out'}, // kerja kelompok memotong galon bekas
  {id: 'd', src: 'd-eksekusi', sec: 10.0, zoom: 'in'}, // menggemburkan tanah & menanam bibit
];

const START_S: Record<string, number> = {};
let acc = 0;
SEGS.forEach((s, i) => {
  const st = i === 0 ? 0 : acc - OVERLAP_S;
  START_S[s.id] = st;
  acc = st + s.sec;
});
const VIDEO_END_S = acc; // klip terakhir selesai di ±38,1 detik

/* ───────────────────────── kartu info (setelah klip) ───────────────────────── */
const CARDS_START_S = VIDEO_END_S - OVERLAP_S;
const C0 = VIDEO_END_S + 0.2;
const CARD = {
  jadwal: {start: C0, end: C0 + 10.5},
  jelas: {start: C0 + 10.6, end: C0 + 20.1},
  next: {start: C0 + 20.2, end: C0 + 23.8},
};
export const ECO2_TOTAL_SECONDS = CARD.next.end; // ±62,1 detik

/* ───────────────────────── util ───────────────────────── */
const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const useFr = () => {
  const {fps} = useVideoConfig();
  return (s: number) => Math.round(s * fps);
};

const fadeWindow = (f: number, dur: number, fi: number, fo: number) =>
  interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], clampOpts);

const rise = (f: number, delay: number, len: number, dist: number) =>
  interpolate(f, [delay, delay + len], [dist, 0], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });

const shadow = '0 3px 24px rgba(0,0,0,0.38)';

/* ───────────────────────── klip video ───────────────────────── */
// Color grading ringan: sedikit hangat, saturasi hijau natural, kontras seimbang.
const GRADE = 'saturate(1.12) contrast(1.05) brightness(0.98) sepia(0.10)';

// Jenis transisi masuk tiap klip (selama OVERLAP_S): dissolve, zoom-through, push, iris.
type Enter = 'fade' | 'dissolve' | 'zoom' | 'push' | 'iris';
const ENTER: Record<string, Enter> = {
  a: 'iris',
  b: 'zoom',
  c: 'iris',
  d: 'push',
};

const VideoSeg: React.FC<{seg: Seg; index: number}> = ({seg, index}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const dur = fr(seg.sec);
  const kind = ENTER[seg.id];
  const inLen = index === 0 ? fr(1.0) : fr(OVERLAP_S);
  const t = interpolate(f, [0, inLen], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const scale =
    seg.zoom === 'in'
      ? interpolate(f, [0, dur], [1.0, 1.045], clampOpts)
      : interpolate(f, [0, dur], [1.045, 1.0], clampOpts);

  let opacity = 1;
  let wrapTransform = 'none';
  let wrapFilter = 'none';
  let clip = 'none';
  if (kind === 'fade' || kind === 'dissolve') {
    opacity = t;
  } else if (kind === 'zoom') {
    opacity = Math.min(1, t * 1.6);
    wrapTransform = `scale(${1 + 0.2 * (1 - t)})`;
    wrapFilter = `blur(${(1 - t) * 10}px)`;
  } else if (kind === 'push') {
    wrapTransform = `translateX(${(1 - t) * 1920}px)`;
    wrapFilter = `blur(${Math.sin(Math.PI * t) * 9}px)`;
  } else if (kind === 'iris') {
    clip = `circle(${t * 75}% at 50% 50%)`;
  }
  return (
    <AbsoluteFill style={{opacity, transform: wrapTransform, filter: wrapFilter, clipPath: clip}}>
      <OffthreadVideo
        src={staticFile(`eco2/clips/${seg.src}.mp4`)}
        volume={0}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${scale})`,
          filter: GRADE,
        }}
      />
    </AbsoluteFill>
  );
};

/* ───────────────────────── teks ───────────────────────── */
const Pill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 28,
      color: WHITE,
      padding: '8px 24px',
      borderRadius: 999,
      border: '2px solid rgba(255,255,255,0.7)',
      background: 'rgba(255,255,255,0.12)',
      textShadow: shadow,
    }}
  >
    {children}
  </div>
);

// Judul bagian di kiri bawah, dengan scrim gradasi halus di bawahnya. start/end dalam detik.
const LowerThird: React.FC<{
  start: number;
  end: number;
  title: string;
  sub: string;
  extra?: string;
}> = ({start, end, title, sub, extra}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <LowerThirdInner dur={fr(end) - fr(start)} title={title} sub={sub} extra={extra} />
    </Sequence>
  );
};

const LowerThirdInner: React.FC<{dur: number; title: string; sub: string; extra?: string}> = ({
  dur,
  title,
  sub,
  extra,
}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = fadeWindow(f, dur, fr(0.47), fr(0.4));
  const bar = interpolate(f, [0, fr(0.67)], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: op,
          background:
            'linear-gradient(to top, rgba(6,22,11,0.70) 0%, rgba(6,22,11,0.38) 28%, rgba(6,22,11,0) 52%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 120,
          display: 'flex',
          gap: 30,
          alignItems: 'stretch',
          opacity: op,
        }}
      >
        <div
          style={{
            width: 7,
            borderRadius: 4,
            background: GREEN,
            transform: `scaleY(${bar})`,
            transformOrigin: 'bottom',
          }}
        />
        <div style={{transform: `translateY(${rise(f, 0, fr(0.53), 18)}px)`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 68,
              lineHeight: 1.12,
              color: WHITE,
              textShadow: shadow,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 36,
              marginTop: 14,
              color: BEIGE,
              textShadow: shadow,
              transform: `translateY(${rise(f, fr(0.2), fr(0.53), 12)}px)`,
            }}
          >
            {sub}
          </div>
          {extra ? (
            <div style={{marginTop: 26, display: 'flex'}}>
              <Pill>{extra}</Pill>
            </div>
          ) : null}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Panel teks di tengah layar (opening). start/end dalam detik.
const CenterPanel: React.FC<{start: number; end: number; children: React.ReactNode}> = ({
  start,
  end,
  children,
}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <CenterInner dur={fr(end) - fr(start)}>{children}</CenterInner>
    </Sequence>
  );
};

const CenterInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, fr(0.6), fr(0.47)),
        transform: `translateY(${rise(f, 0, fr(0.53), 22)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const Line: React.FC<{
  size: number;
  weight: 600 | 800;
  color: string;
  mt?: number;
  spacing?: number;
  children: React.ReactNode;
}> = ({size, weight, color, mt = 0, spacing = 0, children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: weight,
      fontSize: size,
      color,
      marginTop: mt,
      letterSpacing: spacing,
      lineHeight: 1.15,
      textShadow: shadow,
      maxWidth: 1500,
    }}
  >
    {children}
  </div>
);

const Rule: React.FC<{width?: number}> = ({width = 220}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const w = interpolate(f, [fr(0.27), fr(1.13)], [0, width], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });
  return <div style={{height: 5, width: w, borderRadius: 3, background: GREEN, marginTop: 30}} />;
};

// Peredup lembut agar teks putih terbaca di atas footage terang. start/end dalam detik.
const Dim: React.FC<{start: number; end: number; strength: number}> = ({start, end, strength}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <DimInner dur={fr(end) - fr(start)} strength={strength} />
    </Sequence>
  );
};
const DimInner: React.FC<{dur: number; strength: number}> = ({dur, strength}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        background: `rgba(8,26,14,${strength})`,
        opacity: interpolate(f, [0, fr(0.73), dur - fr(0.73), dur], [0, 1, 1, 0], clampOpts),
      }}
    />
  );
};

// Kilau halus saat judul muncul (sinkron dengan efek kamera flash). at dalam detik.
const SoftFlash: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const a = fr(at);
  const o = interpolate(f, [a, a + fr(0.1), a + fr(0.47)], [0, 0.1, 0], clampOpts);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

/* ───────────────────────── latar kartu, logo, komponen kartu ───────────────────────── */
const CardsBg: React.FC = () => {
  const fr = useFr();
  return (
    <Sequence from={fr(CARDS_START_S)} durationInFrames={fr(ECO2_TOTAL_SECONDS) - fr(CARDS_START_S)}>
      <CardsBgInner />
    </Sequence>
  );
};
const CardsBgInner: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(f, [0, fr(OVERLAP_S)], [0, 1], clampOpts),
        background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)',
      }}
    />
  );
};

// Logo kecil di pojok atas, tampil sepanjang video.
const Logos: React.FC = () => {
  const op = 0.96; // langsung tampil: logo sudah ada sejak Hari 1, jadi tidak berkedip saat digabung
  const base: React.CSSProperties = {
    position: 'absolute',
    top: 44,
    height: 96,
    opacity: op,
    filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.45))',
  };
  return (
    <AbsoluteFill>
      <Img src={staticFile('eco2/logo-taman.svg')} style={{...base, left: 56}} />
      <Img src={staticFile('eco2/logo-sma.png')} style={{...base, right: 56}} />
    </AbsoluteFill>
  );
};

// Muncul bertahap di dalam CenterPanel (waktu lokal sequence).
const Stagger: React.FC<{i: number; step?: number; children: React.ReactNode}> = ({i, step = 0.25, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const d = fr(0.7 + i * step);
  return (
    <div
      style={{
        opacity: interpolate(f, [d, d + fr(0.45)], [0, 1], clampOpts),
        transform: `translateY(${rise(f, d, fr(0.45), 14)}px)`,
      }}
    >
      {children}
    </div>
  );
};

const PLAN: [string, string, number][] = [
  ['07.00–07.20', 'Persiapan dan Pengecekan', 20],
  ['07.20–07.40', 'Pengarahan dan K3', 20],
  ['07.40–09.30', 'Persiapan Area Taman', 110],
  ['09.30–09.45', 'Istirahat', 15],
  ['09.45–11.15', 'Penanaman dan Penataan Taman', 90],
  ['11.15–11.45', 'Penyelesaian dan Dokumentasi', 30],
  ['11.45–12.30', 'ISHOMA', 45],
  ['12.30–13.20', 'Produksi Media Kampanye', 50],
  ['13.20–13.40', 'Pemeriksaan Hasil Kegiatan', 20],
  ['13.40–13.50', 'Laporan Harian', 10],
  ['13.50–14.00', 'Penutupan', 10],
];
const STEPS = [
  'Melaksanakan rencana tamanisasi yang telah dibuat',
  'Menata dan mempersiapkan area taman sekolah',
  'Melakukan penanaman dan penataan tanaman',
  'Mengembangkan kepedulian terhadap lingkungan sekolah',
  'Mendokumentasikan proses dan hasil kegiatan',
];

// Jadwal bergaya kartu + bar proporsi waktu (07.00–14.00), beda dari timeline Hari 1.
const PlanBar: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  const total = PLAN.reduce((a, p) => a + p[2], 0);
  const w = interpolate(f, [fr(0.5), fr(1.8)], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <div style={{width: 1640, marginTop: 34}}>
      <div style={{display: 'flex', gap: 4, height: 18, clipPath: `inset(0 ${(1 - w) * 100}% 0 0 round 9px)`}}>
        {PLAN.map(([t], i) => (
          <div key={t} style={{flex: PLAN[i][2] / total, background: i % 2 ? '#7fb56b' : GREEN, borderRadius: 4}} />
        ))}
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 10, fontFamily: FONT, fontWeight: 600, fontSize: 24, color: BEIGE}}>
        <span>07.00</span>
        <span>14.00 WIB</span>
      </div>
    </div>
  );
};

const PlanCard: React.FC<{i: number; time: string; title: string}> = ({i, time, title}) => (
  <Stagger i={i} step={0.18}>
    <div
      style={{
        height: '100%',
        boxSizing: 'border-box',
        padding: '16px 22px 18px',
        borderRadius: 18,
        border: '2px solid rgba(239,229,207,0.3)',
        background: 'rgba(255,255,255,0.06)',
      }}
    >
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 28, color: GREEN}}>{time}</div>
      <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 31, color: WHITE, marginTop: 4, lineHeight: 1.2}}>{title}</div>
    </div>
  </Stagger>
);

// Tujuan Hari 2 sebagai alur 5 langkah (kartu bernomor dengan panah).
const StepFlow: React.FC = () => (
  <div style={{display: 'flex', alignItems: 'stretch', gap: 0, marginTop: 40}}>
    {STEPS.map((t, i) => (
      <React.Fragment key={t}>
        <Stagger i={i} step={0.35}>
          <div
            style={{
              width: 310,
              height: '100%',
              boxSizing: 'border-box',
              padding: '22px 18px 26px',
              borderRadius: 20,
              border: '2px solid rgba(239,229,207,0.35)',
              background: 'rgba(255,255,255,0.06)',
              textAlign: 'left',
            }}
          >
            <div
              style={{
                width: 54,
                height: 54,
                borderRadius: 27,
                background: GREEN,
                color: DEEP,
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: 30,
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              {i + 1}
            </div>
            <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 24, color: WHITE, marginTop: 18, lineHeight: 1.25}}>{t}</div>
          </div>
        </Stagger>
        {i < STEPS.length - 1 ? (
          <Stagger i={i} step={0.35}>
            <div style={{width: 30, height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT, fontWeight: 800, fontSize: 34, color: GREEN}}>
              ›
            </div>
          </Stagger>
        ) : null}
      </React.Fragment>
    ))}
  </div>
);

// Transisi ke hari berikutnya: angka bergulir di dalam lingkaran, lalu panel memudar.
const NextDay: React.FC<{dur: number; from: number; to: number}> = ({dur, from, to}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const roll = interpolate(f, [fr(1.0), fr(1.8)], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const ring = interpolate(f, [fr(0.2), fr(1.6)], [0.6, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  const out = interpolate(f, [dur - fr(0.6), dur], [1, 0], clampOpts);
  const inn = interpolate(f, [0, fr(0.5)], [0, 1], clampOpts);
  const digit: React.CSSProperties = {
    fontFamily: FONT,
    fontWeight: 800,
    fontSize: 230,
    lineHeight: '250px',
    height: 250,
    color: WHITE,
    textAlign: 'center',
    textShadow: shadow,
  };
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: inn * out}}>
      <Line size={42} weight={600} color={BEIGE}>
        Selanjutnya
      </Line>
      <div style={{display: 'flex', alignItems: 'center', gap: 48, marginTop: 26}}>
        <Line size={130} weight={800} color={WHITE} spacing={2}>
          Hari
        </Line>
        <div
          style={{
            width: 280,
            height: 280,
            borderRadius: 140,
            border: `6px solid ${GREEN}`,
            background: 'rgba(159,207,134,0.12)',
            transform: `scale(${ring})`,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-start',
            overflow: 'hidden',
            paddingTop: 15,
            boxSizing: 'border-box',
          }}
        >
          <div style={{width: 280, transform: `translateY(${-roll * 250}px)`}}>
            <div style={digit}>{from}</div>
            <div style={digit}>{to}</div>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── audio ───────────────────────── */
// Daftar SFX: dipakai untuk memutar suara DAN untuk menurunkan volume backsound (ducking).
type SfxItem = {file: 'flash' | 'pop' | 'whoosh' | 'transition' | 'click'; at: number; vol: number};
const SFX_LEN = {flash: 1.2, pop: 0.45, whoosh: 1.2, transition: 0.4, click: 0.37};

const S0 = START_S;
const T_PERSIAPAN = 4.6; // setelah tulisan "Hari 2"
const T_MEDIA = S0.b + 0.7;
const T_KOLAB = S0.c + 0.7;
const T_EKSEKUSI = S0.d + 0.8;
const SFX: SfxItem[] = [
  {file: 'whoosh', at: 0.3, vol: 0.35}, // iris membuka dari layar hijau akhir Hari 1
  {file: 'pop', at: 1.2, vol: 0.45}, // tulisan "Hari 2"
  {file: 'click', at: T_PERSIAPAN + 0.1, vol: 0.4},
  {file: 'transition', at: S0.b, vol: 0.35},
  {file: 'click', at: T_MEDIA + 0.1, vol: 0.4},
  {file: 'whoosh', at: S0.c - 0.4, vol: 0.3},
  {file: 'click', at: T_KOLAB + 0.1, vol: 0.4},
  {file: 'whoosh', at: S0.d - 0.4, vol: 0.3},
  {file: 'click', at: T_EKSEKUSI + 0.1, vol: 0.4},
  {file: 'whoosh', at: CARDS_START_S - 0.3, vol: 0.3},
  {file: 'click', at: CARD.jadwal.start + 0.1, vol: 0.4},
  {file: 'click', at: CARD.jelas.start + 0.1, vol: 0.4},
  {file: 'whoosh', at: CARD.next.start + 0.35, vol: 0.35},
  {file: 'transition', at: CARD.next.start + 1.35, vol: 0.4},
];

const MUSIC_BASE = 0.3; // volume normal backsound
const MUSIC_DUCK = 0.38; // dikali ini saat ada SFX (turun), lalu naik lagi
const duckAt = (t: number) => {
  let g = 1;
  for (const s of SFX) {
    const a = s.at - 0.12;
    const h = s.at + SFX_LEN[s.file];
    let v = 1;
    if (t >= a && t < a + 0.12) v = 1 - (1 - MUSIC_DUCK) * ((t - a) / 0.12);
    else if (t >= a + 0.12 && t < h) v = MUSIC_DUCK;
    else if (t >= h && t < h + 0.8) {
      const k = (t - h) / 0.8;
      v = MUSIC_DUCK + (1 - MUSIC_DUCK) * (k * k * (3 - 2 * k));
    }
    if (v < g) g = v;
  }
  return g;
};

const Sfx: React.FC<{file: string; at: number; vol?: number}> = ({file, at, vol = 0.5}) => {
  const fr = useFr();
  return (
    <Sequence from={Math.max(0, fr(at))}>
      <Audio src={staticFile(`eco2/sfx/${file}.mp3`)} volume={vol} />
    </Sequence>
  );
};

// Cincin hijau yang ikut melebar saat iris membuka di awal video.
const IrisRing: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  const t = interpolate(f, [0, fr(1.0)], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const d = t * 0.75 * 1556 * 2; // diameter lingkaran iris (px)
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: 1 - t}}>
      <div style={{width: d, height: d, borderRadius: d / 2, border: `6px solid ${GREEN}`, boxSizing: 'border-box'}} />
    </AbsoluteFill>
  );
};

/* ───────────────────────── komposisi ───────────────────────── */
export const EcoActionDay2: React.FC = () => {
  const {fps} = useVideoConfig();
  const S = START_S;
  const TITLE_LEN = 4.0;

  // Backsound melanjutkan akhir Hari 1 (tanpa fade-in), turun saat ada SFX.
  const musicVolume = (f: number) => MUSIC_BASE * duckAt(f / fps);

  return (
    <AbsoluteFill
      style={{background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)'}}
    >
      {/* ── video (urut, transisi bervariasi) ── */}
      {SEGS.map((seg, i) => (
        <Sequence
          key={seg.id}
          from={Math.round(START_S[seg.id] * fps)}
          durationInFrames={Math.round(seg.sec * fps)}
        >
          <VideoSeg seg={seg} index={i} />
        </Sequence>
      ))}

      <Sequence from={0} durationInFrames={Math.round(1.0 * fps)}>
        <IrisRing />
      </Sequence>

      {/* vignette tipis di seluruh video */}
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(8,24,12,0.34) 100%)',
        }}
      />

      {/* ── Tulisan "Hari 2" ── */}
      <Dim start={0.6} end={4.3} strength={0.3} />
      <CenterPanel start={1.0} end={4.2}>
        <Line size={168} weight={800} color={WHITE} spacing={2}>
          Hari 2
        </Line>
        <Rule />
        <Line size={54} weight={600} color={BEIGE} mt={30}>
          Do &amp; Create
        </Line>
        <Line size={36} weight={600} color={BEIGE} mt={12}>
          Pelaksanaan rencana tamanisasi
        </Line>
      </CenterPanel>

      {/* ── footage + judul bagian (sesuai jadwal resmi) ── */}
      <LowerThird
        start={T_PERSIAPAN}
        end={T_PERSIAPAN + TITLE_LEN}
        title="Persiapan dan Pengecekan"
        sub="Alat, bahan, bibit tanaman, dan area kegiatan"
        extra="07.00–07.20"
      />
      <LowerThird
        start={T_MEDIA}
        end={T_MEDIA + TITLE_LEN}
        title="Persiapan Area Taman"
        sub="Mempersiapkan media tanam"
        extra="07.40–09.30"
      />
      <LowerThird
        start={T_KOLAB}
        end={T_KOLAB + TITLE_LEN}
        title="Pekerjaan Awal Tamanisasi"
        sub="Menyiapkan dan menata area sesuai desain"
        extra="07.40–09.30"
      />
      <LowerThird
        start={T_EKSEKUSI}
        end={T_EKSEKUSI + TITLE_LEN}
        title="Penanaman dan Penataan Taman"
        sub="Menyiapkan tanah dan menanam bibit"
        extra="09.45–11.15"
      />

      {/* ── KARTU INFO ── */}
      <CardsBg />

      {/* Jadwal Hari 2 */}
      <CenterPanel start={CARD.jadwal.start} end={CARD.jadwal.end}>
        <Line size={62} weight={800} color={WHITE}>
          Jadwal Kegiatan Hari Kedua
        </Line>
        <Rule />
        <PlanBar />
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 400px)', gap: 20, marginTop: 28, textAlign: 'left'}}>
          {PLAN.map(([t, n], i) => (
            <PlanCard key={t} i={i} time={t} title={n} />
          ))}
        </div>
      </CenterPanel>

      {/* Apa yang dikerjakan di Hari 2 */}
      <CenterPanel start={CARD.jelas.start} end={CARD.jelas.end}>
        <Line size={60} weight={800} color={WHITE}>
          Apa yang Dikerjakan di Hari Kedua
        </Line>
        <Rule />
        <Line size={38} weight={600} color={BEIGE} mt={24}>
          Tahap Do &amp; Create: pelaksanaan rencana yang disusun di hari pertama
        </Line>
        <StepFlow />
        <Line size={30} weight={600} color={BEIGE} mt={34}>
          Seluruh kelompok bekerja sesuai tugas masing-masing untuk mewujudkan lingkungan sekolah yang lebih asri, hijau, dan berkelanjutan.
        </Line>
      </CenterPanel>

      {/* Transisi ke Hari 3 */}
      <Sequence from={Math.round(CARD.next.start * fps)} durationInFrames={Math.round((CARD.next.end - CARD.next.start) * fps)}>
        <NextDay dur={Math.round((CARD.next.end - CARD.next.start) * fps)} from={2} to={3} />
      </Sequence>

      {/* logo kecil di pojok atas, sepanjang video */}
      <Logos />

      {/* ── AUDIO ── */}
      {WITH_MUSIC ? <Audio src={staticFile('eco2/music.mp3')} volume={musicVolume} /> : null}
      {SFX.map((x, i) => (
        <Sfx key={i} file={x.file} at={x.at} vol={x.vol} />
      ))}
    </AbsoluteFill>
  );
};
