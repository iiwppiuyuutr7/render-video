IronMan - intro sinematik 2D (16:9, 1920x1080, 60fps, 30 detik)
File: IronMan.tsx, Root.tsx, public/audio.mp3
Taruh IronMan.tsx & Root.tsx di src/ proyek Remotion (audio di public/).
Render: npx remotion render IronMan out/ironman.mp4
Preview: npx remotion studio

Isi 100% SVG + kode (tanpa gambar/aset luar), audio sudah disintesis & disinkronkan dengan scene.

TIMELINE (detik)
  0.0 -  6.3  hening, titik biru berdetak, arc reactor menyala, kamera zoom ke inti
  5.7 -  9.6  HUD Jarvis online (cincin, scan line, teks diketik)
  8.6 - 12.6  scan-wipe -> reveal helm, mata menyala, lens flare + percikan
 12.0 - 17.5  DI DALAM HELM: faceplate menutup (klik), HUD POV, countdown 3-2-1, thruster nyala
 16.8 - 24.8  terbang supersonik, tembus Mach di 20.5 (shockwave + vapor cone), burst radial
 25.1 - 30.0  garis cahaya -> judul IRON MAN

Transisi: match-cut (titik -> reactor -> HUD -> helm -> mata jadi flare -> masuk helm -> countdown
jadi thruster -> launch -> shockwave jadi flash -> judul).

Ubah teks judul: edit TITLE dan SUBTITLE di bagian atas IronMan.tsx.
Efek sinematik: letterbox 2.39:1, color grade teal-orange, vignette, film grain, chromatic aberration pada judul, camera shake + punch di tiap hentakan.

Catatan:
- Font: pakai Orbitron kalau terpasang di sistem, kalau tidak otomatis jatuh ke Arial/sans-serif.
  Mau tampilan pasti: npm i @remotion/google-fonts lalu load Orbitron.
- Audio (audio.mp3) sintetis buatan sendiri (dengung reaktor, beep HUD, klik faceplate, whoosh,
  sonic boom, braam judul), jadi aman dari hak cipta. Mau ganti dengan SFX/musik sendiri: timpa
  public/audio.mp3 dengan file 30 detik (titik hentakan: 9.6, 12.25, 16.9, 20.5, 24.0, 26.0 detik).
- Render 1800 frame dengan blur/glow SVG lumayan berat. Di laptop wajar makan waktu belasan sampai
  puluhan menit. Bisa dipercepat: npx remotion render IronMan out/ironman.mp4 --concurrency=4
- Kalau dirender di server kecil, perhatikan RAM/disk (hasil mp4 + cache frame).
