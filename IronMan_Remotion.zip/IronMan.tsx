import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';

/* =====================================================================
   IRON MAN  –  intro sinematik 2D (SVG murni)
   1920x1080 • 60 fps • 30 detik • audio: public/audio.mp3

   TIMELINE (detik)
    0.0 -  6.3  hening → titik biru → arc reactor menyala
    5.7 -  9.6  HUD Jarvis online (scan line)
    8.6 - 12.6  scan-wipe → reveal helm, mata menyala
   12.0 - 17.5  DI DALAM HELM: faceplate menutup, HUD POV, countdown 3-2-1
   16.8 - 24.8  terbang supersonik, tembus Mach (20.5), burst radial (23-24)
   25.1 - 30.0  garis cahaya → judul
   ===================================================================== */
export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_SECONDS = 30;

// ---------- ubah teks di sini ----------
const TITLE = 'IRON MAN';
const SUBTITLE = 'THE  ARMOR  AWAKENS';

const FONT = "'Orbitron','Eurostile','Bank Gothic','Arial Narrow',Arial,sans-serif";
const MONO = "'Share Tech Mono','Consolas','Courier New',monospace";

// ---------- util ----------
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const sm = (p: number) => {
  const x = clamp(p);
  return x * x * (3 - 2 * x);
};
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const eo = (p: number) => 1 - Math.pow(1 - clamp(p), 3);
const ei = (p: number) => Math.pow(clamp(p), 3);
const eie = (p: number) => {
  const x = clamp(p);
  return x === 0 ? 0 : Math.pow(2, 10 * x - 10);
};
const rnd = (seed: number) => {
  let a = seed * 9301 + 49297;
  a = Math.imul(a ^ (a >>> 15), 2246822507);
  a = Math.imul(a ^ (a >>> 13), 3266489909);
  return ((a ^ (a >>> 16)) >>> 0) / 4294967296;
};
const mod = (a: number, n: number) => ((a % n) + n) % n;
const gauss = (t: number, t0: number, w: number) => Math.exp(-Math.pow((t - t0) / w, 2));
const vis = (t: number, a: number, b: number, fi = 0.3, fo = 0.3) =>
  Math.min(sm(prog(t, a, a + Math.max(fi, 0.001))), 1 - sm(prog(t, b - Math.max(fo, 0.001), b)));
const typed = (s: string, t: number, t0: number, cps = 38) => s.slice(0, Math.max(0, Math.floor((t - t0) * cps)));

// ---------- palet ----------
const ICE = '#8ff0ff';
const CYAN = '#25c8ff';
const WHITE = '#f2fcff';
const GOLD = '#f2b53a';
const RED = '#c4161c';
const RED_D = '#6e0b12';

const pt = (cx: number, cy: number, r: number, a: number): [number, number] => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
const wedge = (cx: number, cy: number, r1: number, r2: number, a0: number, a1: number) => {
  const [x1, y1] = pt(cx, cy, r2, a0);
  const [x2, y2] = pt(cx, cy, r2, a1);
  const [x3, y3] = pt(cx, cy, r1, a1);
  const [x4, y4] = pt(cx, cy, r1, a0);
  return `M${x1} ${y1}A${r2} ${r2} 0 0 1 ${x2} ${y2}L${x3} ${y3}A${r1} ${r1} 0 0 0 ${x4} ${y4}Z`;
};

// =====================================================================
// DEFS (gradien & filter, dipakai semua scene)
// =====================================================================
const FR = {filterUnits: 'userSpaceOnUse' as const, x: -500, y: -500, width: 2920, height: 2080};
const Defs: React.FC = () => (
  <defs>
    <filter id="glow" {...FR}><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
    <filter id="glowL" {...FR}><feGaussianBlur stdDeviation="18" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
    <filter id="blurS" {...FR}><feGaussianBlur stdDeviation="3" /></filter>
    <filter id="blurM" {...FR}><feGaussianBlur stdDeviation="14" /></filter>
    <filter id="blurXL" {...FR}><feGaussianBlur stdDeviation="40" /></filter>
    <radialGradient id="coreG"><stop offset="0" stopColor="#fff" stopOpacity="0.95" /><stop offset="0.25" stopColor={ICE} stopOpacity="0.7" /><stop offset="0.6" stopColor={CYAN} stopOpacity="0.22" /><stop offset="1" stopColor={CYAN} stopOpacity="0" /></radialGradient>
    <linearGradient id="streakG" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stopColor="#fff" stopOpacity="0" /><stop offset="0.5" stopColor="#fff" stopOpacity="1" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
    <linearGradient id="scanG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={ICE} stopOpacity="0" /><stop offset="1" stopColor={ICE} stopOpacity="0.34" /></linearGradient>
    <linearGradient id="scanH" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stopColor={ICE} stopOpacity="0" /><stop offset="1" stopColor={ICE} stopOpacity="0.4" /></linearGradient>
    <linearGradient id="redG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#e8302f" /><stop offset="0.5" stopColor="#a50f19" /><stop offset="1" stopColor="#4c060c" /></linearGradient>
    <linearGradient id="goldG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#fff0b0" /><stop offset="0.45" stopColor={GOLD} /><stop offset="1" stopColor="#8d5d12" /></linearGradient>
    <linearGradient id="titleG" gradientUnits="userSpaceOnUse" x1="0" x2="0" y1="400" y2="640"><stop offset="0" stopColor="#fff8dc" /><stop offset="0.45" stopColor="#f6c04a" /><stop offset="0.52" stopColor="#b9791a" /><stop offset="1" stopColor="#ffe28c" /></linearGradient>
    <linearGradient id="flameG" x1="1" x2="0" y1="0" y2="0"><stop offset="0" stopColor="#fff" stopOpacity="1" /><stop offset="0.3" stopColor="#9fe8ff" stopOpacity="0.9" /><stop offset="1" stopColor="#1aa7ff" stopOpacity="0" /></linearGradient>
    <linearGradient id="trailG" x1="1" x2="0" y1="0" y2="0"><stop offset="0" stopColor="#fff" stopOpacity="0.55" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
    <linearGradient id="skyG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#050f24" /><stop offset="0.4" stopColor="#12477a" /><stop offset="0.72" stopColor="#f0a35a" /><stop offset="1" stopColor="#ffe0a8" /></linearGradient>
    <radialGradient id="sunG"><stop offset="0" stopColor="#fff6dc" stopOpacity="1" /><stop offset="0.2" stopColor="#ffd08a" stopOpacity="0.8" /><stop offset="1" stopColor="#ff9a4a" stopOpacity="0" /></radialGradient>
    <linearGradient id="insideBg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#060d18" /><stop offset="0.6" stopColor="#15263b" /><stop offset="1" stopColor="#2b405a" /></linearGradient>
    <linearGradient id="heatG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#ff7a1a" stopOpacity="0" /><stop offset="1" stopColor="#ff9a3a" stopOpacity="0.85" /></linearGradient>
    <linearGradient id="gradeG" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#0aa0c8" stopOpacity="0.55" /><stop offset="1" stopColor="#ff7a20" stopOpacity="0.5" /></linearGradient>
    <radialGradient id="vigG" cx="0.5" cy="0.5" r="0.75"><stop offset="0.55" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity="0.72" /></radialGradient>
  </defs>
);

// =====================================================================
// SCENE 1-2 : titik biru → arc reactor
// =====================================================================
const Reactor: React.FC<{t: number}> = ({t}) => {
  const cx = 960;
  const cy = 540;
  const beat = (t0: number) => gauss(t, t0, 0.1);
  const pulse = beat(0.9) + 0.7 * beat(1.14) + beat(1.9) + 0.7 * beat(2.14);
  const appear = sm(prog(t, 0.7, 1.1));
  const grow = eo(prog(t, 2.0, 3.4));
  const coreR = lerp((7 + 5 * pulse) * appear, 74, grow);
  const power = sm(prog(t, 2.0, 5.0));
  const flick = t > 2.6 && t < 4.8 ? (rnd(Math.floor(t * 24)) > 0.82 ? 0.55 : 1) : 1;
  const I = (0.25 + 0.75 * power) * flick;
  const S = 1 + 0.14 * prog(t, 2, 5.3) + 13 * eie(prog(t, 5.3, 6.2));
  const rotA = t * 0.2;
  const rotB = -t * 0.32;
  const ringP = eo(prog(t, 2.1, 3.4));
  const segP = eo(prog(t, 2.5, 3.8));
  const seg2P = eo(prog(t, 2.9, 4.2));
  const C = 2 * Math.PI * 310;
  const streak = eo(prog(t, 2.3, 3.5)) * I;
  const rr = lerp(0.6, 1, segP);
  const rr2 = lerp(0.6, 1, seg2P);
  return (
    <g transform={`translate(${cx} ${cy}) scale(${S}) translate(${-cx} ${-cy})`}>
      {Array.from({length: 36}).map((_, i) => {
        const x = rnd(i * 3 + 1) * 1920;
        const y = mod(rnd(i * 3 + 2) * 1080 - t * (8 + rnd(i * 3 + 3) * 16), 1080);
        return <circle key={i} cx={x} cy={y} r={1 + rnd(i * 3 + 4) * 1.6} fill={ICE} opacity={(0.12 + 0.3 * rnd(i * 3 + 5)) * sm(prog(t, 0.6, 1.4))} />;
      })}
      <circle cx={cx} cy={cy} r={560} fill="url(#coreG)" opacity={0.5 * I * grow} />
      <rect x={cx - 800 * streak} y={cy - 12} width={1600 * streak} height={24} fill="url(#streakG)" opacity={0.35} filter="url(#blurM)" />
      <rect x={cx - 800 * streak} y={cy - 2} width={1600 * streak} height={4} fill="url(#streakG)" opacity={0.9} filter="url(#blurS)" />
      <g filter="url(#glow)">
        <circle cx={cx} cy={cy} r={310} fill="none" stroke={ICE} strokeWidth={3} strokeDasharray={C} strokeDashoffset={C * (1 - ringP)} transform={`rotate(-90 ${cx} ${cy})`} opacity={I} />
        <circle cx={cx} cy={cy} r={330} fill="none" stroke={ICE} strokeWidth={1} opacity={0.35 * ringP * I} />
        {Array.from({length: 10}).map((_, i) => {
          const a0 = rotA + (i * Math.PI) / 5 + 0.06;
          return <path key={'a' + i} d={wedge(cx, cy, 190 * rr, 250 * rr, a0, a0 + Math.PI / 5 - 0.12)} fill={`rgba(125,230,255,${0.16 * I})`} stroke={ICE} strokeWidth={2.5} opacity={segP * I} />;
        })}
        {Array.from({length: 10}).map((_, i) => {
          const a0 = rotB + (i * Math.PI) / 5 + 0.05;
          return <path key={'b' + i} d={wedge(cx, cy, 105 * rr2, 158 * rr2, a0, a0 + Math.PI / 5 - 0.1)} fill={`rgba(190,248,255,${0.28 * I})`} stroke={WHITE} strokeWidth={2} opacity={seg2P * I} />;
        })}
        <circle cx={cx} cy={cy} r={coreR + 16} fill="none" stroke={WHITE} strokeWidth={2} opacity={0.8 * grow * I} />
      </g>
      <circle cx={cx} cy={cy} r={coreR * 2.4} fill="url(#coreG)" opacity={0.85 * appear} />
      <circle cx={cx} cy={cy} r={coreR} fill="#eaffff" filter="url(#glowL)" opacity={appear} />
    </g>
  );
};

// =====================================================================
// SCENE 3 : HUD Jarvis
// =====================================================================
const HudText: React.FC<{x: number; y: number; s: string; size?: number; fill?: string; op?: number}> = ({x, y, s, size = 30, fill = ICE, op = 1}) => (
  <text x={x} y={y} fontFamily={MONO} fontSize={size} letterSpacing={3} fill={fill} opacity={op} style={{whiteSpace: 'pre'}}>{s}</text>
);

const Hud: React.FC<{t: number}> = ({t}) => {
  const cx = 960;
  const cy = 540;
  const intro = eo(prog(t, 5.7, 6.8));
  const S = lerp(2.2, 1, intro);
  const power = Math.round(100 * sm(prog(t, 6.5, 8.2)));
  const scan = (a: number, b: number) => {
    const s = prog(t, a, b);
    if (s <= 0 || s >= 1) return null;
    const y = lerp(100, 980, s);
    return (
      <g key={a}>
        <rect x={0} y={y - 170} width={1920} height={170} fill="url(#scanG)" />
        <rect x={0} y={y - 1.5} width={1920} height={3} fill={WHITE} filter="url(#glow)" />
      </g>
    );
  };
  const left = [
    [6.3, 'SYSTEM ONLINE'],
    [6.6, 'A.I. LINK  ESTABLISHED'],
    [6.9, 'ARMOR INTEGRITY  100%'],
    [7.3, 'REPULSORS  ARMED'],
    [7.7, 'FLIGHT SYSTEMS  NOMINAL'],
  ] as [number, string][];
  const right = [
    [6.5, `POWER   ${power}%`],
    [6.8, 'OUTPUT  3.2 GJ/S'],
    [7.2, 'CORE    36.5 C'],
    [7.6, 'THRUST  0 N'],
  ] as [number, string][];
  return (
    <g>
      {Array.from({length: 17}).map((_, i) => (
        <rect key={i} x={0} y={140 + i * 52} width={1920} height={1} fill={ICE} opacity={0.05} />
      ))}
      <g transform={`translate(${cx} ${cy}) scale(${S}) translate(${-cx} ${-cy})`} opacity={sm(prog(t, 5.9, 6.4))} filter="url(#glow)">
        <circle cx={cx} cy={cy} r={392} fill="none" stroke={ICE} strokeWidth={2} strokeDasharray="70 18" transform={`rotate(${t * 6} ${cx} ${cy})`} opacity={0.8} />
        {Array.from({length: 120}).map((_, i) => {
          const a = (i * 2 * Math.PI) / 120 - t * 0.08;
          const big = i % 5 === 0;
          const [x1, y1] = pt(cx, cy, 344, a);
          const [x2, y2] = pt(cx, cy, big ? 374 : 358, a);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={ICE} strokeWidth={big ? 2.5 : 1.5} opacity={0.8} />;
        })}
        <g transform={`rotate(${t * 35} ${cx} ${cy})`}>
          {[0, 1, 2].map((i) => (
            <path key={i} d={wedge(cx, cy, 284, 296, (i * 2 * Math.PI) / 3, (i * 2 * Math.PI) / 3 + 1.2)} fill={ICE} opacity={0.85} />
          ))}
        </g>
        <circle cx={cx} cy={cy} r={210} fill="none" stroke={ICE} strokeWidth={1.5} opacity={0.7} />
        <circle cx={cx} cy={cy} r={180} fill="none" stroke={ICE} strokeWidth={2} strokeDasharray="4 10" transform={`rotate(${-t * 20} ${cx} ${cy})`} opacity={0.7} />
        <circle cx={cx} cy={cy} r={26} fill="none" stroke={WHITE} strokeWidth={2} />
        {[[-1, 0], [1, 0], [0, -1], [0, 1]].map(([dx, dy], i) => (
          <line key={i} x1={cx + dx * 44} y1={cy + dy * 44} x2={cx + dx * 130} y2={cy + dy * 130} stroke={ICE} strokeWidth={2} opacity={0.8} />
        ))}
        <circle cx={cx} cy={cy} r={5} fill={WHITE} />
      </g>
      {scan(6.4, 7.5)}
      {scan(7.6, 8.7)}
      <g filter="url(#glow)">
        {left.map(([t0, s], i) => (
          <g key={i}>
            <rect x={120} y={372 + i * 52} width={10} height={10} fill={ICE} opacity={t > t0 ? 1 : 0} />
            <HudText x={150} y={384 + i * 52} s={typed(s, t, t0)} />
          </g>
        ))}
        {right.map(([t0, s], i) => (
          <g key={i}>
            <rect x={1530} y={372 + i * 52} width={10} height={10} fill={ICE} opacity={t > t0 ? 1 : 0} />
            <HudText x={1560} y={384 + i * 52} s={typed(s, t, t0)} />
          </g>
        ))}
      </g>
    </g>
  );
};

// =====================================================================
// SCENE 4 : helm
// =====================================================================
const HELM_R = 'M0 -305C115 -305 205 -230 219 -110C228 -30 214 52 188 118C162 182 112 246 56 288C40 299 20 305 0 305';
const HELM_G = 'M0 -198C78 -198 142 -150 154 -84C163 -32 152 36 130 92C108 148 72 206 34 240C22 251 12 258 0 258';
const EYE = 'M20 -56L124 -92L118 -64L28 -34Z';

const Helmet: React.FC<{eye: number}> = ({eye}) => {
  const half = (mir: boolean) => (
    <g key={mir ? 'l' : 'r'} transform={mir ? 'scale(-1 1)' : undefined}>
      <path d={HELM_R + 'Z'} fill="url(#redG)" />
      <path d="M40 -292C120 -282 190 -232 207 -140" fill="none" stroke="#fff" strokeOpacity={0.28} strokeWidth={7} strokeLinecap="round" filter="url(#blurS)" />
      <path d={HELM_R} fill="none" stroke="#1a0508" strokeWidth={5} />
      <circle cx={198} cy={-6} r={11} fill="#4c060c" stroke="#1a0508" strokeWidth={3} />
      <path d={HELM_G + 'Z'} fill="url(#goldG)" />
      <path d={HELM_G} fill="none" stroke="#5b3a08" strokeWidth={4} />
      <path d="M150 -26C142 24 124 70 98 118" fill="none" stroke="#5b3a08" strokeOpacity={0.55} strokeWidth={4} strokeLinecap="round" />
      <path d="M0 -36L14 30L0 46Z" fill="#7a5412" fillOpacity={0.5} />
      <path d="M10 112L58 106L56 114L10 120Z" fill="#4a3008" />
      <path d="M10 132L48 128L46 135L10 139Z" fill="#4a3008" />
      <path d="M8 152L34 149L32 155L8 158Z" fill="#4a3008" />
      <path d={EYE} fill="#101820" stroke="#3a2200" strokeWidth={6} strokeLinejoin="round" />
      <path d={EYE} fill="#eaffff" opacity={eye} filter="url(#glow)" />
    </g>
  );
  return (
    <g>
      <path d="M-110 285L110 285L160 420L-160 420Z" fill="#150a0d" />
      {half(false)}
      {half(true)}
      <path d="M0 -198L0 -92" stroke="#5b3a08" strokeOpacity={0.6} strokeWidth={4} />
    </g>
  );
};

const HelmScene: React.FC<{t: number}> = ({t}) => {
  const wipe = sm(prog(t, 8.6, 9.6));
  const w = 1920 * wipe;
  const zoom = lerp(1.22, 1.4, prog(t, 8.6, 12.4));
  const rise = (1 - eo(prog(t, 8.8, 10))) * 40;
  const eye = sm(prog(t, 10.2, 10.5)) * (t > 10.5 ? 0.94 + 0.06 * Math.sin(t * 40) : 1);
  const hy = 548 + rise;
  const ex = 72 * zoom;
  const ey = hy - 62 * zoom;
  const fl = sm(prog(t, 10.3, 10.5)) * (1 - 0.35 * sm(prog(t, 10.6, 12)));
  const sp = prog(t, 10.4, 11.3);
  return (
    <g>
      <defs>
        <clipPath id="helmClip"><rect x={0} y={0} width={w} height={1080} /></clipPath>
      </defs>
      <g clipPath="url(#helmClip)">
        <rect width={1920} height={1080} fill="#05080e" />
        <ellipse cx={960} cy={520} rx={640} ry={540} fill="url(#coreG)" opacity={0.32} />
        <g transform={`translate(960 ${hy}) scale(${zoom})`}>
          <Helmet eye={eye} />
        </g>
        <rect x={960 - 800 * fl} y={ey - 2} width={1600 * fl} height={4} fill="url(#streakG)" filter="url(#glow)" />
        <rect x={960 - 800 * fl} y={ey - 14} width={1600 * fl} height={28} fill="url(#streakG)" opacity={0.3} filter="url(#blurM)" />
        {[-1, 1].map((s) => (
          <circle key={s} cx={960 + s * ex} cy={ey} r={110 * zoom * fl} fill="url(#coreG)" opacity={0.9} />
        ))}
        {sp > 0 && sp < 1 && Array.from({length: 28}).map((_, i) => {
          const a = rnd(i * 2 + 7) * Math.PI * 2;
          const d = 60 + rnd(i * 2 + 8) * 560;
          const side = i % 2 ? 1 : -1;
          return <circle key={i} cx={960 + side * ex + Math.cos(a) * d * eo(sp)} cy={ey + Math.sin(a) * d * eo(sp)} r={2.5} fill={WHITE} opacity={1 - sp} />;
        })}
      </g>
      {wipe > 0 && wipe < 1 && (
        <g>
          <rect x={w - 220} y={0} width={220} height={1080} fill="url(#scanH)" />
          <rect x={w - 3} y={0} width={6} height={1080} fill={WHITE} filter="url(#glow)" />
        </g>
      )}
    </g>
  );
};

// =====================================================================
// SCENE 5 : di dalam helm (POV)
// =====================================================================
const winPath = (hh: number) =>
  `M90 ${540 - hh + 44}Q960 ${540 - hh - 44} 1830 ${540 - hh + 44}L1890 540L1830 ${540 + hh - 44}Q960 ${540 + hh + 44} 90 ${540 + hh - 44}L30 540Z`;

const Inside: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const closeP = eo(prog(t, 12.2, 12.55));
  const reb = t > 12.55 ? 14 * Math.exp(-(t - 12.55) * 9) * Math.sin((t - 12.55) * 38) : 0;
  const hh = lerp(720, 255, closeP) + reb;
  const hud = sm(prog(t, 12.7, 13.2));
  const rumble = 3 * sm(prog(t, 15.8, 16.9)) + 10 * sm(prog(t, 16.6, 17.0));
  const rx = Math.sin(t * 91) * rumble;
  const ry = Math.cos(t * 77) * rumble;
  const spd = Math.round(1200 * ei(prog(t, 16.65, 17.3)));
  const alt = 12 + Math.round(2 * Math.sin(t * 2)) + Math.round(900 * ei(prog(t, 16.65, 17.3)));
  const cd: [number, number, string][] = [[14.0, 14.9, '3'], [14.9, 15.8, '2'], [15.8, 16.7, '1'], [16.7, 17.2, 'GO']];
  const heat = sm(prog(t, 16.3, 16.9)) * (0.7 + 0.3 * rnd(frame));
  const log = [
    [13.1, 'ALL SYSTEMS NOMINAL'],
    [13.5, 'THRUSTERS ARMED'],
    [13.9, 'FLIGHT PATH CLEAR'],
  ] as [number, string][];
  const tapeOff = mod(spd * 0.06, 40);
  const tapeOffA = mod(alt * 0.06, 40);
  return (
    <g transform={`translate(${rx} ${ry})`}>
      <defs>
        <clipPath id="winClip"><path d={winPath(hh)} /></clipPath>
      </defs>
      <g clipPath="url(#winClip)">
        <rect x={-50} y={-50} width={2020} height={1180} fill="url(#insideBg)" />
        <g filter="url(#blurM)">
          {[0, 1, 2].map((i) => (
            <rect key={i} x={380 + i * 40} y={300 + i * 46} width={1160 - i * 80} height={10} fill={ICE} opacity={0.22} />
          ))}
        </g>
        <g filter="url(#blurS)">
          {Array.from({length: 28}).map((_, i) => {
            const x = rnd(i * 5 + 1) * 2100 - 100 + 14 * Math.sin(t * 0.3 + i);
            const y = 240 + rnd(i * 5 + 2) * 620 + 8 * Math.cos(t * 0.4 + i);
            const c = i % 3 === 0 ? '#ffb25a' : i % 3 === 1 ? '#5ad2ff' : '#ffffff';
            return <circle key={i} cx={x} cy={y} r={18 + rnd(i * 5 + 3) * 52} fill={c} opacity={0.08 + rnd(i * 5 + 4) * 0.14} />;
          })}
        </g>
        <rect x={-50} y={500} width={2020} height={600} fill="url(#heatG)" opacity={heat} />
        <path d={winPath(hh)} fill="rgba(40,120,170,0.08)" />
      </g>
      <path d={`M0 0H1920V1080H0Z ${winPath(hh)}`} fill="#06080d" fillRule="evenodd" />
      {[[90, 300, 0, 120], [1830, 300, 1920, 120], [90, 780, 0, 960], [1830, 780, 1920, 960], [30, 540, 0, 540], [1890, 540, 1920, 540]].map(([x1, y1, x2, y2], i) => (
        <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#121926" strokeWidth={4} />
      ))}
      <path d={winPath(hh)} fill="none" stroke="#2a3444" strokeWidth={12} />
      <path d={winPath(hh)} fill="none" stroke={ICE} strokeWidth={2} opacity={0.5 * hud} filter="url(#glow)" />

      <g opacity={hud} filter="url(#glow)">
        <g transform={`rotate(${Math.sin(t * 0.8) * 1.5} 960 540)`}>
          {[-3, -2, -1, 1, 2, 3].map((k) => (
            <g key={k}>
              <line x1={780} y1={540 + k * 62} x2={880} y2={540 + k * 62} stroke={ICE} strokeWidth={2} opacity={0.6} />
              <line x1={1040} y1={540 + k * 62} x2={1140} y2={540 + k * 62} stroke={ICE} strokeWidth={2} opacity={0.6} />
              <text x={750} y={546 + k * 62} fontFamily={MONO} fontSize={20} fill={ICE} textAnchor="end" opacity={0.7}>{Math.abs(k) * 10}</text>
            </g>
          ))}
        </g>
        <circle cx={960} cy={540} r={118} fill="none" stroke={ICE} strokeWidth={2} strokeDasharray="30 12" transform={`rotate(${t * 40} 960 540)`} opacity={0.8} />
        <circle cx={960} cy={540} r={5} fill={WHITE} />
        {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map(([sx, sy], i) => {
          const d = 150 + 6 * Math.sin(t * 3 + i);
          return <path key={i} d={`M${960 + sx * d} ${540 + sy * (d - 38)}L${960 + sx * d} ${540 + sy * d}L${960 + sx * (d - 38)} ${540 + sy * d}`} fill="none" stroke={WHITE} strokeWidth={3} />;
        })}
        {Array.from({length: 13}).map((_, i) => {
          const j = i - 6;
          const y = 540 + j * 40 + tapeOff;
          return <line key={'s' + i} x1={330} y1={y} x2={j % 2 ? 350 : 372} y2={y} stroke={ICE} strokeWidth={2} opacity={0.7} />;
        })}
        {Array.from({length: 13}).map((_, i) => {
          const j = i - 6;
          const y = 540 + j * 40 + tapeOffA;
          return <line key={'a' + i} x1={1590} y1={y} x2={j % 2 ? 1570 : 1548} y2={y} stroke={ICE} strokeWidth={2} opacity={0.7} />;
        })}
        <rect x={250} y={518} width={116} height={44} fill="none" stroke={WHITE} strokeWidth={2} />
        <text x={308} y={550} fontFamily={MONO} fontSize={28} fill={WHITE} textAnchor="middle">{spd}</text>
        <text x={308} y={470} fontFamily={MONO} fontSize={20} fill={ICE} textAnchor="middle">SPD KM/H</text>
        <rect x={1554} y={518} width={116} height={44} fill="none" stroke={WHITE} strokeWidth={2} />
        <text x={1612} y={550} fontFamily={MONO} fontSize={28} fill={WHITE} textAnchor="middle">{alt}</text>
        <text x={1612} y={470} fontFamily={MONO} fontSize={20} fill={ICE} textAnchor="middle">ALT M</text>
        {Array.from({length: 21}).map((_, i) => {
          const j = i - 10;
          const x = 960 + j * 24 - mod(t * 6, 24);
          return <line key={'h' + i} x1={x} y1={330} x2={x} y2={j % 5 === 0 ? 352 : 342} stroke={ICE} strokeWidth={2} opacity={0.7} />;
        })}
        <text x={960} y={318} fontFamily={MONO} fontSize={22} fill={WHITE} textAnchor="middle">N  000</text>
        {[0, 1, 2, 3, 4].map((i) => (
          <rect key={i} x={800 + i * 70} y={740} width={56} height={10} fill={ICE} opacity={0.35 + 0.65 * (i < 5 ? 1 : 0)} />
        ))}
        <text x={960} y={780} fontFamily={MONO} fontSize={20} fill={ICE} textAnchor="middle">PWR 100%   THRUSTERS ARMED</text>
        {log.map(([t0, s], i) => (
          <HudText key={i} x={170} y={640 + i * 34} s={typed(s, t, t0)} size={22} />
        ))}
        {cd.map(([a, b, s]) => {
          if (t < a || t >= b) return null;
          const p = prog(t, a, b);
          const sc = lerp(1.5, 1, eo(p * 4));
          return (
            <text key={s} x={960} y={s === 'GO' ? 600 : 620} fontFamily={FONT} fontWeight={900} fontSize={s === 'GO' ? 150 : 240} textAnchor="middle" fill={WHITE} opacity={1 - ei(p) * 0.8} transform={`translate(960 540) scale(${sc}) translate(-960 -540)`}>{s}</text>
          );
        })}
      </g>
    </g>
  );
};

// =====================================================================
// SCENE 6 : terbang supersonik
// =====================================================================
const trav = (u: number) => {
  let s = 0;
  const M = (x: number) => 0.4 + 0.6 * sm(prog(x, 0, 1)) + 3 * sm(prog(x, 3.4, 4.3));
  for (let x = 0; x < u; x += 0.05) s += M(x) * Math.min(0.05, u - x);
  return s;
};

type Cloud = {x: number; y: number; s: number};
const mkClouds = (n: number, seed: number, y0: number, yr: number, s0: number, sr: number): Cloud[] =>
  Array.from({length: n}, (_, i) => ({x: rnd(seed + i * 3) * 2700, y: y0 + rnd(seed + i * 3 + 1) * yr, s: s0 + rnd(seed + i * 3 + 2) * sr}));
const CLOUD_PARTS = [[0, 0, 150, 38], [-110, 10, 100, 30], [120, 12, 110, 32], [40, -18, 90, 28], [-50, -16, 80, 24]];
const CL_FAR = mkClouds(8, 100, 560, 300, 0.5, 0.5);
const CL_MID = mkClouds(7, 200, 100, 800, 0.8, 0.6);
const CL_NEAR = mkClouds(6, 300, -250, 900, 1.5, 0.8);

type Bld = {x: number; w: number; h: number; far: boolean; seed: number};
const BLD: Bld[] = Array.from({length: 52}, (_, i) => {
  const far = i < 26;
  return {x: (i % 26) * 96 + rnd(i * 4 + 1) * 30, w: 56 + rnd(i * 4 + 2) * 56, h: far ? 120 + rnd(i * 4 + 3) * 200 : 170 + rnd(i * 4 + 3) * 300, far, seed: i * 11};
});

const SL = Array.from({length: 44}, (_, i) => ({
  y: 110 + rnd(i * 7 + 1) * 860,
  v: 2200 + rnd(i * 7 + 2) * 3400,
  len: 160 + rnd(i * 7 + 3) * 620,
  w: 1.5 + rnd(i * 7 + 4) * 3.5,
  off: rnd(i * 7 + 5) * 2800,
}));

const Flyer: React.FC<{t: number}> = ({t}) => {
  const fl = (base: number, ph: number) => base + 26 * Math.sin(t * 61 + ph) + 14 * Math.sin(t * 37 + ph * 2);
  return (
    <g>
      <rect x={-1500} y={6} width={1260} height={6} fill="url(#trailG)" />
      <rect x={-1500} y={20} width={1260} height={4} fill="url(#trailG)" opacity={0.6} />
      <path d={`M-236 -4L${-236 - fl(170, 0)} 8L-236 20Z`} fill="url(#flameG)" filter="url(#blurS)" />
      <path d={`M-228 -16L${-228 - fl(140, 2)} -8L-228 4Z`} fill="url(#flameG)" filter="url(#blurS)" />
      <line x1={-70} y1={8} x2={-224} y2={18} stroke={RED_D} strokeWidth={36} strokeLinecap="round" />
      <line x1={-70} y1={-12} x2={-218} y2={-6} stroke={RED} strokeWidth={36} strokeLinecap="round" />
      <line x1={-70} y1={-12} x2={-140} y2={-9} stroke={GOLD} strokeWidth={22} strokeLinecap="round" />
      <ellipse cx={-236} cy={16} rx={24} ry={20} fill={GOLD} />
      <ellipse cx={-228} cy={-4} rx={22} ry={18} fill="#d99a2c" />
      <line x1={80} y1={-30} x2={238} y2={-52} stroke={RED_D} strokeWidth={28} strokeLinecap="round" />
      <circle cx={256} cy={-54} r={22} fill={ICE} opacity={0.9} filter="url(#glow)" />
      <path d="M-80 -38C-20 -52 70 -50 104 -34L104 30C70 44 -20 46 -80 34Z" fill="url(#redG)" />
      <path d="M10 -44C50 -48 84 -42 100 -30L100 8C70 14 30 14 10 6Z" fill="url(#goldG)" />
      <path d="M-80 12C-30 22 40 20 104 12" fill="none" stroke={GOLD} strokeWidth={8} />
      <line x1={78} y1={-8} x2={236} y2={-20} stroke={RED} strokeWidth={30} strokeLinecap="round" />
      <line x1={150} y1={-14} x2={236} y2={-20} stroke={GOLD} strokeWidth={24} strokeLinecap="round" />
      <circle cx={246} cy={-22} r={26} fill={ICE} opacity={0.35} filter="url(#glowL)" />
      <circle cx={244} cy={-22} r={14} fill={WHITE} />
      <path d="M96 -52C112 -66 150 -64 160 -34C166 -14 160 8 140 22L108 28C98 10 92 -20 96 -52Z" fill="url(#redG)" stroke="#1a0508" strokeWidth={3} />
      <path d="M130 -42C148 -44 158 -30 158 -14C157 2 148 14 136 20L124 14C122 -6 122 -28 130 -42Z" fill="url(#goldG)" />
      <path d="M138 -26L160 -31L157 -22L140 -17Z" fill="#eaffff" filter="url(#glow)" />
    </g>
  );
};

const Flight: React.FC<{t: number}> = ({t}) => {
  const u = t - 17;
  const tr = trav(u);
  const skyShift = lerp(0, 760, eo(prog(u, 0.3, 3.0)));
  const skyY = -1320 + skyShift;
  const cityShift = lerp(0, 1000, eo(prog(u, 0.2, 2.8)));
  const mp = prog(t, 20.5, 21.5);
  const zoom =
    1 + 0.22 * (t >= 20.5 ? Math.exp(-(t - 20.5) * 5) : 0) - 0.07 * sm(prog(t, 20.9, 22.4)) + 0.17 * sm(prog(t, 22.4, 23.7));
  const fx = 760 + 14 * Math.sin(u * 1.3);
  const fy = 540 + 16 * Math.sin(u * 2.1) + (1 - eo(prog(u, 0, 0.9))) * 620;
  const ang = lerp(-52, -16, eo(prog(u, 0, 0.9))) + 12 * eo(prog(u, 1.0, 3.2));
  const burst = prog(t, 22.9, 24.0);
  const ctn = 1 - sm(prog(t, 23.95, 24.2));
  const cloudLayer = (cl: Cloud[], speed: number, drop: number, alpha: number, k: number, blur: boolean) => (
    <g opacity={alpha} filter={blur ? 'url(#blurS)' : undefined}>
      {cl.map((c, i) => {
        const x = mod(c.x - tr * speed, 2700) - 380;
        const y = c.y + drop * skyShift;
        return (
          <g key={i} transform={`translate(${x} ${y}) scale(${c.s * k})`}>
            {CLOUD_PARTS.map(([px, py, rx, ry], j) => (
              <ellipse key={j} cx={px} cy={py} rx={rx} ry={ry} fill="#fff" />
            ))}
          </g>
        );
      })}
    </g>
  );
  const slA = 0.12 + 0.18 * sm(prog(u, 0.4, 2)) + 0.45 * sm(prog(t, 20.5, 21.5));
  return (
    <g>
      <g opacity={ctn}>
        <g transform={`translate(960 540) scale(${zoom}) translate(-960 -540)`}>
          <rect x={-300} y={skyY} width={2520} height={2400} fill="url(#skyG)" />
          <circle cx={1500} cy={skyY + 2400 * 0.74} r={430} fill="url(#sunG)" opacity={0.9} />
          {cloudLayer(CL_FAR, 40, 0.2, 0.35, 0.8, false)}
          {cloudLayer(CL_MID, 170, 0.6, 0.5, 1.0, false)}
          {cityShift < 980 && (
            <g>
              {BLD.map((b, i) => {
                const x = mod(b.x - tr * (b.far ? 50 : 110), 2500) - 300;
                const base = 930 + cityShift;
                const lit = !b.far
                  ? Array.from({length: 8}).map((_, k) => {
                      const col = k % 3;
                      const row = Math.floor(k / 3);
                      return rnd(b.seed + k) > 0.45 ? <rect key={k} x={x + 8 + col * 20} y={base - b.h + 16 + row * 38} width={9} height={14} fill="#ffd27a" opacity={0.7} /> : null;
                    })
                  : null;
                return (
                  <g key={i}>
                    <rect x={x} y={base - b.h} width={b.w} height={b.h + 400} fill={b.far ? '#17283d' : '#0a111b'} opacity={b.far ? 0.85 : 1} />
                    {lit}
                  </g>
                );
              })}
            </g>
          )}
          {cloudLayer(CL_NEAR, 560, 1.0, 0.55, 1.0, true)}
          {SL.map((l, i) => {
            const len = l.len * (1 + 1.2 * mp);
            const x = mod(l.off - tr * l.v, 2400 + len) - len;
            return <line key={i} x1={x} y1={l.y} x2={x + len} y2={l.y} stroke="#fff" strokeWidth={l.w} strokeLinecap="round" opacity={slA} />;
          })}
          {t >= 20.5 && t < 22.4 && (
            <g opacity={sm(prog(t, 20.5, 20.62)) * (1 - sm(prog(t, 20.9, 22.2)))} filter="url(#blurM)">
              <path d={`M${fx + 250} ${fy}L${fx - 900} ${fy - 340}L${fx - 900} ${fy + 340}Z`} fill="url(#trailG)" />
            </g>
          )}
          <g transform={`translate(${fx} ${fy}) rotate(${ang}) scale(1.35)`}>
            <Flyer t={t} />
          </g>
          {[0, 0.12, 0.26].map((d, i) => {
            const p = prog(t, 20.5 + d, 21.5 + d);
            if (p <= 0 || p >= 1) return null;
            const R = eo(p) * 1500;
            return <ellipse key={i} cx={fx + 120} cy={fy} rx={R * 0.35} ry={R} fill="none" stroke="#fff" strokeWidth={18 * (1 - p) + 3} opacity={Math.pow(1 - p, 1.2)} />;
          })}
          {burst > 0 && (
            <g>
              {Array.from({length: 70}).map((_, i) => {
                const a = rnd(i * 3 + 11) * Math.PI * 2;
                const r0 = lerp(120, 900, ei(burst)) * (0.6 + 0.8 * rnd(i * 3 + 12));
                const len = 120 + 900 * ei(burst) * rnd(i * 3 + 13);
                const [x1, y1] = pt(960, 540, r0, a);
                const [x2, y2] = pt(960, 540, r0 + len, a);
                return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#fff" strokeWidth={2 + rnd(i * 3 + 14) * 4} strokeLinecap="round" opacity={0.8 * sm(prog(t, 22.9, 23.3))} />;
              })}
            </g>
          )}
          <circle cx={960} cy={540} r={2400 * eie(prog(t, 23.5, 24.05))} fill="#fff" opacity={t > 23.5 ? 1 : 0} />
        </g>
      </g>
    </g>
  );
};

// =====================================================================
// SCENE 8 : judul
// =====================================================================
const Title: React.FC<{t: number}> = ({t}) => {
  const st = eo(prog(t, 25.4, 26.0));
  const reveal = eo(prog(t, 26.0, 26.8)) * 2100;
  const ls = lerp(70, 18, eo(prog(t, 26.0, 28.0)));
  const ca = lerp(16, 2, eo(prog(t, 26.0, 27.5)));
  const sc = lerp(1.06, 1, prog(t, 26.0, 29));
  const o = 1 - sm(prog(t, 29.2, 30));
  const sub = sm(prog(t, 27.0, 27.6));
  const line = eo(prog(t, 26.8, 27.8));
  const common = {x: 960, y: 590, fontFamily: FONT, fontWeight: 900, fontSize: 230, textAnchor: 'middle' as const, letterSpacing: ls};
  return (
    <g opacity={o}>
      <defs>
        <clipPath id="titleClip"><rect x={960 - reveal / 2} y={300} width={reveal} height={420} /></clipPath>
      </defs>
      <rect x={960 - 850 * st} y={540 - 14} width={1700 * st} height={28} fill="url(#streakG)" opacity={0.5 * (1 - 0.6 * sm(prog(t, 26.2, 27.5)))} filter="url(#blurM)" />
      <rect x={960 - 850 * st} y={538} width={1700 * st} height={4} fill="url(#streakG)" opacity={1 - sm(prog(t, 26.2, 27.5))} filter="url(#glow)" />
      <g transform={`translate(960 540) scale(${sc}) translate(-960 -540)`}>
        <g clipPath="url(#titleClip)">
          <text {...common} fill={RED} opacity={0.55} filter="url(#blurM)">{TITLE}</text>
          <text {...common} x={960 - ca} fill="#ff2a2a" opacity={0.6} style={{mixBlendMode: 'screen'}}>{TITLE}</text>
          <text {...common} x={960 + ca} fill="#2ae0ff" opacity={0.6} style={{mixBlendMode: 'screen'}}>{TITLE}</text>
          <text {...common} fill="url(#titleG)">{TITLE}</text>
        </g>
        <rect x={960 - 560 * line - 40} y={676} width={560 * line} height={2} fill={GOLD} opacity={0.8} />
        <rect x={960 + 40} y={676} width={560 * line} height={2} fill={GOLD} opacity={0.8} />
        <text x={960} y={760} fontFamily={FONT} fontSize={38} letterSpacing={14} textAnchor="middle" fill={ICE} opacity={sub} filter="url(#glow)">{SUBTITLE}</text>
      </g>
    </g>
  );
};

// =====================================================================
// KAMERA GLOBAL, EFEK, KOMPOSISI
// =====================================================================
const ev = (t: number, t0: number, dur: number, amp: number) => {
  const p = prog(t, t0, t0 + dur);
  return p > 0 && p < 1 ? Math.pow(1 - p, 2) * amp : 0;
};
const punch = (t: number, t0: number, amp: number, k: number) => (t >= t0 ? amp * Math.exp(-(t - t0) * k) : 0);

export const IronMan: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;

  const k =
    ev(t, 9.6, 0.6, 12) + ev(t, 12.25, 0.4, 10) + ev(t, 20.5, 1.0, 40) + ev(t, 24.0, 0.7, 44) + ev(t, 26.0, 0.8, 26) +
    (t > 17 && t < 20.5 ? 3 : 0) + (t >= 20.5 && t < 23.5 ? 5 : 0);
  const sx = Math.sin(t * 1.3) * 2.5 + Math.sin(t * 2.9) * 1.4 + Math.sin(t * 83) * k;
  const sy = Math.cos(t * 1.1) * 2.5 + Math.cos(t * 3.3) * 1.2 + Math.cos(t * 97) * k;
  const sr = Math.sin(t * 0.7) * 0.12 + Math.sin(t * 61) * k * 0.03;
  const S = 1.03 + punch(t, 9.6, 0.04, 6) + punch(t, 12.25, 0.05, 8) + punch(t, 20.5, 0.08, 5) + punch(t, 24.0, 0.1, 5) + punch(t, 26.0, 0.06, 3);

  const flash =
    0.35 * gauss(t, 9.6, 0.08) + 0.9 * gauss(t, 12.15, 0.12) + gauss(t, 16.95, 0.22) + 0.85 * gauss(t, 20.5, 0.1) + 0.9 * gauss(t, 26.0, 0.1) +
    sm(prog(t, 23.85, 24.05)) * (1 - sm(prog(t, 24.2, 24.8)));

  const vR = vis(t, 0, 6.4, 0.05, 0.35);
  const vH = vis(t, 5.7, 9.7, 0.6, 0.1);
  const vM = vis(t, 8.6, 12.6, 0.05, 0.45);
  const vI = vis(t, 12.0, 17.5, 0.3, 0.55);
  const vF = vis(t, 16.8, 24.85, 0.3, 0.05);
  const vT = vis(t, 25.1, 30.1, 0.3, 0.05);
  const bar = 100 * sm(prog(t, 0.2, 1.4));

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Audio src={staticFile('audio.mp3')} />
      <svg width={WIDTH} height={HEIGHT} viewBox="0 0 1920 1080" style={{position: 'absolute', left: 0, top: 0}}>
        <Defs />
        <filter id="grainF" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="1" seed={frame % 9} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width={1920} height={1080} fill="#000" />
        <g transform={`translate(${960 + sx} ${540 + sy}) rotate(${sr}) scale(${S}) translate(-960 -540)`}>
          {vR > 0.002 && <g opacity={vR}><Reactor t={t} /></g>}
          {vH > 0.002 && <g opacity={vH}><Hud t={t} /></g>}
          {vM > 0.002 && <g opacity={vM}><HelmScene t={t} /></g>}
          {vI > 0.002 && <g opacity={vI}><Inside t={t} frame={frame} /></g>}
          {vF > 0.002 && <g opacity={vF}><Flight t={t} /></g>}
          {vT > 0.002 && <g opacity={vT}><Title t={t} /></g>}
        </g>
        <rect width={1920} height={1080} fill="url(#gradeG)" opacity={0.16} style={{mixBlendMode: 'overlay'}} />
        <rect width={1920} height={1080} fill="url(#vigG)" />
        <rect width={1920} height={1080} fill="#fff" opacity={clamp(flash)} />
        <rect width={1920} height={1080} filter="url(#grainF)" opacity={0.09} style={{mixBlendMode: 'overlay'}} />
        <rect x={0} y={0} width={1920} height={bar} fill="#000" />
        <rect x={0} y={1080 - bar} width={1920} height={bar} fill="#000" />
      </svg>
    </AbsoluteFill>
  );
};
