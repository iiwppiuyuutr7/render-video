import React from 'react';
import {Composition} from 'remotion';
import {IronMan, FPS, WIDTH, HEIGHT, TOTAL_SECONDS} from './IronMan';

export const RemotionRoot: React.FC = () => (
  <Composition id="IronMan" component={IronMan} durationInFrames={Math.round(TOTAL_SECONDS * FPS)} fps={FPS} width={WIDTH} height={HEIGHT} />
);
