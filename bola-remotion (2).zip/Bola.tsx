import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {TRK, HOM, BALL, HAB} from './trackdata';

/* =====================================================================
   BOLA  –  animasi gol versi kartun, sudut kamera siaran TV
   1920x1080 • 60 fps • 35.57 detik • audio dari video asli (public/audio.mp3)
   ===================================================================== */
export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_SECONDS = 35.57;

// ---------- util ----------
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const sm = (p: number) => {
  const x = clamp(p);
  return x * x * (3 - 2 * x);
};
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const rnd = (seed: number) => {
  let a = seed * 9301 + 49297;
  a = Math.imul(a ^ (a >>> 15), 2246822507);
  a = Math.imul(a ^ (a >>> 13), 3266489909);
  return ((a ^ (a >>> 16)) >>> 0) / 4294967296;
};
// ---------- palet ----------
const GRASS1 = '#3f9a3b';
const GRASS2 = '#489f42';
const NAVY = '#16264f';
const NAVY_S = '#0e1a3a';
const SKY = '#8fc9ee';
const SKIN = ['#e0a878', '#c98b5c', '#7a4a2e', '#f0c29b', '#5a3522'];

// PEMAIN  (tinggi desain 100, kaki di (0,0)) — rig lari dengan condong badan, naik-turun, tendangan
// =====================================================================
type PlayerProps = {
  x: number; y: number; h: number; f?: number; ph?: number; run?: number;
  shirt: string; short: string; sock?: string; skin?: string; hair?: string;
  rot?: number; arms?: 'run' | 'up' | 'out' | 'hips' | 'down'; stripes?: boolean; boot?: string;
  kick?: number; // 0..1 progres tendangan (kaki depan)
};
const Player: React.FC<PlayerProps> = ({
  x, y, h, f = 1, ph = 0, run = 1, shirt, short, sock = '#fff', skin = SKIN[0], hair = '#1c1410',
  rot = 0, arms = 'run', stripes = false, boot = '#e8602c', kick,
}) => {
  const A = run;
  const kicking = kick !== undefined;
  const bounce = Math.abs(Math.sin(ph)) * A * 2.6;
  const lean = A * 0.17 - (kicking ? 0.12 : 0);
  const hipY = -46 - bounce;
  const leg = (phase: number, isKicker: boolean) => {
    let th: number, be: number;
    if (kicking && isKicker) {
      const k = kick as number;
      if (k < 0.4) { const p = sm(k / 0.4); th = lerp(0.1, -1.0, p); be = lerp(0.3, 1.7, p); }
      else if (k < 0.6) { const p = sm((k - 0.4) / 0.2); th = lerp(-1.0, 1.35, p); be = lerp(1.7, 0.15, p); }
      else { const p = sm((k - 0.6) / 0.4); th = lerp(1.35, 0.25, p); be = lerp(0.15, 0.5, p); }
    } else if (kicking) { th = -0.1; be = 0.18; }
    else {
      th = Math.sin(phase) * 0.95 * A + 0.08 * A;
      be = A * (0.22 + 1.05 * Math.pow(Math.max(0, Math.cos(phase)), 1.2)) + (1 - A) * 0.05;
    }
    const kx = Math.sin(th) * 23, ky = hipY + Math.cos(th) * 23;
    const fx = kx + Math.sin(th - be) * 23, fy = ky + Math.cos(th - be) * 23;
    const mx = kx * 0.55, my = hipY + (ky - hipY) * 0.55;
    const fa = ((th - be) * 180) / Math.PI;
    return (
      <g>
        <path d={`M0 ${hipY} L${kx} ${ky}`} stroke={skin} strokeWidth={8} strokeLinecap="round" fill="none" />
        <path d={`M0 ${hipY} L${mx} ${my}`} stroke={short} strokeWidth={11} strokeLinecap="round" fill="none" />
        <path d={`M${kx} ${ky} L${fx} ${fy}`} stroke={sock} strokeWidth={6.5} strokeLinecap="round" fill="none" />
        <ellipse cx={fx + 3} cy={fy + 1} rx={6.5} ry={3.2} fill={boot} transform={`rotate(${Math.max(-40, Math.min(40, -fa * 0.5 + 8))} ${fx} ${fy})`} />
      </g>
    );
  };
  const arm = (phase: number, sign: number) => {
    let sa: number, ea: number;
    if (arms === 'run') { sa = -Math.sin(phase) * A * 1.05 * sign + 0.1; ea = 0.9 + 0.7 * A; }
    else if (arms === 'up') { sa = Math.PI - 0.5 * sign + 0.15 * Math.sin(phase * 2); ea = 0.2; }
    else if (arms === 'out') { sa = Math.PI / 2 + 0.1; ea = 0.1; }
    else if (arms === 'hips') { sa = 0.7 * sign; ea = -1.3; }
    else { sa = 0.1 * sign; ea = 0.1; }
    if (kicking) { sa = sign > 0 ? 1.2 : -0.9; ea = 0.2; }
    const sx = 0, sy = -77;
    const ex = sx + Math.sin(sa) * 15, ey = sy + Math.cos(sa) * 15;
    const hx = ex + Math.sin(sa + ea) * 14, hy = ey + Math.cos(sa + ea) * 14;
    return (
      <g>
        <path d={`M${sx} ${sy} L${ex} ${ey}`} stroke={shirt} strokeWidth={7} strokeLinecap="round" fill="none" />
        <path d={`M${ex} ${ey} L${hx} ${hy}`} stroke={skin} strokeWidth={5.5} strokeLinecap="round" fill="none" />
      </g>
    );
  };
  const sx = Math.abs(f) < 0.6 ? (f < 0 ? -0.6 : 0.6) : f;
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${(h / 100) * sx},${h / 100})`}>
      {leg(ph + Math.PI, false)}
      <g transform={`translate(0,${-bounce}) rotate(${(lean * 180) / Math.PI} 0 -46)`}>
        {arm(ph, 1)}
        <rect x={-11} y={-80} width={22} height={36} rx={8} fill={shirt} />
        {stripes && (<><rect x={-7} y={-78} width={4} height={30} fill="#fff" /><rect x={3} y={-78} width={4} height={30} fill="#fff" /></>)}
        <rect x={-3.5} y={-86} width={7} height={8} fill={skin} />
        <circle cx={0} cy={-91} r={8.6} fill={skin} />
        <path d="M-8.8 -92 C-9 -102 9 -102 8.8 -92 C5 -96 -5 -96 -8.8 -92Z" fill={hair} />
      </g>
      <rect x={-11} y={hipY - 6} width={22} height={12} rx={4} fill={short} />
      {leg(ph, true)}
      <g transform={`translate(0,${-bounce}) rotate(${(lean * 180) / Math.PI} 0 -46)`}>{arm(ph + Math.PI, -1)}</g>
    </g>
  );
};

const Shadow: React.FC<{x: number; y: number; w: number; o?: number}> = ({x, y, w, o = 0.25}) => (
  <ellipse cx={x} cy={y} rx={w} ry={w * 0.22} fill={`rgba(0,0,0,${o})`} />
);

// =====================================================================
// BOLA  (krem + garis emas)
// =====================================================================
const Ball: React.FC<{x: number; y: number; r: number; spin: number}> = ({x, y, r, spin}) => (
  <g transform={`translate(${x},${y})`}>
    <clipPath id="ballclip"><circle r={r} /></clipPath>
    <circle r={r} fill="#f6ecd6" />
    <g clipPath="url(#ballclip)" transform={`rotate(${spin})`}>
      <path d={`M${-r} ${-r * 0.2} C${-r * 0.4} ${-r * 0.9} ${r * 0.4} ${r * 0.1} ${r} ${-r * 0.5}`} stroke="#c9a24a" strokeWidth={r * 0.45} fill="none" />
      <path d={`M${-r} ${r * 0.6} C${-r * 0.3} ${r * 0.2} ${r * 0.5} ${r * 1.1} ${r} ${r * 0.5}`} stroke="#d8b660" strokeWidth={r * 0.35} fill="none" />
      <circle cx={r * 0.35} cy={-r * 0.1} r={r * 0.22} fill="#b98a35" />
    </g>
    <circle r={r} fill="none" stroke="#a88a4c" strokeWidth={Math.max(1, r * 0.1)} />
    <ellipse cx={-r * 0.3} cy={-r * 0.35} rx={r * 0.3} ry={r * 0.18} fill="#fff" opacity={0.5} />
  </g>
);

// =====================================================================
// PENONTON — orang-orangan (kepala, bahu, tangan) digambar per baris tribun, di-memo
// =====================================================================
const CPAL_W = ['#8fc9ee', '#ffffff', '#d9eefb', '#6fb3e0', '#f2f4f8', '#2a4aa0', '#8a96b0', '#1c1c22'];
const CPAL_E = ['#16264f', '#c0303c', '#ffffff', '#2a4aa0', '#8e1b2d', '#8fc9ee', '#1c1c22', '#d8b44a'];
const SKIN4 = ['#f0c29b', '#d99a6c', '#a36a42', '#6b4128'];
const HAIR4 = ['#16110d', '#3a2418', '#7a5a38', '#b8b8be'];
type StripData = {heads: string[]; hair: string[]; body: string[]; arms: string[]; hands: string[]; cols: string[]};
const stripCache = new Map<string, StripData>();
const genStrip = (seed: number, zone: number, cheer: boolean): StripData => {
  const key = `${seed}|${zone}|${cheer}`;
  const hit = stripCache.get(key);
  if (hit) return hit;
  const heads = SKIN4.map(() => ''), hair = HAIR4.map(() => ''), body = CPAL_W.map(() => ''), arms = CPAL_W.map(() => ''), hands = SKIN4.map(() => '');
  const cols = CPAL_W.map((_, i) => `${i}`);
  const n = 38;
  for (let i = 0; i < n; i++) {
    const r1 = rnd(seed * 97 + i * 13 + 1), r2 = rnd(seed * 53 + i * 7 + 2), r3 = rnd(seed * 31 + i * 5 + 3), r4 = rnd(seed * 17 + i * 3 + 4), r5 = rnd(seed * 71 + i * 11 + 5);
    const s = 0.92 + r1 * 0.16;
    const cx = 26 + i * 52 + (r2 - 0.5) * 10;
    const cy = (r3 - 0.5) * 6;
    const east = r4 < zone;
    const ci = Math.floor(r5 * 8) % 8;
    const sk = Math.floor(rnd(seed + i * 19) * 4) % 4;
    const hk = Math.floor(rnd(seed + i * 23 + 9) * 4) % 4;
    const w = 26 * s, sh = 48 * s, hr = 11.5 * s, hy = -62 * s + cy;
    // warna disimpan lewat indeks gabungan: barat 0..7, timur 8..15 (dipecah saat render)
    const idx = east ? ci + 8 : ci;
    while (body.length <= idx) { body.push(''); arms.push(''); }
    body[idx] += `M${cx - w} ${cy}L${cx - w} ${cy - sh + 10}Q${cx - w} ${cy - sh} ${cx - w + 12} ${cy - sh - 2}L${cx + w - 12} ${cy - sh - 2}Q${cx + w} ${cy - sh} ${cx + w} ${cy - sh + 10}L${cx + w} ${cy}Z`;
    heads[sk] += `M${cx - hr} ${hy}a${hr} ${hr} 0 1 0 ${2 * hr} 0a${hr} ${hr} 0 1 0 ${-2 * hr} 0Z`;
    hair[hk] += `M${cx - hr - 0.5} ${hy - 1}a${hr + 0.5} ${hr + 1} 0 0 1 ${2 * hr + 1} 0q${-(hr + 0.5)} -4 ${-(2 * hr + 1)} 0Z`;
    if (cheer && rnd(seed * 3 + i * 29) < 0.6) {
      const two = rnd(seed * 5 + i * 31) < 0.55;
      const sides = two ? [-1, 1] : [rnd(seed + i) < 0.5 ? -1 : 1];
      for (const sd of sides) {
        const ex = cx + sd * (w + 6 + rnd(seed + i * 37) * 10), ey = cy - sh - 30 - rnd(seed + i * 41) * 18;
        arms[idx] += `M${cx + sd * (w - 3)} ${cy - sh + 6}L${ex} ${ey}`;
        hands[sk] += `M${ex - 6} ${ey}a6 6 0 1 0 12 0a6 6 0 1 0 -12 0Z`;
      }
    }
  }
  const out = {heads, hair, body, arms, hands, cols};
  stripCache.set(key, out);
  return out;
};
const palOf = (idx: number) => (idx >= 8 ? CPAL_E[idx - 8] : CPAL_W[idx]);
const Strip = React.memo(({seed, zone, cheer}: {seed: number; zone: number; cheer: boolean}) => {
  const d = genStrip(seed, zone, cheer);
  return (
    <g>
      {d.arms.map((p, i) => (p ? <path key={'a' + i} d={p} stroke={palOf(i)} strokeWidth={13} strokeLinecap="round" fill="none" /> : null))}
      {d.hands.map((p, i) => (p ? <path key={'h' + i} d={p} fill={SKIN4[i]} /> : null))}
      {d.body.map((p, i) => (p ? <path key={'b' + i} d={p} fill={palOf(i)} /> : null))}
      {d.heads.map((p, i) => (p ? <path key={'k' + i} d={p} fill={SKIN4[i]} /> : null))}
      {d.hair.map((p, i) => (p ? <path key={'r' + i} d={p} fill={HAIR4[i]} /> : null))}
    </g>
  );
});
type PF = (u: number, v: number) => [number, number];
type PPM = (u: number, v: number, y: number) => number;
const SEG = 20, N_ROWS = 30;
// tribun bertingkat: sisi jauh + belakang gawang (kanan), bertemu miring di sudut
const StandsRing: React.FC<{proj: PF; ppm: PPM; t: number; cheer: boolean}> = ({proj, ppm, t, cheer}) => {
  const nodes: React.ReactNode[] = [];
  const place = (key: string, q0: [number, number], q1: [number, number], z: number, pp: number, seed: number, zone: number) => {
    const [p0, p1] = q1[0] < q0[0] ? [q1, q0] : [q0, q1];
    const ax = (p1[0] - p0[0]) / (SEG * 100), ay = (p1[1] - p0[1]) / (SEG * 100);
    if (!(Math.abs(p1[0] - p0[0]) >= 6) || Math.abs(p1[0] - p0[0]) > 1700 || !(pp < 450)) return;
    const top = Math.min(p0[1], p1[1]) - (z + 1.2) * pp, bot = Math.max(p0[1], p1[1]) - (z - 0.6) * pp;
    if (Math.max(p0[0], p1[0]) < -60 || Math.min(p0[0], p1[0]) > WIDTH + 60 || bot < -40 || top > HEIGHT + 40) return;
    nodes.push(
      <g key={key} transform={`matrix(${ax} ${ay} 0 ${pp / 100} ${p0[0]} ${p0[1] - z * pp})`}>
        <Strip seed={seed} zone={Math.round(zone * 4) / 4} cheer={cheer} />
      </g>,
    );
  };
  for (let i = N_ROWS - 1; i >= 0; i--) {
    const d = 7 + i * 0.85, z0 = 0.5 + i * 0.62;
    const z = z0 + Math.sin(t * (cheer ? 7 : 1.3) + i * 1.7) * (cheer ? 0.1 : 0.012);
    const uEnd = 105 + d;
    for (let k = 0; k < 12; k++) {
      const u1 = uEnd - SEG * k, u0 = u1 - SEG;
      if (u1 <= -d) continue;
      const p0 = proj(u0, -d), p1 = proj(u1, -d);
      place(`f${i}_${k}`, p0, p1, z, ppm((u0 + u1) / 2, -d, (p0[1] + p1[1]) / 2), i * 31 + k * 7 + 3, clamp(((u0 + u1) / 2 + 10) / 120));
    }
    for (let k = 0; k < 6; k++) {
      const v0 = -d + SEG * k, v1 = v0 + SEG;
      const p0 = proj(uEnd, v0), p1 = proj(uEnd, v1);
      place(`e${i}_${k}`, p0, p1, z, ppm(uEnd, (v0 + v1) / 2, (p0[1] + p1[1]) / 2), i * 17 + k * 11 + 101, 0.92);
    }
    for (let k = 0; k < 6; k++) {
      const v0 = -d + SEG * k, v1 = v0 + SEG;
      const p0 = proj(-d, v0), p1 = proj(-d, v1);
      place(`w${i}_${k}`, p0, p1, z, ppm(-d, (v0 + v1) / 2, (p0[1] + p1[1]) / 2), i * 19 + k * 13 + 211, 0.05);
    }
  }
  return <g>{nodes}</g>;
};
// papan iklan di belakang garis samping jauh & garis gawang
const AdBoards: React.FC<{proj: PF; ppm: PPM}> = ({proj, ppm}) => {
  const out: React.ReactNode[] = [];
  const panel = (key: string, a: [number, number], b: [number, number], pp: number, i: number) => {
    let p0 = a, p1 = b;
    if (p1[0] < p0[0]) { p0 = b; p1 = a; }
    if (Math.max(p0[0], p1[0]) < -50 || Math.min(p0[0], p1[0]) > WIDTH + 50 || p0[1] < 20 || p1[1] < 20 || p0[1] > 1200 || p1[1] > 1200) return;
    const hh = Math.min(95, pp * 1.1);
    const len = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
    if (!(len >= 8)) return;
    const ang = (Math.atan2(p1[1] - p0[1], p1[0] - p0[0]) * 180) / Math.PI;
    out.push(
      <g key={key}>
        <path d={`M${p0[0]} ${p0[1]}L${p1[0]} ${p1[1]}L${p1[0]} ${p1[1] - hh}L${p0[0]} ${p0[1] - hh}Z`} fill={i % 2 ? '#7a1830' : '#8c1d38'} stroke="#2a1d1d" strokeWidth={1} />
        <text transform={`translate(${(p0[0] + p1[0]) / 2},${(p0[1] + p1[1]) / 2 - hh * 0.3}) skewY(${ang}) scale(${Math.min(len / (hh * 7.3), 1.4)},1)`} fontSize={hh * 0.55} fontFamily="Poppins, Arial, sans-serif" fontWeight={800} fill="#f3e3b0" textAnchor="middle" letterSpacing={2}>{i % 2 ? 'SKY ARENA' : 'FLY HIGH'}</text>
      </g>,
    );
  };
  const L0 = -4.5, L1 = 109.5, V0 = -4.5, V1 = 72.5;
  for (let i = 0; L0 + i * 8 < L1; i++) {
    const u0 = L0 + i * 8, u1 = Math.min(u0 + 8, L1);
    const a = proj(u0, V0), b = proj(u1, V0);
    panel('bf' + i, a, b, ppm(u0, V0, a[1]), i);
  }
  for (let i = 0; V0 + i * 8 < V1; i++) {
    const v0 = V0 + i * 8, v1 = Math.min(v0 + 8, V1);
    const a = proj(L1, v0), b = proj(L1, v1);
    panel('be' + i, a, b, ppm(L1, v0, a[1]), i);
    const c = proj(L0, v0), d = proj(L0, v1);
    panel('bw' + i, c, d, ppm(L0, v0, c[1]), i);
  }
  return <g>{out}</g>;
};
// kerumunan datar (untuk latar blur adegan close-up)
const FlatCrowd: React.FC<{x: number; y: number; w: number; h: number; s: number; t: number; zone: number; cheer?: boolean; blur?: boolean; dim?: number}> = ({x, y, w, h, s, t, zone, cheer = false, blur = false, dim = 0}) => {
  const rowStep = 46 * s, segPx = 2000 * s;
  const rows = Math.ceil(h / rowStep) + 2;
  const cols = Math.ceil(w / segPx) + 2;
  const nodes: React.ReactNode[] = [];
  const off = ((x % segPx) + segPx) % segPx;
  for (let r = 0; r < rows; r++) {
    const bob = Math.sin(t * (cheer ? 7 : 1.3) + r * 1.7) * (cheer ? 5 : 0.8) * s;
    for (let c = 0; c < cols; c++) {
      nodes.push(
        <g key={r * 20 + c} transform={`translate(${c * segPx - off},${y + r * rowStep + 90 * s + bob}) scale(${s})`}>
          <Strip seed={r * 13 + c * 5 + 1} zone={Math.round(zone * 4) / 4} cheer={cheer} />
        </g>,
      );
    }
  }
  return (
    <g filter={blur ? 'url(#bl)' : undefined}>
      <rect x={x - 3000} y={y} width={6000} height={h} fill="#141b30" />
      {nodes}
      {dim > 0 && <rect x={0} y={y} width={WIDTH} height={h} fill="#0a1020" opacity={dim} />}
    </g>
  );
};


const Crowd = ({tx, ty, s, blur = 0, dim = 0}: {tx: number; ty: number; s: number; blur?: number; dim?: number}) => (
  <FlatCrowd x={tx} y={ty} w={WIDTH} h={HEIGHT - ty} s={s} t={0} zone={0.3} blur={blur > 0} dim={dim} />
);

const Defs: React.FC = () => (
  <defs>
    <filter id="bl" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="6" /></filter>
    <filter id="bl2" x="-10%" y="-10%" width="120%" height="120%"><feGaussianBlur stdDeviation="16" /></filter>
    <linearGradient id="gGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2e8a38" /><stop offset="1" stopColor="#5bb64c" /></linearGradient>
    <linearGradient id="gVip" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7f98c8" /><stop offset="1" stopColor="#b7c6e6" /></linearGradient>
    <linearGradient id="gShade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#000" stopOpacity="0.45" /><stop offset="1" stopColor="#000" stopOpacity="0" /></linearGradient>
  </defs>
);

// =====================================================================
// PROYEKSI LAPANGAN (kamera siaran)
// =====================================================================
type Cam = {cu: number; cx: number; kf: number; kn: number; y0: number; y1: number};
const P = (c: Cam, u: number, v: number): [number, number, number] => {
  const k = c.kf + ((c.kn - c.kf) * v) / 68;
  return [c.cx + (u - c.cu) * k, c.y0 + ((c.y1 - c.y0) * v) / 68, k];
};
const pl = (c: Cam, pts: number[][]) => pts.map(([u, v], i) => { const [x, y] = P(c, u, v); return `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`; }).join('');
const arcPts = (cu: number, cv: number, r: number, a0: number, a1: number, n = 24) =>
  Array.from({length: n + 1}, (_, i) => { const a = lerp(a0, a1, i / n); return [cu + r * Math.cos(a), cv + r * Math.sin(a)]; });

const Pitch: React.FC<{c: Cam; lw?: number}> = ({c, lw = 3}) => {
  const stripes = [];
  for (let i = -6; i < 30; i++) {
    const u0 = i * 5;
    stripes.push(<path key={i} d={pl(c, [[u0, -0.3], [u0 + 5, -0.3], [u0 + 5, 95], [u0, 95]]) + 'Z'} fill={i % 2 ? GRASS1 : GRASS2} />);
  }
  const L = (pts: number[][], k = 0) => <path d={pl(c, pts)} stroke="#fff" strokeWidth={lw} fill="none" opacity={0.9} key={k} />;
  return (
    <g>
      <rect x={0} y={c.y0 - 4} width={WIDTH} height={HEIGHT} fill={GRASS1} />
      {stripes}
      {L([[0, 0], [105, 0], [105, 68], [0, 68], [0, 0]])}
      {L([[52.5, 0], [52.5, 68]], 1)}
      {L(arcPts(52.5, 34, 9.15, 0, Math.PI * 2, 36), 2)}
      {L([[88.5, 13.85], [105, 13.85]], 3)}{L([[88.5, 13.85], [88.5, 54.15]], 4)}{L([[88.5, 54.15], [105, 54.15]], 5)}
      {L([[99.5, 24.85], [105, 24.85]], 6)}{L([[99.5, 24.85], [99.5, 43.15]], 7)}{L([[99.5, 43.15], [105, 43.15]], 8)}
      {L(arcPts(94, 34, 9.15, 2.2, 4.08, 14), 9)}
      {L([[16.5, 13.85], [0, 13.85]], 10)}{L([[16.5, 13.85], [16.5, 54.15]], 11)}{L([[16.5, 54.15], [0, 54.15]], 12)}
      {L(arcPts(11, 34, 9.15, -0.94, 0.94, 14), 13)}
    </g>
  );
};

const Goal: React.FC<{c: Cam; ripple?: number}> = ({c, ripple = 0}) => {
  const hh = 2.44 * 1.5;
  const [x1, y1, k1] = P(c, 105, 30.3); const [x2, y2] = P(c, 105, 37.7);
  const bu = 107 + ripple;
  const [bx1, by1, bk] = P(c, bu, 31.2); const [bx2, by2] = P(c, bu, 36.8);
  const t1 = hh * k1, tb = hh * bk * 0.9;
  const meshV = Array.from({length: 9}, (_, i) => { const p = i / 8; return `M${lerp(bx1, bx2, p)} ${lerp(by1, by2, p)}v${-tb}`; }).join('');
  const meshH = Array.from({length: 7}, (_, i) => { const p = i / 6; return `M${bx1} ${by1 - tb * p}H${bx2}`; }).join('');
  return (
    <g>
      <path d={`M${x1} ${y1}L${bx1} ${by1}v${-tb}L${x1} ${y1 - t1}Z`} fill="rgba(255,255,255,.16)" />
      <path d={`M${bx1} ${by1}L${bx2} ${by2}v${-tb}H${bx1}Z`} fill="rgba(255,255,255,.2)" />
      <path d={meshV + meshH} stroke="rgba(255,255,255,.55)" strokeWidth={1} />
      <path d={`M${x1} ${y1}L${bx1} ${by1}M${x1} ${y1 - t1}L${bx1} ${by1 - tb}`} stroke="#fff" strokeWidth={1.5} />
      <path d={`M${x1} ${y1}v${-t1}M${x2} ${y2}v${-t1}M${x1} ${y1 - t1}L${x2} ${y2 - t1}`} stroke="#fff" strokeWidth={5} strokeLinecap="round" />
    </g>
  );
};

// papan iklan + tribun di belakang lapangan
const Stands: React.FC<{c: Cam}> = ({c}) => {
  const ky = c.kf * 0.7;
  const boardY = c.y0 - Math.max(26, c.kf * 2.6) - 6;
  const boardH = Math.max(26, c.kf * 2.6);
  const items = [];
  const w = 22 * c.kf;
  const x0 = c.cx - c.cu * c.kf;
  for (let i = -3; i < 12; i++) {
    const x = x0 + i * w;
    if (x > WIDTH + 50 || x + w < -50) continue;
    items.push(
      <g key={i}>
        <rect x={x} y={boardY} width={w - 3} height={boardH} fill={i % 2 ? '#7a1830' : '#8c1d38'} />
        <text x={x + w / 2} y={boardY + boardH * 0.68} fontSize={boardH * 0.55} fontFamily="Poppins, Arial, sans-serif" fontWeight={800} fill="#f3e3b0" textAnchor="middle" letterSpacing={2}>
          {i % 2 ? 'SKY ARENA' : 'FLY HIGH'}
        </text>
      </g>,
    );
  }
  return (
    <g>
      <rect x={0} y={0} width={WIDTH} height={boardY + 4} fill="#162038" />
      <Crowd tx={c.cx - c.cu * ky} ty={0} s={boardY / 420} />
      <rect x={0} y={0} width={WIDTH} height={boardY} fill="url(#gShade)" />
      {items}
      <rect x={0} y={boardY + boardH} width={WIDTH} height={8} fill="#2a1d1d" opacity={0.7} />
    </g>
  );
};

// =====================================================================
// PAPAN SKOR
// =====================================================================
const Scoreboard: React.FC<{t: number}> = ({t}) => {
  const sec = 80 * 60 + 45 + Math.floor(t);
  const clock = `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
  const sB = t < 15 ? '1' : '2';
  return (
    <g transform="translate(90,34)" fontFamily="Poppins, Arial, sans-serif" fontWeight={700}>
      <rect width={660} height={50} rx={4} fill="#8b1030" />
      <rect width={150} height={50} rx={4} fill="#6c0d26" />
      <text x={75} y={35} fontSize={28} fill="#fff" textAnchor="middle">{clock}</text>
      <rect x={160} y={13} width={34} height={24} fill={SKY} /><rect x={160} y={21} width={34} height={8} fill="#fff" />
      <text x={204} y={35} fontSize={26} fill="#fff">ARG</text>
      <text x={300} y={35} fontSize={28} fill="#fff" textAnchor="middle">2</text>
      <path d="M322 14l22 22M344 14l-22 22" stroke="#fff" strokeWidth={5} />
      <text x={372} y={35} fontSize={28} fill="#fff" textAnchor="middle">{sB}</text>
      <text x={400} y={35} fontSize={26} fill="#fff">FRA</text>
      <rect x={484} y={13} width={11} height={24} fill="#2a4aa0" /><rect x={495} y={13} width={11} height={24} fill="#fff" /><rect x={506} y={13} width={11} height={24} fill="#d03040" />
    </g>
  );
};

// =====================================================================
// SCENE B — kamera siaran, posisi pemain & bola DILACAK dari video asli
// (data di trackdata.ts: koordinat 720p, 30 fps, frame 0 = detik 2.4 klip)
// =====================================================================
const DATA_T0 = 2.4;
const NF = HOM.length;
const at = (arr: number[], fi: number) => {
  const i = Math.max(0, Math.min(arr.length - 1, Math.floor(fi)));
  const j = Math.min(arr.length - 1, i + 1);
  return lerp(arr[i], arr[j], clamp(fi - i, 0, 1));
};
const hAt = (f: number, y: number) => {
  const [a, b] = HAB[Math.max(0, Math.min(NF - 1, f))];
  return Math.max(26, (a * y + b) * 1.3);
};
// homografi lapangan (meter -> piksel 1080p), diinterpolasi antar frame
const homAt = (fi: number) => {
  const i = Math.max(0, Math.min(NF - 1, Math.floor(fi)));
  const j = Math.min(NF - 1, i + 1);
  const p = clamp(fi - i, 0, 1);
  return HOM[i].map((v, k) => lerp(v, HOM[j][k], p));
};
const proj = (H: number[], u: number, v: number): [number, number] => {
  const w = H[6] * u + H[7] * v + 1;
  return [((H[0] * u + H[1] * v + H[2]) / w) * 1.5, ((H[3] * u + H[4] * v + H[5]) / w) * 1.5];
};
// gerak kaki dari kecepatan lari ASLI (m/s) hasil lacak video
const PROC = TRK.map((t) => {
  const n = t.x.length;
  const ph: number[] = [], amp: number[] = [];
  let p = (t.x[0] % 7) * 0.9, vs = t.gs[0];
  for (let i = 0; i < n; i++) {
    vs = vs * 0.75 + Math.min(t.gs[i], 8.5) * 0.25;
    p += (2 * Math.PI * clamp(vs / 1.7, 0.4, 3.7)) / 30;
    ph.push(p); amp.push(clamp(vs / 6, 0.12, 1));
  }
  return {ph, amp};
});
// bola melambung di segmen operan panjang / tembakan: [frame awal, frame akhir, tinggi puncak (px 720p)]
const LIFTS: number[][] = [[108, 126, 16], [168, 206, 80], [296, 318, 14]];
// tendangan: frame, dipasangkan ke pemain terdekat dari bola
const KICKS = [111, 170, 299];
const KICKER: number[] = KICKS.map((kf) => {
  let best = -1, bd = 1e9;
  TRK.forEach((tr, k) => {
    const i = kf - tr.f0;
    if (i < 0 || i >= tr.x.length || tr.team === 'k') return;
    const dd = Math.hypot(tr.x[i] - BALL[kf][0], tr.y[i] - BALL[kf][1]);
    if (dd < bd) { bd = dd; best = k; }
  });
  return bd < 70 ? best : -1;
});
// arah hadap halus (pecahan -1..1) agar tidak berbalik mendadak
const faceAt = (gd: number[], i: number) => {
  let sum = 0, c = 0;
  for (let j = -5; j <= 5; j++) { const q = Math.max(0, Math.min(gd.length - 1, Math.round(i) + j)); sum += gd[q]; c++; }
  return clamp((sum / c) * 1.6, -1, 1);
};

// garis lapangan dalam meter
const circ = (cu: number, cv: number, r: number, a0: number, a1: number, n: number) =>
  Array.from({length: n + 1}, (_, i) => [cu + r * Math.cos(a0 + ((a1 - a0) * i) / n), cv + r * Math.sin(a0 + ((a1 - a0) * i) / n)]);
const LINES_UV: number[][][] = [
  [[0, 0], [105, 0], [105, 68], [0, 68], [0, 0]],
  [[52.5, 0], [52.5, 68]],
  circ(52.5, 34, 9.15, 0, Math.PI * 2, 48),
  [[88.5, 13.85], [105, 13.85], [105, 54.15], [88.5, 54.15], [88.5, 13.85]],
  [[16.5, 13.85], [0, 13.85], [0, 54.15], [16.5, 54.15], [16.5, 13.85]],
  [[99.5, 24.85], [105, 24.85], [105, 43.15], [99.5, 43.15], [99.5, 24.85]],
  [[5.5, 24.85], [0, 24.85], [0, 43.15], [5.5, 43.15], [5.5, 24.85]],
  circ(94, 34, 9.15, 2.2, 4.08, 16),
  circ(11, 34, 9.15, -0.94, 0.94, 16),
];

// dunia statis: tribun, rumput, papan, garis, gawang (dipakai adegan lapangan & perayaan)
const PitchWorld: React.FC<{H: number[]; f: number; t: number; cheer: boolean; ripple?: number; ox?: number; oy?: number}> = ({H, f, t, cheer, ripple = 0, ox = 0, oy = 0}) => {
  const P2 = (u: number, v: number): [number, number] => { const [x, y] = proj(H, u, v); return [x + ox, y + oy]; };
  const P3 = (u: number, v: number): [number, number] => (H[6] * u + H[7] * v + 1 < 0.1 ? [NaN, NaN] : P2(u, v));
  const ppmF = (_u: number, _v: number, yy0: number) => (hAt(f, (yy0 - oy) / 1.5) * 1.5) / 1.8;
  const wOf = (u: number, v: number) => H[6] * u + H[7] * v + 1;
  const EPS = 0.12;
  let d = '';
  for (const pl of LINES_UV) {
    let pen = false;
    for (let k = 0; k < pl.length; k++) {
      const [u1, v1] = pl[k];
      const w1 = wOf(u1, v1);
      if (k > 0) {
        const [u0, v0] = pl[k - 1];
        const w0 = wOf(u0, v0);
        if (w0 >= EPS && w1 < EPS) {
          const q = (w0 - EPS) / (w0 - w1);
          const [x, y] = P2(u0 + (u1 - u0) * q, v0 + (v1 - v0) * q);
          d += `L${x.toFixed(1)} ${y.toFixed(1)}`; pen = false; continue;
        }
        if (w0 < EPS && w1 >= EPS) {
          const q = (EPS - w0) / (w1 - w0);
          const [x, y] = P2(u0 + (u1 - u0) * q, v0 + (v1 - v0) * q);
          d += `M${x.toFixed(1)} ${y.toFixed(1)}`; pen = true;
        }
      }
      if (w1 < EPS) { pen = false; continue; }
      const [x, y] = P2(u1, v1);
      d += `${pen ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`; pen = true;
    }
  }
  const stripes = [];
  for (let i = -14; i < 21; i++) {
    const u0 = i * 5.25, u1 = u0 + 5.25;
    if (H[6] * u0 + H[7] * -4.4 + 1 <= 0.1 || H[6] * u1 + H[7] * -4.4 + 1 <= 0.1) continue;
    let vb = 100;
    for (const uu of [u0, u1]) if (H[6] * uu + H[7] * vb + 1 < 0.1 && H[7] < 0) vb = Math.min(vb, (0.1 - 1 - H[6] * uu) / H[7]);
    const a = P2(u0, -4.4), b = P2(u1, -4.4), c = P2(u1, vb), e = P2(u0, vb);
    stripes.push(<path key={i} d={`M${a[0]} ${a[1]}L${b[0]} ${b[1]}L${c[0]} ${c[1]}L${e[0]} ${e[1]}Z`} fill={i % 2 ? GRASS1 : GRASS2} stroke={i % 2 ? GRASS1 : GRASS2} strokeWidth={1.5} />);
  }
  const [gx1, gy1] = P2(105, 30.34), [gx2, gy2] = P2(105, 37.66);
  const [gbx1, gby1] = P2(107.2, 31), [gbx2, gby2] = P2(107.2, 37);
  const gh = ppmF(0, 0, gy1) * 2.44, gbh = gh * 0.9;
  const goalVis = Math.min(gx1, gx2) < WIDTH + 200;
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="#141b30" />
      <StandsRing proj={P3} ppm={ppmF} t={t} cheer={cheer} />
      {stripes}
      <AdBoards proj={P3} ppm={ppmF} />
      <path d={d} stroke="#fff" strokeWidth={3.6} fill="none" opacity={0.92} strokeLinejoin="round" />
      {goalVis && (
        <g>
          <path d={`M${gx1} ${gy1}L${gbx1} ${gby1}v${-gbh}L${gx1} ${gy1 - gh}Z`} fill="rgba(255,255,255,.16)" />
          <path d={`M${gbx1 + ripple} ${gby1}L${gbx2 + ripple} ${gby2}v${-gbh}H${gbx1 + ripple}Z`} fill="rgba(255,255,255,.22)" stroke="rgba(255,255,255,.5)" strokeWidth={1} />
          <path d={`M${gx1} ${gy1}v${-gh}M${gx2} ${gy2}v${-gh}M${gx1} ${gy1 - gh}L${gx2} ${gy2 - gh}`} stroke="#fff" strokeWidth={5} strokeLinecap="round" />
        </g>
      )}
    </g>
  );
};

const PitchScene: React.FC<{t: number}> = ({t}) => {
  const fi = Math.max(0, (t - DATA_T0) * 30);
  const f = Math.min(NF - 1, Math.round(fi));
  const H = homAt(fi);
  const P2 = (u: number, v: number) => proj(H, u, v);
  // pemain
  const items: {y: number; node: React.ReactNode}[] = [];
  TRK.forEach((tr, k) => {
    const n = tr.x.length;
    let i = fi - tr.f0;
    const hold = tr.team === 'k' && tr.f0 + n >= 290 && fi >= tr.f0 + n - 1;
    if (!hold && (i < 0 || i > n - 1)) return;
    i = Math.max(0, Math.min(n - 1, i));
    const x = at(tr.x, i) * 1.5, yy = at(tr.y, i) * 1.5;
    const h = hAt(f, at(tr.y, i)) * 1.5;
    const pr = PROC[k];
    const edge = x < 60 || x > 1860;
    const fade = hold || edge ? 1 : clamp(Math.min(i + 1, n - i) / 6);
    if (fade <= 0.02) return;
    const team = tr.team;
    const dive = team === 'k' ? sm((fi - 304) / 9) : 0;
    const props: Partial<PlayerProps> & {shirt: string; short: string} =
      team === 'n' ? {shirt: NAVY, short: NAVY_S, sock: NAVY, skin: SKIN[(k * 3) % 5]}
        : team === 'w' ? {shirt: SKY, short: '#222a44', sock: '#fff', stripes: true, skin: SKIN[(k * 2 + 1) % 5]}
          : team === 'r' ? {shirt: '#f0661e', short: '#111', sock: '#111', skin: SKIN[3]}
            : {shirt: '#c5d733', short: '#1b1b1b', sock: '#1b1b1b', skin: SKIN[3]};
    const ii = Math.min(n - 1, Math.round(i));
    const afterGoal = fi > 318;
    const kickP = (kk: number, ff: number) => { const q = KICKER.indexOf(kk); if (q < 0) return undefined; const p = (ff - (KICKS[q] - 7)) / 14; return p >= 0 && p <= 1 ? p : undefined; };
    items.push({y: yy, node: (
      <g key={k} opacity={fade}>
        <Shadow x={x} y={yy + 1} w={h * 0.26} />
        <Player x={x} y={yy} h={h} f={hold ? -1 : faceAt(tr.gd, i)} kick={kickP(k, fi)} ph={pr.ph[ii]} run={afterGoal && team === 'w' ? 0.15 : pr.amp[ii]}
          arms={team === 'k' && dive > 0 ? 'up' : afterGoal && team === 'w' ? 'hips' : 'run'} rot={-84 * dive} {...props} />
      </g>
    )});
  });
  {
    const dive = sm((fi - 304) / 9);
    const [kx, ky] = P2(104.2, 34 + dive * 2.5);
    const kh = hAt(f, ky / 1.5) * 1.5;
    items.push({y: ky, node: (
      <g key="gk">
        <Shadow x={kx} y={ky + 1} w={kh * 0.26} />
        <Player x={kx - dive * kh * 0.25} y={ky + dive * kh * 0.18} h={kh} f={-1} shirt="#c5d733" short="#1b1b1b" sock="#1b1b1b" run={0} arms={dive > 0 ? 'up' : 'hips'} rot={-84 * dive} />
      </g>
    )});
  }
  items.sort((a, b) => a.y - b.y);
  // bola
  const bx = at(BALL.map((b) => b[0]), fi) * 1.5, byy = at(BALL.map((b) => b[1]), fi) * 1.5;
  let lift = 0;
  for (const [a, b, hp] of LIFTS) if (fi >= a && fi <= b) { const s = (fi - a) / (b - a); lift = hp * 4 * s * (1 - s) * 1.5; }
  const hb = hAt(f, byy / 1.5) * 1.5;
  const r = Math.max(8, hb * 0.085);
  const ripple = fi > 318 ? Math.sin((fi - 318) * 0.6) * 5 * Math.exp(-(fi - 318) / 14) : 0;
  return (
    <g>
      <PitchWorld H={H} f={f} t={t} cheer={fi > 322} ripple={ripple} />
      {items.map((e) => e.node)}
      <Shadow x={bx} y={byy + 2} w={r * 1.1} o={0.3} />
      <Ball x={bx} y={byy - lift - r * 0.4} r={r} spin={fi * 40} />
    </g>
  );
};

// =====================================================================
// SCENE A — duel jarak dekat (kamera mengikuti pemain yang lari kencang)
// =====================================================================
const DuelScene: React.FC<{t: number}> = ({t}) => {
  const H = 560, gy = 950, hs = H;
  // kecepatan dunia: ~3.4 tinggi badan / detik, mengebut setelah duel
  const Nx = 1900 * t + 650 * Math.max(0, t - 0.9) * sm(prog(t, 0.9, 1.6));
  const cam = Nx - 1020;
  const wf = 0.85;
  const Nwf = 1900 * wf;
  const Wx = t < wf ? Nx - 380 : Nwf - 380 + 520 * (1 - Math.exp(-(t - wf) * 2.4));
  const Bx = Nx + 330 + (t > 0.95 ? 1500 * sm(prog(t, 0.95, 2.5)) * 0.8 + 140 * (t - 0.95) : 0);
  const fall = sm(prog(t, 0.85, 1.4));
  const stripes = [];
  for (let i = -2; i < 8; i++) {
    const x0 = i * 460 - (((cam % 920) + 920) % 920);
    stripes.push(<rect key={i} x={x0} y={700} width={460} height={400} fill={(i + Math.floor(cam / 920) * 2) % 2 ? GRASS1 : GRASS2} />);
  }
  const boards = [];
  for (let i = -1; i < 4; i++) {
    const x = i * 700 - (((cam % 700) + 700) % 700);
    const k = ((i + Math.floor(cam / 700)) % 2 + 2) % 2;
    boards.push(
      <g key={i}>
        <rect x={x} y={610} width={690} height={92} fill={k ? '#7a1830' : '#8c1d38'} />
        <text x={x + 345} y={676} fontSize={56} fontFamily="Poppins, Arial, sans-serif" fontWeight={800} fill="#f3e3b0" textAnchor="middle" letterSpacing={4}>{k ? 'SKY ARENA' : 'FLY HIGH'}</text>
      </g>,
    );
  }
  const cyc = t * 2 * Math.PI * 3.4;
  const r = 34;
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="#162038" />
      <Crowd tx={-cam * 0.3 - 900} ty={-20} s={6} blur={1} />
      <rect width={WIDTH} height={650} fill="url(#gShade)" opacity={0.6} />
      {boards}
      <rect y={700} width={WIDTH} height={400} fill={GRASS1} />
      {stripes}
      <Shadow x={Wx - cam} y={gy + 4} w={150} />
      <Shadow x={1020} y={gy + 4} w={150} />
      <Player x={Wx - cam} y={gy} h={hs} ph={cyc + 1} run={fall > 0 ? 0 : 1} arms={fall > 0 ? 'up' : 'run'} shirt={SKY} short="#222a44" stripes skin={SKIN[3]} rot={-86 * fall} />
      <Player x={1020} y={gy} h={hs} ph={cyc} run={1} shirt={NAVY} short={NAVY_S} sock={NAVY} skin={SKIN[2]} />
      <Shadow x={Bx - cam} y={gy + 6} w={r} o={0.3} />
      <Ball x={Bx - cam} y={gy - r + 6} r={r} spin={Bx * 1.7} />
    </g>
  );
};

// =====================================================================
// WAJAH BESAR & BUST
// =====================================================================
const Face: React.FC<{x: number; y: number; s: number; skin: string; hair: string; shirt: string; mood: 'scream' | 'up' | 'smile'; rot?: number; t: number; back?: boolean}> = ({x, y, s, skin, hair, shirt, mood, rot = 0, t, back}) => {
  const mo = 62 + 12 * Math.sin(t * 14);
  const dk = 'rgba(0,0,0,.18)';
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
      <rect x={-62} y={140} width={124} height={190} fill={skin} />
      <rect x={-62} y={140} width={124} height={60} fill={dk} />
      <path d="M-340 560C-340 380 -160 310 -70 300L70 300C160 310 340 380 340 560Z" fill={shirt} />
      <path d="M-70 300Q0 380 70 300" fill="none" stroke="#c9a24a" strokeWidth={14} />
      <circle cx={-190} cy={440} r={24} fill="#d9b24a" /><circle cx={-190} cy={440} r={13} fill={shirt} />
      <ellipse cx={-172} cy={20} rx={26} ry={44} fill={skin} /><ellipse cx={172} cy={20} rx={26} ry={44} fill={skin} />
      <ellipse cx={0} cy={0} rx={170} ry={205} fill={skin} />
      <path d="M-172 -30C-200 -250 200 -250 172 -30C150 -120 -150 -120 -172 -30Z" fill={hair} />
      {mood === 'scream' && (
        <g>
          <path d="M-125 -62L-30 -30M125 -62L30 -30" stroke={hair} strokeWidth={18} strokeLinecap="round" />
          <path d="M-115 0Q-78 -34 -40 0M115 0Q78 -34 40 0" stroke="#2a1410" strokeWidth={11} fill="none" strokeLinecap="round" />
        </g>
      )}
      {mood === 'up' && (
        <g>
          <path d="M-125 -85L-35 -70M125 -85L35 -70" stroke={hair} strokeWidth={16} strokeLinecap="round" />
          <ellipse cx={-76} cy={-20} rx={36} ry={30} fill="#fff" /><ellipse cx={76} cy={-20} rx={36} ry={30} fill="#fff" />
          <circle cx={-70} cy={-32} r={15} fill="#2a1a10" /><circle cx={82} cy={-32} r={15} fill="#2a1a10" />
        </g>
      )}
      {mood === 'smile' && (
        <g>
          <path d="M-125 -72L-35 -62M125 -72L35 -62" stroke={hair} strokeWidth={16} strokeLinecap="round" />
          <path d="M-115 -4Q-78 -38 -40 -4M115 -4Q78 -38 40 -4" stroke="#2a1410" strokeWidth={11} fill="none" strokeLinecap="round" />
        </g>
      )}
      <path d="M0 5L-16 75Q0 92 20 75" stroke="rgba(0,0,0,.28)" strokeWidth={9} fill="none" strokeLinecap="round" />
      {mood !== 'smile' ? (
        <g>
          <clipPath id={'mc' + Math.round(x)}><ellipse cx={0} cy={135} rx={88} ry={mo} /></clipPath>
          <ellipse cx={0} cy={135} rx={88} ry={mo} fill="#5a1620" />
          <g clipPath={`url(#mc${Math.round(x)})`}>
            <path d="M-90 80Q0 60 90 80L90 112Q0 94 -90 112Z" fill="#fff" />
            <ellipse cx={0} cy={190} rx={52} ry={30} fill="#d8606c" />
          </g>
        </g>
      ) : (
        <path d="M-85 105Q0 205 85 105Q0 135 -85 105Z" fill="#fff" stroke="#5a1620" strokeWidth={8} strokeLinejoin="round" />
      )}
      <ellipse cx={-110} cy={80} rx={30} ry={18} fill="#e0605a" opacity={0.25} /><ellipse cx={110} cy={80} rx={30} ry={18} fill="#e0605a" opacity={0.25} />
    </g>
  );
};

const Arm: React.FC<{x1: number; y1: number; x2: number; y2: number; sleeve: string; skin: string; w?: number}> = ({x1, y1, x2, y2, sleeve, skin, w = 90}) => {
  const mx = lerp(x1, x2, 0.55), my = lerp(y1, y2, 0.55);
  return (
    <g strokeLinecap="round">
      <path d={`M${x1} ${y1}L${mx} ${my}`} stroke={sleeve} strokeWidth={w} />
      <path d={`M${mx} ${my}L${x2} ${y2}`} stroke={skin} strokeWidth={w * 0.72} />
      <circle cx={x2} cy={y2} r={w * 0.52} fill={skin} />
    </g>
  );
};

const GrassBG: React.FC<{t: number; sway?: number}> = ({t, sway = 1}) => (
  <g>
    <rect width={WIDTH} height={HEIGHT} fill="url(#gGrass)" />
    <path d={`M-100 ${300 + Math.sin(t) * 10}L2100 ${180 + Math.sin(t) * 10}`} stroke="#fff" strokeWidth={14} opacity={0.5} />
    <g filter="url(#bl2)" opacity={0.7}>
      <ellipse cx={1500 + 40 * Math.sin(t * 0.7) * sway} cy={430} rx={110} ry={210} fill={NAVY} />
      <ellipse cx={260} cy={470} rx={90} ry={200} fill={NAVY} />
      <ellipse cx={780} cy={330} rx={60} ry={130} fill="#fff" opacity={0.7} />
    </g>
  </g>
);

const CloseUp1: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const sx = Math.sin(t * 23) * 6, sy = Math.cos(t * 19) * 5;
  const pump = Math.sin(t * 7);
  return (
    <g>
      <GrassBG t={t} />
      <Arm x1={420} y1={1000} x2={520 + sx} y2={500 + pump * 40} sleeve={NAVY} skin={SKIN[0]} />
      <Arm x1={1500} y1={1000} x2={1400 + sx} y2={540 - pump * 40} sleeve={NAVY} skin={SKIN[0]} />
      <Face x={960 + sx} y={440 + sy + sm(prog(lt, 0, 0.4)) * 0} s={1.55} skin={SKIN[0]} hair="#1c1410" shirt={NAVY} mood="scream" rot={Math.sin(t * 3) * 3} t={t} />
    </g>
  );
};
const CloseUp2: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const sx = Math.sin(t * 17) * 5;
  const slide = sm(prog(lt, 0, 0.6));
  return (
    <g>
      <GrassBG t={t} />
      <g transform={`translate(${lerp(-500, 0, slide)},0)`}>
        <rect x={-60} y={430} width={760} height={700} rx={140} fill={NAVY} transform="rotate(-8 300 700)" />
        <circle cx={540} cy={560} r={50} fill="#d9b24a" opacity={0.9} />
        <Arm x1={150} y1={620} x2={720} y2={420 + 30 * Math.sin(t * 8)} sleeve={NAVY} skin={SKIN[2]} w={110} />
      </g>
      <Face x={1130 + sx} y={500} s={1.45} skin={SKIN[0]} hair="#1c1410" shirt={NAVY} mood="up" rot={-7 + Math.sin(t * 4) * 2} t={t} />
    </g>
  );
};
const CloseUp3: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const b = Math.sin(t * 9) * 8;
  return (
    <g>
      <GrassBG t={t} />
      <Face x={760} y={380 + b} s={1.15} skin={SKIN[2]} hair="#0e0a08" shirt={NAVY_S} mood="scream" rot={-6} t={t + 1} />
      <Face x={1150} y={600 + b * 0.5} s={1.4} skin={SKIN[0]} hair="#1c1410" shirt={NAVY} mood="smile" rot={5} t={t} />
      <Arm x1={620} y1={720} x2={1000} y2={900} sleeve={NAVY_S} skin={SKIN[2]} w={120} />
      <Arm x1={1000} y1={760} x2={1500} y2={960} sleeve={NAVY_S} skin={SKIN[2]} w={110} />
    </g>
  );
};

// ---------- bust (VIP & penonton) ----------
type BustProps = {x: number; y: number; s: number; skin: string; kind: 'suit' | 'thobe' | 'shirt'; col?: string; hair?: string; pose: 'clap' | 'fist' | 'cheer' | 'still'; t: number; ph: number; open?: boolean; scarf?: boolean};
const Bust: React.FC<BustProps> = ({x, y, s, skin, kind, col = '#1d2230', hair = '#1c1410', pose, t, ph, open, scarf}) => {
  const c = Math.abs(Math.cos(t * 8 + ph));
  const hands: [number, number, number, number] =
    pose === 'clap' ? [-28 - 70 * c, 260, 28 + 70 * c, 260]
      : pose === 'fist' ? [-215, 20 + 30 * Math.sin(t * 7 + ph), 215, 40 - 30 * Math.sin(t * 7 + ph)]
        : pose === 'cheer' ? [-230 - 20 * Math.sin(t * 6 + ph), -150 + 40 * Math.sin(t * 8 + ph), 230 + 20 * Math.sin(t * 6 + ph + 1), -170 + 40 * Math.sin(t * 8 + ph + 2)]
          : [-170, 330, 170, 330];
  const sleeve = kind === 'thobe' ? '#f6f6f8' : col;
  const body = kind === 'thobe' ? '#f6f6f8' : col;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <path d="M-200 360C-200 200 -120 150 0 150C120 150 200 200 200 360Z" fill={body} />
      {kind === 'suit' && (<><path d="M-34 150L0 260L34 150Z" fill="#f4f4f6" /><path d="M-9 165L9 165L14 240L0 262L-14 240Z" fill="#b4202e" /></>)}
      {kind === 'shirt' && <path d="M-50 150Q0 200 50 150" stroke="#fff" strokeWidth={10} fill="none" />}
      {scarf && <path d="M-80 150Q0 200 80 150L80 190Q0 240 -80 190Z" fill="#c0303c" />}
      <g strokeLinecap="round">
        <path d={`M-165 215L${hands[0]} ${hands[1]}`} stroke={sleeve} strokeWidth={62} />
        <path d={`M165 215L${hands[2]} ${hands[3]}`} stroke={sleeve} strokeWidth={62} />
      </g>
      {kind === 'thobe' ? (
        <g>
          <path d="M-135 -10C-135 -150 135 -150 135 -10L158 180L-158 180Z" fill="#f6f6f8" />
          <ellipse cx={0} cy={5} rx={78} ry={92} fill={skin} />
          <path d="M-98 -78Q0 -150 98 -78" stroke="#15151a" strokeWidth={16} fill="none" strokeLinecap="round" />
        </g>
      ) : (
        <g>
          <ellipse cx={0} cy={0} rx={80} ry={94} fill={skin} />
          <path d="M-80 -20C-90 -130 90 -130 80 -20C60 -75 -60 -75 -80 -20Z" fill={hair} />
        </g>
      )}
      <path d="M-50 -34L-22 -40M50 -34L22 -40" stroke={kind === 'thobe' ? '#222' : hair} strokeWidth={7} strokeLinecap="round" />
      <circle cx={-30} cy={-12} r={7} fill="#241812" /><circle cx={30} cy={-12} r={7} fill="#241812" />
      {open ? (<ellipse cx={0} cy={46} rx={26} ry={12 + 8 * Math.abs(Math.sin(t * 9 + ph))} fill="#5a1620" />) : (<path d="M-26 40Q0 62 26 40" stroke="#5a1620" strokeWidth={7} fill="none" strokeLinecap="round" />)}
      <circle cx={hands[0]} cy={hands[1]} r={34} fill={skin} /><circle cx={hands[2]} cy={hands[3]} r={34} fill={skin} />
    </g>
  );
};

const VipScene: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const up = lt < 1.2;
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="url(#gVip)" />
      <Crowd tx={-200} ty={60} s={7} blur={1} dim={0.2} />
      <rect width={WIDTH} height={HEIGHT} fill="#8aa0d0" opacity={0.45} />
      <g transform={`translate(0,${Math.sin(t * 1.2) * 6})`}>
        <Bust x={330} y={470} s={1.55} skin={SKIN[3]} kind="thobe" pose="clap" t={t} ph={0.5} />
        <Bust x={800} y={500} s={1.7} skin={SKIN[3]} kind="suit" hair="#1a1410" pose={up ? 'fist' : 'clap'} t={t} ph={0} open />
        <Bust x={1290} y={520} s={1.6} skin={SKIN[0]} kind="suit" hair="#6b6b70" pose="clap" t={t} ph={1.3} />
        <Bust x={1700} y={480} s={1.5} skin={SKIN[1]} kind="thobe" pose="still" t={t} ph={2} />
      </g>
      <rect y={930} width={WIDTH} height={160} fill="#2a2220" />
      <rect y={930} width={WIDTH} height={14} fill="#c9a24a" />
    </g>
  );
};

// =====================================================================
// SCENE F — sorak perayaan dari kamera tinggi
// =====================================================================
const CelebrateScene: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const HL = homAt(NF - 1), OX = 300, OY = -30;
  const zoom = 1 + 0.9 * sm(prog(lt, 4.6, 7.0));
  const px = 1070, py = 650;
  const nodes: {v: number; n: React.ReactNode}[] = [];
  const add = (key: string, u: number, v: number, o: Partial<PlayerProps> & {shirt: string; short: string}, jump = 0) => {
    const [x0, y0] = proj(HL, u, v);
    const x = x0 + OX, y = y0 + OY;
    const hh = hAt(NF - 1, y0 / 1.5) * 1.5;
    nodes.push({v, n: (
      <g key={key}>
        <Shadow x={x} y={y + 1} w={hh * 0.26} />
        <Player x={x} y={y - jump * hh * 0.22} h={hh} {...o} />
      </g>
    )});
  };
  const mt = prog(lt, 0, 4.0);
  const pile = prog(lt, 3.8, 4.6);
  // pencetak gol lari ke bendera sudut
  {
    const [u, v] = [lerp(95, 104, sm(mt)), lerp(36, 2.6, sm(mt))];
    add('s', u, v, {shirt: NAVY, short: NAVY_S, sock: NAVY, skin: SKIN[0], ph: t * 24, run: mt < 1 ? 1 : 0, arms: 'out'}, pile > 0.9 ? Math.abs(Math.sin(t * 8)) : 0);
  }
  [[70, 20], [74, 46], [80, 60], [66, 36], [84, 30], [90, 50]].forEach(([bu, bv], i) => {
    const ang = (i / 6) * Math.PI * 2;
    const tu = 103.4 + Math.cos(ang) * 1.5, tv = 2.8 + Math.sin(ang) * 1.5;
    const p = sm(prog(lt, 0.4, 4.2 + i * 0.15));
    add('t' + i, lerp(bu, tu, p), lerp(bv, tv, p), {shirt: NAVY, short: NAVY_S, sock: NAVY, skin: SKIN[(i + 1) % 5], ph: t * 24 + i, run: p < 1 ? 1 : 0, arms: p < 1 ? 'run' : 'up'}, p >= 1 ? Math.abs(Math.sin(t * 7 + i)) : 0);
  });
  // staf berompi kuning
  [0, 1, 2, 3].forEach((i) => {
    const p = sm(prog(lt, 2.2 + i * 0.2, 4.6));
    add('st' + i, lerp(96 + i, 102 + i * 0.6, p), lerp(-3.6, 3.4, p), {shirt: '#e6d31c', short: '#222', sock: '#222', skin: SKIN[(i + 2) % 5], ph: t * 24 + i, run: p < 1 ? 1 : 0.1, arms: 'run'});
  });
  // lawan lesu
  [[85, 28], [88, 44], [92, 20], [90, 55], [80, 34]].forEach(([bu, bv], i) => {
    add('w' + i, bu - sm(prog(lt, 1, 6)) * 4, bv + Math.sin(i) * 0.5, {shirt: SKY, short: '#222a44', stripes: true, skin: SKIN[i % 5], run: 0.15, ph: t * 2 + i, arms: 'hips'});
  });
  add('gk', 104.5, 34, {shirt: '#c5d733', short: '#1b1b1b', sock: '#1b1b1b', f: -1, run: 0, arms: 'hips'});
  nodes.sort((a, b) => a.v - b.v);
  return (
    <g transform={`translate(${px},${py}) scale(${zoom}) translate(${-px},${-py})`}>
      <PitchWorld H={HL} f={NF - 1} t={t} cheer ox={OX} oy={OY} />
      {nodes.map((e) => e.n)}
    </g>
  );
};

// =====================================================================
// SCENE G — sorak penonton + piala
// =====================================================================
const CrowdScene: React.FC<{t: number; lt: number}> = ({t, lt}) => {
  const sway = Math.sin(t * 1.4) * 14;
  const fans = Array.from({length: 11}, (_, i) => {
    const row = i % 2;
    const x = 130 + i * 165 + (row ? 60 : 0) + sway * (row ? 1 : 0.5);
    const y = 560 + row * 210 + Math.abs(Math.sin(t * 6 + i * 1.3)) * -34;
    const kinds: ('shirt' | 'suit')[] = ['shirt', 'shirt'];
    return (
      <Bust key={i} x={x} y={y} s={1.05 + row * 0.2} skin={SKIN[i % 5]} kind={kinds[row]} col={[ '#1b2a58', '#8fc9ee', '#2a4aa0', '#f4f6fa', '#c0303c', '#1b2a58'][i % 6]} hair={['#1c1410', '#4a3020', '#8a8a90', '#0e0a08'][i % 4]} pose={i % 3 === 0 ? 'fist' : 'cheer'} t={t} ph={i * 1.7} open scarf={i % 4 === 1} />
    );
  });
  const flags = [0, 1, 2].map((i) => {
    const fx = 420 + i * 520, fy = 120 + (i % 2) * 40;
    const wv = (k: number) => Math.sin(t * 7 + k * 1.1 + i) * 10;
    const cols = ['#2a4aa0', '#ffffff', '#d03040'];
    return (
      <g key={i}>
        <path d={`M${fx} ${fy}V${fy + 520}`} stroke="#ddd" strokeWidth={9} />
        {cols.map((cl, k) => (<path key={k} d={`M${fx} ${fy + k * 70}q${70} ${wv(k)} ${140} ${wv(k + 1)} q${70} ${wv(k + 2)} ${130} ${wv(k + 3)}V${fy + k * 70 + 70}q${-60} ${-wv(k)} ${-130} ${-wv(k + 2)}q${-70} ${wv(k)} ${-140} ${wv(k + 3)}Z`} fill={cl} />))}
      </g>
    );
  });
  const trophy = sm(prog(lt, 1.35, 2.2));
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="#22305e" />
      <Crowd tx={-300 + sway * 2} ty={-20} s={7} blur={1} />
      <rect width={WIDTH} height={HEIGHT} fill="#0a1020" opacity={0.25} />
      {flags}
      {fans}
      <g transform={`translate(${1650},${lerp(1560, 860, trophy)})`}>
        <circle r={190} cy={-120} fill="#ffe9a0" opacity={0.25 * trophy} />
        <path d="M-70 -300C-70 -190 -45 -130 -18 -90L-18 -40L-60 0L60 0L18 -40L18 -90C45 -130 70 -190 70 -300Z" fill="#e6bc47" />
        <path d="M-70 -280C-120 -280 -120 -190 -50 -170M70 -280C120 -280 120 -190 50 -170" stroke="#e6bc47" strokeWidth={18} fill="none" />
        <path d="M-40 -280C-40 -190 -20 -140 -4 -100" stroke="#fff6cc" strokeWidth={10} fill="none" opacity={0.7} />
        <rect x={-62} y={-4} width={124} height={30} rx={6} fill="#2e7d4f" />
      </g>
    </g>
  );
};

// =====================================================================
// KOMPOSISI UTAMA
// =====================================================================
const CUTS = {duel: [0, 2.5], pitch: [2.5, 14.6], c1: [14.6, 17.4], c2: [17.4, 20.0], c3: [20.0, 21.8], vip: [21.8, 25.6], cel: [25.6, 32.8], crowd: [32.8, 99]} as const;

export const Bola: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const inn = (k: keyof typeof CUTS) => t >= CUTS[k][0] && t < CUTS[k][1];
  const lt = (k: keyof typeof CUTS) => t - CUTS[k][0];
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Audio src={staticFile('audio.mp3')} />
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0}}>
        <Defs />
        {inn('duel') && <DuelScene t={t} />}
        {inn('pitch') && <PitchScene t={t} />}
        {inn('c1') && <CloseUp1 t={t} lt={lt('c1')} />}
        {inn('c2') && <CloseUp2 t={t} lt={lt('c2')} />}
        {inn('c3') && <CloseUp3 t={t} lt={lt('c3')} />}
        {inn('vip') && <VipScene t={t} lt={lt('vip')} />}
        {inn('cel') && <CelebrateScene t={t} lt={lt('cel')} />}
        {inn('crowd') && <CrowdScene t={t} lt={lt('crowd')} />}
        <rect width={WIDTH} height={HEIGHT} fill="url(#gShade)" opacity={0.25} />
        <Scoreboard t={t} />
      </svg>
    </AbsoluteFill>
  );
};
