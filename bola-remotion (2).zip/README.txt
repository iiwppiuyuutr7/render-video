Bola - animasi gol kartun (16:9, 1920x1080, 60fps, 35.57 detik)
File: Bola.tsx, Root.tsx, trackdata.ts (data posisi pemain/bola/kamera hasil lacak dari videomu), public/audio.mp3
Taruh semuanya di src/ proyek Remotion (audio di public/).
Render: npx remotion render Bola out/bola.mp4

v3: tribun lengkap (sisi jauh + belakang gawang + sudut) dengan penonton berbentuk orang (kepala, bahu, tangan),
    bersorak setelah gol; papan iklan di sisi jauh & belakang gawang.
    Gerak pemain: condong badan, naik-turun, siku/lutut menekuk, tendangan di 3 momen, arah hadap halus.
v3.2: bola lebih besar; papan iklan membentuk persegi tertutup (tidak menembus tribun); adegan perayaan memakai tribun 3D yang sama.
