import React from 'react';
import {Composition} from 'remotion';
import {Kota} from './Kota';

export const RemotionRoot: React.FC = () => (
  <Composition id="Kota" component={Kota} durationInFrames={900} fps={30} width={1080} height={1920} />
);
