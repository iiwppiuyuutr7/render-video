import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  MALAM HUJAN DI KOTA KECIL  ·  30 detik, 1080x1920
  Kota voxel isometrik "3D" murni SVG (tanpa WebGL), jadi ringan di RAM.
  Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const TW = 200; // lebar tile
const ZH = 80; // tinggi 1 unit

/* ---------- util ---------- */
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (t: number, a: number, b: number, from = 0, to = 1, easing: (x: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(t, [a, b], [from, to], {...cl, easing});
const lin = Easing.linear;
const outC = Easing.out(Easing.cubic);

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const hx = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const toHex = (v: number[]) => '#' + v.map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0')).join('');
const blend = (a: string, b: string, k: number) => {
  const A = hx(a);
  const B = hx(b);
  return toHex(A.map((v, i) => v + (B[i] - v) * k));
};
// warna malam: sedikit kebiruan lalu digelapkan
const shade = (c: string, k: number) => blend(blend(c, '#0b1230', 0.28), '#000000', k);

const iso = (x: number, y: number, z: number): [number, number] => [((x - y) * TW) / 2, ((x + y) * TW) / 4 - z * ZH];
const P = (pts: [number, number][]) => pts.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
// matriks dekal untuk sisi +y (kiri-bawah) dan +x (kanan-bawah) sebuah balok
const mY = (x: number, y: number, z: number, d: number) => {
  const [ox, oy] = iso(x, y + d, z);
  return `matrix(${TW / 2} ${TW / 4} 0 ${-ZH} ${ox.toFixed(1)} ${oy.toFixed(1)})`;
};
const mX = (x: number, y: number, z: number, w: number) => {
  const [ox, oy] = iso(x + w, y, z);
  return `matrix(${-TW / 2} ${TW / 4} 0 ${-ZH} ${ox.toFixed(1)} ${oy.toFixed(1)})`;
};

/* ---------- dialog (harus sama dengan skrip audio) ---------- */
type Line = {who: 'main' | 'npc'; a: number; b: number; text: string[]};
const DIALOG: Line[] = [
  {who: 'main', a: 14.0, b: 16.6, text: ['Permisi, mas. Tau toko', 'buku yang masih buka?']},
  {who: 'npc', a: 17.0, b: 19.8, text: ['Oh, itu di ujung jalan.', 'Lampunya yang kuning.']},
  {who: 'main', a: 20.2, b: 22.4, text: ['Hujan-hujan gini', 'masih buka?']},
  {who: 'npc', a: 22.8, b: 25.2, text: ['Buka terus. Pemiliknya', 'nggak pernah tidur.']},
  {who: 'main', a: 25.5, b: 27.2, text: ['Wah, keren.', 'Makasih ya!']},
];

/* ---------- gerak tokoh ---------- */
const mainX = (t: number) => (t < 0.8 ? 0.2 : t < 13.0 ? 0.2 + (12.8 * (t - 0.8)) / 12.2 : t < 27.3 ? 13.0 : 13.0 + 1.2 * (t - 27.3));
const mainY = (t: number) => -0.62 + 0.62 * ramp(t, 27.3, 28.6);
const moving = (t: number) => (t >= 0.8 && t < 13.0) || t >= 27.3;
const NPC_X = 14.8;
const NPC_Y = -0.75;

/* ---------- dunia statis ---------- */
type Draw = {key: number; cx: number; cy: number; r: number; node: React.ReactNode};

const Box: React.FC<{x: number; y: number; z: number; w: number; d: number; h: number; c: string; top?: string; dk?: number}> = ({x, y, z, w, d, h, c, top, dk = 0}) => {
  const tp = P([iso(x, y, z + h), iso(x + w, y, z + h), iso(x + w, y + d, z + h), iso(x, y + d, z + h)]);
  const lf = P([iso(x, y + d, z + h), iso(x + w, y + d, z + h), iso(x + w, y + d, z), iso(x, y + d, z)]);
  const rt = P([iso(x + w, y, z + h), iso(x + w, y + d, z + h), iso(x + w, y + d, z), iso(x + w, y, z)]);
  return (
    <g>
      <polygon points={lf} fill={shade(c, 0.22 + dk)} />
      <polygon points={rt} fill={shade(c, 0.42 + dk)} />
      <polygon points={tp} fill={shade(top ?? c, 0.0 + dk)} />
    </g>
  );
};

const statics: Draw[] = [];
const rngB = mulberry32(5);
const WARM = '#ffcf70';
const COOL = '#8fc4ff';

const BACK = [
  {w: 3.6, h: 5.2, c: '#3d7f8f'},
  {w: 3.0, h: 3.6, c: '#c9a07a'},
  {w: 3.4, h: 6.4, c: '#8a4b5e'},
  {w: 3.2, h: 4.2, c: '#4f6aa8'},
  {w: 3.6, h: 5.0, c: '#b9704a'},
  {w: 3.6, h: 3.8, c: '#5a8f6b'},
  {w: 4.2, h: 3.4, c: '#d9b25f', kind: 'kopi'},
  {w: 3.4, h: 6.0, c: '#46608f'},
  {w: 5.4, h: 3.6, c: '#8a3b2e', kind: 'buku'},
  {w: 3.2, h: 5.4, c: '#3d7f8f'},
  {w: 3.8, h: 4.0, c: '#a45d73'},
  {w: 3.4, h: 6.2, c: '#4f6aa8'},
  {w: 3.6, h: 4.6, c: '#c9a07a'},
];

(() => {
  let x = -8;
  BACK.forEach((b: any, i) => {
    const y = -5.3;
    const d = 4.0;
    const kids: React.ReactNode[] = [];
    // jendela sisi +y (menghadap jalan)
    const cols = Math.max(2, Math.floor(b.w / 0.95));
    const startRow = b.kind ? 2.6 : 1.0;
    const wins: React.ReactNode[] = [];
    for (let r = 0; startRow + r * 1.25 + 0.7 < b.h - 0.2; r++) {
      for (let k = 0; k < cols; k++) {
        const lit = rngB() < 0.55;
        const u = 0.35 + k * ((b.w - 0.7) / cols);
        wins.push(<rect key={`w${r}_${k}`} x={u} y={startRow + r * 1.25} width={0.5} height={0.65} fill={lit ? (rngB() < 0.8 ? WARM : COOL) : '#16254a'} />);
      }
    }
    // jendela sisi +x
    const wins2: React.ReactNode[] = [];
    const cols2 = Math.floor(d / 1.0);
    for (let r = 0; 1.0 + r * 1.25 + 0.7 < b.h - 0.2; r++) {
      for (let k = 0; k < cols2; k++) {
        const lit = rngB() < 0.45;
        wins2.push(<rect key={`v${r}_${k}`} x={0.35 + k * 0.95} y={1.0 + r * 1.25} width={0.5} height={0.65} fill={lit ? WARM : '#16254a'} />);
      }
    }
    const yFront = y + d; // = -1.3
    kids.push(<Box key="b" x={x} y={y} z={0} w={b.w} d={d} h={b.h} c={b.c} top={blend(b.c, '#ffffff', 0.12)} />);
    kids.push(<g key="wy" transform={mY(x, y, 0, d)}>{wins}</g>);
    kids.push(<g key="wx" transform={mX(x, y, 0, b.w)}>{wins2}</g>);
    // lantai dasar: pintu
    kids.push(
      <g key="door" transform={mY(x, y, 0, d)}>
        <rect x={b.w / 2 - 0.35} y={0} width={0.7} height={1.35} fill="#241a2e" />
      </g>,
    );
    // atap: tangki / antena
    if (i % 3 === 1) kids.push(<Box key="tank" x={x + 0.6} y={y + 1.0} z={b.h} w={0.9} d={0.9} h={0.8} c="#5b6477" />);
    if (i % 4 === 2) kids.push(<Box key="ant" x={x + b.w - 0.9} y={y + 2.4} z={b.h} w={0.12} d={0.12} h={1.4} c="#7b8399" />);
    if (b.kind === 'kopi') {
      kids.push(
        <g key="kopi" transform={mY(x, y, 0, d)}>
          <rect x={0.4} y={0.45} width={b.w - 0.8} height={1.5} fill="#ffd9a0" />
          <rect x={0.4} y={0.45} width={b.w - 0.8} height={0.12} fill="#fff1d6" />
          <rect x={0.5} y={2.1} width={1.9} height={0.5} fill="#20142a" />
          <text x={0.62} y={2.18} fontSize={0.34} fontFamily={cond} fontWeight={700} fill="#ffd9a0" transform="translate(0 0.34) scale(1 1)" />
        </g>,
      );
      kids.push(<AwningNode key="aw" x={x} w={b.w} y0={yFront} />);
    }
    if (b.kind === 'buku') {
      kids.push(
        <g key="buku" transform={mY(x, y, 0, d)}>
          <rect x={0.35} y={0.4} width={b.w - 1.5} height={1.55} fill="#ffd36a" />
          {[0.9, 1.7, 2.5].map((u) => (
            <rect key={u} x={u} y={0.4} width={0.08} height={1.55} fill="#b8862a" />
          ))}
          <rect x={b.w - 0.95} y={0} width={0.65} height={1.45} fill="#3a2a1a" />
          <rect x={0.2} y={2.15} width={b.w - 0.4} height={0.62} fill="#1a1322" />
        </g>,
      );
      kids.push(<AwningNode key="aw" x={x} w={b.w} y0={yFront} />);
    }
    statics.push({key: x + b.w / 2 + y + d / 2, cx: iso(x + b.w / 2, y + d / 2, 0)[0], cy: 0, r: 700, node: <g key={`bk${i}`}>{kids}</g>});
    x += b.w;
  });
})();

function AwningNode({x, w, y0}: {x: number; w: number; y0: number}) {
  // kanopi miring di atas trotoar belakang
  const z = 2.45;
  const n = Math.floor(w / 0.6);
  const out: React.ReactNode[] = [];
  for (let i = 0; i < n; i++) {
    const a = x + i * (w / n);
    const b = a + w / n;
    out.push(
      <polygon
        key={i}
        points={P([iso(a, y0, z + 0.2), iso(b, y0, z + 0.2), iso(b, y0 + 0.95, z), iso(a, y0 + 0.95, z)])}
        fill={i % 2 ? '#fff1d6' : '#ff7a1a'}
        opacity={0.96}
      />,
    );
  }
  return <g>{out}</g>;
}

// sisi depan: bangunan rendah + pohon + lampu jalan
(() => {
  let x = -8;
  const cs = ['#7a5a8f', '#c46a4f', '#4f8f8a', '#b08f5a', '#5f6fa8'];
  let i = 0;
  while (x < 36) {
    const w = 2.6 + rngB() * 1.6;
    const h = 1.2 + rngB() * 1.0;
    const y = 4.4;
    const c = cs[i % cs.length];
    statics.push({
      key: x + w / 2 + y + 1.2,
      cx: iso(x + w / 2, y + 1.2, 0)[0],
      cy: 0,
      r: 400,
      node: (
        <g key={`fr${i}`}>
          <Box x={x} y={y} z={0} w={w} d={2.4} h={h} c={c} top={blend(c, '#ffffff', 0.1)} />
          <g transform={mY(x, y, 0, 2.4)}>
            <rect x={0.4} y={0.4} width={0.55} height={0.5} fill={rngB() < 0.6 ? WARM : '#16254a'} />
            <rect x={w - 1.0} y={0.4} width={0.55} height={0.5} fill={rngB() < 0.6 ? WARM : '#16254a'} />
          </g>
        </g>
      ),
    });
    x += w + 0.35;
    i++;
  }
  [5, 11, 17, 23, 29].forEach((tx, k) => {
    const ty = 3.0;
    statics.push({
      key: tx + ty + 0.3,
      cx: iso(tx, ty, 0)[0],
      cy: 0,
      r: 160,
      node: (
        <g key={`tree${k}`}>
          <Box x={tx} y={ty} z={0} w={0.28} d={0.28} h={0.9} c="#6b4a2e" />
          <Box x={tx - 0.35} y={ty - 0.35} z={0.8} w={1.0} d={1.0} h={0.8} c="#3f8f4f" />
          <Box x={tx - 0.2} y={ty - 0.2} z={1.6} w={0.7} d={0.7} h={0.6} c="#4fa35f" />
        </g>
      ),
    });
  });
  [2, 8, 14, 20, 26].forEach((lx, k) => {
    const ly = 2.7;
    statics.push({
      key: lx + ly + 0.1,
      cx: iso(lx, ly, 0)[0],
      cy: 0,
      r: 200,
      node: (
        <g key={`lamp${k}`}>
          <Box x={lx} y={ly} z={0} w={0.12} d={0.12} h={2.7} c="#3a4258" />
          <Box x={lx - 0.2} y={ly - 0.2} z={2.7} w={0.52} d={0.52} h={0.2} c="#ffe9b0" top="#fff6d8" dk={-0.2} />
        </g>
      ),
    });
  });
})();

const LAMPS = [2, 8, 14, 20, 26];

/* ---------- potongan dinamis ---------- */
const Person: React.FC<{
  x: number;
  y: number;
  face: 1 | -1;
  phase: number;
  walk: number;
  talk: boolean;
  t: number;
  body: string;
  pants: string;
  hat: string;
  arm?: 'point' | 'wave' | 'none';
  lift?: number;
}> = ({x, y, face, phase, walk, talk, t, body, pants, hat, arm = 'none', lift = 0}) => {
  const PS = 1.3;
  const s = Math.sin(phase) * walk;
  const bounce = Math.abs(Math.cos(phase)) * 0.06 * walk + (talk ? Math.abs(Math.sin(t * 9)) * 0.025 : 0) + lift;
  const skin = '#f0c9a0';
  const parts: {k: number; z: number; node: React.ReactNode}[] = [];
  const add = (ox: number, oy: number, z: number, w: number, d: number, h: number, c: string, top?: string) =>
    parts.push({k: ox + oy, z, node: <Box key={parts.length} x={x + (ox - w / 2) * PS} y={y + (oy - d / 2) * PS} z={(z + bounce) * PS} w={w * PS} d={d * PS} h={h * PS} c={c} top={top} />});
  // kaki
  add(s * 0.22, -0.14, 0 + Math.max(0, -s) * 0.06, 0.22, 0.22, 0.72, pants);
  add(-s * 0.22, 0.14, 0 + Math.max(0, s) * 0.06, 0.22, 0.22, 0.72, pants);
  // badan
  add(0, 0, 0.7, 0.36, 0.62, 0.72, body);
  // lengan
  const pointing = arm === 'point';
  const waving = arm === 'wave';
  add(-s * 0.2 * face, -0.4, 0.74, 0.16, 0.16, 0.62, body);
  if (pointing) {
    add(face * 0.38, 0.4, 1.12, 0.78, 0.16, 0.16, body);
  } else if (waving) {
    add(0.06 * face + Math.sin(t * 9) * 0.1, 0.4, 1.0, 0.16, 0.16, 0.7, body);
  } else {
    add(s * 0.2 * face, 0.4, 0.74, 0.16, 0.16, 0.62, body);
  }
  // kepala + topi
  add(0, 0, 1.42, 0.42, 0.42, 0.42, skin, '#f7d8b6');
  add(0, 0, 1.78, 0.5, 0.5, 0.16, hat);
  parts.sort((a, b) => a.k - b.k || a.z - b.z);

  // wajah di sisi yang terlihat
  const hz = (1.42 + bounce) * PS;
  const mouth = talk && Math.sin(t * 14) > 0 ? 0.1 : 0.04;
  const face2 =
    face === 1 ? (
      <g transform={mX(x - 0.21 * PS, y - 0.21 * PS, hz, 0.42 * PS)}>
        <rect x={0.08 * PS} y={0.2 * PS} width={0.07 * PS} height={0.09 * PS} fill="#1a1020" />
        <rect x={0.27 * PS} y={0.2 * PS} width={0.07 * PS} height={0.09 * PS} fill="#1a1020" />
        <rect x={0.15 * PS} y={0.06 * PS} width={0.12 * PS} height={mouth * PS} fill="#7a2a2a" />
      </g>
    ) : (
      <g transform={mY(x - 0.21 * PS, y - 0.21 * PS, hz, 0.42 * PS)}>
        <rect x={0.06 * PS} y={0.2 * PS} width={0.07 * PS} height={0.09 * PS} fill="#1a1020" />
        <rect x={0.04 * PS} y={0.06 * PS} width={0.1 * PS} height={mouth * PS} fill="#7a2a2a" />
      </g>
    );
  return (
    <g>
      {parts.map((p) => p.node)}
      {face2}
    </g>
  );
};

const Umbrella: React.FC<{x: number; y: number; z: number; o: number}> = ({x, y, z, o}) => {
  if (o <= 0.01) return null;
  const [cx, cy] = iso(x, y, z);
  const rx = 0.8 * TW * 0.7071;
  const ry = 0.8 * TW * 0.3536;
  return (
    <g opacity={o}>
      <line x1={cx} y1={cy} x2={cx} y2={cy + 0.9 * ZH} stroke="#3a3a4a" strokeWidth={5} />
      <ellipse cx={cx} cy={cy + 10} rx={rx} ry={ry} fill="#b8860b" />
      <ellipse cx={cx} cy={cy - 6} rx={rx} ry={ry} fill="#ffd166" />
      <ellipse cx={cx} cy={cy - 14} rx={rx * 0.55} ry={ry * 0.55} fill="#ffe29a" />
    </g>
  );
};

const Car: React.FC<{x: number; y: number; dir: 1 | -1; c: string; bus?: boolean}> = ({x, y, dir, c, bus}) => {
  const L = bus ? 3.4 : 1.8;
  const hh = bus ? 1.0 : 0.5;
  const cx = x - L / 2;
  const [fx, fy] = iso(dir === 1 ? cx + L : cx, y + 0.4, 0.3);
  return (
    <g>
      <Box x={cx} y={y} z={0.15} w={L} d={0.8} h={hh} c={c} />
      {!bus && <Box x={cx + 0.45} y={y + 0.05} z={0.15 + hh} w={0.95} d={0.7} h={0.38} c={blend(c, '#ffffff', 0.15)} />}
      {bus && (
        <g transform={mY(cx, y, 0.15, 0.8)}>
          {Array.from({length: 6}, (_, i) => (
            <rect key={i} x={0.2 + i * 0.5} y={0.5} width={0.38} height={0.4} fill="#ffe29a" />
          ))}
        </g>
      )}
      {[0.25, L - 0.55].map((o, i) => (
        <Box key={i} x={cx + o} y={y + 0.65} z={0} w={0.35} d={0.2} h={0.35} c="#15181f" />
      ))}
      <circle cx={fx} cy={fy} r={34} fill="url(#hl)" />
      <circle cx={fx} cy={fy} r={9} fill="#fff6d8" />
    </g>
  );
};

/* ---------- komponen utama ---------- */
const WrapLines: React.FC<{line: Line; t: number; sx: number; sy: number}> = ({line, t, sx, sy}) => {
  const tot = line.text.join('').length;
  const shown = Math.floor(tot * ramp(t, line.a, line.a + 0.8 * (line.b - line.a), 0, 1, lin) + 0.0001);
  let left = shown;
  const bw = Math.max(...line.text.map((s) => s.length)) * 23 + 60;
  const bh = line.text.length * 52 + 36;
  const x0 = Math.max(60, Math.min(W - 60 - bw, sx - bw / 2));
  const y0 = sy - bh - 90;
  const tx = Math.max(x0 + 40, Math.min(x0 + bw - 40, sx));
  const fill = line.who === 'main' ? '#ffffff' : '#d7f5f0';
  const o = ramp(t, line.a - 0.1, line.a + 0.15, 0, 1, lin) * ramp(t, line.b + 0.3, line.b + 0.6, 1, 0, lin);
  return (
    <g opacity={o}>
      <rect x={x0} y={y0} width={bw} height={bh} rx={26} fill={fill} />
      <polygon points={`${tx - 18},${y0 + bh - 1} ${tx + 18},${y0 + bh - 1} ${tx},${y0 + bh + 28}`} fill={fill} />
      {line.text.map((s, i) => {
        const part = s.slice(0, Math.max(0, Math.min(s.length, left)));
        left -= s.length;
        return (
          <text key={i} x={x0 + 30} y={y0 + 56 + i * 52} fontFamily={sans} fontWeight={700} fontSize={38} fill="#1a1426">
            {part}
          </text>
        );
      })}
    </g>
  );
};

export const Kota: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  // kamera
  const mx = mainX(t);
  const my = mainY(t);
  const talkMid = (mx + NPC_X) / 2;
  const dlg = ramp(t, 12.6, 13.8, 0, 1) * ramp(t, 27.4, 28.4, 1, 0);
  const follow = mx + 1.4;
  const endFocus = 17.5;
  const fxBase = t < 2.4 ? 5 + ((follow - 5) * ramp(t, 0.5, 2.4)) : follow;
  const fxEnd = fxBase * (1 - ramp(t, 27.4, 29.6)) + endFocus * ramp(t, 27.4, 29.6);
  const fx = fxEnd * (1 - dlg) + talkMid * dlg;
  const fy = 0.3;
  const zoom = 0.62 + 0.24 * ramp(t, 0, 3.2) + (1.5 - 0.86) * dlg - 0.1 * ramp(t, 27.4, 29.8);
  const [fix, fiy] = iso(fx, fy, 0);
  const S = (x: number, y: number, z: number): [number, number] => {
    const [ix, iy] = iso(x, y, z);
    return [W / 2 + zoom * (ix - fix), 1050 + zoom * (iy - fiy)];
  };

  const phaseMain = (mx * 2 * Math.PI) / 1.2;
  const walkM = moving(t) ? ramp(t, 0.8, 1.2, 0, 1, lin) * (t < 13 ? ramp(t, 12.6, 13.0, 1, 0, lin) : ramp(t, 27.3, 27.6, 0, 1, lin)) : 0;
  const lineAt = DIALOG.find((l) => t >= l.a && t <= l.b);
  const mainTalk = !!lineAt && lineAt.who === 'main';
  const npcTalk = !!lineAt && lineAt.who === 'npc';
  const pointing = t >= 17.8 && t < 19.8;
  const wave = t >= 27.0;
  const npcPhase = 0;

  // lantai bawah + objek dinamis
  const items: Draw[] = [];
  const view = (700 + 200) / zoom;
  for (const s of statics) {
    if (Math.abs(s.cx - fix) < view + s.r) items.push(s);
  }
  const carA = ramp(t, 5.0, 11.0, -3, 24, lin);
  const busB = ramp(t, 16.0, 22.0, 26, -4, lin);
  items.push({key: carA + 0.9 + 0.5 + 0.4, cx: iso(carA, 0.5, 0)[0], cy: 0, r: 200, node: <Car key="car" x={carA} y={0.4} dir={1} c="#e0504a" />});
  items.push({key: busB - 1.7 + 1.9 + 0.4, cx: iso(busB, 1.5, 0)[0], cy: 0, r: 300, node: <Car key="bus" x={busB} y={1.45} dir={-1} c="#3d8f6a" bus />});
  const umbO = ramp(mx, 12.0, 12.4, 1, 0, lin);
  items.push({
    key: mx + my + 0.02,
    cx: iso(mx, my, 0)[0],
    cy: 0,
    r: 200,
    node: (
      <g key="main">
        <Person x={mx} y={my} face={1} phase={phaseMain} walk={walkM} talk={mainTalk} t={t} body="#ff7a1a" pants="#2a3350" hat="#2a1a14" arm={wave ? 'wave' : 'none'} />
        <Umbrella x={mx} y={my} z={2.75 + Math.abs(Math.cos(phaseMain)) * 0.08 * walkM} o={umbO} />
      </g>
    ),
  });
  items.push({
    key: NPC_X + NPC_Y + 0.02,
    cx: iso(NPC_X, NPC_Y, 0)[0],
    cy: 0,
    r: 200,
    node: <Person key="npc" x={NPC_X} y={NPC_Y} face={-1} phase={npcPhase} walk={0} talk={npcTalk} t={t} body="#2fa59a" pants="#4a4f5e" hat="#ffd166" arm={pointing ? 'point' : 'none'} lift={Math.sin(t * 1.6) * 0.015} />,
  });
  items.sort((a, b) => a.key - b.key);

  // pori-pori hujan
  const rain = [];
  const rr = mulberry32(9);
  for (let i = 0; i < 90; i++) {
    const x0 = rr() * 1300 - 100;
    const sp = 1500 + rr() * 900;
    const len = 50 + rr() * 60;
    const off = rr() * 2200;
    const y = ((t * sp + off) % 2300) - 150;
    const x = x0 - ((t * sp + off) % 2300) * 0.2;
    rain.push(<line key={i} x1={x} y1={y} x2={x - len * 0.2} y2={y + len} stroke="#bcd6ff" strokeWidth={2.2} opacity={0.32} />);
  }

  // siluet kota jauh (paralaks)
  const sky = [];
  const rs = mulberry32(3);
  for (let i = 0; i < 16; i++) {
    const bx = i * 160 - 120 - ((fix * 0.12) % 160);
    const bh = 160 + rs() * 340;
    sky.push(<rect key={i} x={bx} y={760 - bh} width={140} height={bh + 400} fill="#141c3c" opacity={0.9} />);
  }

  const lampFlicker = 0.9 + 0.1 * Math.sin(t * 7);

  // tanah (isometrik)
  const g = (x0: number, y0: number, x1: number, y1: number, c: string) => <polygon points={P([iso(x0, y0, 0), iso(x1, y0, 0), iso(x1, y1, 0), iso(x0, y1, 0)])} fill={c} />;
  const X0 = -10;
  const X1 = 40;
  const stripes = [];
  for (let i = 0; i < 22; i++) {
    const a = -8 + i * 2.2;
    stripes.push(<polygon key={i} points={P([iso(a, 1.12, 0), iso(a + 1.1, 1.12, 0), iso(a + 1.1, 1.28, 0), iso(a, 1.28, 0)])} fill="#d8d2b0" opacity={0.75} />);
  }
  const zebra = [];
  for (let i = 0; i < 6; i++) zebra.push(<polygon key={i} points={P([iso(8 + i * 0.4, 0.05, 0), iso(8.22 + i * 0.4, 0.05, 0), iso(8.22 + i * 0.4, 2.35, 0), iso(8 + i * 0.4, 2.35, 0)])} fill="#e6e1c8" opacity={0.7} />);

  // bubble
  const bubble = DIALOG.map((l, i) => {
    if (t < l.a - 0.15 || t > l.b + 0.7) return null;
    const [hxp, hyp] = l.who === 'main' ? S(mx, my, 2.9) : S(NPC_X, NPC_Y, 2.8);
    return <WrapLines key={i} line={l} t={t} sx={hxp} sy={hyp} />;
  });

  const title1 = ramp(t, 0.3, 0.9, 0, 1, lin) * ramp(t, 3.3, 4.0, 1, 0, lin);
  const title2 = ramp(t, 27.9, 28.7, 0, 1, lin);

  return (
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#0a1230 0%,#1c1a4a 42%,#3a2358 62%,#150f28 100%)'}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <defs>
          <radialGradient id="pool" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#ffd98a" stopOpacity="0.55" />
            <stop offset="1" stopColor="#ffd98a" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="hl" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#fff6d8" stopOpacity="0.9" />
            <stop offset="1" stopColor="#fff6d8" stopOpacity="0" />
          </radialGradient>
        </defs>
        {sky}
        <g transform={`translate(${W / 2} 1050) scale(${zoom}) translate(${-fix} ${-fiy})`}>
          {g(X0, -1.3, X1, 0, '#2c3250')}
          {g(X0, 0, X1, 2.4, '#1a1f33')}
          {g(X0, 2.4, X1, 3.8, '#2c3250')}
          {g(X0, 3.8, X1, 9, '#202640')}
          {stripes}
          {zebra}
          {/* kolam cahaya lampu jalan + jendela toko */}
          {LAMPS.map((lx) => {
            const [px, py] = iso(lx, 1.4, 0);
            return <ellipse key={lx} cx={px} cy={py} rx={230} ry={120} fill="url(#pool)" opacity={lampFlicker} />;
          })}
          {[[22.7, -0.3], [14.6, -0.3]].map(([wx, wy], i) => {
            const [px, py] = iso(wx, wy, 0);
            return <ellipse key={i} cx={px} cy={py} rx={230} ry={100} fill="url(#pool)" opacity={0.8} />;
          })}
          {items.map((d, i) => (
            <g key={i}>{d.node}</g>
          ))}
          {LAMPS.map((lx) => {
            const [px, py] = iso(lx + 0.06, 2.76, 2.85);
            return <circle key={lx} cx={px} cy={py} r={70} fill="url(#hl)" opacity={lampFlicker} />;
          })}
        </g>
        {rain}
        {bubble}
      </svg>
      <div style={{position: 'absolute', left: 60, right: 60, top: 190, textAlign: 'center', opacity: title1, fontFamily: cond, fontWeight: 700, fontSize: 88, lineHeight: 1.0, color: '#fff', letterSpacing: '0.03em', textShadow: '0 4px 14px rgba(0,0,0,0.8)'}}>
        MALAM HUJAN
        <br />
        DI KOTA KECIL
      </div>
      <div style={{position: 'absolute', left: 40, right: 40, top: 1430, height: 190, borderRadius: 36, background: 'rgba(10,8,24,0.62)', opacity: title2}} />
      <div style={{position: 'absolute', left: 70, right: 70, top: 1470, textAlign: 'center', opacity: title2, transform: `translateY(${(1 - title2) * 16}px)`, fontFamily: sans, fontWeight: 700, fontSize: 46, lineHeight: 1.3, color: '#fff', textShadow: '0 3px 12px rgba(0,0,0,0.9)'}}>
        Kadang, satu obrolan kecil
        <br />
        bikin malam terasa lebih hangat.
      </div>
      <AbsoluteFill style={{background: '#000', opacity: Math.max(ramp(t, 0, 0.5, 1, 0, lin), ramp(t, 29.2, 30, 0, 1, lin)), pointerEvents: 'none'}} />
      <Audio src={staticFile('audio.mp3')} />
    </AbsoluteFill>
  );
};
