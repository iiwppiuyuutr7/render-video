import React from 'react';
import {Composition} from 'remotion';
import {Waktu} from './Waktu';

export const RemotionRoot: React.FC = () => (
  <Composition id="Waktu" component={Waktu} durationInFrames={2700} fps={30} width={1080} height={1920} />
);
