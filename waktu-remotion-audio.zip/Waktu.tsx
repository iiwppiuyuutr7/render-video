import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  KENAPA WAKTU BISA BERJALAN BERBEDA DI LUAR ANGKASA?
  90 detik, vertikal 1080x1920. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Gaya: 2D motion graphics + ilusi 3D (bola Bumi berjaring, orbit miring, kamera CSS perspective).
  Waktu mulai tiap scene ada di SC; ubah di situ kalau mau menggeser scene.
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  hot: '#ffe9c8',
  blue: '#2f5fd0',
  blueBright: '#6f9bff',
  cyan: '#5ad1ff',
  navy: '#0a1a3a',
  steel: '#c9d2e3',
};

// awal tiap scene (detik)
const SC = [0, 6.6, 20.6, 33.0, 49.4, 70.6];
const SD = [6.6, 14, 12.4, 17, 21.2, 19.4];
const CHAPTERS = ['HOOK', 'RELATIVITAS KHUSUS', 'GRAVITASI', 'ASTRONAUT', 'BUKTI NYATA: GPS', 'PENUTUP'];

/* ---------- util ---------- */

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (
  t: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (x: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const inC = Easing.in(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.5) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const rad = (d: number) => (d * Math.PI) / 180;

const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mix = (a: string, b: string, k: number) => {
  const kk = Math.max(0, Math.min(1, k));
  const A = hex(a);
  const B = hex(b);
  return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * kk)).join(',')})`;
};

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const STARS = (() => {
  const r = mulberry32(11);
  return Array.from({length: 360}, () => {
    const k = r();
    return {
      x: r() * W,
      y: r() * H,
      s: r() * 1.7 + 0.5,
      o: r() * 0.6 + 0.3,
      d: 0.2 + r() * 0.8,
      tw: r() * 6.28,
      c: k < 0.12 ? '#ffd9b0' : k < 0.3 ? '#bcd2ff' : '#ffffff',
    };
  });
})();

/* ---------- narasi -> subtitle (ganti dengan waktu asli setelah audio jadi) ---------- */

const SENT: {a: number; b: number; t: string}[] = [
  {a: 0.05, b: 5.9, t: 'Gimana kalau gue bilang, waktu yang lo alami belum tentu sama dengan waktu yang dialami orang lain?'},
  {a: 6.43, b: 10.5, t: 'Menurut relativitas Einstein, gerak memengaruhi pengukuran waktu.'},
  {a: 11.0, b: 20.4, t: 'Ketika sebuah jam bergerak sangat cepat relatif terhadap pengamat, jam itu akan mencatat waktu yang lebih sedikit dibandingkan jam pengamat dalam perbandingan yang sesuai.'},
  {a: 20.84, b: 22.52, t: 'Tapi bukan cuma kecepatan.'},
  {a: 22.96, b: 25.19, t: 'Gravitasi juga memengaruhi laju waktu.'},
  {a: 25.66, b: 32.76, t: 'Semakin kuat medan gravitasi, jam akan berdetak lebih lambat dibandingkan jam yang berada di medan gravitasi lebih lemah.'},
  {a: 33.2, b: 36.05, t: 'Lalu, apakah astronaut pasti menua lebih lambat?'},
  {a: 36.52, b: 37.9, t: 'Nggak sesederhana itu.'},
  {a: 38.28, b: 49.1, t: 'Kecepatan mereka membuat waktu yang terukur lebih lambat dalam perbandingan tertentu, sementara gravitasi yang lebih lemah di orbit membuat jam berdetak lebih cepat dibandingkan di permukaan Bumi.'},
  {a: 49.55, b: 50.89, t: 'Ini bukan sekadar teori.'},
  {a: 51.23, b: 55.11, t: 'Jam atom pada satelit GPS harus memperhitungkan relativitas.'},
  {a: 55.49, b: 65.38, t: 'Efek kecepatan membuat jam satelit tertinggal sekitar tujuh mikrodetik per hari, sementara gravitasi yang lebih lemah membuatnya maju sekitar empat puluh lima mikrodetik.'},
  {a: 65.8, b: 70.34, t: 'Hasil akhirnya, sekitar tiga puluh delapan mikrodetik lebih cepat setiap hari.'},
  {a: 70.77, b: 75.24, t: 'Jadi, waktu bukan selalu sesederhana jam yang berdetak sama di mana pun.'},
  {a: 75.56, b: 79.38, t: 'Kecepatan dan gravitasi bisa membuat waktu yang tercatat berbeda.'},
  {a: 79.69, b: 85.22, t: 'Bahkan teknologi yang kita gunakan sehari-hari sudah harus memperhitungkan efek relativitas ini.'},
  {a: 85.61, b: 89.3, t: 'Semesta ternyata jauh lebih menarik daripada yang kita kira.'},
];

const CAPS = (() => {
  const out: {a: number; b: number; text: string}[] = [];
  for (const n of SENT) {
    const w = n.t.split(' ');
    const parts = Math.ceil(w.length / 9);
    const size = Math.ceil(w.length / parts);
    const pieces: string[] = [];
    for (let i = 0; i < w.length; i += size) pieces.push(w.slice(i, i + size).join(' '));
    const total = pieces.reduce((a, p) => a + p.length, 0);
    let cur = n.a;
    for (const p of pieces) {
      const d = ((n.b - n.a) * p.length) / total;
      out.push({a: cur, b: cur + d - 0.04, text: p});
      cur += d;
    }
  }
  return out;
})();

/* ---------- potongan umum ---------- */

const Cam: React.FC<{t: number; amp?: number; children: React.ReactNode}> = ({t, amp = 1, children}) => (
  <AbsoluteFill style={{perspective: 1700, perspectiveOrigin: '50% 42%'}}>
    <AbsoluteFill
      style={{
        transform: `rotateY(${Math.sin(t * 0.4) * 2.6 * amp}deg) rotateX(${Math.cos(t * 0.3) * 2 * amp}deg) scale(1.04)`,
        transformOrigin: '50% 42%',
      }}
    >
      {children}
    </AbsoluteFill>
  </AbsoluteFill>
);

// bintang dengan paralaks: tiap bintang punya kedalaman sendiri
const Stars: React.FC<{t: number; ox?: number; oy?: number; zoom?: number; alpha?: number}> = ({t, ox = 0, oy = 0, zoom = 1, alpha = 1}) => (
  <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
    {STARS.map((s, i) => {
      const mx = (((s.x - ox * s.d) % W) + W) % W;
      const my = (((s.y - oy * s.d) % H) + H) % H;
      const x = CX + (mx - CX) * zoom;
      const y = 960 + (my - 960) * zoom;
      return <circle key={i} cx={x} cy={y} r={s.s} fill={s.c} opacity={alpha * s.o * (0.75 + 0.25 * Math.sin(t * 2 + s.tw))} />;
    })}
  </svg>
);

const Title: React.FC<{
  t: number;
  lines: string[];
  start: number;
  end: number;
  y: number;
  size: number;
  color?: string;
  step?: number;
}> = ({t, lines, start, end, y, size, color = '#fff', step = 0.1}) => {
  if (t < start - 0.1 || t > end + 0.1) return null;
  const outA = ramp(t, end - 0.5, end, 1, 0, lin);
  let idx = 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: 40,
        right: 40,
        top: y,
        textAlign: 'center',
        opacity: outA,
        fontFamily: cond,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 0.98,
        letterSpacing: '0.02em',
        color,
        textShadow: '0 0 36px rgba(255,122,26,0.35), 0 4px 30px rgba(0,0,0,0.8)',
      }}
    >
      {lines.map((ln, li) => (
        <div key={li} style={{display: 'flex', justifyContent: 'center', gap: size * 0.22}}>
          {ln.split(' ').map((w, wi) => {
            const i = idx++;
            const p = ramp(t, start + i * step, start + i * step + 0.5, 0, 1, outC);
            return (
              <span key={wi} style={{display: 'inline-block', opacity: p, transform: `translateY(${(1 - p) * 40}px) scale(${0.96 + 0.04 * p})`}}>
                {w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

const Caption: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find((x) => t >= x.a && t < x.b);
  if (!c) return null;
  const o = ramp(t, c.a, c.a + 0.18, 0, 1, lin) * ramp(t, c.b - 0.12, c.b, 1, 0, lin);
  return (
    <div
      style={{
        position: 'absolute',
        left: 90,
        right: 90,
        top: 1330,
        height: 230,
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center',
        opacity: o,
        transform: `translateY(${(1 - o) * 12}px)`,
        fontFamily: sans,
        fontWeight: 700,
        fontSize: 56,
        lineHeight: 1.22,
        color: '#fff',
        textShadow: '0 3px 22px rgba(0,0,0,0.95), 0 0 6px rgba(0,0,0,0.9)',
      }}
    >
      <span>{c.text}</span>
    </div>
  );
};

const Hud: React.FC<{t: number}> = ({t}) => {
  let s = 0;
  SC.forEach((a, i) => {
    if (t >= a) s = i;
  });
  const o = ramp(t, 0.8, 1.6, 0, 1, lin) * ramp(t, 87.5, 89, 1, 0, lin);
  return (
    <div style={{position: 'absolute', inset: 0, opacity: o}}>
      <div style={{position: 'absolute', left: 64, right: 64, top: 66, height: 4, background: 'rgba(255,255,255,0.18)', borderRadius: 2}}>
        <div style={{width: `${(t / 90) * 100}%`, height: 4, background: C.orange, borderRadius: 2, boxShadow: `0 0 12px ${C.orange}`}} />
      </div>
      <div style={{position: 'absolute', left: 64, top: 92, fontFamily: cond, fontWeight: 600, fontSize: 30, letterSpacing: '0.16em', color: 'rgba(255,255,255,0.85)'}}>
        {`0${s + 1} / 06  ·  ${CHAPTERS[s]}`}
      </div>
      <div style={{position: 'absolute', left: 64, top: 130, fontFamily: sans, fontWeight: 600, fontSize: 20, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.42)'}}>
        ILUSTRASI ARTISTIK · BUKAN REKAMAN NYATA
      </div>
    </div>
  );
};

/* ---------- objek: Bumi, satelit, astronaut, pesawat, jam ---------- */

const Earth: React.FC<{cx: number; cy: number; R: number; rot: number; elev?: number; alpha?: number; grid?: number; id?: string}> = ({
  cx,
  cy,
  R,
  rot,
  elev = 22,
  alpha = 1,
  grid = 1,
  id = 'e',
}) => {
  const e = rad(elev);
  const proj = (phi: number, lam: number): [number, number, number] => {
    const X = Math.cos(phi) * Math.sin(lam);
    const Y = Math.sin(phi);
    const Z = Math.cos(phi) * Math.cos(lam);
    const Y2 = Y * Math.cos(e) - Z * Math.sin(e);
    const Z2 = Y * Math.sin(e) + Z * Math.cos(e);
    return [cx + R * X, cy - R * Y2, Z2];
  };
  const paths: string[] = [];
  for (let m = 0; m < 12; m++) {
    const lam = rad(m * 30) + rot;
    let d = '';
    let pen = false;
    for (let p = -90; p <= 90; p += 6) {
      const [x, y, z] = proj(rad(p), lam);
      if (z > 0) {
        d += `${pen ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)} `;
        pen = true;
      } else pen = false;
    }
    if (d) paths.push(d);
  }
  for (const p of [-60, -30, 0, 30, 60]) {
    let d = '';
    let pen = false;
    for (let l = 0; l <= 360; l += 6) {
      const [x, y, z] = proj(rad(p), rad(l) + rot);
      if (z > 0) {
        d += `${pen ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)} `;
        pen = true;
      } else pen = false;
    }
    if (d) paths.push(d);
  }
  return (
    <g opacity={alpha}>
      <defs>
        <radialGradient id={`${id}atmo`} cx={cx} cy={cy} r={R * 1.25} gradientUnits="userSpaceOnUse">
          <stop offset="0.78" stopColor="#4d8bff" stopOpacity="0" />
          <stop offset="0.82" stopColor="#4d8bff" stopOpacity="0.55" />
          <stop offset="1" stopColor="#4d8bff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`${id}body`} cx={cx - R * 0.35} cy={cy - R * 0.4} r={R * 1.5} gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#3f7dff" />
          <stop offset="0.45" stopColor="#173b9a" />
          <stop offset="1" stopColor="#030b26" />
        </radialGradient>
        <linearGradient id={`${id}rim`} x1={cx + R} y1={cy - R} x2={cx - R * 0.2} y2={cy + R * 0.4} gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor={C.orange} stopOpacity="0.95" />
          <stop offset="0.5" stopColor={C.orange} stopOpacity="0.1" />
          <stop offset="1" stopColor={C.orange} stopOpacity="0" />
        </linearGradient>
      </defs>
      <circle cx={cx} cy={cy} r={R * 1.25} fill={`url(#${id}atmo)`} />
      <circle cx={cx} cy={cy} r={R} fill={`url(#${id}body)`} />
      <g opacity={0.55 * grid}>
        {paths.map((d, i) => (
          <path key={i} d={d} fill="none" stroke={C.blueBright} strokeWidth={1.6} />
        ))}
      </g>
      <circle cx={cx} cy={cy} r={R} fill="none" stroke={`url(#${id}rim)`} strokeWidth={Math.max(3, R * 0.012)} />
    </g>
  );
};

const Satellite: React.FC<{x: number; y: number; s: number; rot?: number; glow?: number}> = ({x, y, s, rot = 0, glow = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {[-1, 1].map((k) => (
      <g key={k} transform={`translate(${k * 74} 0)`}>
        <rect x={-42} y={-24} width={84} height={48} rx={2} fill="#14327a" stroke={C.blueBright} strokeWidth={1.5} />
        {[-21, 0, 21].map((gx) => (
          <line key={gx} x1={gx} y1={-24} x2={gx} y2={24} stroke={C.blueBright} strokeWidth={1} opacity={0.7} />
        ))}
        <line x1={-42} y1={0} x2={42} y2={0} stroke={C.blueBright} strokeWidth={1} opacity={0.7} />
      </g>
    ))}
    <line x1={-32} y1={0} x2={-32} y2={0} stroke="#fff" />
    <rect x={-32} y={-4} width={64} height={8} fill="#7e8aa3" />
    <rect x={-30} y={-22} width={60} height={44} rx={6} fill="#c9d2e3" stroke="#fff" strokeWidth={1.5} />
    <rect x={-30} y={-22} width={60} height={12} rx={4} fill={C.orange} opacity={0.9} />
    <circle cx={0} cy={6} r={11} fill="#071226" stroke={C.cyan} strokeWidth={2} opacity={1} />
    {glow > 0 && <circle cx={0} cy={6} r={11 + glow * 22} fill={C.cyan} opacity={0.35 * glow} />}
    <line x1={0} y1={-22} x2={0} y2={-44} stroke="#fff" strokeWidth={2.5} />
    <circle cx={0} cy={-46} r={4} fill={C.orange} />
  </g>
);

const Astronaut: React.FC<{x: number; y: number; s: number; rot?: number}> = ({x, y, s, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <defs>
      <linearGradient id="visor" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#0b1b44" />
        <stop offset="0.55" stopColor="#1b4fb5" />
        <stop offset="1" stopColor="#ff9a4a" />
      </linearGradient>
    </defs>
    <rect x={-54} y={-34} width={108} height={118} rx={26} fill="#aab6cc" />
    <path d="M -34 6 L -92 36 L -86 58" fill="none" stroke="#e8edf6" strokeWidth={30} strokeLinecap="round" strokeLinejoin="round" />
    <path d="M 34 6 L 92 -22 L 104 -48" fill="none" stroke="#e8edf6" strokeWidth={30} strokeLinecap="round" strokeLinejoin="round" />
    <circle cx={-86} cy={64} r={17} fill="#c9d2e3" />
    <circle cx={104} cy={-54} r={17} fill="#c9d2e3" />
    <path d="M -16 84 L -30 160" stroke="#e8edf6" strokeWidth={32} strokeLinecap="round" />
    <path d="M 18 84 L 38 156" stroke="#e8edf6" strokeWidth={32} strokeLinecap="round" />
    <rect x={-48} y={152} width={36} height={22} rx={9} fill="#aab6cc" transform="rotate(-8 -30 160)" />
    <rect x={20} y={146} width={36} height={22} rx={9} fill="#aab6cc" transform="rotate(8 38 156)" />
    <rect x={-42} y={-22} width={84} height={106} rx={24} fill="#f1f4fa" />
    <rect x={-26} y={20} width={52} height={22} rx={5} fill="#0b1b44" />
    <rect x={-20} y={26} width={14} height={10} rx={2} fill={C.orange} />
    <circle cx={14} cy={31} r={5} fill={C.cyan} />
    <circle cx={0} cy={-62} r={48} fill="#f1f4fa" />
    <ellipse cx={5} cy={-60} rx={34} ry={28} fill="url(#visor)" />
    <ellipse cx={-6} cy={-70} rx={13} ry={7} fill="#fff" opacity={0.35} transform="rotate(-20 -6 -70)" />
    <path d="M 44 -62 A 48 48 0 0 1 20 -18" fill="none" stroke={C.orange} strokeWidth={6} opacity={0.75} strokeLinecap="round" />
    <path d="M 42 -22 L 42 84" fill="none" stroke={C.orange} strokeWidth={5} opacity={0.55} strokeLinecap="round" />
  </g>
);

const Ship: React.FC<{x: number; y: number; s: number; flame: number; t: number}> = ({x, y, s, flame, t}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <defs>
      <linearGradient id="hull" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffffff" />
        <stop offset="1" stopColor="#8e9ab4" />
      </linearGradient>
    </defs>
    {flame > 0 && (
      <g opacity={flame}>
        <path d={`M -112 0 L ${-190 - 40 * flame - 10 * Math.sin(t * 40)} -9 L ${-250 - 70 * flame} 0 L ${-190 - 40 * flame - 10 * Math.sin(t * 40)} 9 Z`} fill={C.orange} />
        <path d={`M -112 0 L ${-160 - 25 * flame} -4 L ${-195 - 35 * flame} 0 L ${-160 - 25 * flame} 4 Z`} fill={C.hot} />
      </g>
    )}
    <path d="M -120 0 C -120 -24 -40 -32 40 -32 C 100 -32 150 -10 176 0 C 150 10 100 32 40 32 C -40 32 -120 24 -120 0 Z" fill="url(#hull)" />
    <path d="M -60 -30 L -100 -62 L -80 -62 L -30 -31 Z" fill={C.orange} />
    <path d="M -60 30 L -100 62 L -80 62 L -30 31 Z" fill={C.orange} />
    <rect x={-120} y={-5} width={290} height={5} fill={C.orange} opacity={0.9} />
    <circle cx={70} cy={-6} r={15} fill="#0b1b44" stroke={C.cyan} strokeWidth={3} />
    <circle cx={20} cy={-6} r={11} fill="#0b1b44" stroke={C.cyan} strokeWidth={3} />
  </g>
);

// jam atom ikon: lingkaran + jarum yang berputar
const ClockIcon: React.FC<{x: number; y: number; r: number; t: number; speed?: number; color?: string}> = ({x, y, r, t, speed = 1, color = '#fff'}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={r} fill="#06102a" stroke={color} strokeWidth={4} />
    {Array.from({length: 12}, (_, i) => (
      <line key={i} x1={0} y1={-r + 6} x2={0} y2={-r + (i % 3 === 0 ? 20 : 12)} stroke={color} strokeWidth={i % 3 === 0 ? 4 : 2} transform={`rotate(${i * 30})`} />
    ))}
    <line x1={0} y1={0} x2={0} y2={-r + 24} stroke={color} strokeWidth={5} strokeLinecap="round" transform={`rotate(${t * 90 * speed})`} />
    <circle r={6} fill={C.orange} />
  </g>
);

const Chip: React.FC<{x: number; y: number; w: number; h: number; stroke?: string; fill?: string; o?: number}> = ({x, y, w, h, stroke = 'rgba(255,255,255,0.35)', fill = 'rgba(6,16,42,0.82)', o = 1}) => (
  <rect x={x} y={y} width={w} height={h} rx={26} fill={fill} stroke={stroke} strokeWidth={2.5} opacity={o} />
);

const Arrow: React.FC<{x: number; y: number; len: number; dir: 1 | -1; color: string; w?: number}> = ({x, y, len, dir, color, w = 10}) => {
  const y2 = y + dir * len;
  const h = w * 2.4;
  return (
    <g stroke={color} fill={color} strokeWidth={w} strokeLinecap="round">
      <line x1={x} y1={y} x2={x} y2={y2 - dir * h * 0.7} />
      <polygon points={`${x - h * 0.8},${y2 - dir * h} ${x + h * 0.8},${y2 - dir * h} ${x},${y2}`} stroke="none" />
    </g>
  );
};

/* ---------- scene 1: hook ---------- */

const Digit: React.FC<{sec: number}> = ({sec}) => {
  const s = Math.floor(sec);
  return <>{`00:00:${String(s).padStart(2, '0')}`}</>;
};

const Scene1: React.FC<{t: number}> = ({t}) => {
  const camZ = ramp(t, 0.6, 4.1, 0, 1500, Easing.inOut(Easing.cubic));
  const clocks = t < 4.25;
  const flash = ramp(t, 3.95, 4.2, 0, 1, lin) * ramp(t, 4.2, 4.7, 1, 0, lin);
  const appear = ramp(t, 0.4, 1.4, 0, 1, outC);
  const panels = [
    {x: -170, y: -90, z: -1300, label: 'JAM A'},
    {x: 170, y: 130, z: -2100, label: 'JAM B'},
  ];
  const astro = t >= 4.2;
  const bob = Math.sin(t * 1.3) * 10;
  const zoom = 1 + ramp(t, 4.2, 8, 0, 0.07, lin);
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, #060d22 0%, #02040c 60%, #000 100%)'}}>
      <Stars t={t} ox={t * 14} oy={t * -4} alpha={ramp(t, 0.5, 2, 0, 1)} />
      {clocks && (
        <AbsoluteFill style={{perspective: 1100, perspectiveOrigin: '50% 48%', opacity: appear}}>
          {panels.map((p, i) => {
            const z = p.z + camZ;
            const o = ramp(z, 0, 300, 1, 0, lin) * ramp(z, -2300, -1500, 0, 1, lin);
            return (
              <div
                key={i}
                style={{
                  position: 'absolute',
                  left: CX - 230,
                  top: 880 - 100,
                  width: 460,
                  height: 200,
                  opacity: o,
                  transform: `translate3d(${p.x}px, ${p.y}px, ${z}px) rotateY(${i === 0 ? 14 : -14}deg)`,
                  borderRadius: 26,
                  background: 'linear-gradient(160deg, rgba(14,28,66,0.95), rgba(4,9,26,0.95))',
                  border: `3px solid ${C.blueBright}`,
                  boxShadow: `0 0 60px rgba(90,209,255,0.35), inset 0 0 40px rgba(47,95,208,0.35)`,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <div style={{fontFamily: cond, fontWeight: 600, fontSize: 28, letterSpacing: '0.2em', color: C.blueBright}}>{p.label}</div>
                <div style={{fontFamily: cond, fontWeight: 700, fontSize: 112, color: '#fff', textShadow: `0 0 28px ${C.cyan}`, fontVariantNumeric: 'tabular-nums'}}>
                  <Digit sec={Math.max(0, t - 0.4)} />
                </div>
              </div>
            );
          })}
        </AbsoluteFill>
      )}
      <AbsoluteFill style={{background: '#cfe4ff', opacity: flash * 0.9}} />
      {astro && (
        <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: '50% 45%'}}>
          <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
            <defs>
              <radialGradient id="sun" cx="0.5" cy="0.5" r="0.5">
                <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
                <stop offset="0.2" stopColor={C.orange} stopOpacity="0.5" />
                <stop offset="1" stopColor={C.orange} stopOpacity="0" />
              </radialGradient>
            </defs>
            <circle cx={930} cy={260} r={300} fill="url(#sun)" opacity={ramp(t, 4.2, 5.2)} />
            <Earth cx={CX} cy={2300} R={1250} rot={t * 0.05} elev={8} id="s1" grid={0.5} />
            <Astronaut x={CX + 40} y={760 + bob} s={1.6} rot={Math.sin(t * 0.8) * 7 - 8} />
          </svg>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};

// jarum jam -> garis orbit satelit (match cut ke scene 2)
const ClockOrbit: React.FC<{t: number}> = ({t}) => {
  const p = ramp(t, 6.4, 8.4, 0, 1, Easing.inOut(Easing.cubic));
  const o = ramp(t, 6.3, 6.8, 0, 1, lin) * ramp(t, 8.3, 9.2, 1, 0, lin);
  if (o <= 0) return null;
  const rx = 300 + 280 * p;
  const ry = 300 - 190 * p;
  const ang = rad(-90 + t * 380 * (1 - p * 0.4));
  const hx = CX + rx * Math.cos(ang) * (0.35 + 0.65 * p);
  const hy = 880 + ry * Math.sin(ang) * (0.35 + 0.65 * p);
  const ex = CX + rx * Math.cos(ang);
  const ey = 880 + ry * Math.sin(ang);
  return (
    <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: o}}>
      <ellipse cx={CX} cy={880} rx={rx} ry={ry} fill="none" stroke="#fff" strokeWidth={6 - 3 * p} opacity={0.9} />
      {p < 0.6 &&
        Array.from({length: 12}, (_, i) => {
          const a = rad(i * 30);
          return <line key={i} x1={CX + (rx - 16) * Math.cos(a)} y1={880 + (ry - 16) * Math.sin(a)} x2={CX + rx * Math.cos(a)} y2={880 + ry * Math.sin(a)} stroke="#fff" strokeWidth={4} opacity={1 - p * 1.6} />;
        })}
      <line x1={CX} y1={880} x2={ex} y2={ey} stroke={C.orange} strokeWidth={8} strokeLinecap="round" opacity={1 - p * 0.7} />
      <circle cx={ex} cy={ey} r={10 + 8 * p} fill={C.orange} />
      <circle cx={ex} cy={ey} r={30 + 20 * p} fill={C.orange} opacity={0.25} />
    </svg>
  );
};

/* ---------- scene 2: relativitas khusus ---------- */

const Scene2: React.FC<{t: number}> = ({t}) => {
  const inA = ramp(t, 0, 1.2, 0, 1, lin);
  const exit = ramp(t, 13.0, 14.5, 0, 1, inC);
  const labA = ramp(t, 1.0, 2.0, 0, 1, outC);
  // pesawat: berangkat 2.8 -> 6.2, balik 6.8 -> 9.6
  const go = ramp(t, 3.6, 6.8, 0, 1, Easing.inOut(Easing.cubic));
  const back = ramp(t, 7.4, 10.0, 0, 1, Easing.inOut(Easing.cubic));
  const prog = go - back;
  const shipX = 330 + 500 * prog;
  const speed = Math.abs(Math.sin(Math.PI * Math.min(1, Math.max(0, t < 7.1 ? go : back))));
  const moving = (t > 3.6 && t < 10.0) ? 1 : 0;
  const flame = moving * (0.5 + 0.5 * speed);
  const compare = ramp(t, 10.2, 11.4, 0, 1, outC);
  const bars = ramp(t, 10.8, 12.5, 0, 1, outC);
  const reveal = t >= 10.4;
  const Y = 900;
  const dots = Math.floor(t * 3) % 4;
  return (
    <AbsoluteFill style={{opacity: inA, transform: `translateY(${-exit * 760}px)`}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 40%, #0b1d45 0%, #050b1c 55%, #02040c 100%)'}} />
      <Stars t={t} ox={t * 40 * (0.3 + speed)} alpha={0.8} />
      <Cam t={t} amp={0.7}>
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          {/* laboratorium */}
          <g opacity={labA}>
            <Chip x={70} y={400} w={500} h={210} stroke={C.blueBright} />
            <ClockIcon x={160} y={505} r={58} t={t} />
            <text x={240} y={478} fontFamily={cond} fontWeight={700} fontSize={36} letterSpacing={3} fill="#fff">
              LABORATORIUM
            </text>
            <text x={240} y={514} fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.7)">
              jam atom diam
            </text>
            <text x={240} y={560} fontFamily={cond} fontWeight={700} fontSize={44} fill={reveal ? C.cyan : 'rgba(255,255,255,0.6)'}>
              {reveal ? '10,0 detik' : `mencatat${'.'.repeat(dots)}`}
            </text>
            <line x1={200} y1={612} x2={200} y2={Y - 8} stroke="#fff" strokeWidth={2} strokeDasharray="4 10" opacity={0.4} />
          </g>

          {/* lintasan */}
          <g opacity={ramp(t, 1.6, 2.6)}>
            <line x1={120} y1={Y + 70} x2={960} y2={Y + 70} stroke={C.blueBright} strokeWidth={3} strokeDasharray="14 12" opacity={0.6} />
            <text x={120} y={Y + 120} fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.65)">
              titik awal
            </text>
            <text x={960} y={Y + 120} textAnchor="end" fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.65)">
              jauh sekali
            </text>
          </g>

          {/* garis kecepatan */}
          {moving > 0 &&
            Array.from({length: 9}, (_, i) => {
              const len = (60 + ((i * 37) % 120)) * speed;
              const yy = Y - 70 + i * 18;
              const xx = shipX - 230 - ((t * 700 + i * 90) % 400) * (prog > 0.02 ? 1 : 0);
              return <line key={i} x1={xx} y1={yy} x2={xx - len} y2={yy} stroke="#fff" strokeWidth={3} opacity={0.5 * speed} strokeLinecap="round" />;
            })}

          {/* pesawat + jamnya */}
          <g opacity={ramp(t, 2.0, 2.8)}>
            <Ship x={shipX} y={Y} s={0.8} flame={flame} t={t} />
            <g transform={`translate(${shipX - 40} ${Y - 150})`}>
              <Chip x={-170} y={-70} w={400} h={130} stroke={C.orange} />
              <ClockIcon x={-110} y={-5} r={40} t={t} color={C.amber} />
              <text x={-58} y={-26} fontFamily={cond} fontWeight={700} fontSize={26} letterSpacing={2} fill="#fff">
                JAM PESAWAT
              </text>
              <text x={-58} y={26} fontFamily={cond} fontWeight={700} fontSize={40} fill={reveal ? C.amber : 'rgba(255,255,255,0.6)'}>
                {reveal ? '5,0 detik' : `mencatat${'.'.repeat(dots)}`}
              </text>
            </g>
          </g>
          <g opacity={ramp(t, 4.0, 4.8) * ramp(t, 9.0, 9.8, 1, 0, lin)}>
            <text x={CX} y={Y + 215} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={38} letterSpacing={3} fill={C.amber}>
              KECEPATAN SANGAT TINGGI (±0,866 c)
            </text>
          </g>

          {/* hasil perbandingan */}
          <g opacity={compare}>
            <Chip x={70} y={1010} w={940} h={290} stroke={C.blueBright} />
            <text x={110} y={1062} fontFamily={cond} fontWeight={700} fontSize={36} letterSpacing={3} fill="#fff">
              HASIL PERBANDINGAN
            </text>
            <text x={970} y={1062} textAnchor="end" fontFamily={sans} fontWeight={600} fontSize={22} fill="rgba(255,255,255,0.6)">
              contoh ilustrasi · bukan skala nyata
            </text>
            <rect x={110} y={1092} width={760 * bars} height={50} rx={12} fill={C.cyan} />
            <text x={120} y={1128} fontFamily={cond} fontWeight={700} fontSize={32} fill="#02040c" opacity={bars}>
              JAM LAB · 10 detik
            </text>
            <rect x={110} y={1160} width={380 * bars} height={50} rx={12} fill={C.amber} />
            <text x={120} y={1196} fontFamily={cond} fontWeight={700} fontSize={32} fill="#02040c" opacity={bars}>
              JAM PESAWAT · 5 detik
            </text>
            <text x={110} y={1260} fontFamily={sans} fontWeight={600} fontSize={22} fill="rgba(255,255,255,0.78)" opacity={ramp(t, 11.8, 12.6)}>
              Selisih ini hasil pengukuran yang dibandingkan, bukan karena animasi diperlambat.
            </text>
          </g>
        </svg>
      </Cam>
    </AbsoluteFill>
  );
};

/* ---------- scene 3: gravitasi ---------- */

const Scene3: React.FC<{t: number}> = ({t}) => {
  const rise = ramp(t, 0, 2.2, 0, 1, outC);
  const cy = 1010 + (1 - rise) * 1100;
  const R = 330;
  const out = ramp(t, 11.4, 13, 0, 1, inC);
  const cardsO = ramp(t, 2.4, 3.4);
  const graph = ramp(t, 4.6, 5.8);
  // selisih laju: berlebihan dulu, lalu mengecil (nyaris tak terlihat di sekitar Bumi)
  const slope = t < 8.2 ? 0.9 : ramp(t, 8.2, 10, 0.9, 0.992, Easing.inOut(Easing.cubic));
  const gx0 = 190;
  const gy0 = 1200;
  const gw = 700;
  const gh = 100;
  const T = ramp(t, 5.2, 11.6, 0, 1, lin);
  const hiN = Math.floor(Math.max(0, t - 2.4) * 2);
  const loN = Math.floor(Math.max(0, t - 2.4) * 2 * slope);
  return (
    <AbsoluteFill style={{opacity: 1 - out * 0.0}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, #0a1a3d 0%, #050b1c 55%, #02040c 100%)'}} />
      <Stars t={t} oy={-t * 8} alpha={0.7} />
      <Cam t={t} amp={0.8}>
        <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: 1 - out}}>
          <Earth cx={CX} cy={cy} R={R} rot={t * 0.12} elev={20} id="s3" />
          {/* ketinggian (digambarkan berlebihan) */}
          <g opacity={cardsO}>
            <line x1={700} y1={cy - Math.sqrt(R * R - 160 * 160) + 6} x2={700} y2={690} stroke="#fff" strokeWidth={2.5} strokeDasharray="5 9" opacity={0.7} />
            <text x={716} y={770} fontFamily={sans} fontWeight={600} fontSize={20} fill="rgba(255,255,255,0.7)">
              lebih tinggi
            </text>
            {/* jam tinggi */}
            <Chip x={590} y={560} w={400} h={140} stroke={C.cyan} />
            <ClockIcon x={650} y={630} r={36} t={t} color={C.cyan} />
            <text x={700} y={606} fontFamily={cond} fontWeight={700} fontSize={26} letterSpacing={2} fill="#fff">
              GRAVITASI LEMAH
            </text>
            <text x={700} y={656} fontFamily={cond} fontWeight={700} fontSize={40} fill={C.cyan}>
              {`${hiN} detak`}
            </text>
            {/* jam rendah */}
            <line x1={250} y1={cy - Math.sqrt(R * R - 290 * 290) - 4} x2={250} y2={776} stroke="#fff" strokeWidth={2.5} strokeDasharray="5 9" opacity={0.7} />
            <Chip x={50} y={640} w={380} h={140} stroke={C.orange} />
            <ClockIcon x={110} y={710} r={36} t={t} color={C.amber} />
            <text x={160} y={686} fontFamily={cond} fontWeight={700} fontSize={26} letterSpacing={2} fill="#fff">
              GRAVITASI KUAT
            </text>
            <text x={160} y={736} fontFamily={cond} fontWeight={700} fontSize={40} fill={C.amber}>
              {`${loN} detak`}
            </text>
          </g>
          {/* grafik sederhana */}
          <g opacity={graph}>
            <rect x={140} y={1050} width={800} height={260} rx={26} fill="rgba(4,9,26,0.88)" stroke="rgba(255,255,255,0.3)" strokeWidth={2.5} />
            <text x={170} y={1096} fontFamily={cond} fontWeight={700} fontSize={30} letterSpacing={2} fill="#fff">
              BANYAKNYA DETAK DALAM WAKTU YANG SAMA
            </text>
            <line x1={gx0} y1={gy0} x2={gx0 + gw} y2={gy0} stroke="#fff" strokeWidth={2} opacity={0.5} />
            <line x1={gx0} y1={gy0} x2={gx0} y2={gy0 - gh} stroke="#fff" strokeWidth={2} opacity={0.5} />
            <line x1={gx0} y1={gy0} x2={gx0 + gw * T} y2={gy0 - gh * T} stroke={C.cyan} strokeWidth={6} strokeLinecap="round" />
            <line x1={gx0} y1={gy0} x2={gx0 + gw * T} y2={gy0 - gh * T * slope} stroke={C.amber} strokeWidth={6} strokeLinecap="round" />
            <text x={gx0 + gw} y={gy0 + 28} textAnchor="end" fontFamily={sans} fontWeight={600} fontSize={20} fill="rgba(255,255,255,0.7)">
              waktu →
            </text>
          </g>
          <g opacity={ramp(t, 5.6, 6.4) * ramp(t, 8.0, 8.6, 1, 0, lin)}>
            <text x={CX} y={1290} textAnchor="middle" fontFamily={sans} fontWeight={600} fontSize={22} fill={C.amber}>
              selisih digambarkan berlebihan agar terlihat
            </text>
          </g>
          <g opacity={ramp(t, 9.4, 10.4)}>
            <text x={CX} y={1290} textAnchor="middle" fontFamily={sans} fontWeight={700} fontSize={24} fill={C.cyan}>
              di sekitar Bumi selisihnya sangat kecil
            </text>
          </g>
        </svg>
      </Cam>
    </AbsoluteFill>
  );
};

/* ---------- sumur ruang-waktu (jaring) ---------- */

const Well: React.FC<{t: number; cx: number; cy: number; maxR: number; D: number; tilt: number; alpha: number}> = ({t, cx, cy, maxR, D, tilt, alpha}) => {
  const rho = maxR * 0.3;
  const g = (r: number) => 1 / (1 + (r / rho) * (r / rho));
  const pt = (r: number, th: number): [number, number] => [cx + r * Math.cos(th), cy + r * Math.sin(th) * tilt + D * g(r)];
  const rings = Array.from({length: 14}, (_, i) => {
    const r = maxR * Math.pow((i + 1) / 14, 1.6);
    let d = '';
    for (let k = 0; k <= 72; k++) {
      const [x, y] = pt(r, (k / 72) * Math.PI * 2);
      d += `${k === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return {d, u: i / 13};
  });
  const spokes = Array.from({length: 24}, (_, j) => {
    const th = (j / 24) * Math.PI * 2 + t * 0.05;
    let d = '';
    for (let k = 0; k <= 30; k++) {
      const [x, y] = pt(maxR * Math.pow(k / 30, 1.3) + 4, th);
      d += `${k === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)} `;
    }
    return d;
  });
  return (
    <g opacity={alpha}>
      {spokes.map((d, i) => (
        <path key={i} d={d} fill="none" stroke={C.blue} strokeWidth={1.3} opacity={0.4} />
      ))}
      {rings.map((p, i) => (
        <path key={i} d={p.d} fill="none" stroke={mix('#ffb36b', C.blueBright, p.u * 1.5)} strokeWidth={1.4 + (1 - p.u) * 2} opacity={0.85} />
      ))}
    </g>
  );
};

/* ---------- scene 4: astronaut ---------- */

const Scene4: React.FC<{t: number}> = ({t}) => {
  const inA = ramp(t, 0, 1.4, 0, 1, lin);
  const net = ramp(t, 0, 1.6, 1, 0, lin);
  const ER = 860;
  const ECY = 1750;
  const orbA = t * 0.35;
  const ax = 700 + 40 * Math.sin(orbA);
  const ay = ECY - Math.sqrt(1000 * 1000 - (ax - CX) * (ax - CX)) + 8;
  const speedChip = ramp(t, 5.4, 6.6, 0, 1, outC);
  const gravChip = ramp(t, 10.2, 11.4, 0, 1, outC);
  const meet = ramp(t, 13.4, 15.2, 0, 1, Easing.inOut(Easing.cubic));
  const sum = ramp(t, 14.4, 15.6, 0, 1, outC);
  const merge = ramp(t, 15.6, 17, 0, 1, Easing.inOut(Easing.cubic));
  const chipsO = Math.max(0, 1 - meet * 2.5);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, #0b1d45 0%, #050b1c 60%, #02040c 100%)', opacity: inA}} />
      <AbsoluteFill style={{opacity: inA}}>
        <Stars t={t} ox={t * 6} alpha={0.7} />
        <Cam t={t} amp={0.6}>
          <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
            <Well t={t} cx={CX} cy={760} maxR={760} D={140} tilt={0.35} alpha={0.2 * net} />
            <g opacity={1 - merge}>
              <Earth cx={CX} cy={ECY} R={ER} rot={t * 0.05} elev={10} id="s4" />
              {/* orbit */}
              <path d={`M ${CX - 560} ${ECY - Math.sqrt(1000 * 1000 - 560 * 560)} A 1000 1000 0 0 1 ${CX + 560} ${ECY - Math.sqrt(1000 * 1000 - 560 * 560)}`} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="12 14" opacity={0.5} />
              {/* astronaut + jam */}
              <Astronaut x={ax} y={ay - 85} s={0.8} rot={Math.sin(t) * 5} />
              <g transform={`translate(${ax} ${ay - 270})`} opacity={ramp(t, 3.4, 4.4)}>
                <Chip x={-130} y={-50} w={310} h={100} stroke={C.orange} />
                <ClockIcon x={-80} y={0} r={30} t={t} color={C.amber} />
                <text x={-38} y={-8} fontFamily={cond} fontWeight={700} fontSize={22} letterSpacing={2} fill="#fff">
                  JAM ASTRONAUT
                </text>
              </g>
              {/* orang di Bumi */}
              <g transform={`translate(330 ${ECY - Math.sqrt(ER * ER - 210 * 210) + 4}) rotate(-14)`}>
                <circle cx={0} cy={-76} r={14} fill="#f1f4fa" />
                <line x1={0} y1={-60} x2={0} y2={-14} stroke="#f1f4fa" strokeWidth={9} strokeLinecap="round" />
                <line x1={0} y1={-50} x2={-20} y2={-26} stroke="#f1f4fa" strokeWidth={7} strokeLinecap="round" />
                <line x1={0} y1={-50} x2={20} y2={-26} stroke="#f1f4fa" strokeWidth={7} strokeLinecap="round" />
                <line x1={0} y1={-14} x2={-12} y2={14} stroke="#f1f4fa" strokeWidth={8} strokeLinecap="round" />
                <line x1={0} y1={-14} x2={12} y2={14} stroke="#f1f4fa" strokeWidth={8} strokeLinecap="round" />
              </g>
              <g transform={`translate(330 ${ECY - Math.sqrt(ER * ER - 210 * 210) - 200})`} opacity={ramp(t, 3.4, 4.4)}>
                <Chip x={-120} y={-50} w={280} h={100} stroke={C.cyan} />
                <ClockIcon x={-72} y={0} r={30} t={t} color={C.cyan} />
                <text x={-32} y={-8} fontFamily={cond} fontWeight={700} fontSize={22} letterSpacing={2} fill="#fff">
                  JAM DI BUMI
                </text>
              </g>
            </g>

            {/* dua efek */}
            <g opacity={chipsO}>
              <g opacity={speedChip} transform={`translate(0 ${(1 - speedChip) * 30})`}>
                <Chip x={70} y={880} w={940} h={150} stroke={C.orange} />
                <Arrow x={150} y={910} len={90} dir={1} color={C.orange} w={11} />
                <text x={220} y={950} fontFamily={cond} fontWeight={700} fontSize={46} letterSpacing={3} fill={C.orange}>
                  EFEK KECEPATAN
                </text>
                <text x={220} y={992} fontFamily={sans} fontWeight={600} fontSize={27} fill="rgba(255,255,255,0.85)">
                  jam astronaut cenderung tertinggal
                </text>
              </g>
              <g opacity={gravChip} transform={`translate(0 ${(1 - gravChip) * 30})`}>
                <Chip x={70} y={1060} w={940} h={150} stroke={C.cyan} />
                <Arrow x={150} y={1190} len={90} dir={-1} color={C.cyan} w={11} />
                <text x={220} y={1130} fontFamily={cond} fontWeight={700} fontSize={46} letterSpacing={3} fill={C.cyan}>
                  EFEK GRAVITASI
                </text>
                <text x={220} y={1172} fontFamily={sans} fontWeight={600} fontSize={27} fill="rgba(255,255,255,0.85)">
                  jam astronaut cenderung lebih cepat
                </text>
              </g>
            </g>

            {/* bertemu: dua panah jadi satu diagram */}
            <g opacity={ramp(meet, 0.4, 1, 0, 1, lin) * (1 - merge)}>
              <Chip x={70} y={880} w={940} h={330} stroke={C.blueBright} />
              <Arrow x={CX - 120 * (1 - meet * 0.35)} y={930} len={110} dir={1} color={C.orange} w={13} />
              <Arrow x={CX + 120 * (1 - meet * 0.35)} y={1170} len={110} dir={-1} color={C.cyan} w={13} />
              <text x={CX - 180} y={1020} textAnchor="end" fontFamily={cond} fontWeight={700} fontSize={36} fill={C.orange}>
                KECEPATAN
              </text>
              <text x={CX + 180} y={1090} fontFamily={cond} fontWeight={700} fontSize={36} fill={C.cyan}>
                GRAVITASI
              </text>
              <circle cx={CX} cy={1050} r={46 * sum} fill="none" stroke="#fff" strokeWidth={5} />
              <text x={CX} y={1066} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={50 * sum} fill="#fff">
                =?
              </text>
              <text x={CX} y={1250} textAnchor="middle" fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.8)" opacity={sum}>
                Hasilnya bergantung pada orbit, kecepatan, dan lama perjalanan.
              </text>
            </g>

            {/* dua jam menyatu jadi satelit GPS */}
            {merge > 0 && (
              <g>
                <g opacity={1 - merge} transform={`translate(${CX} 1050)`}>
                  <circle r={0} />
                </g>
                <g opacity={ramp(merge, 0.2, 0.9, 0, 1, lin)}>
                  <Satellite x={CX} y={980} s={1.4 - 0.2 * (1 - merge)} />
                </g>
              </g>
            )}
          </svg>
        </Cam>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ---------- scene 5: GPS ---------- */

const Scene5: React.FC<{t: number}> = ({t}) => {
  const inA = ramp(t, 0, 0.8, 0, 1, lin);
  // 0-2.6: dari satelit besar zoom out ke konstelasi; 4.6-8 zoom in ke satelit & jamnya
  const zoomOut = ramp(t, 0, 2.6, 0, 1, Easing.inOut(Easing.cubic));
  const zoomIn = ramp(t, 5.0, 8.0, 0, 1, Easing.inOut(Easing.cubic));
  const CYe = 980;
  const R = 300;
  // posisi satelit pahlawan di orbit (orbit 2, indeks 0)
  const tilt = rad(32);
  const rx = R * 1.55;
  const ry = rx * 0.3;
  const th = 1.2 + t * 0.5;
  const lx = rx * Math.cos(th);
  const ly = ry * Math.sin(th);
  const hx = CX + lx * Math.cos(tilt) - ly * Math.sin(tilt);
  const hy = CYe + lx * Math.sin(tilt) + ly * Math.cos(tilt);
  // transformasi kamera
  const sBig = 5.2;
  const scale = (1 + (sBig - 1) * (1 - zoomOut)) * (1 + 1.9 * zoomIn);
  // zoomOut=0 -> satelit besar di tengah; zoomIn -> mendekati satelit lagi
  const fx = hx * (1 - zoomOut) + hx * zoomIn * zoomOut + CX * zoomOut * (1 - zoomIn) + 0;
  const focusX = zoomOut < 1 ? hx : CX + (hx - CX) * zoomIn;
  const focusY = zoomOut < 1 ? hy : CYe + (hy - CYe) * zoomIn;
  const targetY = 760 + 0 * zoomIn;
  const tr = `translate(${CX} ${targetY}) scale(${scale}) translate(${-focusX} ${-focusY})`;
  const earthA = ramp(zoomOut, 0.2, 1, 0, 1, lin) * (1 - zoomIn * 0.85);
  const heroGlow = ramp(t, 7.6, 8.6, 0, 1);
  const rows = [
    {a: 8.8, label: 'KECEPATAN', val: '−7', unit: 'μs/hari', c: C.orange, w: -0.16, note: 'jam satelit tertinggal'},
    {a: 12.8, label: 'GRAVITASI', val: '+45', unit: 'μs/hari', c: C.cyan, w: 0.7, note: 'jam satelit lebih cepat'},
    {a: 17.0, label: 'HASIL BERSIH', val: '+38', unit: 'μs/hari', c: '#ffffff', w: 0.6, note: 'lebih cepat dari jam di Bumi'},
  ];
  const wave = ramp(t, 19.0, 20.5, 0, 1, lin);
  const infoO = ramp(t, 7.8, 8.6);
  // semua satelit lain dan Bumi saat wide
  const others = [
    {o: 0, tl: -28, ss: [0.3, 2.4, 4.4]},
    {o: 1, tl: 32, ss: [3.3, 5.4]},
    {o: 2, tl: 90, ss: [0.2, 2.2, 4.2]},
  ];
  const front: React.ReactNode[] = [];
  const back: React.ReactNode[] = [];
  others.forEach((o) => {
    const rxx = R * 1.55;
    const ryy = rxx * 0.3;
    back.push(<ellipse key={'oe' + o.o} cx={CX} cy={CYe} rx={rxx} ry={ryy} fill="none" stroke={C.blueBright} strokeWidth={2.2} opacity={0.55} transform={`rotate(${o.tl} ${CX} ${CYe})`} />);
    o.ss.forEach((s0, si) => {
      const tt = s0 + t * 0.5;
      const a = rad(o.tl);
      const x0 = rxx * Math.cos(tt);
      const y0 = ryy * Math.sin(tt);
      const x = CX + x0 * Math.cos(a) - y0 * Math.sin(a);
      const y = CYe + x0 * Math.sin(a) + y0 * Math.cos(a);
      (Math.sin(tt) < 0 ? back : front).push(<Satellite key={`sx${o.o}${si}`} x={x} y={y} s={0.3} rot={o.tl * 0.4} />);
    });
  });
  return (
    <AbsoluteFill style={{opacity: inA}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, #0b1d45 0%, #050b1c 60%, #02040c 100%)'}} />
      <Stars t={t} ox={t * 10} alpha={0.7} zoom={1 + 0.3 * zoomIn} />
      <Cam t={t} amp={0.5}>
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <g transform={tr}>
            {back}
            <g opacity={earthA}>
              <Earth cx={CX} cy={CYe} R={R} rot={t * 0.1} elev={22} id="s5" />
            </g>
            <g opacity={earthA}>{front}</g>
            <Satellite x={hx} y={hy} s={0.3 + 0.0 * zoomIn} rot={tilt * 12} glow={heroGlow} />
          </g>

          {/* sorotan jam atom */}
          <g opacity={infoO}>
            <line x1={CX + 90} y1={730} x2={CX + 210} y2={600} stroke="#fff" strokeWidth={2.5} />
            <circle cx={CX + 90} cy={730} r={8} fill="none" stroke="#fff" strokeWidth={2.5} />
            <text x={CX + 214} y={596} fontFamily={cond} fontWeight={700} fontSize={40} letterSpacing={3} fill="#fff">
              JAM ATOM
            </text>
          </g>
          <g opacity={ramp(t, 3.0, 4.0) * ramp(t, 4.8, 5.6, 1, 0, lin)}>
            <text x={CX} y={1250} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={44} letterSpacing={4} fill="#fff">
              SATELIT GPS
            </text>
          </g>

          {/* infografik berurutan */}
          {rows.map((r, i) => {
            const p = ramp(t, r.a, r.a + 0.7, 0, 1, outC);
            const y = 900 + i * 118;
            const bw = 300 * Math.abs(r.w) * p;
            const x0 = 520;
            return (
              <g key={i} opacity={p} transform={`translate(0 ${(1 - p) * 24})`}>
                <Chip x={60} y={y} w={960} h={104} stroke={r.c} fill="rgba(6,16,42,0.9)" />
                <text x={92} y={y + 46} fontFamily={cond} fontWeight={700} fontSize={32} letterSpacing={3} fill={r.c}>
                  {r.label}
                </text>
                <text x={92} y={y + 82} fontFamily={sans} fontWeight={600} fontSize={22} fill="rgba(255,255,255,0.7)">
                  {r.note}
                </text>
                <rect x={520} y={y + 34} width={300} height={36} rx={10} fill="rgba(255,255,255,0.08)" />
                <rect x={x0} y={y + 34} width={bw} height={36} rx={10} fill={r.c} opacity={0.9} />
                <text x={900} y={y + 76} textAnchor="end" fontFamily={cond} fontWeight={700} fontSize={r.val === '+38' ? 72 : 60} fill="#fff" style={{textShadow: `0 0 24px ${r.c}`}}>
                  {r.val}
                </text>
                <text x={992} y={y + 76} textAnchor="end" fontFamily={sans} fontWeight={600} fontSize={20} fill="rgba(255,255,255,0.6)">
                  {r.unit}
                </text>
              </g>
            );
          })}
          <g opacity={ramp(t, 9.0, 10.0) * ramp(t, 16.8, 17.4, 1, 0, lin)}>
            <text x={CX} y={1285} textAnchor="middle" fontFamily={sans} fontWeight={600} fontSize={22} fill="rgba(255,255,255,0.7)">
              Perbandingan jam satelit dengan jam di permukaan Bumi.
            </text>
          </g>
          <g opacity={ramp(t, 17.6, 18.6)}>
            <text x={CX} y={1285} textAnchor="middle" fontFamily={sans} fontWeight={700} fontSize={23} fill={C.cyan}>
              Koreksi ini perlu agar navigasi GPS tetap akurat.
            </text>
          </g>

          {/* sinyal satelit -> gelombang cahaya ke Bumi */}
          {wave > 0 &&
            [0, 1, 2, 3].map((i) => {
              const k = (wave * 1.4 - i * 0.18);
              if (k <= 0) return null;
              return <circle key={i} cx={CX} cy={760} r={40 + k * 560} fill="none" stroke={C.cyan} strokeWidth={6 - k * 3} opacity={Math.max(0, 0.8 - k * 0.6)} />;
            })}
        </svg>
      </Cam>
    </AbsoluteFill>
  );
};

/* ---------- scene 6: penutup ---------- */

const Scene6: React.FC<{t: number}> = ({t}) => {
  const pull = ramp(t, 0, 4.5, 0, 1, Easing.inOut(Easing.cubic));
  const R = 250 + 40 * (1 - pull);
  const cy = 1000;
  const clocks = ramp(t, 3.4, 4.6) * ramp(t, 6.8, 8.4, 1, 0, lin);
  const merge = ramp(t, 6.0, 8.2, 0, 1, Easing.inOut(Easing.cubic));
  const fin = t > 13.2;
  const sat = rad(-30 + t * 18);
  const rx = R * 1.6;
  const ry = rx * 0.3;
  const sx = CX + rx * Math.cos(sat);
  const sy = cy + ry * Math.sin(sat);
  const fade = ramp(t, 18.4, 19.4, 0, 1, lin);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%, #0b1d45 0%, #050b1c 60%, #02040c 100%)'}} />
      <Stars t={t} oy={-t * 3} alpha={0.8} zoom={1 - 0.0 * pull} />
      <Cam t={t} amp={0.5}>
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <ellipse cx={CX} cy={cy} rx={rx} ry={ry} fill="none" stroke={C.blueBright} strokeWidth={2.4} opacity={0.6} />
          <Earth cx={CX} cy={cy} R={R} rot={t * 0.08} elev={20} id="s6" />
          <Satellite x={sx} y={sy} s={0.32} rot={-12} />
          {/* diagram jam muncul sebentar lalu menyatu */}
          <g opacity={clocks}>
            <ClockIcon x={CX - 170 + 170 * merge} y={560} r={58} t={t} color={C.amber} />
            <ClockIcon x={CX + 170 - 170 * merge} y={560} r={58} t={t} color={C.cyan} />
            <text x={CX - 170 + 170 * merge} y={660} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={30} letterSpacing={2} fill={C.amber} opacity={1 - merge}>
              KECEPATAN
            </text>
            <text x={CX + 170 - 170 * merge} y={660} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={30} letterSpacing={2} fill={C.cyan} opacity={1 - merge}>
              GRAVITASI
            </text>
          </g>
        </svg>
      </Cam>
      {fin && (
        <>
          <Title t={t} lines={['WAKTU TIDAK', 'SESERHANA', 'YANG KITA KIRA.']} start={13.5} end={18.6} y={170} size={100} step={0.14} />
          <div
            style={{
              position: 'absolute',
              left: 0,
              right: 0,
              top: 1190,
              textAlign: 'center',
              opacity: ramp(t, 16.6, 17.8, 0, 1, lin),
              transform: `translateY(${(1 - ramp(t, 16.6, 17.8, 0, 1, outC)) * 20}px)`,
            }}
          >
            <div style={{width: 120, height: 3, background: C.orange, margin: '0 auto 22px', boxShadow: `0 0 16px ${C.orange}`}} />
            <div style={{fontFamily: cond, fontWeight: 700, fontSize: 92, letterSpacing: '0.06em', color: '#fff'}}>
              SEMESTA<span style={{color: C.orange}}>KITA</span>
            </div>
          </div>
        </>
      )}
      <AbsoluteFill style={{background: '#000', opacity: fade}} />
    </AbsoluteFill>
  );
};

/* ---------- komposisi utama ---------- */

export const Waktu: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const l = (i: number) => t - SC[i];
  const on = (i: number, pre = 0, post = 1.0) => t >= SC[i] - pre && t < SC[i] + SD[i] + post;

  const fadeIn = ramp(t, 0, 0.5, 1, 0, lin);
  const fadeOut = ramp(t, 88.6, 90, 0, 1, lin);

  return (
    <AbsoluteFill style={{background: '#000'}}>
      {on(0, 0, 1.2) && <Scene1 t={l(0)} />}
      {l(0) >= 6.2 && l(0) < 9.4 && <ClockOrbit t={l(0)} />}
      {on(1, 0, 1.0) && <Scene2 t={l(1)} />}
      {on(2, 0, 1.0) && <Scene3 t={l(2)} />}
      {on(3, 0, 1.0) && <Scene4 t={l(3)} />}
      {on(4, 0, 1.0) && <Scene5 t={l(4)} />}
      {on(5, 0, 0.5) && <Scene6 t={l(5)} />}

      <Title t={t} lines={['WAKTU BISA', 'BERJALAN', 'BERBEDA.']} start={4.5} end={6.6} y={170} size={96} />
      <Title t={l(1)} lines={['EFEK KECEPATAN']} start={0.7} end={13.0} y={190} size={96} />
      <Title t={l(2)} lines={['GRAVITASI LEBIH KUAT', '→ WAKTU LEBIH LAMBAT']} start={1.0} end={11.6} y={190} size={64} />
      <Title t={l(3)} lines={['ASTRONAUT MENUA', 'LEBIH LAMBAT?']} start={0.7} end={13.2} y={190} size={80} />
      <Title t={l(3)} lines={['DUA EFEK —', 'SATU HASIL AKHIR']} start={13.6} end={16.6} y={190} size={80} />
      <Title t={l(4)} lines={['BUKTI NYATA:', 'GPS']} start={0.8} end={8.0} y={190} size={110} />

      <Audio src={staticFile('audio.mp3')} />
      <Caption t={t} />
      <Hud t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
