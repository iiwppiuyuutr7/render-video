// @ts-nocheck
import React, {useLayoutEffect, useRef} from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

/**
 * Video "Apa yang terjadi kalau kita menggali tembus ke sisi lain Bumi?"
 * 1080x1920, 60 fps, 5400 frame (90 detik). Dominan 2D, dengan 3D WebGL di tiga momen
 * (hook, pusat Bumi, penutup). Engine sendiri, tanpa library tambahan, satu file.
 * Semua dihitung dari nomor frame, jadi aman dirender Remotion.
 * Audio: public/audio.mp3 (narasi + SFX + musik, sudah dimix).
 */
function createEngine(outc) {
  const ENGINE = {};
'use strict';
/* Mesin 3D WebGL minimal (tanpa library). Dipakai untuk render video lewat Chromium. */
const CW = window.OUT_W || 1080, CH = window.OUT_H || 1920;
const glc = document.createElement('canvas'); glc.width = CW; glc.height = CH;
const gl = glc.getContext('webgl', {antialias: true, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance'});
outc.width = CW; outc.height = CH;
const ctx = outc.getContext('2d');
const SC = CH / 1920; // skala UI relatif ke desain 1080x1920

/* ---------- util ---------- */
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, k) => a + (b - a) * k;
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const eio = (t) => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const eout = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
const ein = (t) => Math.pow(clamp(t, 0, 1), 3);
const eoutB = (t) => { t = clamp(t, 0, 1); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const ramp = (t, a, b) => clamp((t - a) / (b - a), 0, 1);
const win = (t, a, b, f = .3) => clamp((t - a) / f, 0, 1) * clamp((b - t) / f, 0, 1);
function hash(n) { n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n ^= n >>> 16; return (n >>> 0) / 4294967296; }
const R = (i, s = 0) => hash((i * 7919 + s * 104729) | 0);
function noise2(x, y, s = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const a = R(xi * 73856093 ^ yi * 19349663, s), b = R((xi + 1) * 73856093 ^ yi * 19349663, s), c = R(xi * 73856093 ^ (yi + 1) * 19349663, s), d = R((xi + 1) * 73856093 ^ (yi + 1) * 19349663, s);
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
const fbm = (x, y, s = 0) => noise2(x, y, s) * .55 + noise2(x * 2.1, y * 2.1, s + 1) * .28 + noise2(x * 4.3, y * 4.3, s + 2) * .17;
const hexc = (h) => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
const mixc = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const scl = (a, k) => [a[0] * k, a[1] * k, a[2] * k];

/* ---------- vektor & matriks ---------- */
const vadd = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const vsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const vmul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const vdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const vcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const vlen = (a) => Math.hypot(a[0], a[1], a[2]);
const vnorm = (a) => { const l = vlen(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const vlerp = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const ident = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
function mmul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
const mT = (x, y, z) => { const m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; };
const mS = (x, y = x, z = x) => { const m = ident(); m[0] = x; m[5] = y; m[10] = z; return m; };
const mRx = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; };
const mRy = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; };
const mRz = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; };
function mPersp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), m = new Float32Array(16); m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m; }
function mLook(e, t, up) { const z = vnorm(vsub(e, t)), x = vnorm(vcross(up, z)), y = vcross(z, x); const m = ident(); m[0] = x[0]; m[4] = x[1]; m[8] = x[2]; m[1] = y[0]; m[5] = y[1]; m[9] = y[2]; m[2] = z[0]; m[6] = z[1]; m[10] = z[2]; m[12] = -vdot(x, e); m[13] = -vdot(y, e); m[14] = -vdot(z, e); return m; }
function mApply(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; }
function mApplyN(m, n) { return vnorm([m[0] * n[0] + m[4] * n[1] + m[8] * n[2], m[1] * n[0] + m[5] * n[1] + m[9] * n[2], m[2] * n[0] + m[6] * n[1] + m[10] * n[2]]); }
function normalMat(m) { // inverse transpose 3x3
  const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
  const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
  const det = a * A + b * B + c * C || 1;
  return new Float32Array([A / det, B / det, C / det, -(b * i - c * h) / det, (a * i - c * g) / det, -(a * h - b * g) / det, (b * f - c * e) / det, -(a * f - c * d) / det, (a * e - b * d) / det]);
}
const TRS = (p, r = [0, 0, 0], s = [1, 1, 1]) => mmul(mT(p[0], p[1], p[2]), mmul(mRy(r[1]), mmul(mRx(r[0]), mmul(mRz(r[2]), mS(s[0], s[1], s[2])))));

/* ---------- mesh builder ---------- */
class B {
  constructor() { this.p = []; this.n = []; this.c = []; this.m = ident(); this.st = []; }
  push() { this.st.push(this.m); return this; }
  pop() { this.m = this.st.pop(); return this; }
  T(x, y, z) { this.m = mmul(this.m, mT(x, y, z)); return this; }
  S(x, y, z) { this.m = mmul(this.m, mS(x, y === undefined ? x : y, z === undefined ? x : z)); return this; }
  Rx(a) { this.m = mmul(this.m, mRx(a)); return this; }
  Ry(a) { this.m = mmul(this.m, mRy(a)); return this; }
  Rz(a) { this.m = mmul(this.m, mRz(a)); return this; }
  v(p, n, c) { const q = mApply(this.m, p), nn = mApplyN(this.m, n); this.p.push(q[0], q[1], q[2]); this.n.push(nn[0], nn[1], nn[2]); this.c.push(c[0], c[1], c[2]); }
  tri(a, b, c, ca, cb = ca, cc = ca, n) { n = n || vnorm(vcross(vsub(b, a), vsub(c, a))); this.v(a, n, ca); this.v(b, n, cb); this.v(c, n, cc); }
  quad(a, b, c, d, ca, cb = ca, cc = ca, cd = ca) { const n = vnorm(vcross(vsub(b, a), vsub(d, a))); this.tri(a, b, c, ca, cb, cc, n); this.tri(a, c, d, ca, cc, cd, n); }
  build() { return mkMesh(this.p, this.n, this.c); }
}
function mkMesh(p, n, c) {
  const mk = (arr) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STATIC_DRAW); return b; };
  return {bp: mk(p), bn: mk(n), bc: mk(c), count: p.length / 3};
}
function box(b, x, y, z, sx, sy, sz, col, jit = 0, seed = 0) {
  const hx = sx / 2, hy = sy / 2, hz = sz / 2;
  const P = [[x - hx, y - hy, z - hz], [x + hx, y - hy, z - hz], [x + hx, y + hy, z - hz], [x - hx, y + hy, z - hz], [x - hx, y - hy, z + hz], [x + hx, y - hy, z + hz], [x + hx, y + hy, z + hz], [x - hx, y + hy, z + hz]];
  const F = [[4, 5, 6, 7], [1, 0, 3, 2], [5, 1, 2, 6], [0, 4, 7, 3], [7, 6, 2, 3], [0, 1, 5, 4]];
  F.forEach((f, i) => { const k = 1 + (R(i + seed * 13, seed) - .5) * jit; const cc = scl(col, k); b.quad(P[f[0]], P[f[1]], P[f[2]], P[f[3]], cc); });
}
function cyl(b, p0, p1, r0, r1, seg, col, caps = true, col1) {
  const ax = vsub(p1, p0), L = vlen(ax); if (L < 1e-6) return;
  const a = vnorm(ax); const t = Math.abs(a[1]) < .9 ? [0, 1, 0] : [1, 0, 0];
  const u = vnorm(vcross(a, t)), v = vcross(a, u); col1 = col1 || col;
  const dir = (i) => vadd(vmul(u, Math.cos(i / seg * 6.2832)), vmul(v, Math.sin(i / seg * 6.2832)));
  const sl = (r0 - r1) / L;
  for (let i = 0; i < seg; i++) {
    const d0 = dir(i), d1 = dir(i + 1);
    const a0 = vadd(p0, vmul(d0, r0)), a1 = vadd(p0, vmul(d1, r0)), b0 = vadd(p1, vmul(d0, r1)), b1 = vadd(p1, vmul(d1, r1));
    const n0 = vnorm(vadd(d0, vmul(a, sl))), n1 = vnorm(vadd(d1, vmul(a, sl)));
    b.v(a0, n0, col); b.v(a1, n1, col); b.v(b1, n1, col1);
    b.v(a0, n0, col); b.v(b1, n1, col1); b.v(b0, n0, col1);
    if (caps) {
      if (r1 > 0) { b.v(p1, a, col1); b.v(b0, a, col1); b.v(b1, a, col1); }
      if (r0 > 0) { const na = vmul(a, -1); b.v(p0, na, col); b.v(a1, na, col); b.v(a0, na, col); }
    }
  }
}
function sphere(b, c, r, col, lat = 10, lon = 14, sy = 1) {
  for (let i = 0; i < lat; i++) {
    const t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
    for (let j = 0; j < lon; j++) {
      const p0 = 6.2832 * j / lon, p1 = 6.2832 * (j + 1) / lon;
      const P = (t, p) => [Math.sin(t) * Math.cos(p), Math.cos(t), Math.sin(t) * Math.sin(p)];
      const A = P(t0, p0), Bq = P(t0, p1), C = P(t1, p1), D = P(t1, p0);
      const pt = (n) => [c[0] + n[0] * r, c[1] + n[1] * r * sy, c[2] + n[2] * r];
      b.v(pt(A), A, col); b.v(pt(D), D, col); b.v(pt(C), C, col);
      b.v(pt(A), A, col); b.v(pt(C), C, col); b.v(pt(Bq), Bq, col);
    }
  }
}
function torus(b, R0, r0, segs, sides, col) {
  const P = (i, j) => { const u = 6.2832 * i / segs, v = 6.2832 * j / sides; const cx = Math.cos(u) * R0, cy = Math.sin(u) * R0; const nx = Math.cos(u) * Math.cos(v), ny = Math.sin(u) * Math.cos(v), nz = Math.sin(v); return [[cx + nx * r0, cy + ny * r0, nz * r0], [nx, ny, nz]]; };
  for (let i = 0; i < segs; i++) for (let j = 0; j < sides; j++) {
    const a = P(i, j), c = P(i + 1, j), d = P(i + 1, j + 1), e = P(i, j + 1);
    b.v(a[0], a[1], col); b.v(c[0], c[1], col); b.v(d[0], d[1], col); b.v(a[0], a[1], col); b.v(d[0], d[1], col); b.v(e[0], e[1], col);
  }
}
// permukaan grid dengan warna per-vertex bergoyang (tekstur batu murah)
function grid(b, o, u, v, nu, nv, col, jit, seed, flip) {
  const n = vnorm(vcross(u, v)); const nn = flip ? vmul(n, -1) : n;
  const P = (i, j) => vadd(o, vadd(vmul(u, i / nu), vmul(v, j / nv)));
  const C = (i, j) => scl(col, 1 + (fbm(i * .55 + seed, j * .9 + seed * 3, seed) - .5) * jit * 2 + (R(i * 131 + j * 17 + seed, seed) - .5) * jit * .5);
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), d = P(i, j + 1);
    const ca = C(i, j), cb = C(i + 1, j), cc = C(i + 1, j + 1), cd = C(i, j + 1);
    if (!flip) { b.v(a, nn, ca); b.v(bb, nn, cb); b.v(c, nn, cc); b.v(a, nn, ca); b.v(c, nn, cc); b.v(d, nn, cd); }
    else { b.v(a, nn, ca); b.v(c, nn, cc); b.v(bb, nn, cb); b.v(a, nn, ca); b.v(d, nn, cd); b.v(c, nn, cc); }
  }
}
function hfield(b, x0, z0, w, d, nx, nz, fh, fc) {
  const H_ = (i, j) => fh(x0 + w * i / nx, z0 + d * j / nz);
  const P = (i, j) => [x0 + w * i / nx, H_(i, j), z0 + d * j / nz];
  const N = (i, j) => { const e = .5; const hx = fh(x0 + w * i / nx + e, z0 + d * j / nz) - fh(x0 + w * i / nx - e, z0 + d * j / nz); const hz = fh(x0 + w * i / nx, z0 + d * j / nz + e) - fh(x0 + w * i / nx, z0 + d * j / nz - e); return vnorm([-hx / (2 * e), 1, -hz / (2 * e)]); };
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), dd = P(i, j + 1);
    const na = N(i, j), nb = N(i + 1, j), nc = N(i + 1, j + 1), nd = N(i, j + 1);
    b.v(a, na, fc(a)); b.v(c, nc, fc(c)); b.v(bb, nb, fc(bb)); b.v(a, na, fc(a)); b.v(dd, nd, fc(dd)); b.v(c, nc, fc(c));
  }
}

/* ---------- shader ---------- */
function prog(vs, fs) {
  const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
  const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const inf = gl.getActiveUniform(p, i); u[inf.name] = gl.getUniformLocation(p, inf.name); }
  return {p, u};
}
const MESH = prog(`
attribute vec3 aP; attribute vec3 aN; attribute vec3 aC;
uniform mat4 uVP; uniform mat4 uM; uniform mat3 uNM;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
void main(){ vec4 w=uM*vec4(aP,1.0); vW=w.xyz; vN=normalize(uNM*aN); vC=aC; gl_Position=uVP*w; }`, `
precision highp float;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
uniform vec3 uLD; uniform vec3 uLC; uniform vec3 uAT; uniform vec3 uAB; uniform vec3 uCam; uniform vec3 uFog; uniform float uFD;
uniform vec3 uTint; uniform float uEm; uniform float uAl; uniform float uSp; uniform float uRim; uniform vec3 uRC; uniform vec3 uL2D; uniform vec3 uL2C; uniform float uClip;
void main(){
  if(uClip>-900.0 && vW.y>uClip) discard;
  vec3 n=normalize(vN); vec3 v=normalize(uCam-vW);
  float d=max(dot(n,-uLD),0.0); float d2=max(dot(n,-uL2D),0.0);
  vec3 hemi=mix(uAB,uAT,n.y*0.5+0.5);
  vec3 base=vC*uTint;
  vec3 h=normalize(v-uLD); float s=pow(max(dot(n,h),0.0),28.0)*uSp;
  float rim=pow(1.0-max(dot(n,v),0.0),3.0)*uRim;
  vec3 col=base*(hemi+uLC*d+uL2C*d2)+uLC*s+uRC*rim+base*uEm;
  float dist=length(uCam-vW); float f=1.0-exp(-dist*uFD*0.12-dist*dist*uFD*0.004);
  col=mix(col,uFog,clamp(f,0.0,1.0));
  gl_FragColor=vec4(col,uAl);
}`);
const PART = prog(`
attribute vec3 aP; attribute vec2 aU; attribute vec4 aC; attribute float aS;
uniform mat4 uVP; varying vec2 vU; varying vec4 vC; varying float vS;
void main(){ vU=aU; vC=aC; vS=aS; gl_Position=uVP*vec4(aP,1.0); }`, `
precision highp float;
varying vec2 vU; varying vec4 vC; varying float vS;
void main(){
  float a;
  if(vS<0.5){ float r=length(vU); a=smoothstep(1.0,0.0,r); a=a*a*(3.0-2.0*a); }
  else if(vS<1.5){ float r=length(vU); a=smoothstep(1.0,0.78,r)*smoothstep(0.0,0.15,r+0.0); a=min(1.0,a)*(1.0-0.45*smoothstep(0.5,1.0,r)); }
  else { a=smoothstep(1.0,0.0,abs(vU.x)); a=a*a; a*=smoothstep(1.0,0.85,abs(vU.y)); }
  gl_FragColor=vec4(vC.rgb*vC.a*a, vC.a*a);
}`);
function attr(p, name, buf, size) { const l = gl.getAttribLocation(p, name); if (l < 0) return; gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0); }

/* ---------- scene state ---------- */
const LT = {ld: vnorm([-.4, -.8, -.45]), lc: [1, .95, .85], at: [.35, .38, .45], ab: [.12, .1, .1], fog: [.03, .03, .05], fd: .02, rc: [.2, .3, .5], l2d: [.5, -.2, .6], l2c: [0, 0, 0], clip: -1000};
const CAM = {eye: [0, 3, 10], tgt: [0, 1, 0], fov: 50, roll: 0, up: [0, 1, 0]};
let VP = ident(), VIEW = ident(), PRJ = ident(), CR = [1, 0, 0], CU = [0, 1, 0], CF = [0, 0, -1];
function setCam() {
  const e = CAM.eye, t = CAM.tgt;
  let up = CAM.up; if (CAM.roll) { const f = vnorm(vsub(t, e)); const r = vnorm(vcross(f, [0, 1, 0])); up = vadd(vmul([0, 1, 0], Math.cos(CAM.roll)), vmul(r, Math.sin(CAM.roll))); }
  VIEW = mLook(e, t, up); PRJ = mPersp(CAM.fov * Math.PI / 180, CW / CH, .1, 600); VP = mmul(PRJ, VIEW);
  CF = vnorm(vsub(t, e)); CR = vnorm(vcross(CF, up)); CU = vcross(CR, CF);
}
function useMesh() { gl.useProgram(MESH.p); const u = MESH.u; gl.uniformMatrix4fv(u.uVP, false, VP); gl.uniform3fv(u.uLD, LT.ld); gl.uniform3fv(u.uLC, LT.lc); gl.uniform3fv(u.uAT, LT.at); gl.uniform3fv(u.uAB, LT.ab); gl.uniform3fv(u.uCam, CAM.eye); gl.uniform3fv(u.uFog, LT.fog); gl.uniform1f(u.uFD, LT.fd); gl.uniform3fv(u.uRC, LT.rc); gl.uniform3fv(u.uL2D, LT.l2d); gl.uniform3fv(u.uL2C, LT.l2c); }
function draw(mesh, M, o = {}) {
  const u = MESH.u; if (!mesh || !mesh.count) return;
  gl.uniformMatrix4fv(u.uM, false, M || ident()); gl.uniformMatrix3fv(u.uNM, false, normalMat(M || ident()));
  gl.uniform3fv(u.uTint, o.tint || [1, 1, 1]); gl.uniform1f(u.uEm, o.em || 0); gl.uniform1f(u.uAl, o.al === undefined ? 1 : o.al); gl.uniform1f(u.uSp, o.sp === undefined ? .15 : o.sp); gl.uniform1f(u.uRim, o.rim === undefined ? .25 : o.rim);
  gl.uniform1f(u.uClip, o.clip === undefined ? LT.clip : o.clip);
  attr(MESH.p, 'aP', mesh.bp, 3); attr(MESH.p, 'aN', mesh.bn, 3); attr(MESH.p, 'aC', mesh.bc, 3);
  if (o.al !== undefined && o.al < 1) { gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(o.dw === true); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
  gl.drawArrays(gl.TRIANGLES, 0, mesh.count);
}
/* partikel / billboard */
const PB = {add: [], alp: []};
function pt(list, p, size, col, a = 1, shape = 0) { // lingkaran billboard
  const r = vmul(CR, size), u = vmul(CU, size);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(vsub(p, r), u), Bq = vsub(vadd(p, r), u), C_ = vadd(vadd(p, r), u), D = vadd(vsub(p, r), u);
  list.push([A, -1, -1, c, shape], [Bq, 1, -1, c, shape], [C_, 1, 1, c, shape], [A, -1, -1, c, shape], [C_, 1, 1, c, shape], [D, -1, 1, c, shape]);
}
function beam(list, p0, p1, w, col, a = 1) {
  const d = vsub(p1, p0), mid = vmul(vadd(p0, p1), .5); const toC = vsub(CAM.eye, mid); let s = vcross(d, toC); s = vnorm(s); s = vmul(s, w);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(p0, s), Bq = vadd(p0, s), C_ = vadd(p1, s), D = vsub(p1, s);
  list.push([A, -1, -1, c, 2], [Bq, 1, -1, c, 2], [C_, 1, 1, c, 2], [A, -1, -1, c, 2], [C_, 1, 1, c, 2], [D, -1, 1, c, 2]);
}
const pbuf = {p: gl.createBuffer(), u: gl.createBuffer(), c: gl.createBuffer(), s: gl.createBuffer()};
function flushList(list, additive) {
  if (!list.length) return;
  const P = new Float32Array(list.length * 3), U = new Float32Array(list.length * 2), Cc = new Float32Array(list.length * 4), S = new Float32Array(list.length);
  list.forEach((v, i) => { P[i * 3] = v[0][0]; P[i * 3 + 1] = v[0][1]; P[i * 3 + 2] = v[0][2]; U[i * 2] = v[1]; U[i * 2 + 1] = v[2]; Cc.set(v[3], i * 4); S[i] = v[4]; });
  gl.useProgram(PART.p); gl.uniformMatrix4fv(PART.u.uVP, false, VP);
  const up = (b, d) => { gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, d, gl.DYNAMIC_DRAW); };
  up(pbuf.p, P); attr(PART.p, 'aP', pbuf.p, 3); up(pbuf.u, U); attr(PART.p, 'aU', pbuf.u, 2); up(pbuf.c, Cc); attr(PART.p, 'aC', pbuf.c, 4); up(pbuf.s, S); attr(PART.p, 'aS', pbuf.s, 1);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
  gl.drawArrays(gl.TRIANGLES, 0, list.length); gl.depthMask(true);
  list.length = 0;
}
function flushParticles() { flushList(PB.alp, false); flushList(PB.add, true); }
function beginFrame() { gl.depthMask(true); gl.disable(gl.BLEND); gl.viewport(0, 0, CW, CH); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.disable(gl.CULL_FACE); setCam(); useMesh(); }
function proj(p) { // dunia -> layar (px output)
  const c = mApply(VIEW, p); const w = -c[2]; if (w < .05) return {x: 0, y: 0, z: w, vis: false, s: 0};
  const t = 1 / Math.tan(CAM.fov * Math.PI / 360);
  const x = (c[0] * t / (CW / CH)) / w, y = (c[1] * t) / w;
  return {x: (x * .5 + .5) * CW, y: (1 - (y * .5 + .5)) * CH, z: w, vis: Math.abs(x) < 1.3 && Math.abs(y) < 1.3, s: (CH / 2) * t / w};
}

const WORDS=[{"w": "Bayangkan", "a": 0.05, "e": 0.571, "b": null}, {"w": "kamu", "a": 0.571, "e": 0.918, "b": null}, {"w": "menggali", "a": 0.918, "e": 1.439, "b": null}, {"w": "terowongan", "a": 1.439, "e": 2.134, "b": null}, {"w": "lurus", "a": 2.134, "e": 2.481, "b": null}, {"w": "menembus", "a": 2.481, "e": 3.002, "b": null}, {"w": "Bumi,", "a": 3.002, "e": 3.349, "b": "weak"}, {"w": "lalu", "a": 3.784, "e": 4.104, "b": null}, {"w": "muncul", "a": 4.104, "e": 4.424, "b": null}, {"w": "di", "a": 4.424, "e": 4.584, "b": null}, {"w": "sisi", "a": 4.584, "e": 4.904, "b": null}, {"w": "yang", "a": 4.904, "e": 5.064, "b": null}, {"w": "berlawanan.", "a": 5.064, "e": 5.704, "b": "strong"}, {"w": "Apa", "a": 6.213, "e": 6.459, "b": null}, {"w": "yang", "a": 6.459, "e": 6.582, "b": null}, {"w": "akan", "a": 6.582, "e": 6.827, "b": null}, {"w": "terjadi?", "a": 6.827, "e": 7.196, "b": "strong"}, {"w": "Pertama,", "a": 7.808, "e": 8.313, "b": "weak"}, {"w": "kamu", "a": 8.606, "e": 8.899, "b": null}, {"w": "melewati", "a": 8.899, "e": 9.486, "b": null}, {"w": "kerak", "a": 9.486, "e": 9.78, "b": null}, {"w": "Bumi,", "a": 9.78, "e": 10.073, "b": "weak"}, {"w": "lapisan", "a": 10.459, "e": 10.918, "b": null}, {"w": "terluar", "a": 10.918, "e": 11.378, "b": null}, {"w": "setebal", "a": 11.378, "e": 11.837, "b": null}, {"w": "5", "a": 11.837, "e": 12.143, "b": null}, {"w": "sampai", "a": 12.143, "e": 12.449, "b": null}, {"w": "70", "a": 12.449, "e": 13.062, "b": null}, {"w": "kilometer.", "a": 13.062, "e": 13.674, "b": "strong"}, {"w": "Lalu", "a": 14.156, "e": 14.579, "b": null}, {"w": "mantel,", "a": 14.579, "e": 15.001, "b": "weak"}, {"w": "batuan", "a": 15.301, "e": 15.742, "b": null}, {"w": "yang", "a": 15.742, "e": 15.888, "b": null}, {"w": "membentang", "a": 15.888, "e": 16.329, "b": null}, {"w": "hingga", "a": 16.329, "e": 16.623, "b": null}, {"w": "kedalaman", "a": 16.623, "e": 17.21, "b": null}, {"w": "2.900", "a": 17.21, "e": 18.532, "b": null}, {"w": "kilometer.", "a": 18.532, "e": 19.119, "b": "strong"}, {"w": "Setelah", "a": 19.61, "e": 20.105, "b": null}, {"w": "itu", "a": 20.105, "e": 20.435, "b": null}, {"w": "inti", "a": 20.435, "e": 20.765, "b": null}, {"w": "luar,", "a": 20.765, "e": 21.095, "b": "weak"}, {"w": "lautan", "a": 21.434, "e": 21.875, "b": null}, {"w": "besi", "a": 21.875, "e": 22.316, "b": null}, {"w": "dan", "a": 22.316, "e": 22.536, "b": null}, {"w": "nikel", "a": 22.536, "e": 22.977, "b": null}, {"w": "cair.", "a": 22.977, "e": 23.197, "b": "strong"}, {"w": "Terakhir", "a": 23.652, "e": 24.247, "b": null}, {"w": "inti", "a": 24.247, "e": 24.644, "b": null}, {"w": "dalam,", "a": 24.644, "e": 25.041, "b": "weak"}, {"w": "besi", "a": 25.355, "e": 25.705, "b": null}, {"w": "padat", "a": 25.705, "e": 26.055, "b": null}, {"w": "di", "a": 26.055, "e": 26.229, "b": null}, {"w": "pusat", "a": 26.229, "e": 26.579, "b": null}, {"w": "Bumi.", "a": 26.579, "e": 26.929, "b": "strong"}, {"w": "Makin", "a": 27.387, "e": 27.782, "b": null}, {"w": "dalam,", "a": 27.782, "e": 28.176, "b": "weak"}, {"w": "makin", "a": 28.347, "e": 28.838, "b": null}, {"w": "ekstrem.", "a": 28.838, "e": 29.329, "b": "strong"}, {"w": "Suhu", "a": 29.723, "e": 30.034, "b": null}, {"w": "inti", "a": 30.034, "e": 30.345, "b": null}, {"w": "diperkirakan", "a": 30.345, "e": 31.122, "b": null}, {"w": "mencapai", "a": 31.122, "e": 31.589, "b": null}, {"w": "5.000", "a": 31.589, "e": 32.211, "b": null}, {"w": "sampai", "a": 32.211, "e": 32.522, "b": null}, {"w": "6.000", "a": 32.522, "e": 33.144, "b": null}, {"w": "derajat", "a": 33.144, "e": 33.611, "b": null}, {"w": "Celsius,", "a": 33.611, "e": 34.077, "b": "weak"}, {"w": "setara", "a": 34.314, "e": 34.681, "b": null}, {"w": "permukaan", "a": 34.681, "e": 35.171, "b": null}, {"w": "Matahari.", "a": 35.171, "e": 35.66, "b": "strong"}, {"w": "Tekanannya", "a": 36.046, "e": 36.665, "b": null}, {"w": "sekitar", "a": 36.665, "e": 37.129, "b": null}, {"w": "3,6", "a": 37.129, "e": 38.058, "b": null}, {"w": "juta", "a": 38.058, "e": 38.367, "b": null}, {"w": "kali", "a": 38.367, "e": 38.677, "b": null}, {"w": "tekanan", "a": 38.677, "e": 39.141, "b": null}, {"w": "atmosfer", "a": 39.141, "e": 39.605, "b": null}, {"w": "di", "a": 39.605, "e": 39.76, "b": null}, {"w": "permukaan", "a": 39.76, "e": 40.379, "b": null}, {"w": "laut.", "a": 40.379, "e": 40.534, "b": "strong"}, {"w": "Tapi", "a": 41.017, "e": 41.375, "b": null}, {"w": "di", "a": 41.375, "e": 41.554, "b": null}, {"w": "pusat", "a": 41.554, "e": 41.912, "b": null}, {"w": "Bumi,", "a": 41.912, "e": 42.269, "b": "weak"}, {"w": "ada", "a": 42.269, "e": 42.627, "b": null}, {"w": "hal", "a": 42.627, "e": 42.806, "b": null}, {"w": "aneh:", "a": 42.806, "e": 43.164, "b": "weak"}, {"w": "gravitasi", "a": 43.561, "e": 44.398, "b": null}, {"w": "bersihnya", "a": 44.398, "e": 45.026, "b": null}, {"w": "nol,", "a": 45.026, "e": 45.235, "b": "weak"}, {"w": "karena", "a": 45.636, "e": 46.058, "b": null}, {"w": "tarikan", "a": 46.058, "e": 46.48, "b": null}, {"w": "dari", "a": 46.48, "e": 46.761, "b": null}, {"w": "segala", "a": 46.761, "e": 47.183, "b": null}, {"w": "arah", "a": 47.183, "e": 47.464, "b": null}, {"w": "saling", "a": 47.464, "e": 47.745, "b": null}, {"w": "menyeimbangkan.", "a": 47.745, "e": 48.448, "b": "strong"}, {"w": "Meski", "a": 48.941, "e": 49.27, "b": null}, {"w": "begitu,", "a": 49.27, "e": 49.763, "b": "weak"}, {"w": "kamu", "a": 49.921, "e": 50.188, "b": null}, {"w": "tidak", "a": 50.188, "e": 50.455, "b": null}, {"w": "berhenti", "a": 50.455, "e": 50.856, "b": null}, {"w": "di", "a": 50.856, "e": 50.99, "b": null}, {"w": "sana,", "a": 50.99, "e": 51.257, "b": "weak"}, {"w": "kamu", "a": 51.64, "e": 51.942, "b": null}, {"w": "terus", "a": 51.942, "e": 52.245, "b": null}, {"w": "meluncur", "a": 52.245, "e": 52.698, "b": null}, {"w": "karena", "a": 52.698, "e": 53.152, "b": null}, {"w": "sudah", "a": 53.152, "e": 53.454, "b": null}, {"w": "punya", "a": 53.454, "e": 53.756, "b": null}, {"w": "kecepatan.", "a": 53.756, "e": 54.361, "b": "strong"}, {"w": "Jika", "a": 54.734, "e": 55.055, "b": null}, {"w": "terowongan", "a": 55.055, "e": 55.698, "b": null}, {"w": "tanpa", "a": 55.698, "e": 56.019, "b": null}, {"w": "udara", "a": 56.019, "e": 56.5, "b": null}, {"w": "dan", "a": 56.5, "e": 56.661, "b": null}, {"w": "tanpa", "a": 56.661, "e": 56.982, "b": null}, {"w": "gesekan,", "a": 56.982, "e": 57.464, "b": "weak"}, {"w": "kecepatanmu", "a": 57.773, "e": 58.481, "b": null}, {"w": "paling", "a": 58.481, "e": 58.765, "b": null}, {"w": "tinggi", "a": 58.765, "e": 59.048, "b": null}, {"w": "di", "a": 59.048, "e": 59.19, "b": null}, {"w": "pusat,", "a": 59.19, "e": 59.473, "b": "weak"}, {"w": "lalu", "a": 59.854, "e": 60.148, "b": null}, {"w": "melambat", "a": 60.148, "e": 60.59, "b": null}, {"w": "menuju", "a": 60.59, "e": 61.032, "b": null}, {"w": "sisi", "a": 61.032, "e": 61.326, "b": null}, {"w": "seberang.", "a": 61.326, "e": 61.768, "b": "strong"}, {"w": "Perjalanannya", "a": 62.127, "e": 62.772, "b": null}, {"w": "diperkirakan", "a": 62.772, "e": 63.416, "b": null}, {"w": "sekitar", "a": 63.416, "e": 63.803, "b": null}, {"w": "38", "a": 63.803, "e": 64.705, "b": null}, {"w": "menit,", "a": 64.705, "e": 64.963, "b": "weak"}, {"w": "menurut", "a": 65.319, "e": 65.735, "b": null}, {"w": "perhitungan", "a": 65.735, "e": 66.289, "b": null}, {"w": "teoretis.", "a": 66.289, "e": 66.843, "b": "strong"}, {"w": "Sebagai", "a": 67.23, "e": 67.687, "b": null}, {"w": "perbandingan,", "a": 67.687, "e": 68.296, "b": "weak"}, {"w": "lubang", "a": 68.562, "e": 68.858, "b": null}, {"w": "terdalam", "a": 68.858, "e": 69.303, "b": null}, {"w": "buatan", "a": 69.303, "e": 69.747, "b": null}, {"w": "manusia,", "a": 69.747, "e": 70.34, "b": "weak"}, {"w": "Kola", "a": 70.641, "e": 70.919, "b": null}, {"w": "Superdeep", "a": 70.919, "e": 71.476, "b": null}, {"w": "Borehole", "a": 71.476, "e": 72.033, "b": null}, {"w": "di", "a": 72.033, "e": 72.172, "b": null}, {"w": "Rusia,", "a": 72.172, "e": 72.59, "b": "weak"}, {"w": "baru", "a": 72.836, "e": 73.134, "b": null}, {"w": "sekitar", "a": 73.134, "e": 73.58, "b": null}, {"w": "12,2", "a": 73.58, "e": 74.771, "b": null}, {"w": "kilometer,", "a": 74.771, "e": 75.366, "b": "weak"}, {"w": "belum", "a": 75.716, "e": 76.023, "b": null}, {"w": "sampai", "a": 76.023, "e": 76.331, "b": null}, {"w": "0,2", "a": 76.331, "e": 77.1, "b": null}, {"w": "persen", "a": 77.1, "e": 77.407, "b": null}, {"w": "perjalanan", "a": 77.407, "e": 78.022, "b": null}, {"w": "menuju", "a": 78.022, "e": 78.483, "b": null}, {"w": "pusat", "a": 78.483, "e": 78.791, "b": null}, {"w": "Bumi.", "a": 78.791, "e": 79.098, "b": "strong"}, {"w": "Jadi,", "a": 79.49, "e": 80.028, "b": "weak"}, {"w": "ini", "a": 80.222, "e": 80.53, "b": null}, {"w": "masih", "a": 80.53, "e": 80.838, "b": null}, {"w": "eksperimen", "a": 80.838, "e": 81.455, "b": null}, {"w": "pikiran.", "a": 81.455, "e": 81.917, "b": "strong"}, {"w": "Suhu", "a": 82.254, "e": 82.567, "b": null}, {"w": "dan", "a": 82.567, "e": 82.724, "b": null}, {"w": "tekanan", "a": 82.724, "e": 83.194, "b": null}, {"w": "ekstrem", "a": 83.194, "e": 83.507, "b": null}, {"w": "membuatnya", "a": 83.507, "e": 84.133, "b": null}, {"w": "mustahil", "a": 84.133, "e": 84.603, "b": null}, {"w": "dengan", "a": 84.603, "e": 84.916, "b": null}, {"w": "teknologi", "a": 84.916, "e": 85.542, "b": null}, {"w": "sekarang.", "a": 85.542, "e": 86.012, "b": "strong"}];const NARR_DUR=86.2040625;

/* Terowongan tembus Bumi — 1080x1920, dominan 2D + 3D di tiga momen */
(function () {
const OFF = .5, DUR = 90; window.OFF = OFF; window.DUR = DUR;
const SB = [-9, 7.81, 29.72, 36.05, 41.02, 48.94, 54.73, 62.13, 67.23, 79.49, 999];
const NEND = 86.2;
const EVL = []; const E = (t, ty, v = 1) => EVL.push([+t.toFixed(3), ty, v]); window.EV = EVL;
let n = 0, USEGL = false, BGF = () => {}, HUD = () => {};
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9\-\.]/g, '').replace(/\.$/, '');
function W(w, k = 0) { let c = 0; for (const t of WORDS) if (norm(t.w) === w) { if (c++ === k) return t.a; } return 0; }
const P2 = (p) => { const q = proj(p); q.x /= SC; q.y /= SC; q.s /= SC; return q; };
const INK = '#080b1a', ORG = '#ff9b3d', ORG2 = '#ffc07a', CYN = '#35d0ee', WHT = '#f4f6ff';
const lin = (t, kf) => { if (t <= kf[0][0]) return kf[0][1]; for (let i = 1; i < kf.length; i++) if (t <= kf[i][0]) return lerp(kf[i - 1][1], kf[i][1], (t - kf[i - 1][0]) / (kf[i][0] - kf[i - 1][0])); return kf[kf.length - 1][1]; };
const sk = (t, kf) => { if (t <= kf[0][0]) return kf[0][1]; for (let i = 1; i < kf.length; i++) if (t <= kf[i][0]) return lerp(kf[i - 1][1], kf[i][1], sstep(kf[i - 1][0], kf[i][0], t)); return kf[kf.length - 1][1]; };
const fmt = (v) => String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

/* ---------- 3D ---------- */
function buildEarth(r = 1) {
  const b = new B(); const lat = 30, lon = 48;
  const cf = (lt, ln) => { const x = Math.cos(lt) * Math.cos(ln), y = Math.sin(lt), z = Math.cos(lt) * Math.sin(ln); const n = fbm(x * 2.2 + 5, z * 2.2 + y * 2, 12); const polar = Math.abs(y) > .86; if (polar) return hexc('#eaf2f8'); return n > .52 ? mixc(hexc('#3f8f4a'), hexc('#b89a5a'), clamp((n - .52) * 4, 0, 1)) : mixc(hexc('#123f8a'), hexc('#1f6fc4'), n * 1.4); };
  for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) {
    const t0 = -Math.PI / 2 + Math.PI * i / lat, t1 = -Math.PI / 2 + Math.PI * (i + 1) / lat, p0 = 6.2832 * j / lon, p1 = 6.2832 * (j + 1) / lon;
    const P = (t, p) => [Math.cos(t) * Math.cos(p), Math.sin(t), Math.cos(t) * Math.sin(p)];
    const A = P(t0, p0), Bq = P(t0, p1), C_ = P(t1, p1), D = P(t1, p0);
    const q = (n) => vmul(n, r); const cA = cf(t0, p0), cB = cf(t0, p1), cC = cf(t1, p1), cD = cf(t1, p0);
    b.v(q(A), A, cA); b.v(q(Bq), Bq, cB); b.v(q(C_), C_, cC); b.v(q(A), A, cA); b.v(q(C_), C_, cC); b.v(q(D), D, cD);
  }
  return b.build();
}

const mk = (f) => { const b = new B(); f(b); return b.build(); };
const EARTH = buildEarth(1);
const UB = mk((b) => box(b, 0, 0, 0, 1, 1, 1, [1, 1, 1]));
const CY = mk((b) => cyl(b, [0, 0, 0], [0, 1, 0], 1, 1, 30, [1, 1, 1]));
const SP = mk((b) => sphere(b, [0, 0, 0], 1, [1, 1, 1], 12, 18));
const TOR = mk((b) => torus(b, 1, .05, 48, 8, [1, 1, 1]));
const O = (o) => Object.assign({sp: .2, rim: .3}, o);
function lights(o) { Object.assign(LT, {ld: vnorm([-.4, -.7, -.55]), lc: [1, .95, .9], at: [.4, .45, .6], ab: [.1, .09, .12], l2d: [.6, -.1, .5], l2c: [.1, .12, .3], rc: [.3, .5, .9], fog: [.04, .06, .14], fd: .006, clip: -1000}, o); }
const SHK = []; const shake = (t, a, d) => SHK.push([t, a, d]);
function camSet(eye, tgt, fov) { let o = [0, 0, 0]; for (const [t0, a, d] of SHK) { const t = n - t0; if (t >= 0 && t < d) { const k = Math.pow(1 - t / d, 2) * a; o = [o[0] + Math.sin(n * 83 + t0) * k, o[1] + Math.cos(n * 97 + t0) * k, 0]; } } CAM.eye = vadd(eye, o); CAM.tgt = tgt; CAM.fov = fov; CAM.roll = 0; }

/* ---------- 2D util ---------- */
const FONT = 'Inter, "Plus Jakarta Sans", "Arial Black", Arial, sans-serif', MONO = '"DejaVu Sans Mono", "Courier New", monospace';
const popK = (t, d = .32) => ({sc: eoutB(clamp(t / d, 0, 1)), al: clamp(t / .1, 0, 1)});
function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
function txt(s, x, y, size, c, o = {}) {
  ctx.save(); ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, sc); ctx.globalAlpha = o.al === undefined ? 1 : o.al;
  ctx.font = `${o.w || 800} ${size}px ${o.font || FONT}`; ctx.textAlign = o.align || 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  const lines = String(s).split('\n'), lh = size * 1.1, y0 = -(lines.length - 1) * lh / 2;
  lines.forEach((ln, i) => { if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = o.gb || 30; } if (o.stroke) { ctx.lineWidth = o.sw || 8; ctx.strokeStyle = o.stroke; ctx.strokeText(ln, 0, y0 + i * lh); } ctx.fillStyle = c; ctx.fillText(ln, 0, y0 + i * lh); ctx.shadowBlur = 0; });
  ctx.restore();
}
function tag(s, x, y, o = {}) {
  ctx.save(); ctx.translate(x, y); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, sc); ctx.globalAlpha = o.al === undefined ? 1 : o.al; const size = o.size || 28;
  ctx.font = `800 ${size}px ${FONT}`; const w = ctx.measureText(s).width + size * 1.3, h = size * 1.75, ox = o.left ? 0 : -w / 2;
  if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = 26; } ctx.fillStyle = o.bg || 'rgba(8,11,26,.82)'; rr(ox, -h / 2, w, h, h / 2); ctx.fill(); ctx.shadowBlur = 0;
  ctx.lineWidth = 2.5; ctx.strokeStyle = o.border || 'rgba(255,255,255,.35)'; ctx.stroke(); ctx.fillStyle = o.fg || WHT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, ox + w / 2, size * .05); ctx.restore();
}
function head(s, t0, t1 = 1e9) {
  if (n < t0 || n > t1) return; const t = n - t0, a = clamp(t / .3, 0, 1) * clamp((t1 - n) / .2, 0, 1), lines = s.split('\n'); ctx.save(); ctx.globalAlpha = a; ctx.font = `800 54px ${FONT}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 14;
  lines.forEach((ln, li) => { let x = 60; const y = 108 + li * 64 + (1 - eout(t / .3)) * 22; ln.split('*').forEach((p, i) => { ctx.fillStyle = i % 2 ? ORG : WHT; ctx.fillText(p, x, y); x += ctx.measureText(p).width; }); }); ctx.restore();
}
function glow(x, y, r, c, a) { const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${c},${a})`); g.addColorStop(1, `rgba(${c},0)`); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
function vgrad(y0, y1, c0, c1) { const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, c0); g.addColorStop(1, c1); ctx.fillStyle = g; ctx.fillRect(0, y0, 1080, y1 - y0); }
const STARS = []; for (let i = 0; i < 160; i++) STARS.push([R(i, 1) * 1080, R(i, 2) * 1920, .6 + R(i, 3) * 1.8, R(i, 4)]);
function stars(a = 1, drift = 0) { STARS.forEach((s) => { ctx.globalAlpha = a * (.3 + .7 * Math.abs(Math.sin(n * (.6 + s[3] * 2) + s[3] * 20))); ctx.fillStyle = '#cfe0ff'; ctx.beginPath(); ctx.arc(s[0], (s[1] + drift * s[2] * 20) % 1920, s[2], 0, 6.283); ctx.fill(); }); ctx.globalAlpha = 1; }
function diver(x, y, s, rot = 0, flail = 0) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot); ctx.scale(s, s); const w = Math.sin(n * 7) * flail;
  ctx.strokeStyle = '#ff7a2a'; ctx.lineWidth = 15; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(-18, -4); ctx.lineTo(-44, -38 + w * 10); ctx.moveTo(18, -4); ctx.lineTo(44, -38 - w * 10); ctx.moveTo(-9, 40); ctx.lineTo(-16 - w * 4, 78); ctx.moveTo(9, 40); ctx.lineTo(16 + w * 4, 78); ctx.stroke();
  ctx.fillStyle = '#ff8a3d'; rr(-24, -12, 48, 62, 20); ctx.fill(); ctx.fillStyle = '#ffd7b0'; rr(-14, 8, 28, 14, 6); ctx.fill();
  ctx.fillStyle = '#eef2ff'; ctx.beginPath(); ctx.arc(0, -34, 30, 0, 6.283); ctx.fill(); ctx.fillStyle = '#16213f'; rr(-21, -46, 42, 26, 13); ctx.fill(); ctx.fillStyle = 'rgba(120,200,255,.55)'; rr(-17, -43, 16, 8, 4); ctx.fill(); ctx.restore();
}
function arrow(x0, y0, x1, y1, c, w = 8, head = 22) { const a = Math.atan2(y1 - y0, x1 - x0); ctx.save(); ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - Math.cos(a) * head * .6, y1 - Math.sin(a) * head * .6); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - Math.cos(a - .45) * head, y1 - Math.sin(a - .45) * head); ctx.lineTo(x1 - Math.cos(a + .45) * head, y1 - Math.sin(a + .45) * head); ctx.fill(); ctx.restore(); }
function sun(x, y, r, a = 1) { ctx.save(); ctx.globalAlpha = a; glow(x, y, r * 2.6, '255,200,80', .55); for (let i = 0; i < 12; i++) { const an = i / 12 * 6.283 + n * .5; ctx.strokeStyle = '#ffd86a'; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x + Math.cos(an) * r * 1.25, y + Math.sin(an) * r * 1.25); ctx.lineTo(x + Math.cos(an) * r * 1.6, y + Math.sin(an) * r * 1.6); ctx.stroke(); } ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(x, y, r, 0, 6.283); ctx.fill(); ctx.restore(); }

/* ---------- SFX ---------- */
SB.slice(1, -1).forEach((t) => E(t - .12, 'whoosh', .6));
[7.9, 9.5, 12.0, 12.6, 14.58, 17.2, 20.43, 24.25, 30.0, 31.59, 32.52, 35.17, 37.13, 39.0, 42.0, 55.05, 56.4, 58.5, 63.8, 66.3, 70.64, 73.58, 76.33, 81.45, 82.25, 83.1].forEach((t) => E(t, 'pop', .8));
E(.05, 'impact', .9); E(1.44, 'zap', .7); E(3.35, 'ding', .7); E(6.21, 'riser', .7); E(6.21, 'pop', 1); E(45.03, 'impact', 1.2); E(45.03, 'shimmer', .9); E(47.7, 'ding', .8); E(58.5, 'ding', .8); E(64.9, 'ding', .8); E(84.13, 'stamp', 1.1); E(84.13, 'impact', 1.1); E(86.3, 'ding', .8);
shake(45.03, .35, .6); shake(84.13, .5, .6);
for (let i = 0; i < 18; i++) E(31.6 + i * .12, 'tick', .25);
for (let i = 0; i < 10; i++) E(36.9 + i * .22, 'tick', .3);

/* ================= S0: hook (3D globe) ================= */
function s0() {
  USEGL = true; lights(); const t = n + .5, rot = n * .55 + .6, tilt = .38;
  BGF = () => { vgrad(0, 1920, '#10173a', '#04060f'); stars(.9); glow(540, 700, 600, '60,110,255', .14); };
  camSet([0, .2, 10.8 - .6 * Math.min(1, t / 3)], [0, -.15, 0], 34); beginFrame();
  const G = mmul(mRz(tilt), mRy(rot)), top = mApply(mRz(tilt), [0, 1.62, 0]), bot = mApply(mRz(tilt), [0, -1.62, 0]), grow = eout(ramp(n, 1.3, 3.2));
  const endp = vlerp(top, bot, grow); seg(top, endp);
  function seg(p0, p1) { const d = vsub(p1, p0), L = vlen(d); if (L < 1e-4) return; const a = vnorm(d), tt = Math.abs(a[1]) < .9 ? [0, 1, 0] : [1, 0, 0], u = vnorm(vcross(a, tt)), v = vcross(a, u), mid = vmul(vadd(p0, p1), .5), m = ident(); const w = .1; m[0] = u[0] * w; m[1] = u[1] * w; m[2] = u[2] * w; m[4] = a[0] * L; m[5] = a[1] * L; m[6] = a[2] * L; m[8] = v[0] * w; m[9] = v[1] * w; m[10] = v[2] * w; m[12] = mid[0]; m[13] = mid[1]; m[14] = mid[2]; draw(UB, m, O({tint: [1, .62, .2], em: 1.2})); }
  draw(EARTH, mmul(G, mS(1.6)), O({al: .55, dw: false, sp: .5, rim: .6}));
  const e1 = popK(n - 1.4, .4).sc, e2 = popK(n - 3.4, .4).sc;
  draw(SP, TRS(top, [0, 0, 0], [.2 * e1, .2 * e1, .2 * e1]), O({tint: [1, .6, .2], em: 1}));
  draw(SP, TRS(bot, [0, 0, 0], [.2 * e2, .2 * e2, .2 * e2]), O({tint: [.2, .85, 1], em: 1}));
  flushParticles();
  HUD = () => {
    const a = popK(n + .5, .5); txt('GALI LURUS\nTEMBUS BUMI?', 540, 320, 112, WHT, {sc: a.sc, al: a.al * (1 - sstep(6.1, 6.4, n)), stroke: INK, sw: 22, glow: 'rgba(255,150,60,.7)', gb: 50});
    if (n > 1.4) { const q = P2(top), p = popK(n - 1.4); tag('MASUK', q.x + 150, q.y + 20, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff'}); }
    if (n > 3.4) { const q = P2(bot), p = popK(n - 3.4); tag('KELUAR DI SISI LAIN', q.x - 60, q.y + 70, {sc: p.sc, al: p.al, bg: CYN, fg: INK, border: '#fff', size: 26}); }
    if (n > 6.21) { const p = popK(n - 6.21, .45); txt('Apa yang\nakan terjadi?', 540, 1030, 84, WHT, {sc: p.sc, al: p.al, stroke: INK, sw: 18, glow: 'rgba(53,208,238,.7)', rot: -.03}); }
  };
}

/* ================= S1: perjalanan lapisan (2D scroll) ================= */
const BANDS = [{y0: 0, y1: 1300, a: '#3b2a1d', b: '#7a5636', nm: 'KERAK BUMI', sub: 'tebal 5–70 km'}, {y0: 1300, y1: 3200, a: '#7d200f', b: '#e0601f', nm: 'MANTEL', sub: 'batuan hingga 2.900 km'}, {y0: 3200, y1: 4500, a: '#a84f10', b: '#e8941c', nm: 'INTI LUAR', sub: 'besi & nikel cair'}, {y0: 4500, y1: 6200, a: '#c8741a', b: '#f2b540', nm: 'INTI DALAM', sub: 'besi padat'}];
const PKF = [[7.81, 0], [8.5, 0], [14.3, 1300], [19.7, 3200], [23.7, 4500], [29.72, 5800]], DKF = [[7.81, 0], [8.5, 0], [14.3, 70], [18.5, 2900], [19.7, 2900], [23.7, 5150], [29.72, 6371]];
function s1() {
  const P = lin(n, PKF), depth = sk(n, DKF), PY = 790;
  BGF = () => {
    const sy = (wy) => PY + wy - P;
    if (sy(0) > 0) { vgrad(0, sy(0), '#2a1a4a', '#e0764a'); stars(.5); ctx.fillStyle = '#1a1220'; ctx.fillRect(0, sy(0) - 4, 1080, 10); }
    BANDS.forEach((bd, bi) => { const y0 = sy(bd.y0), y1 = sy(bd.y1); if (y1 < -20 || y0 > 1940) return; vgrad(Math.max(0, y0), Math.min(1920, y1), bd.a, bd.b); ctx.save(); ctx.beginPath(); ctx.rect(0, Math.max(0, y0), 1080, Math.min(1920, y1) - Math.max(0, y0)); ctx.clip();
      if (bi === 0) { for (let i = 0; i < 14; i++) { const y = y0 + i * 98 + R(i, 7) * 30; ctx.fillStyle = i % 2 ? 'rgba(255,220,170,.07)' : 'rgba(0,0,0,.12)'; ctx.fillRect(0, y, 1080, 36 + R(i, 8) * 40); } for (let i = 0; i < 60; i++) { ctx.fillStyle = `rgba(${R(i, 3) > .5 ? '255,235,200' : '30,15,8'},.16)`; ctx.beginPath(); ctx.ellipse(R(i, 1) * 1080, y0 + R(i, 2) * 1300, 8 + R(i, 4) * 30, 5 + R(i, 5) * 14, 0, 0, 6.283); ctx.fill(); } }
      if (bi === 1) { for (let i = 0; i < 26; i++) { const x = R(i, 1) * 1080 + Math.sin(n * .6 + i) * 40, y = y0 + R(i, 2) * 1900 + Math.cos(n * .5 + i * 2) * 40; glow(x, y, 120 + R(i, 3) * 120, '255,170,70', .22 + .1 * Math.sin(n + i)); } }
      if (bi === 2) { for (let k = 0; k < 16; k++) { const y = y0 + 40 + k * 82; ctx.strokeStyle = `rgba(255,245,200,${.18 + .1 * Math.sin(k)})`; ctx.lineWidth = 7; ctx.beginPath(); for (let x = 0; x <= 1080; x += 20) { const yy = y + Math.sin(x / 110 + n * 1.6 + k * 1.3) * 22; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); } ctx.stroke(); } for (let i = 0; i < 30; i++) { const y = ((R(i, 4) * 1300 - n * 160 * (.5 + R(i, 5))) % 1300 + 1300) % 1300; ctx.fillStyle = 'rgba(255,250,220,.4)'; ctx.beginPath(); ctx.arc(R(i, 6) * 1080, y0 + y, 4 + R(i, 7) * 8, 0, 6.283); ctx.fill(); } }
      if (bi === 3) { for (let r = 0; r < 26; r++) for (let c = 0; c < 14; c++) { const x = c * 84 + (r % 2) * 42, y = y0 + r * 72, tw = .25 + .35 * Math.abs(Math.sin(n * 1.5 + r * .7 + c)); ctx.fillStyle = `rgba(255,255,255,${tw * .6})`; ctx.beginPath(); ctx.arc(x, y, 6, 0, 6.283); ctx.fill(); ctx.strokeStyle = 'rgba(255,190,90,.25)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 42, y + 72); ctx.stroke(); } glow(540, y0 + 1400, 700, '255,255,255', .4); }
      ctx.restore(); });
    // garis kecepatan
    if (n > 8.5) { ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.14)'; ctx.lineWidth = 3; for (let i = 0; i < 24; i++) { const x = R(i, 11) * 1080, y = ((R(i, 12) * 2200 + n * 900) % 2200) - 150; ctx.beginPath(); ctx.moveTo(x, 1920 - y); ctx.lineTo(x, 1920 - y - 110); ctx.stroke(); } ctx.restore(); }
  };
  HUD = () => {
    const sy = (wy) => PY + wy - P;
    [[0, 'PERMUKAAN BUMI'], [1300, 'KERAK ▸ MANTEL'], [3200, 'MANTEL ▸ INTI LUAR'], [4500, 'INTI LUAR ▸ INTI DALAM'], [5800, 'PUSAT BUMI']].forEach(([wy, nm], i) => { const y = sy(wy); if (y < 60 || y > 1500) return; ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 4; ctx.setLineDash([22, 14]); ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(1080, y); ctx.stroke(); ctx.restore(); tag(nm, 540, y, {size: 26, bg: 'rgba(8,11,26,.85)'}); });
    const gy = sy(0); if (gy > 330) { ctx.save(); ctx.fillStyle = '#05060c'; ctx.beginPath(); ctx.ellipse(540, gy + 4, 120, 22, 0, 0, 6.283); ctx.fill(); ctx.restore(); }
    head('Perjalanan ke *pusat Bumi*', 7.9, 29.7);
    const bi = BANDS.findIndex((b, i) => i === 3 || P < BANDS[i].y1), bd = BANDS[Math.max(0, bi)];
    if (n > 8.3) { const k = n < 9.5 ? 0 : 1; const lt = [[9.4, 14.2, 0], [14.2, 19.6, 1], [19.6, 23.6, 2], [23.6, 30, 3]].find((s) => n >= s[0] && n < s[1]); if (lt) { const p = popK(n - lt[0], .35); const b2 = BANDS[lt[2]]; ctx.save(); tag(b2.nm + ' · ' + b2.sub, 60, 230, {left: true, sc: p.sc, al: p.al, size: 30, bg: 'rgba(8,11,26,.85)', border: ORG}); ctx.restore(); } }
    // readout kedalaman
    ctx.save(); ctx.globalAlpha = clamp((n - 8.3) / .3, 0, 1); ctx.fillStyle = 'rgba(8,11,26,.78)'; rr(60, 1040, 300, 96, 24); ctx.fill(); ctx.restore(); txt('KEDALAMAN', 90, 1066, 22, '#9fb0d6', {align: 'left', al: clamp((n - 8.3) / .3, 0, 1), w: 700}); txt(fmt(depth) + ' km', 90, 1108, 42, WHT, {align: 'left', font: MONO, w: 700, al: clamp((n - 8.3) / .3, 0, 1)});
    // mini-map
    const mx = 920, my = 300, mr = 84, ma = clamp((n - 8.3) / .3, 0, 1); ctx.save(); ctx.globalAlpha = ma; [[mr, '#c9a073'], [mr * .93, '#d9531c'], [mr * .55, '#ffc24a'], [mr * .2, '#fff4cf']].forEach(([r, c]) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(mx, my, r, 0, 6.283); ctx.fill(); }); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 3; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.moveTo(mx, my - mr); ctx.lineTo(mx, my + mr); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#fff'; ctx.shadowColor = '#000'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(mx, my - mr + mr * depth / 6371, 11, 0, 6.283); ctx.fill(); ctx.restore();
    // pemain
    if (n > 7.85) { const fall = n > 8.5 ? 1 : 0; const sw = Math.sin(n * 3) * .08 * fall; diver(540, 700 + (n < 8.5 ? 40 : 0), 1.25, sw, fall); }
    if (n > 8.5) { ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 4; for (let i = 0; i < 6; i++) { const x = 470 + i * 28; ctx.beginPath(); ctx.moveTo(x, 520 - (i % 2) * 30); ctx.lineTo(x, 430 - (i % 2) * 30); ctx.stroke(); } ctx.restore(); }
    if (n >= 11.8 && n < 14.2) { const p = popK(n - 11.84, .3); tag('5 – 70 km', 760, 640, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff', size: 34}); }
    if (n >= 17.2 && n < 19.6) { const p = popK(n - 17.2, .3); tag('2.900 km', 800, 640, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff', size: 34}); }
    if (n >= 27.39) { const p = popK(n - 27.39, .35); txt('MAKIN DALAM,\nMAKIN EKSTREM', 540, 380, 70, WHT, {sc: p.sc, al: p.al * clamp((29.65 - n) / .15, 0, 1), stroke: INK, sw: 16, glow: 'rgba(255,120,40,.8)'}); }
  };
}

/* ================= S2: suhu ================= */
function s2() {
  const t = n - SB[2];
  BGF = () => { vgrad(0, 1920, '#2a0a0a', '#070308'); glow(300, 760, 700, '255,80,30', .3 + .08 * Math.sin(n * 3)); stars(.25); };
  HUD = () => {
    head('*Suhu* inti Bumi', 29.8, 36.0);
    const fill = eout(ramp(n, 30.0, 32.6)), tx = 230, ty0 = 330, ty1 = 1020, tw = 96;
    ctx.save(); ctx.fillStyle = 'rgba(255,255,255,.12)'; rr(tx - tw / 2, ty0, tw, ty1 - ty0, 48); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = 5; ctx.stroke();
    const fh = (ty1 - ty0 - 30) * fill + 60; const g = ctx.createLinearGradient(0, ty1, 0, ty0); g.addColorStop(0, '#ff3a1a'); g.addColorStop(1, '#ffd24a'); ctx.fillStyle = g; rr(tx - tw / 2 + 10, ty1 - fh - 8, tw - 20, fh, 38); ctx.fill(); ctx.beginPath(); ctx.arc(tx, ty1 + 50, 78, 0, 6.283); ctx.fillStyle = '#ff3a1a'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.stroke(); ctx.restore();
    for (let i = 0; i <= 6; i++) { const y = ty1 - i * (ty1 - ty0) / 6; ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fillRect(tx + tw / 2 + 12, y - 2, 26, 4); }
    if (n > 31.59) { const p = popK(n - 31.59, .4); txt('5.000 – 6.000', 650, 500, 88, '#ffe08a', {sc: p.sc, al: p.al, stroke: '#2a0a00', sw: 18, glow: 'rgba(255,140,40,.9)'}); txt('°C', 840, 585, 70, WHT, {sc: p.sc, al: p.al, stroke: '#2a0a00', sw: 14}); }
    if (n > 30.0 && n < 31.6) tag('SUHU INTI BUMI', 650, 500, {sc: popK(n - 30.0).sc, al: popK(n - 30.0).al, bg: '#ff3a1a', border: '#fff'});
    if (n > 33.6) {
      const p = popK(n - 33.6, .4); ctx.save(); ctx.globalAlpha = p.al; const bx = 400, bw = 600, ax = (v) => bx + (v / 7000) * bw; ctx.fillStyle = 'rgba(8,11,26,.8)'; rr(330, 690, 700, 330, 30); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(bx, 940, bw, 3); [0, 2000, 4000, 6000].forEach((v) => { ctx.fillRect(ax(v), 934, 3, 14); ctx.fillStyle = '#9fb0d6'; ctx.font = `700 22px ${MONO}`; ctx.textAlign = 'center'; ctx.fillText(fmt(v), ax(v), 972); ctx.fillStyle = 'rgba(255,255,255,.18)'; });
      ctx.fillStyle = '#ff5a2a'; rr(ax(5000), 760, ax(6000) - ax(5000), 56, 14); ctx.fill(); txt('INTI BUMI', 360, 788, 24, WHT, {align: 'left', w: 800}); ctx.restore();
      if (n > 35.17) { const q = popK(n - 35.17, .35); ctx.save(); ctx.globalAlpha = q.al; ctx.fillStyle = '#ffd24a'; ctx.beginPath(); ctx.arc(ax(5500), 884, 28, 0, 6.283); ctx.fill(); ctx.restore(); sun(ax(5500), 884, 22 * q.sc, q.al); txt('PERMUKAAN MATAHARI ≈ 5.500 °C', 680, 850, 24, '#ffe08a', {w: 800, al: q.al, stroke: INK, sw: 6}); }
    }
  };
}

/* ================= S3: tekanan ================= */
function s3() {
  const t = n - SB[3];
  BGF = () => { vgrad(0, 1920, '#0f1c33', '#050912'); glow(540, 700, 650, '70,130,255', .3); glow(540, 700, 620, '60,120,255', .16); };
  HUD = () => {
    head('*Tekanan* di pusat Bumi', 36.1, 41.0);
    const sq = eout(ramp(n, 36.6, 38.4)), gap = lerp(300, 46, sq), cx = 540, cy = 640;
    ctx.save(); ctx.fillStyle = '#5d6c8a'; rr(cx - 260, cy - gap - 90, 520, 90, 20); ctx.fill(); rr(cx - 260, cy + gap, 520, 90, 20); ctx.fill(); ctx.fillStyle = '#7e8eb0'; ctx.fillRect(cx - 60, cy - gap - 250, 120, 170); ctx.fillRect(cx - 60, cy + gap + 90, 120, 170); ctx.restore();
    diver(cx, cy + 10, 1.0 - .3 * sq, 0, 0);
    for (let i = 0; i < 7; i++) { const dx = (i - 3) * 62, a = ramp(n, 36.6, 37.2); arrow(cx + dx, cy - gap - 130 - 50 * a, cx + dx, cy - gap - 96, '#6ec0ff', 6, 16); arrow(cx + dx, cy + gap + 130 + 50 * a, cx + dx, cy + gap + 96, '#6ec0ff', 6, 16); }
    for (let i = 0; i < 2; i++) { const s = i ? 1 : -1; arrow(cx + s * 420, cy, cx + s * 230, cy, '#6ec0ff', 8, 22); }
    if (n > 37.13) { const k = ramp(n, 37.13, 38.4), p = popK(n - 37.13, .4); txt((3.6 * k).toFixed(1).replace('.', ',') + ' JUTA ×', 540, 1010, 100, '#9fd6ff', {sc: p.sc, al: p.al, stroke: INK, sw: 20, glow: 'rgba(80,160,255,.9)'}); }
    if (n > 38.6) { const p = popK(n - 38.6, .4); txt('tekanan atmosfer di permukaan laut', 540, 1100, 38, WHT, {al: p.al, stroke: INK, sw: 10, w: 700}); }
    if (n > 39.9) { const p = popK(n - 39.9, .4); tag('BAYANGKAN TERTEKAN DARI SEGALA ARAH', 540, 400, {sc: p.sc, al: p.al * clamp((41.0 - n) / .2, 0, 1), size: 26, border: CYN}); }
  };
}

/* ================= S4: pusat Bumi (3D mengambang) ================= */
const DEB = []; for (let i = 0; i < 16; i++) DEB.push({p: [(R(i, 1) - .5) * 9, (R(i, 2) - .5) * 9, (R(i, 3) - .5) * 5 - 1], r: [R(i, 4) * 6, R(i, 5) * 6, R(i, 6) * 6], v: [R(i, 7) - .5, R(i, 8) - .5, R(i, 9) - .5], s: .22 + R(i, 10) * .3, k: i % 3});
function s4() {
  USEGL = true; lights({fog: [.07, .04, .16], fd: .01, l2c: [.35, .2, .5]}); const t = n - SB[4];
  BGF = () => { vgrad(0, 1920, '#2b1450', '#080614'); glow(540, 700, 650, '255,170,90', .2); stars(.7, n * .2); };
  const a = t * .12; camSet([Math.sin(a) * 2, .6, 15.5], [0, 0, 0], 34); beginFrame();
  const bob = Math.sin(n * 1.3) * .18; const M = mmul(mT(0, bob, 0), mmul(mRz(Math.sin(n * .9) * .25), mRx(.15)));
  draw(CY, mmul(M, TRS([0, -.9, 0], [0, 0, 0], [.5, 1.3, .5])), O({tint: [1, .55, .18]})); draw(SP, mmul(M, TRS([0, .55, 0], [0, 0, 0], [.55, .55, .55])), O({tint: [.93, .95, 1], sp: .8})); draw(UB, mmul(M, TRS([0, .58, .3], [0, 0, 0], [.6, .26, .3])), O({tint: [.09, .13, .25], sp: .9}));
  [[-.65, -.5, 0, .5], [.65, -.5, 0, -.5]].forEach(([x, y, z, r], i) => draw(CY, mmul(M, TRS([x, y, z], [0, 0, r + Math.sin(n * 2 + i) * .3], [.16, 1, .16])), O({tint: [1, .5, .15]})));
  DEB.forEach((d, i) => { const p = [d.p[0] + Math.sin(n * .3 + i) * .6 + d.v[0] * t * .3, d.p[1] + Math.cos(n * .4 + i) * .6 + d.v[1] * t * .3, d.p[2]]; if (Math.abs(p[0]) < 1.5 && Math.abs(p[1]) < 2) p[0] += 3; const r = [d.r[0] + n * d.v[0] * 1.3, d.r[1] + n * d.v[1] * 1.3, d.r[2]]; if (d.k === 0) draw(UB, TRS(p, r, [d.s, d.s, d.s]), O({tint: [.6, .65, .8]})); else if (d.k === 1) draw(SP, TRS(p, r, [d.s * .8, d.s * .8, d.s * .8]), O({tint: [.9, .6, .3]})); else draw(UB, TRS(p, r, [d.s * 1.4, d.s * .6, d.s * .9]), O({tint: [.5, .8, .9]})); });
  flushParticles();
  HUD = () => {
    head('*Pusat Bumi*:\nada hal aneh', 41.1, 45.0);
    const q = P2([0, 0, 0]); if (n > 45.03) { const p = popK(n - 45.03, .35); head('Gravitasi bersih\n= *nol*', 45.1); txt('0', 540, 1020, 300, WHT, {sc: p.sc, al: p.al, stroke: INK, sw: 30, glow: 'rgba(255,150,60,.9)', gb: 60}); }
    if (n > 45.9) { const ar = clamp((n - 45.9) / .5, 0, 1), L = 150 + 12 * Math.sin(n * 4); for (let i = 0; i < 8; i++) { const an = i / 8 * 6.283 + .39, x0 = q.x + Math.cos(an) * (330 + 30 * (1 - ar)), y0 = q.y + Math.sin(an) * (330 + 30 * (1 - ar)), x1 = q.x + Math.cos(an) * (330 - L * ar), y1 = q.y + Math.sin(an) * (330 - L * ar); ctx.save(); ctx.globalAlpha = ar * .9; arrow(x0, y0, x1, y1, ORG, 8, 24); ctx.restore(); } }
    if (n > 47.7) { const p = popK(n - 47.7, .4); tag('SALING MENYEIMBANGKAN', 540, 1190, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff', size: 32}); }
  };
}

/* ================= S5: melewati pusat (penampang 2D) ================= */
function s5() {
  const u = clamp((n - 48.94) / 5.8, 0, 1), s = -Math.cos(Math.PI * u), cx = 540, cy = 700, RAD = 400, dy = cy + s * RAD, spd = Math.abs(Math.sin(Math.PI * u));
  BGF = () => { vgrad(0, 1920, '#0b1230', '#04060f'); stars(.8); glow(540, 700, 520, '60,100,255', .16); };
  HUD = () => {
    head('Kamu *tidak berhenti*\ndi sana', 48.98, 54.7);
    [[RAD, '#b98a5b'], [RAD * .95, '#d9531c'], [RAD * .55, '#ffc24a'], [RAD * .19, '#fff4cf']].forEach(([r, c]) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.283); ctx.fill(); });
    ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 5; ctx.setLineDash([14, 12]); ctx.beginPath(); ctx.moveTo(cx, cy - RAD - 40); ctx.lineTo(cx, cy + RAD + 40); ctx.stroke(); ctx.setLineDash([]); ctx.restore();
    ctx.save(); ctx.strokeStyle = `rgba(255,190,90,${.3 + spd * .6})`; ctx.lineWidth = 10 + spd * 14; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(cx, cy - RAD); ctx.lineTo(cx, dy); ctx.stroke(); ctx.restore();
    glow(cx, dy, 90, '255,200,120', .7); diver(cx, dy, .55, 0, 1);
    tag('PUSAT', cx + 200, cy, {size: 26, sc: 1}); const q = ramp(n, 49.2, 49.6);
    if (n > 52.2) { const p = popK(n - 52.2, .35); tag('TERUS MELUNCUR ▼', 540, 1190 - 20, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff', size: 32}); }
    ctx.save(); ctx.fillStyle = 'rgba(8,11,26,.8)'; rr(160, 1100 - 10, 760, 70, 35); ctx.fill(); const g = ctx.createLinearGradient(160, 0, 920, 0); g.addColorStop(0, '#35d0ee'); g.addColorStop(1, '#ff9b3d'); ctx.fillStyle = g; rr(166, 1106 - 10, 748 * spd, 58, 29); ctx.fill(); ctx.restore(); txt('KECEPATAN', 540, 1135 - 10, 26, WHT, {w: 800, stroke: INK, sw: 6});
  };
}

/* ================= S6: grafik kecepatan ================= */
function s6() {
  const u = clamp((n - 54.73) / 7.94, 0, 1), s = -Math.cos(Math.PI * u), gx0 = 130, gx1 = 950, gy0 = 1000, gy1 = 560, vx = (ss) => lerp(gx0, gx1, (ss + 1) / 2), vy = (ss) => lerp(gy0, gy1, Math.cos(Math.PI * ss / 2));
  BGF = () => { vgrad(0, 1920, '#06222c', '#03070d'); stars(.35); glow(540, 700, 500, '40,200,200', .12); };
  HUD = () => {
    head('Tanpa *udara* dan\ntanpa *gesekan*', 54.8, 62.1);
    ctx.save(); ctx.fillStyle = 'rgba(8,11,26,.55)'; rr(70, 480, 940, 600, 30); ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(gx0, gy1 - 40); ctx.lineTo(gx0, gy0); ctx.lineTo(gx1, gy0); ctx.stroke(); ctx.restore();
    txt('KECEPATAN', 120, 520, 24, '#9fe7ff', {align: 'left', w: 800}); txt('POSISI DI TEROWONGAN →', 950, 1048, 22, '#9fe7ff', {align: 'right', w: 700}); txt('atas', gx0, 1040, 20, '#7aa', {w: 700}); txt('bawah', gx1 - 4, 1018 - 0, 20, '#7aa', {w: 700, al: 0});
    ctx.save(); ctx.strokeStyle = CYN; ctx.lineWidth = 8; ctx.lineCap = 'round'; ctx.beginPath(); for (let i = 0; i <= 80; i++) { const ss = -1 + 2 * i / 80; i ? ctx.lineTo(vx(ss), vy(ss)) : ctx.moveTo(vx(ss), vy(ss)); } ctx.stroke(); ctx.restore();
    ctx.save(); ctx.strokeStyle = ORG; ctx.lineWidth = 8; ctx.beginPath(); for (let i = 0; i <= 80; i++) { const ss = -1 + 2 * i / 80; if (ss > s) break; i ? ctx.lineTo(vx(ss), vy(ss)) : ctx.moveTo(vx(ss), vy(ss)); } ctx.stroke(); ctx.restore();
    glow(vx(s), vy(s), 70, '255,170,70', .8); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(vx(s), vy(s), 15, 0, 6.283); ctx.fill();
    if (n > 55.05 && n < 58) { const p = popK(n - 55.05, .3); tag('UDARA ✕', 300, 400, {sc: p.sc, al: p.al, bg: '#7a1d1d', border: '#ff7a7a'}); }
    if (n > 56.4 && n < 58) { const p = popK(n - 56.4, .3); tag('GESEKAN ✕', 700, 400, {sc: p.sc, al: p.al, bg: '#7a1d1d', border: '#ff7a7a'}); }
    if (n > 58.5) { const p = popK(n - 58.5, .35); tag('PALING CEPAT: PUSAT', vx(0), vy(0) - 60, {sc: p.sc, al: p.al, bg: ORG, fg: INK, border: '#fff'}); }
    if (n > 60.3) { const p = popK(n - 60.3, .35); tag('MELAMBAT ↘', vx(.55), vy(.55) - 60, {sc: p.sc, al: p.al * clamp((62.1 - n) / .2, 0, 1)}); }
    if (n > 61.6) { const p = popK(n - 61.6, .35); tag('SISI SEBERANG', vx(1) - 100, vy(1) + 70, {sc: p.sc, al: p.al, bg: CYN, fg: INK, border: '#fff'}); }
  };
}

/* ================= S7: 38 menit ================= */
function s7() {
  const k = ramp(n, 62.8, 64.9), mins = 38 * eout(k);
  BGF = () => { vgrad(0, 1920, '#1a0f33', '#07040f'); stars(.5); glow(540, 650, 500, '150,90,255', .18); };
  HUD = () => {
    head('Berapa lama\nperjalanannya?', 62.2, 67.2);
    const cx = 540, cy = 650, r = 270; ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 26; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.283); ctx.stroke(); const g = ctx.createLinearGradient(cx - r, 0, cx + r, 0); g.addColorStop(0, '#35d0ee'); g.addColorStop(1, '#ff9b3d'); ctx.strokeStyle = g; ctx.lineCap = 'round'; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + 6.283 * (mins / 60)); ctx.stroke();
    for (let i = 0; i < 12; i++) { const a = i / 12 * 6.283; ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * (r + 30), cy + Math.sin(a) * (r + 30)); ctx.lineTo(cx + Math.cos(a) * (r + 46), cy + Math.sin(a) * (r + 46)); ctx.stroke(); }
    const ha = -Math.PI / 2 + 6.283 * (mins / 60); ctx.strokeStyle = '#fff'; ctx.lineWidth = 10; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(ha) * (r - 40), cy + Math.sin(ha) * (r - 40)); ctx.stroke(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(cx, cy, 14, 0, 6.283); ctx.fill(); ctx.restore();
    const mm = Math.floor(mins), ss = Math.floor((mins - mm) * 60); const p = popK(n - 62.8, .4); txt(String(mm).padStart(2, '0') + ':' + String(ss).padStart(2, '0'), 540, 640, 118, WHT, {font: MONO, w: 800, al: p.al, stroke: INK, sw: 18}); txt('menit', 540, 740, 40, '#c9b6ff', {w: 700, al: p.al});
    if (n > 63.8) { const q = popK(n - 63.8, .4); tag('≈ 38 MENIT', 540, 1030, {sc: q.sc, al: q.al, bg: ORG, fg: INK, border: '#fff', size: 44}); }
    if (n > 66.3) { const q = popK(n - 66.3, .35); tag('PERHITUNGAN TEORETIS', 540, 1130, {sc: q.sc, al: q.al, size: 30, border: '#c9b6ff'}); }
    if (n > 66.8) { txt('bukan percobaan nyata', 540, 1215 - 10, 26, '#9fa8d6', {al: clamp((n - 66.8) / .3, 0, 1) * clamp((67.1 - n) / .1, 0, 1), w: 600}); }
  };
}

/* ================= S8: Kola ================= */
function s8() {
  BGF = () => { vgrad(0, 1920, '#14202e', '#05090f'); stars(.3); };
  HUD = () => {
    head(n < 70.5 ? 'Lubang terdalam\nbuatan manusia' : '*Kola Superdeep\nBorehole*, Rusia', 67.3, 79.4);
    const r0 = 230, bx = 150, by0 = 330, by1 = 1130, bw = 90, a = clamp((n - 67.5) / .4, 0, 1); ctx.save(); ctx.globalAlpha = a; const g = ctx.createLinearGradient(0, by0, 0, by1); g.addColorStop(0, '#c9a073'); g.addColorStop(.12, '#d9531c'); g.addColorStop(.5, '#e0841c'); g.addColorStop(.8, '#ffc24a'); g.addColorStop(1, '#fff4cf'); ctx.fillStyle = g; rr(bx - bw / 2, by0, bw, by1 - by0, 14); ctx.fill(); ctx.restore();
    txt('PERMUKAAN', bx + 70, by0 - 24, 22, '#9fb0d6', {align: 'left', w: 800, al: a}); txt('PUSAT BUMI', bx + 70, by1 + 24, 22, '#9fb0d6', {align: 'left', w: 800, al: a}); txt('6.371 km', bx + 70, (by0 + by1) / 2, 30, WHT, {align: 'left', w: 800, al: a, stroke: INK, sw: 8});
    if (n > 70.64) { const p = popK(n - 70.64, .35); ctx.save(); ctx.globalAlpha = p.al; ctx.fillStyle = '#ff3a2e'; ctx.fillRect(bx - 70, by0, 140, 5); ctx.restore(); arrow(bx + 190, by0 - 70, bx + 40, by0 - 4, '#ff3a2e', 6, 20); }
    if (n > 71.3) { const p = popK(n - 71.3, .45), cx = 690, cy = 650, r = 230; ctx.save(); ctx.globalAlpha = p.al; ctx.translate(cx, cy); ctx.scale(p.sc, p.sc); ctx.fillStyle = '#0e1a29'; ctx.beginPath(); ctx.arc(0, 0, r, 0, 6.283); ctx.fill(); ctx.save(); ctx.beginPath(); ctx.arc(0, 0, r - 4, 0, 6.283); ctx.clip(); vgrad2(-r, r); ctx.restore(); ctx.strokeStyle = '#ff3a2e'; ctx.lineWidth = 8; ctx.beginPath(); ctx.arc(0, 0, r, 0, 6.283); ctx.stroke(); ctx.restore(); }
    function vgrad2(y0, y1) { const g = ctx.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#2a1a4a'); g.addColorStop(.35, '#e0764a'); g.addColorStop(.36, '#6b4a2f'); g.addColorStop(1, '#2b1a10'); ctx.fillStyle = g; ctx.fillRect(-r0, y0, r0 * 2, y1 - y0); }
    if (n > 71.3) { const p = popK(n - 71.3, .45), cx = 690, cy = 650, k = clamp((n - 73.0) / 1.2, 0, 1); ctx.save(); ctx.globalAlpha = p.al; ctx.translate(cx, cy); ctx.fillStyle = '#c9d4e8'; ctx.fillRect(-40, -90, 12, 90); ctx.fillRect(-70, -60, 70, 8); ctx.strokeStyle = '#c9d4e8'; ctx.lineWidth = 7; ctx.beginPath(); ctx.moveTo(-70, 0); ctx.lineTo(-34, -92); ctx.lineTo(0, 0); ctx.stroke(); ctx.fillStyle = '#05060c'; ctx.fillRect(-34, 0, 12, 170 * k); ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 3; for (let i = 0; i < 6; i++) { ctx.beginPath(); ctx.moveTo(-10, i * 34); ctx.lineTo(18, i * 34); ctx.stroke(); } ctx.restore(); }
    if (n > 73.58) { const p = popK(n - 73.58, .4); txt('12,2 km', 690, 960, 84, ORG2, {sc: p.sc, al: p.al, stroke: INK, sw: 16, glow: 'rgba(255,140,40,.8)'}); }
    if (n > 76.33) { const p = popK(n - 76.33, .4); txt('< 0,2 %', 690, 1075, 92, WHT, {sc: p.sc, al: p.al, stroke: INK, sw: 18, glow: 'rgba(255,60,50,.8)'}); txt('jarak menuju pusat Bumi', 690, 1160, 32, '#c0cbe6', {al: p.al, w: 700}); }
  };
}

/* ================= S9: penutup (3D) + end card ================= */
function s9() {
  USEGL = true; lights(); const t = n - SB[9], rot = n * .4 + 2.2, tilt = .38;
  BGF = () => { vgrad(0, 1920, '#10173a', '#04060f'); stars(.9); glow(540, 700, 600, '60,110,255', .14); };
  camSet([0, .2, 10.4], [0, -.1, 0], 34); beginFrame();
  const top = mApply(mRz(tilt), [0, 1.62, 0]), bot = mApply(mRz(tilt), [0, -1.62, 0]); const G = mmul(mRz(tilt), mRy(rot));
  for (let i = 0; i < 12; i++) { const a = vlerp(top, bot, i / 12), b = vlerp(top, bot, (i + .55) / 12), d = vsub(b, a), L = vlen(d); if (L < 1e-4) continue; const an = vnorm(d), tt = Math.abs(an[1]) < .9 ? [0, 1, 0] : [1, 0, 0], u = vnorm(vcross(an, tt)), v = vcross(an, u), mid = vmul(vadd(a, b), .5), m = ident(); m[0] = u[0] * .08; m[1] = u[1] * .08; m[2] = u[2] * .08; m[4] = an[0] * L; m[5] = an[1] * L; m[6] = an[2] * L; m[8] = v[0] * .08; m[9] = v[1] * .08; m[10] = v[2] * .08; m[12] = mid[0]; m[13] = mid[1]; m[14] = mid[2]; draw(UB, m, O({tint: [1, .62, .2], em: 1.2})); }
  draw(EARTH, mmul(G, mS(1.6)), O({al: .6, dw: false, sp: .5, rim: .6}));
  flushParticles();
  HUD = () => {
    if (n < NEND) {
      head('Masih *eksperimen\npikiran*', 79.55, 84.0);
      if (n > 81.45) { const p = popK(n - 81.45, .4); txt('💭', 840, 380, 120, WHT, {sc: p.sc, al: p.al * clamp((84 - n) / .2, 0, 1)}); }
      if (n > 82.25) { const p = popK(n - 82.25, .35); tag('SUHU EKSTREM', 300, 1000, {sc: p.sc, al: p.al, bg: '#7a1d1d', border: '#ff9a7a', size: 32}); }
      if (n > 83.1) { const p = popK(n - 83.1, .35); tag('TEKANAN EKSTREM', 760, 1060, {sc: p.sc, al: p.al, bg: '#1d3a7a', border: '#7ab0ff', size: 32}); }
      if (n > 84.13) { const p = popK(n - 84.13, .22), k = 1 + Math.exp(-(n - 84.13) * 9) * .8; ctx.save(); ctx.translate(540, 460); ctx.rotate(-.1); ctx.scale(p.sc * k, p.sc * k); ctx.globalAlpha = p.al; ctx.lineWidth = 14; ctx.strokeStyle = '#ff3a2e'; ctx.shadowColor = 'rgba(255,50,30,.9)'; ctx.shadowBlur = 36; rr(-420, -118, 840, 236, 26); ctx.stroke(); ctx.restore(); txt('MUSTAHIL\nSAAT INI', 540, 460, 96, '#ff4a3d', {rot: -.1, sc: p.sc * k, al: p.al, stroke: INK, sw: 18}); }
    } else {
      const k = n - NEND, a = clamp(k / .5, 0, 1); ctx.save(); ctx.globalAlpha = a * .86; ctx.fillStyle = '#04060f'; ctx.fillRect(0, 0, 1080, 1920); ctx.restore();
      const p = popK(k - .1, .5); txt('Semesta', 540, 520, 140, WHT, {sc: p.sc, al: p.al}); txt('Kita', 540, 655, 160, ORG, {sc: popK(k - .25, .5).sc, al: popK(k - .25, .5).al, glow: 'rgba(255,150,60,.7)'});
      txt('Simpan video ini, kirim ke teman\nyang masih penasaran 👇', 540, 840, 44, WHT, {w: 700, al: clamp((k - .7) / .4, 0, 1)}); tag('38 MENIT = MODEL TEORETIS', 540, 1000, {size: 30, border: ORG, al: clamp((k - 1.0) / .4, 0, 1)});
      txt('Sumber: USGS • American Journal of Physics •\nGuinness World Records • NASA Earth Science', 540, 1130, 26, '#9fb0d6', {w: 600, al: clamp((k - 1.3) / .5, 0, 1)});
    }
  };
}

/* ================= caption & watermark & transisi ================= */
const CHUNKS = (() => { const out = []; let cur = []; const flush = () => { if (cur.length) out.push(cur); cur = []; }; WORDS.forEach((w) => { const len = cur.reduce((a, c) => a + c.w.length + 1, 0); if (cur.length && (len + w.w.length > 28 || cur.length >= 5)) flush(); cur.push(w); if (w.b) flush(); }); flush(); return out.map((c, i) => ({ws: c, a: c[0].a, e: out[i + 1] ? Math.min(out[i + 1][0].a, c[c.length - 1].e + .4) : c[c.length - 1].e + .3})); })();
function captions() {
  if (n >= NEND - .1) return; const ch = CHUNKS.find((c) => n >= c.a - .02 && n < c.e); if (!ch) return; const size = 48, y = 1250; const clean = (s) => s.replace(/[,\.\?:]+$/, '');
  ctx.save(); ctx.font = `800 ${size}px ${FONT}`; const sp = size * .3, ws = ch.ws.map((w) => ctx.measureText(clean(w.w)).width), tot = ws.reduce((a, b) => a + b, 0) + sp * (ws.length - 1);
  let lines = [[...ch.ws.keys()]]; if (tot > 860) { let acc = 0, split = 0; for (let i = 0; i < ws.length; i++) { acc += ws[i] + sp; if (acc > tot / 2) { split = i + 1; break; } } lines = [[...ch.ws.keys()].slice(0, split), [...ch.ws.keys()].slice(split)]; }
  const lw = lines.map((l) => l.reduce((a, i) => a + ws[i], 0) + sp * (l.length - 1)), pw = Math.max(...lw) + 76, ph = lines.length * size * 1.4 + 28, py = y - ph / 2, pop = clamp((n - ch.a) / .1, 0, 1);
  ctx.globalAlpha = pop; ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = 20; ctx.fillStyle = 'rgba(6,9,22,.8)'; rr(540 - pw / 2, py, pw, ph, 34); ctx.fill(); ctx.shadowBlur = 0; ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 2; ctx.stroke();
  lines.forEach((l, li) => { let x = 540 - lw[li] / 2; const yy = py + 14 + size * .7 + li * size * 1.4; l.forEach((i) => { const w = ch.ws[i], act = n >= w.a - .02 && n < w.e + .04 || (i === ch.ws.length - 1 && n >= w.a); if (act) { ctx.fillStyle = ORG; rr(x - 12, yy - size * .64, ws[i] + 24, size * 1.28, 14); ctx.fill(); } ctx.fillStyle = act ? INK : WHT; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(clean(w.w), x, yy); x += ws[i] + sp; }); }); ctx.restore();
}
function watermark() { ctx.save(); ctx.globalAlpha = .85; const x = 1030, y = 1445; ctx.font = `800 34px ${FONT}`; const wk = ctx.measureText('Kita').width, ws = ctx.measureText('Semesta').width; ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 10; ctx.textBaseline = 'middle'; ctx.textAlign = 'right'; ctx.fillStyle = WHT; ctx.fillText('Semesta', x - wk, y); ctx.fillStyle = ORG; ctx.fillText('Kita', x, y); ctx.shadowBlur = 0; const cx = x - wk - ws - 28; ctx.fillStyle = ORG; ctx.beginPath(); ctx.arc(cx, y, 14, 0, 6.283); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(cx, y, 14, 5, -.5, 0, 6.283); ctx.stroke(); ctx.restore(); }
function transitions() { SB.slice(1, -1).forEach((b) => { const t = n - b; if (t > -.06 && t < .3) { const yt = -1920 + (t + .06) / .36 * 3840; ctx.save(); ctx.globalAlpha = .96; ctx.fillStyle = '#070a18'; ctx.fillRect(0, yt, 1080, 1920); ctx.fillStyle = ORG; ctx.fillRect(0, yt + 1920 - 6, 1080, 6); ctx.restore(); } }); }

const SCN = [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9];
ENGINE.renderFrame = function (T) {
  n = T - OFF; let i = 0; while (i < SCN.length - 1 && n >= SB[i + 1]) i++; USEGL = false; SCN[i]();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; ctx.save(); ctx.scale(SC, SC); BGF(); ctx.restore(); if (USEGL) ctx.drawImage(glc, 0, 0);
  ctx.save(); ctx.scale(SC, SC); HUD(); captions(); watermark(); transitions(); ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fillRect(0, 0, 1080, 8); ctx.fillStyle = ORG; ctx.fillRect(0, 0, 1080 * clamp(T / DUR, 0, 1), 8); ctx.restore();
};
ENGINE.grab = () => outc.toDataURL('image/jpeg', .92);
})();

  return ENGINE;
}

export const Bumi: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<any>(null);

  useLayoutEffect(() => {
    if (!engineRef.current) engineRef.current = createEngine(canvasRef.current!);
    engineRef.current.renderFrame(frame / fps);
  }, [frame, fps]);

  return (
    <AbsoluteFill style={{backgroundColor: '#04060f'}}>
      <canvas ref={canvasRef} style={{width: 1080, height: 1920, display: 'block'}} />
      <Audio src={staticFile('audio.mp3')} />
    </AbsoluteFill>
  );
};
