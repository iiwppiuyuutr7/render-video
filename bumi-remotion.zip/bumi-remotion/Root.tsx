import React from 'react';
import {Composition} from 'remotion';
import {Bumi} from './Bumi';

// 90 detik x 60 fps = 5400 frame, 1080x1920 (9:16)
export const RemotionRoot: React.FC = () => (
  <Composition id="Bumi" component={Bumi} durationInFrames={5400} fps={60} width={1080} height={1920} />
);
