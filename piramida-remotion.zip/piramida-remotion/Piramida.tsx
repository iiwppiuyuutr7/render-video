import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  BAGAIMANA MANUSIA ZAMAN DAHULU MEMBANGUN PIRAMIDA RAKSASA?
  90 detik tepat (2700 frame @ 30 fps), 1080x1920 (9:16).
  Motion graphics 2D + rekonstruksi "3D" murni SVG (proyeksi manual, tanpa WebGL), jadi ringan di RAM.
  Semua waktu dalam DETIK.

  AUDIO
  - public/audio.mp3  : MIX FINAL = narasi (ElevenLabs) + musik + ambience + whoosh/impact, 90 detik.
    Musik otomatis turun saat narator bicara. Timing subtitle (SUBS) dan adegan (SCENE_START) sudah disesuaikan.
  - public/audio_tanpa_narasi.mp3 : versi musik + efek saja (cadangan, tidak dipakai di komposisi).
*/


const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;

const C = {
  sand: '#d9b36c',
  sandL: '#f1d9a0',
  sandD: '#a8793c',
  gold: '#f2c14e',
  goldD: '#b9832a',
  stone: '#8a6a4a',
  stoneD: '#5b4430',
  black: '#08080b',
  navy: '#0b1530',
  navyL: '#17295a',
  cream: '#efe2bd',
  water: '#1d4f7a',
  waterL: '#3f86b5',
  palm: '#3d6a3a',
  ink: '#2a1e14',
  red: '#a8372a',
  lime: '#e6d3a2',
};

/* ---------- util ---------- */
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (t: number, a: number, b: number, from = 0, to = 1, easing: (x: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(t, [a, b], [from, to], {...cl, easing});
const lin = Easing.linear;
const outC = Easing.out(Easing.cubic);
const inC = Easing.in(Easing.cubic);
const inOutC = Easing.inOut(Easing.cubic);
// jendela tampil: fade in di a, fade out di b
const win = (t: number, a: number, b: number, f = 0.35) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const hx = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const toHex = (v: number[]) => '#' + v.map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0')).join('');
const blend = (a: string, b: string, k: number) => {
  const A = hx(a);
  const B = hx(b);
  return toHex(A.map((v, i) => v + (B[i] - v) * k));
};
const pts = (arr: [number, number][]) => arr.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
const cam = (z: number, fx: number, fy: number, sx = W / 2, sy = H / 2) => `translate(${sx} ${sy}) scale(${z}) translate(${-fx} ${-fy})`;
const TXT_SH = '0 4px 18px rgba(0,0,0,0.85)';

/* ---------- adegan, narasi + subtitle ----------
   Waktu mulai adegan disesuaikan dengan rekaman narasi (public/audio.mp3 sudah berisi narasi).
   WARP = durasi rancangan adegan / durasi sebenarnya: isi adegan dipercepat/diperlambat secara seragam. */
const SCENES: {tag: string}[] = [
  {tag: '01 · PEMBUKA'},
  {tag: '02 · PERENCANAAN & MATERIAL'},
  {tag: '03 · DARI TURA KE GIZA'},
  {tag: '04 · MENAIKKAN BATU'},
  {tag: '05 · SIAPA PEMBANGUNNYA?'},
  {tag: '06 · PENUTUP'},
];
const SCENE_START = [0, 9.0, 21.9, 36.5, 52.0, 69.0];
const WARP = [8 / 9.0, 15 / 12.9, 16 / 14.6, 19 / 15.5, 15 / 17.0, 17 / 21.0];

// subtitle sinkron dengan rekaman narasi (hasil penyelarasan suku kata + jeda pada audio)
const SUBS: {a: number; b: number; text: string}[] = [
  {a: 0.8, b: 2.83, text: "Lebih dari empat ribu tahun lalu,"},
  {a: 2.85, b: 5.56, text: "manusia berhasil membangun sebuah bangunan"},
  {a: 5.58, b: 7.63, text: "raksasa tanpa alat berat modern."},
  {a: 8.03, b: 9.1, text: "Bagaimana caranya?"},
  {a: 9.94, b: 13.09, text: "Piramida Agung Giza dibangun untuk Raja Khufu."},
  {a: 13.48, b: 17.28, text: "Bangunan ini awalnya memiliki tinggi sekitar 146"},
  {a: 17.3, b: 20.05, text: "setengah meter, menggunakan batu-batu yang"},
  {a: 20.07, b: 21.58, text: "jumlahnya sangat besar."},
  {a: 22.79, b: 25.5, text: "Sebagian batu berasal dari sekitar Giza."},
  {a: 25.74, b: 28.61, text: "Namun, batu kapur berkualitas tinggi untuk"},
  {a: 28.63, b: 30.88, text: "lapisan luar didatangkan dari Tura."},
  {a: 31.18, b: 33.77, text: "Catatan kuno bahkan merekam pengangkutan batu"},
  {a: 33.79, b: 36.08, text: "menggunakan kapal melalui Sungai Nil."},
  {a: 37.36, b: 38.69, text: "Di lokasi pembangunan,"},
  {a: 38.79, b: 41.83, text: "batu-batu besar harus dipindahkan dan dinaikkan."},
  {a: 42.04, b: 44.81, text: "Salah satu penjelasan yang banyak dibahas adalah"},
  {a: 44.83, b: 47.32, text: "penggunaan ramp, yaitu jalur miring untuk"},
  {a: 47.34, b: 50.26, text: "membantu menarik batu ke tingkat yang lebih tinggi."},
  {a: 52.86, b: 54.93, text: "Dan siapa yang mengerjakannya?"},
  {a: 55.19, b: 57.8, text: "Bukti arkeologi menunjukkan adanya permukiman"},
  {a: 57.82, b: 59.65, text: "pekerja, tempat penyimpanan,"},
  {a: 59.67, b: 60.73, text: "dan pemakaman."},
  {a: 60.93, b: 63.5, text: "Pembangunan piramida melibatkan masyarakat yang"},
  {a: 63.52, b: 66.47, text: "terorganisasi, bukan sekadar cerita tentang"},
  {a: 66.49, b: 68.41, text: "budak atau makhluk luar angkasa."},
  {a: 69.87, b: 72.09, text: "Hingga sekarang, beberapa detail teknik"},
  {a: 72.11, b: 74.89, text: "pembangunannya masih menjadi bahan penelitian."},
  {a: 75.11, b: 77.62, text: "Kita mungkin belum mengetahui setiap langkahnya,"},
  {a: 77.84, b: 80.88, text: "tetapi bukti yang ditemukan menunjukkan betapa"},
  {a: 80.9, b: 82.69, text: "hebatnya kemampuan teknik,"},
  {a: 82.86, b: 86.07, text: "organisasi, dan pengetahuan manusia pada masa itu."},
];

/* ---------- proyeksi 3D piramida ---------- */
type V3 = [number, number, number];
const HH = 1.272; // tinggi relatif terhadap setengah alas (146,5 m : 115,2 m)

const rot = (x: number, y: number, z: number, yaw: number, pitch: number): V3 => {
  const x1 = x * Math.cos(yaw) + z * Math.sin(yaw);
  const z1 = -x * Math.sin(yaw) + z * Math.cos(yaw);
  const y2 = y * Math.cos(pitch) + z1 * Math.sin(pitch);
  const z2 = -y * Math.sin(pitch) + z1 * Math.cos(pitch);
  return [x1, y2, z2];
};
const makeCam = (cx: number, cy: number, S: number, yaw: number, pitch: number) => ({
  P: (v: V3): [number, number] => {
    const r = rot(v[0], v[1], v[2], yaw, pitch);
    return [cx + r[0] * S, cy - r[1] * S];
  },
  N: (v: V3): V3 => rot(v[0], v[1], v[2], yaw, pitch),
});
const lerp3 = (a: V3, b: V3, k: number): V3 => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const nrm = (v: V3): V3 => {
  const l = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / l, v[1] / l, v[2] / l];
};
const LIGHT = nrm([-0.5, 0.62, -0.6]);

type PyrProps = {
  cx: number;
  cy: number;
  S: number;
  yaw: number;
  pitch: number;
  trunc?: number;
  fill?: number;
  wire?: number;
  courses?: number;
  sweep?: number;
  lit?: string;
  dark?: string;
  lineOp?: number;
};

const Pyr: React.FC<PyrProps> = ({cx, cy, S, yaw, pitch, trunc = 1, fill = 1, wire = 0, courses = 30, sweep = -1, lit = C.sandL, dark = '#6b4c33', lineOp = 0.26}) => {
  const {P, N} = makeCam(cx, cy, S, yaw, pitch);
  const ht = HH * trunc;
  const a = 1 - trunc;
  const A: V3 = [-1, 0, -1];
  const B: V3 = [1, 0, -1];
  const Cc: V3 = [1, 0, 1];
  const D: V3 = [-1, 0, 1];
  const A2: V3 = [-a, ht, -a];
  const B2: V3 = [a, ht, -a];
  const C2: V3 = [a, ht, a];
  const D2: V3 = [-a, ht, a];
  const faces: {q: V3[]; n: V3; side: boolean}[] = [
    {q: [A, B, B2, A2], n: [0, 1 / HH, -1], side: true},
    {q: [B, Cc, C2, B2], n: [1, 1 / HH, 0], side: true},
    {q: [Cc, D, D2, C2], n: [0, 1 / HH, 1], side: true},
    {q: [D, A, A2, D2], n: [-1, 1 / HH, 0], side: true},
  ];
  if (trunc < 0.999) faces.push({q: [A2, B2, C2, D2], n: [0, 1, 0], side: false});
  const out: React.ReactNode[] = [];
  const hidden: React.ReactNode[] = [];
  faces.forEach((f, i) => {
    const nv = nrm(N(f.n));
    const vis = nv[2] < 0;
    const poly = pts(f.q.map((v) => P(v)));
    if (!vis) {
      if (wire > 0.01) hidden.push(<polygon key={'h' + i} points={poly} fill="none" stroke={C.gold} strokeWidth={2} opacity={wire * 0.3} strokeDasharray="10 8" />);
      return;
    }
    const dot = Math.max(0, nv[0] * LIGHT[0] + nv[1] * LIGHT[1] + nv[2] * LIGHT[2]);
    const col = blend(dark, lit, 0.12 + 0.88 * dot);
    out.push(<polygon key={'f' + i} points={poly} fill={col} opacity={fill} stroke={wire > 0.01 ? C.gold : 'none'} strokeOpacity={wire} strokeWidth={3} strokeLinejoin="round" />);
    if (f.side && courses > 0) {
      for (let k = 1; k < courses; k++) {
        const tt = (k / courses) * 1;
        const p0 = P(lerp3(f.q[0], f.q[3], tt));
        const p1 = P(lerp3(f.q[1], f.q[2], tt));
        const on = sweep >= 0 && tt <= sweep;
        const head = sweep >= 0 && Math.abs(tt - sweep) < 0.5 / courses;
        out.push(
          <line
            key={`c${i}_${k}`}
            x1={p0[0]}
            y1={p0[1]}
            x2={p1[0]}
            y2={p1[1]}
            stroke={head ? '#ffffff' : on ? C.gold : '#000000'}
            strokeOpacity={head ? 1 : on ? 0.95 : lineOp * Math.max(fill, wire * 0.8)}
            strokeWidth={head ? 5 : on ? 3 : 1.6}
          />,
        );
      }
    }
  });
  return (
    <g>
      {hidden}
      {out}
    </g>
  );
};

/* ---------- figur manusia 2D (tanpa wajah, gaya silhouette) ---------- */
type Pose = 'walk' | 'pull' | 'cut' | 'carry' | 'stand' | 'pour' | 'idle';
const SKIN = '#a9683c';
const SKIN_D = '#85492a';
const KILT = '#efe6cf';
const HAIR = '#16110d';
const lim = (ox: number, oy: number, a1: number, a2: number, l1: number, l2: number): [number, number, number, number] => {
  const kx = ox + l1 * Math.sin(a1);
  const ky = oy + l1 * Math.cos(a1);
  return [kx, ky, kx + l2 * Math.sin(a2), ky + l2 * Math.cos(a2)];
};
const PULL_HAND: [number, number] = [73, -93];

const Man: React.FC<{x: number; y: number; s?: number; flip?: boolean; pose?: Pose; t: number; ph?: number; sp?: number; kilt?: string}> = ({x, y, s = 1, flip = false, pose = 'idle', t, ph = 0, sp = 6, kilt = KILT}) => {
  const p = t * sp + ph;
  const sw = Math.sin(p);
  const cw = Math.cos(p);
  let ln = 0;
  let lf: [number, number] = [0.08, 0.04];
  let lb: [number, number] = [-0.08, -0.04];
  let af: [number, number] = [0.1, 0.2];
  let ab: [number, number] = [-0.1, 0.1];
  let hold: ((hf: [number, number], hb: [number, number]) => React.ReactNode) | null = null;
  let gear: React.ReactNode = null;
  if (pose === 'walk' || pose === 'carry') {
    lf = [0.55 * sw, 0.55 * sw - 0.45 * (0.5 + 0.5 * cw)];
    lb = [-0.55 * sw, -0.55 * sw - 0.45 * (0.5 - 0.5 * cw)];
    af = [-0.5 * sw, -0.5 * sw + 0.25];
    ab = [0.5 * sw, 0.5 * sw + 0.25];
    ln = 0.05;
    if (pose === 'carry') {
      af = [2.75, 2.95];
      ab = [2.6, 2.85];
      gear = (
        <g>
          <path d="M -22 -154 Q 0 -128 22 -154 Z" fill="#9b6b3a" />
          <circle cx={-8} cy={-158} r={8} fill="#e8d9a8" />
          <circle cx={6} cy={-160} r={9} fill="#d9c58a" />
          <circle cx={0} cy={-166} r={7} fill="#e8d9a8" />
        </g>
      );
    }
  } else if (pose === 'pull') {
    ln = 0.5;
    lf = [0.45 + 0.28 * sw, 0.15 + 0.2 * sw];
    lb = [-0.55 - 0.28 * sw, -0.3 - 0.2 * sw];
    af = [1.15, 1.2];
    ab = [1.05, 1.15];
  } else if (pose === 'cut') {
    const strike = 0.5 + 0.5 * Math.sin(p);
    ln = 0.22 - 0.25 * strike;
    lf = [0.5, 0.1];
    lb = [-0.45, -0.1];
    af = [1.4 + 1.5 * strike, 1.5 + 1.5 * strike];
    ab = [1.3, 1.45];
    hold = (hf, hb) => {
      const a2 = af[1];
      const dx = Math.sin(a2);
      const dy = Math.cos(a2);
      const tx = hf[0] + dx * 26;
      const ty = hf[1] + dy * 26;
      return (
        <g>
          <line x1={hb[0]} y1={hb[1]} x2={hb[0] + Math.sin(1.55) * 24} y2={hb[1] + Math.cos(1.55) * 24} stroke="#c9773a" strokeWidth={5} strokeLinecap="round" />
          <line x1={hf[0]} y1={hf[1]} x2={tx} y2={ty} stroke="#6b4a2a" strokeWidth={6} strokeLinecap="round" />
          <line x1={tx - dy * 9} y1={ty + dx * 9} x2={tx + dy * 9} y2={ty - dx * 9} stroke="#4a3220" strokeWidth={12} strokeLinecap="round" />
        </g>
      );
    };
  } else if (pose === 'stand') {
    lf = [0.12, 0.08];
    lb = [-0.12, -0.08];
    af = [0.35, 0.4];
    ab = [1.1, 1.65];
    hold = (hf, hb) => (
      <g>
        <line x1={hf[0] + 6} y1={hf[1] + 70} x2={hf[0] + 6} y2={hf[1] - 92} stroke="#6b4a2a" strokeWidth={6} strokeLinecap="round" />
        <circle cx={hf[0] + 6} cy={hf[1] - 94} r={7} fill={C.gold} />
        <rect x={hb[0] - 6} y={hb[1] - 22} width={26} height={34} rx={3} fill="#efe2bd" stroke="#8a6a4a" strokeWidth={2} />
        <line x1={hb[0]} y1={hb[1] - 12} x2={hb[0] + 14} y2={hb[1] - 12} stroke="#8a6a4a" strokeWidth={2} />
        <line x1={hb[0]} y1={hb[1] - 4} x2={hb[0] + 14} y2={hb[1] - 4} stroke="#8a6a4a" strokeWidth={2} />
      </g>
    );
  } else if (pose === 'pour') {
    ln = 0.38;
    lf = [0.5, 0.2];
    lb = [-0.5, -0.2];
    af = [1.5, 1.75];
    ab = [0.9, 0.45];
    hold = (hf) => (
      <g>
        <ellipse cx={hf[0] + 8} cy={hf[1] + 4} rx={13} ry={17} fill="#8a5a3a" transform={`rotate(-50 ${hf[0] + 8} ${hf[1] + 4})`} />
        {[0, 1, 2, 3].map((i) => {
          const f = (t * 2.2 + i * 0.25) % 1;
          return <line key={i} x1={hf[0] + 24 + f * 6} y1={hf[1] + 6 + f * 70} x2={hf[0] + 24 + f * 6} y2={hf[1] + 16 + f * 70} stroke="#8fc4ff" strokeWidth={3} strokeLinecap="round" opacity={1 - f * 0.6} />;
        })}
      </g>
    );
  }
  const hip: [number, number] = [0, -72];
  const sh: [number, number] = [hip[0] + 48 * Math.sin(ln), hip[1] - 48 * Math.cos(ln)];
  const neck: [number, number] = [hip[0] + 58 * Math.sin(ln), hip[1] - 58 * Math.cos(ln)];
  const hd: [number, number] = [hip[0] + 72 * Math.sin(ln), hip[1] - 72 * Math.cos(ln)];
  const LF = lim(hip[0], hip[1], lf[0], lf[1], 36, 36);
  const LB = lim(hip[0], hip[1], lb[0], lb[1], 36, 36);
  const AF = lim(sh[0], sh[1], af[0], af[1], 27, 28);
  const AB = lim(sh[0], sh[1], ab[0], ab[1], 27, 28);
  const pl = (q: number[], c: string, w: number, a: [number, number]) => (
    <polyline points={`${a[0]},${a[1]} ${q[0]},${q[1]} ${q[2]},${q[3]}`} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" />
  );
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={2} rx={34} ry={7} fill="rgba(0,0,0,0.22)" />
      {pl(AB, SKIN_D, 10, sh)}
      {pl(LB, SKIN_D, 13, hip)}
      <line x1={hip[0]} y1={hip[1]} x2={neck[0]} y2={neck[1]} stroke={SKIN} strokeWidth={24} strokeLinecap="round" />
      <polygon points={`-15,-82 15,-82 19,-46 -17,-46`} fill={kilt} />
      <polygon points={`-15,-82 15,-82 15,-76 -15,-76`} fill="#d4c7a3" />
      {pl(LF, SKIN, 13, hip)}
      <circle cx={hd[0]} cy={hd[1]} r={12.5} fill={SKIN} />
      <path d={`M ${hd[0] - 13} ${hd[1] + 1} A 13 13 0 0 1 ${hd[0] + 13} ${hd[1] + 1} L ${hd[0] + 13} ${hd[1] + 7} L ${hd[0] + 9} ${hd[1] - 1} L ${hd[0] - 9} ${hd[1] - 1} L ${hd[0] - 13} ${hd[1] + 7} Z`} fill={HAIR} />
      {gear}
      {pl(AF, SKIN, 10, sh)}
      {hold ? hold([AF[2], AF[3]], [AB[2], AB[3]]) : null}
    </g>
  );
};

/* ---------- elemen umum ---------- */
const Blk: React.FC<{x: number; y: number; w: number; h: number; dx?: number; dy?: number; c?: string}> = ({x, y, w, h, dx = 46, dy = 30, c = C.lime}) => (
  <g>
    <polygon points={`${x},${y} ${x + dx},${y - dy} ${x + w + dx},${y - dy} ${x + w},${y}`} fill={blend(c, '#ffffff', 0.3)} />
    <polygon points={`${x + w},${y} ${x + w + dx},${y - dy} ${x + w + dx},${y + h - dy} ${x + w},${y + h}`} fill={blend(c, '#000000', 0.3)} />
    <rect x={x} y={y} width={w} height={h} fill={c} />
    <rect x={x} y={y} width={w} height={4} fill="rgba(255,255,255,0.4)" />
    <line x1={x + w * 0.5} y1={y} x2={x + w * 0.5} y2={y + h} stroke="rgba(0,0,0,0.07)" strokeWidth={2} />
  </g>
);

const Dune: React.FC<{y: number; amp: number; f: number; ph: number; color: string; shift?: number}> = ({y, amp, f, ph, color, shift = 0}) => {
  const a: string[] = [];
  for (let x = -60; x <= W + 60; x += 24) {
    const yy = y + amp * Math.sin((x + shift) * f + ph) + amp * 0.4 * Math.sin((x + shift) * f * 2.3 + ph * 1.7);
    a.push(`${x},${yy.toFixed(1)}`);
  }
  return <polygon points={`-60,${H + 100} ${a.join(' ')} ${W + 60},${H + 100}`} fill={color} />;
};

const Tag: React.FC<{text: string; o: number}> = ({text, o}) => (
  <div style={{position: 'absolute', left: 60, top: 130, opacity: o, display: 'flex', alignItems: 'center', gap: 14}}>
    <div style={{width: 10, height: 38, background: C.gold, borderRadius: 3}} />
    <div style={{fontFamily: cond, fontWeight: 700, fontSize: 38, letterSpacing: '0.08em', color: '#fff', textShadow: TXT_SH}}>{text}</div>
  </div>
);

const Chip: React.FC<{x: number; y: number; w: number; label: string; value: string; o: number}> = ({x, y, w, label, value, o}) => (
  <div style={{position: 'absolute', left: x, top: y + (1 - o) * 24, width: w, opacity: o, background: 'rgba(8,10,22,0.72)', borderLeft: `6px solid ${C.gold}`, borderRadius: 10, padding: '12px 16px 14px'}}>
    <div style={{fontFamily: sans, fontWeight: 600, fontSize: 21, letterSpacing: '0.12em', color: C.sandL}}>{label}</div>
    <div style={{fontFamily: cond, fontWeight: 700, fontSize: 40, lineHeight: 1.05, color: '#fff'}}>{value}</div>
  </div>
);

const Big: React.FC<{top: number; o: number; lines: string[]; size?: number; color?: string; ls?: string; dy?: number}> = ({top, o, lines, size = 96, color = '#fff', ls = '0.03em', dy = 0}) => (
  <div style={{position: 'absolute', left: 50, right: 50, top: top + (1 - o) * dy, textAlign: 'center', opacity: o, fontFamily: cond, fontWeight: 700, fontSize: size, lineHeight: 1.02, letterSpacing: ls, color, textShadow: TXT_SH}}>
    {lines.map((l, i) => (
      <div key={i}>{l}</div>
    ))}
  </div>
);

const Disclaimer: React.FC<{o: number}> = ({o}) => (
  <div style={{position: 'absolute', left: 50, right: 50, top: 1392, textAlign: 'center', opacity: o, fontFamily: cond, fontWeight: 700, fontSize: 33, letterSpacing: '0.05em', lineHeight: 1.15, color: C.gold, background: 'rgba(8,8,14,0.82)', border: `2px solid ${C.gold}`, borderRadius: 14, padding: '9px 14px'}}>
    ILUSTRASI REKONSTRUKSI — METODE PASTI MASIH DIPERDEBATKAN.
  </div>
);

const Subtitles: React.FC<{t: number}> = ({t}) => {
  const c = SUBS.find((s) => t >= s.a && t < s.b);
  if (!c) return null;
  const o = ramp(t, c.a, c.a + 0.12, 0, 1, lin) * ramp(t, c.b - 0.1, c.b, 1, 0, lin);
  return (
    <div style={{position: 'absolute', left: 50, right: 50, top: 1500, display: 'flex', justifyContent: 'center', opacity: o}}>
      <div style={{background: 'rgba(8,8,14,0.74)', borderRadius: 26, padding: '20px 32px 22px', fontFamily: sans, fontWeight: 700, fontSize: 50, lineHeight: 1.26, color: '#fff', textAlign: 'center', borderBottom: `6px solid ${C.gold}`}}>{c.text}</div>
    </div>
  );
};

/* ======================================================================
   SCENE 1 — HOOK (0–8 s)
   ====================================================================== */
const STONE_ROWS = (() => {
  const r = mulberry32(11);
  const rows: {y: number; h: number; blocks: {x: number; w: number; c: string}[]}[] = [];
  let y = -300;
  while (y < 2400) {
    const h = 150 + r() * 90;
    const blocks: {x: number; w: number; c: string}[] = [];
    let x = -300 + r() * 160;
    while (x < 1400) {
      const w = 230 + r() * 230;
      blocks.push({x, w: w - 10, c: blend('#d6b676', '#8a6a45', r() * 0.8)});
      x += w;
    }
    rows.push({y, h: h - 10, blocks});
    y += h;
  }
  return rows;
})();
const STARS = (() => {
  const r = mulberry32(21);
  return Array.from({length: 70}, () => ({x: r() * W, y: r() * 760, r: 1 + r() * 2.2, ph: r() * 6}));
})();

const S1: React.FC<{t: number}> = ({t}) => {
  const z = 1 + 3.4 * ramp(t, 1.0, 6.2, 0, 1) + 2.4 * ramp(t, 6.2, 8.6, 0, 1, Easing.in(Easing.quad));
  const tx = 540;
  const ty = 1010 - 235 * ramp(t, 0.8, 5.6, 0, 1);
  const yaw = 0.18 + 0.03 * t;
  const zf = 1 + (z - 1) * 0.3;
  const zn = 1 + (z - 1) * 0.75;
  const G = (k: number) => cam(k, tx, ty, 540, 1056);
  const sunY = 1110 - 130 * ramp(t, 0, 6, 0, 1, lin);
  const dustO = 0.92 * (1 - ramp(t, 0.3, 3.8)) + 0.16;
  const stoneO = ramp(t, 5.6, 7.4, 0, 1);
  const sz = 1 + 1.4 * ramp(t, 5.6, 8.6, 0, 1, lin);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="s1sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#050a1c" />
            <stop offset="0.38" stopColor="#14224a" />
            <stop offset="0.58" stopColor="#7a5a6e" />
            <stop offset="0.7" stopColor="#f0a860" />
            <stop offset="1" stopColor="#f6d08a" />
          </linearGradient>
          <radialGradient id="s1sun" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#fff2c8" stopOpacity="1" />
            <stop offset="0.25" stopColor="#ffd27a" stopOpacity="0.8" />
            <stop offset="1" stopColor="#ffb050" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="s1dust" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#d9b07a" stopOpacity="0.85" />
            <stop offset="1" stopColor="#d9b07a" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill="url(#s1sky)" />
        {STARS.map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff" opacity={(0.35 + 0.35 * Math.sin(t * 2 + s.ph)) * (1 - ramp(t, 1, 5))} />
        ))}
        <circle cx={700} cy={sunY} r={560} fill="url(#s1sun)" opacity={0.85} />
        <circle cx={700} cy={sunY} r={74} fill="#fff4d2" />
        <g transform={G(zf)}>
          <Dune y={1170} amp={26} f={0.006} ph={1.2} color="#b9855a" shift={t * 5} />
          <Dune y={1200} amp={30} f={0.005} ph={0.2} color="#9d6b48" shift={-t * 7} />
        </g>
        <g transform={G(z)}>
          <ellipse cx={540} cy={1200} rx={560} ry={36} fill="rgba(40,22,12,0.35)" />
          <Pyr cx={540} cy={1190} S={330} yaw={yaw} pitch={0.1} lit="#f6dca0" dark="#5a3a28" courses={34} lineOp={0.22} />
        </g>
        <g transform={G(zn)}>
          <Dune y={1262} amp={34} f={0.0046} ph={2.1} color="#6e4630" shift={t * 10} />
          <Dune y={1340} amp={40} f={0.004} ph={0.6} color="#4a2e22" shift={-t * 14} />
        </g>
        {Array.from({length: 7}, (_, i) => {
          const x = ((i * 260 + t * (60 + (i % 3) * 30)) % 1600) - 260;
          return <ellipse key={i} cx={x} cy={860 + i * 66} rx={420} ry={120} fill="url(#s1dust)" opacity={dustO * (0.55 + 0.45 * Math.sin(t * 0.8 + i))} />;
        })}
        <g opacity={stoneO}>
          <rect width={W} height={H} fill="#7a5a3a" />
          <g transform={`translate(540 960) scale(${sz}) translate(-540 ${-960 - t * 40})`}>
            {STONE_ROWS.map((r, i) =>
              r.blocks.map((b, j) => (
                <g key={`${i}_${j}`}>
                  <rect x={b.x} y={r.y} width={b.w} height={r.h} rx={8} fill={b.c} />
                  <rect x={b.x} y={r.y} width={b.w} height={7} rx={3} fill="rgba(255,255,255,0.28)" />
                  <rect x={b.x} y={r.y + r.h - 14} width={b.w} height={14} rx={4} fill="rgba(0,0,0,0.22)" />
                </g>
              )),
            )}
          </g>
        </g>
      </svg>
      <Big top={250} o={win(t, 3.0, 7.3, 0.5)} lines={['DIBANGUN TANPA', 'TEKNOLOGI MODERN?']} size={84} dy={30} />
      <div style={{position: 'absolute', left: 540 - 300 * ramp(t, 3.4, 4.6), top: 478, width: 600 * ramp(t, 3.4, 4.6), height: 6, background: C.gold, opacity: win(t, 3.2, 7.3, 0.5)}} />
      <AbsoluteFill style={{background: '#000', opacity: ramp(t, 0, 1.4, 1, 0, lin), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};

/* ======================================================================
   SCENE 2 — PERENCANAAN & MATERIAL (8–23 s)
   ====================================================================== */
const S2Quarry: React.FC<{t: number}> = ({t}) => {
  const sx = -t * 12;
  const hit = (ph: number) => {
    const f = (((t * 5.2 + ph) / (2 * Math.PI)) % 1 + 1) % 1;
    return f;
  };
  const puff = (x: number, y: number, ph: number) => {
    const f = hit(ph);
    const k = f < 0.45 ? f / 0.45 : 1;
    return f < 0.45 ? <circle cx={x} cy={y - k * 24} r={10 + k * 26} fill="#efe2bd" opacity={0.7 * (1 - k)} /> : null;
  };
  const bx = 600 + 1100 * ramp(t, 2.2, 5.6, 0, 1, Easing.in(Easing.quad));
  return (
    <AbsoluteFill>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="s2qs" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#e7b06a" />
            <stop offset="0.6" stopColor="#f6dba4" />
            <stop offset="1" stopColor="#f9ecc8" />
          </linearGradient>
          <linearGradient id="s2qg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#dcb774" />
            <stop offset="1" stopColor="#a8793c" />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill="url(#s2qs)" />
        <circle cx={800} cy={640} r={90} fill="#fff6dc" opacity={0.85} />
        <g transform={`translate(${sx * 0.2} 0)`}>
          <Dune y={1010} amp={30} f={0.005} ph={0.4} color="#e4c48a" />
        </g>
        <g transform={`translate(${sx * 0.5} 0)`}>
          <polygon points="-200,1190 -200,640 160,640 160,760 330,760 330,880 500,880 500,1000 680,1000 680,1190" fill="#e6d1a0" />
          <polygon points="-200,640 160,640 160,760 -200,760" fill="#f3e3b8" />
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <line key={i} x1={-200} y1={720 + i * 80} x2={680} y2={720 + i * 80} stroke="rgba(120,90,50,0.22)" strokeWidth={3} />
          ))}
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <line key={i} x1={-120 + i * 130} y1={650 + (i % 3) * 20} x2={-120 + i * 130} y2={1190} stroke="rgba(120,90,50,0.14)" strokeWidth={3} />
          ))}
          <polygon points="160,760 330,760 330,1190 160,1190" fill="rgba(120,90,50,0.12)" />
        </g>
        <rect x={0} y={1175} width={W} height={760} fill="url(#s2qg)" />
        <g transform={`translate(${sx} 0)`}>
          {Array.from({length: 16}, (_, i) => (
            <ellipse key={i} cx={i * 150 + 40} cy={1330 + (i % 4) * 90} rx={30 + (i % 3) * 14} ry={7} fill="rgba(90,60,30,0.2)" />
          ))}
          <Blk x={130} y={1130} w={230} h={130} dx={50} dy={32} />
          <Blk x={60} y={1244} w={120} h={70} dx={30} dy={20} c="#d6c08e" />
          <Man x={95} y={1285} s={1.2} pose="cut" t={t} ph={0} sp={5.2} />
          <Man x={455} y={1290} s={1.2} flip pose="cut" t={t} ph={1.6} sp={5.2} />
          {puff(165, 1138, 0)}
          {puff(390, 1138, 1.6)}
        </g>
        <g transform={`translate(${sx * 0.2} 0)`}>
          <rect x={bx - 30} y={1262} width={290} height={16} rx={6} fill="#5b4430" />
          <Blk x={bx} y={1140} w={200} h={122} dx={44} dy={28} c="#ead9ac" />
          {[0, 1, 2].map((i) => {
            const mx = bx + 270 + i * 96;
            const my = 1292 + i * 20;
            return (
              <g key={i}>
                <line x1={bx + 244} y1={1212} x2={mx + PULL_HAND[0] * 1.1} y2={my - PULL_HAND[1] * -1.1} stroke="#6b5130" strokeWidth={4} />
                <Man x={mx} y={my} s={1.1} pose="pull" t={t} ph={i * 1.3} sp={5.2} />
              </g>
            );
          })}
        </g>
      </svg>
      <div style={{position: 'absolute', left: 50, right: 50, top: 250, opacity: win(t, 0.9, 5.6, 0.5)}}>
        <div style={{display: 'inline-block', background: 'rgba(8,10,22,0.78)', borderLeft: `6px solid ${C.gold}`, borderRadius: 10, padding: '12px 20px'}}>
          <div style={{fontFamily: sans, fontWeight: 600, fontSize: 22, letterSpacing: '0.12em', color: C.sandL}}>PENAMBANGAN BATU</div>
          <div style={{fontFamily: cond, fontWeight: 700, fontSize: 48, color: '#fff'}}>PAHAT TEMBAGA · PALU KAYU · TALI</div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

const S2: React.FC<{t: number}> = ({t}) => {
  const yaw = -0.5 + t * 0.17;
  const fillA = ramp(t, 3.8, 5.4, 1, 0.1);
  const wire = ramp(t, 3.8, 5.4, 0, 1);
  const sweep = t < 5.4 ? -1 : ramp(t, 5.4, 9.2, 0, 1, lin);
  const cx = 540;
  const cy = 1090;
  const S = 300;
  const pitch = 0.34;
  const {P} = makeCam(cx, cy, S, yaw, pitch);
  const apex = P([0, HH, 0]);
  const base = P([0, 0, 0]);
  const gx = -(t * 7) % 90;
  const qIn = ramp(t, 9.2, 10.8, 0, 1);
  const zoomA = 1 + 0.06 * (t / 10);
  const orbitA = yaw + Math.PI / 2;
  const diagO = 1 - ramp(t, 10.4, 10.9, 0, 1, lin);
  return (
    <AbsoluteFill style={{background: C.navy}}>
      {diagO > 0.01 && (
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s2bg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#070d22" />
              <stop offset="0.6" stopColor="#142a5c" />
              <stop offset="1" stopColor="#0b1530" />
            </linearGradient>
            <radialGradient id="s2glow" cx="0.5" cy="0.5" r="0.5">
              <stop offset="0" stopColor="#f2c14e" stopOpacity="0.4" />
              <stop offset="1" stopColor="#f2c14e" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width={W} height={H} fill="url(#s2bg)" />
          <g transform={cam(zoomA, 540, 1000)}>
            {Array.from({length: 14}, (_, i) => (
              <line key={'v' + i} x1={gx + i * 90} y1={0} x2={gx + i * 90} y2={H} stroke="#6f8fd0" strokeOpacity={0.09} strokeWidth={2} />
            ))}
            {Array.from({length: 24}, (_, i) => (
              <line key={'h' + i} x1={0} y1={i * 90} x2={W} y2={i * 90} stroke="#6f8fd0" strokeOpacity={0.09} strokeWidth={2} />
            ))}
            <ellipse cx={cx} cy={cy + 20} rx={520} ry={200} fill="none" stroke={C.gold} strokeOpacity={0.35} strokeWidth={2} strokeDasharray="6 12" />
            <circle cx={cx + Math.cos(orbitA) * 520} cy={cy + 20 + Math.sin(orbitA) * 200} r={9} fill={C.gold} />
            <ellipse cx={cx} cy={cy + 30} rx={470} ry={170} fill="url(#s2glow)" />
            <Pyr cx={cx} cy={cy} S={S} yaw={yaw} pitch={pitch} fill={fillA} wire={wire} courses={30} sweep={sweep} lit="#f0d796" dark="#4a3626" />
            <g opacity={ramp(t, 3.6, 4.6, 0, 1)}>
              <line x1={base[0]} y1={base[1]} x2={apex[0]} y2={apex[1]} stroke="#fff" strokeWidth={3} strokeDasharray="12 8" />
              <circle cx={apex[0]} cy={apex[1]} r={10} fill={C.gold} />
              <circle cx={base[0]} cy={base[1]} r={7} fill="#fff" />
              <rect x={apex[0] + 24} y={apex[1] - 36} width={190} height={56} rx={10} fill="rgba(8,10,22,0.85)" stroke={C.gold} strokeWidth={2} />
              <text x={apex[0] + 119} y={apex[1] + 3} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={42} fill="#fff">
                ±146,5 m
              </text>
            </g>
          </g>
        </svg>
      )}
      {diagO > 0.01 && (
        <div style={{opacity: diagO}}>
          <Chip x={50} y={250} w={290} label="MAKAM RAJA" value="KHUFU" o={ramp(t, 1.0, 1.7, 0, 1, lin)} />
          <Chip x={365} y={250} w={330} label="DIBANGUN" value="±4.500 TAHUN LALU" o={ramp(t, 2.0, 2.7, 0, 1, lin)} />
          <Chip x={720} y={250} w={310} label="TINGGI ASLI" value="±146,5 METER" o={ramp(t, 3.0, 3.7, 0, 1, lin)} />
          <div style={{position: 'absolute', left: 50, right: 50, top: 1300, textAlign: 'center', opacity: win(t, 5.8, 9.9, 0.5), fontFamily: cond, fontWeight: 700, fontSize: 46, letterSpacing: '0.08em', color: C.gold, textShadow: TXT_SH}}>
            LAPISAN KONSTRUKSI <span style={{color: '#fff', fontSize: 34}}>(DISEDERHANAKAN)</span>
          </div>
        </div>
      )}
      {qIn > 0.001 && (
        <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `translateX(${(1 - qIn) * W}px)`, overflow: 'hidden'}}>
          <S2Quarry t={Math.max(0, t - 9.2)} />
        </div>
      )}
    </AbsoluteFill>
  );
};

/* ======================================================================
   SCENE 3 — BATU DARI TURA (23–39 s)
   ====================================================================== */
const PALMS = (() => {
  const r = mulberry32(33);
  return Array.from({length: 18}, (_, i) => ({side: i % 2 === 0 ? -1 : 1, y0: r() * 2400, off: 30 + r() * 90, sc: 0.8 + r() * 0.6}));
})();

const Palm: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle cx={6} cy={8} r={44} fill="rgba(0,0,0,0.22)" />
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
      <ellipse key={i} cx={0} cy={-30} rx={9} ry={34} fill={i % 2 ? '#2f5a2e' : C.palm} transform={`rotate(${i * 45})`} />
    ))}
    <circle r={8} fill="#5a3a22" />
  </g>
);

const S3A: React.FC<{t: number}> = ({t}) => {
  const camX = -150 * ramp(t, 0, 5.4, 0, 1, lin);
  const z = 1 + 0.08 * ramp(t, 0, 5.4, 0, 1, lin) + 1.6 * ramp(t, 4.6, 6.2, 0, 1, inC);
  const bob = Math.sin(t * 1.6) * 3;
  const bxk = 300 + 330 * ramp(t, 0.6, 4.4, 0, 1, lin);
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <linearGradient id="s3sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#e3a965" />
          <stop offset="0.6" stopColor="#f5d9a0" />
          <stop offset="1" stopColor="#f8e8c2" />
        </linearGradient>
        <linearGradient id="s3w" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a7ba6" />
          <stop offset="1" stopColor="#173f66" />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#s3sky)" />
      <g transform={cam(z, 760, 1330, 760, 1330)}>
        <g transform={`translate(${camX * 0.3} 0)`}>
          <Dune y={1000} amp={26} f={0.005} ph={2} color="#e6c88e" />
        </g>
        <g transform={`translate(${camX * 0.6} 0)`}>
          <polygon points="-300,1210 -300,620 120,620 120,760 330,760 330,890 540,890 540,1020 760,1020 760,1210" fill="#eedcae" />
          <polygon points="-300,620 120,620 120,760 -300,760" fill="#f7ebc6" />
          {Array.from({length: 7}, (_, i) => (
            <line key={i} x1={-300} y1={700 + i * 70} x2={760} y2={700 + i * 70} stroke="rgba(120,90,50,0.2)" strokeWidth={3} />
          ))}
          {Array.from({length: 9}, (_, i) => (
            <line key={i} x1={-260 + i * 120} y1={640 + (i % 4) * 40} x2={-260 + i * 120} y2={1210} stroke="rgba(120,90,50,0.12)" strokeWidth={3} />
          ))}
        </g>
        <g transform={`translate(${camX} 0)`}>
          <polygon points="-300,1200 1500,1200 1500,1336 -300,1336" fill="#d9b36c" />
          <rect x={-300} y={1334} width={1800} height={700} fill="url(#s3w)" />
          {Array.from({length: 24}, (_, i) => {
            const x = ((i * 190 + t * 40) % 1900) - 300;
            return <line key={i} x1={x} y1={1360 + (i % 6) * 36} x2={x + 90} y2={1360 + (i % 6) * 36} stroke="#bfe0f5" strokeOpacity={0.45} strokeWidth={3} />;
          })}
          {Array.from({length: 22}, (_, i) => (
            <g key={i} transform={`translate(${-250 + i * 80} 1336)`}>
              <line x1={0} y1={0} x2={-4} y2={-34 - (i % 3) * 8} stroke="#4f7a3a" strokeWidth={4} />
              <line x1={0} y1={0} x2={8} y2={-28 - (i % 4) * 6} stroke="#3f6a30" strokeWidth={4} />
            </g>
          ))}
          <Blk x={190} y={1100} w={210} h={110} dx={46} dy={28} />
          <Blk x={120} y={1196} w={110} h={62} dx={28} dy={18} c="#d6c08e" />
          <Man x={150} y={1262} s={1.15} pose="cut" t={t} ph={0.4} sp={5.2} />
          <Man x={470} y={1268} s={1.15} flip pose="cut" t={t} ph={2.0} sp={5.2} />
          <rect x={bxk - 20} y={1236} width={250} height={14} rx={6} fill="#5b4430" />
          <Blk x={bxk} y={1126} w={180} h={110} dx={40} dy={26} c="#ead9ac" />
          <polygon points="600,1330 760,1296 760,1308 620,1344" fill="#6b4a2a" />
          <g transform={`translate(880 ${1346 + bob}) scale(0.9)`}>
            <path d="M -270 -78 C -240 -22, -200 22, -120 30 L 150 30 C 230 22, 260 -22, 282 -84 C 260 -66, 238 -54, 214 -54 L -214 -54 C -240 -54, -256 -66, -270 -78 Z" fill="#8c5a34" />
            <path d="M -214 -54 L 214 -54 L 200 -40 L -200 -40 Z" fill="#6b4226" />
            <path d="M -270 -78 C -280 -100 -270 -122 -250 -134" fill="none" stroke="#c9a15a" strokeWidth={8} strokeLinecap="round" />
            <path d="M 282 -84 C 296 -108 288 -130 268 -144" fill="none" stroke="#c9a15a" strokeWidth={8} strokeLinecap="round" />
            {[0, 1, 2, 3].map((i) => (
              <Blk key={i} x={-190 + i * 100} y={-54 - 80} w={84} h={80} dx={20} dy={14} c={i % 2 ? '#e6d3a2' : '#ead9ac'} />
            ))}
            {[0, 1].map((i) => {
              const mx = -150 + i * 90;
              return <Man key={i} x={mx + 240} y={-54} s={0.95} pose="pull" t={t} ph={i * 1.4} sp={5.2} />;
            })}
          </g>
        </g>
      </g>
    </svg>
  );
};

const S3B: React.FC<{t: number}> = ({t}) => {
  const v = 420;
  const bx = 540;
  const sway = Math.sin(t * 1.3) * 4;
  const scroll = t < 8.2 ? v * t : v * (8.2 + 0.5 * (1 - Math.exp(-2 * (t - 8.2))));
  const siteY = -900 + scroll - v * 5.2;
  const wiggle = (i: number) => Math.sin(t * 5 + i) * 0.18;
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <linearGradient id="s3top" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#245f8a" />
          <stop offset="0.5" stopColor="#2f7aa8" />
          <stop offset="1" stopColor="#245f8a" />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#s3top)" />
      {Array.from({length: 36}, (_, i) => {
        const x = 170 + ((i * 97) % 740);
        const y = ((i * 211 + scroll * 1.05) % 2200) - 150;
        return <line key={i} x1={x} y1={y} x2={x} y2={y + 60 + (i % 4) * 22} stroke="#cfe9f7" strokeOpacity={0.35} strokeWidth={3} strokeLinecap="round" />;
      })}
      <rect x={-20} y={0} width={190} height={H} fill="#d6b374" />
      <rect x={-20} y={0} width={140} height={H} fill="#5a8a3c" />
      <rect x={910} y={0} width={190} height={H} fill="#d6b374" />
      <rect x={960} y={0} width={140} height={H} fill="#5a8a3c" />
      {PALMS.map((p, i) => {
        const y = ((p.y0 + scroll) % 2500) - 250;
        const x = p.side < 0 ? 70 + p.off * 0.3 : 1010 - p.off * 0.3;
        return <Palm key={i} x={x} y={y} s={p.sc} />;
      })}
      {siteY > -320 && (
        <g transform={`translate(540 ${siteY})`}>
          <rect x={-330} y={236} width={660} height={22} fill="#8c6a42" />
          <rect x={-330} y={258} width={660} height={10} fill="rgba(0,0,0,0.25)" />
          {Array.from({length: 9}, (_, i) => {
            const k = 9 - i;
            const w = 30 + k * 22;
            return <rect key={i} x={-w} y={-w + 0} width={w * 2} height={w * 2} fill={i % 2 ? '#e7cf95' : '#d8bb7c'} stroke="#7a5a38" strokeWidth={2} transform={`translate(0 ${-i * 0})`} />;
          })}
          <rect x={-20} y={-20} width={40} height={40} fill="#f6e4b0" />
          {Array.from({length: 12}, (_, i) => (
            <circle key={i} cx={-300 + i * 55} cy={247} r={8} fill="#6b4a2a" />
          ))}
        </g>
      )}
      <g transform={`translate(${bx + sway} ${1010})`}>
        <ellipse cx={14} cy={20} rx={96} ry={420} fill="rgba(0,20,40,0.28)" />
        {[-1, 1].map((sd) => (
          <g key={sd}>
            {Array.from({length: 6}, (_, i) => {
              const oy = -250 + i * 100;
              const a = sd * (0.5 + wiggle(i));
              return <line key={i} x1={sd * 60} y1={oy} x2={sd * 60 + Math.sin(a) * 120} y2={oy + Math.cos(a) * 70} stroke="#e0c690" strokeWidth={5} strokeLinecap="round" />;
            })}
          </g>
        ))}
        <path d="M 0 -400 C 70 -300 76 -140 70 40 C 66 220 62 330 40 400 L -40 400 C -62 330 -66 220 -70 40 C -76 -140 -70 -300 0 -400 Z" fill="#8c5a34" />
        <path d="M 0 -380 C 50 -290 54 -140 50 40 C 46 210 44 320 30 380 L -30 380 C -44 320 -46 210 -50 40 C -54 -140 -50 -290 0 -380 Z" fill="#a8723f" />
        {Array.from({length: 14}, (_, i) => (
          <line key={i} x1={-56} y1={-300 + i * 50} x2={56} y2={-300 + i * 50} stroke="rgba(60,30,10,0.35)" strokeWidth={2} />
        ))}
        {[0, 1, 2, 3, 4].map((i) => (
          <g key={i}>
            <rect x={-44 + 0} y={-250 + i * 118} width={88} height={92} fill={i % 2 ? '#e6d3a2' : '#ead9ac'} />
            <rect x={-44} y={-250 + i * 118} width={88} height={8} fill="rgba(255,255,255,0.45)" />
            <rect x={30} y={-250 + i * 118} width={14} height={92} fill="rgba(0,0,0,0.18)" />
          </g>
        ))}
        {[-1, 1].map((sd) => [0, 1, 2, 3, 4, 5].map((i) => <circle key={`${sd}_${i}`} cx={sd * 64} cy={-250 + i * 100} r={12} fill={SKIN} stroke="#14100d" strokeWidth={5} />))}
        <path d="M -60 -330 C -30 -380 30 -380 60 -330" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth={4} transform="translate(0 -60)" />
      </g>
      <g opacity={0.5}>
        <path d={`M ${bx - 70} 1420 L ${bx - 250} 1900`} stroke="#fff" strokeOpacity={0.35} strokeWidth={6} fill="none" />
        <path d={`M ${bx + 70} 1420 L ${bx + 250} 1900`} stroke="#fff" strokeOpacity={0.35} strokeWidth={6} fill="none" />
      </g>
    </svg>
  );
};

const Papyrus: React.FC<{t: number}> = ({t}) => {
  const p = ramp(t, 0, 1.0, 0, 1, outC);
  const rows = (() => {
    const r = mulberry32(77);
    return Array.from({length: 11}, () => Array.from({length: 7 + Math.floor(r() * 5)}, () => 10 + r() * 38));
  })();
  return (
    <div style={{position: 'absolute', left: 150, top: 330 + (1 - p) * 1100, width: 780, height: 920, transform: `rotate(${-3 + (1 - p) * 8}deg)`, opacity: Math.min(1, p * 1.4)}}>
      <svg width={780} height={920}>
        <defs>
          <linearGradient id="s3pap" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#f3e4b6" />
            <stop offset="0.5" stopColor="#e6cf93" />
            <stop offset="1" stopColor="#d8bb78" />
          </linearGradient>
        </defs>
        <polygon points="14,10 120,0 250,12 400,2 560,14 700,4 770,16 764,170 776,330 762,520 774,720 760,906 600,920 420,908 250,920 90,906 6,914 16,720 4,520 18,330 6,150" fill="url(#s3pap)" stroke="#8a6a3a" strokeWidth={4} />
        {Array.from({length: 22}, (_, i) => (
          <line key={i} x1={20} y1={30 + i * 41} x2={760} y2={30 + i * 41} stroke="rgba(120,90,40,0.10)" strokeWidth={3} />
        ))}
        {rows.map((r, i) => {
          let x = 740;
          return (
            <g key={i}>
              {r.map((w, j) => {
                x -= w + 10;
                const red = i === 0;
                return <rect key={j} x={x} y={230 + i * 54} width={w} height={14} rx={7} fill={red ? C.red : C.ink} opacity={i === 0 ? 0.9 : 0.7} />;
              })}
            </g>
          );
        })}
      </svg>
      <div style={{position: 'absolute', left: 0, right: 0, top: 36, textAlign: 'center', fontFamily: sans, fontWeight: 700, fontSize: 24, letterSpacing: '0.16em', color: '#6b4a2a'}}>PAPIRUS KUNO</div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 70, textAlign: 'center', fontFamily: cond, fontWeight: 700, fontSize: 150, lineHeight: 1, letterSpacing: '0.06em', color: C.red}}>MERER</div>
      <div style={{position: 'absolute', left: 60, right: 60, top: 790, textAlign: 'center', fontFamily: sans, fontWeight: 700, fontSize: 30, lineHeight: 1.3, color: '#3a2a16'}}>
        Catatan pengawas: bukti pengangkutan batu kapur Tura untuk proyek Khufu
      </div>
    </div>
  );
};

const S3: React.FC<{t: number}> = ({t}) => {
  const aO = 1 - ramp(t, 5.0, 6.2, 0, 1, lin);
  const bO = ramp(t, 4.6, 6.0, 0, 1, lin);
  const bz = 1.5 - 0.5 * ramp(t, 4.6, 8.0, 0, 1, outC);
  const dark = ramp(t, 10.8, 11.8, 0, 0.55, lin);
  return (
    <AbsoluteFill style={{background: '#1d4f7a'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: aO}}>
        <S3A t={t} />
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: bO, transform: `scale(${bz})`, transformOrigin: '50% 60%'}}>
        <S3B t={t} />
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, background: '#000', opacity: dark}} />
      <Big top={230} o={win(t, 0.6, 4.8, 0.5)} lines={['TAMBANG BATU KAPUR', 'TURA']} size={84} dy={24} />
      <Big top={230} o={win(t, 6.2, 11.0, 0.5)} lines={['BATU DARI TURA →', 'DIANGKUT MELALUI', 'SUNGAI NIL']} size={84} dy={24} color={C.sandL} />
      {t > 10.6 && <Papyrus t={t - 10.8} />}
    </AbsoluteFill>
  );
};

/* ======================================================================
   SCENE 4 — BAGAIMANA BATU DIANGKAT? (39–58 s)
   ====================================================================== */
const rampBandA = (P: (v: V3) => [number, number], N: (v: V3) => V3, prog: number, op: number): React.ReactNode => {
  // ramp lurus menempel pada sisi depan (-z) piramida
  const w = 0.22;
  const D = 1.8;
  const Hr = 0.86 * HH;
  const zc = -(1 - Hr / HH);
  const z0 = -1 - D;
  const k = prog;
  const hk = Hr * k;
  const zk = z0 + (zc - z0) * k;
  const top: V3[] = [
    [-w, 0, z0],
    [w, 0, z0],
    [w, hk, zk],
    [-w, hk, zk],
  ];
  const nodes: React.ReactNode[] = [];
  [-1, 1].forEach((sd) => {
    const nv = N([sd, 0, 0]);
    if (nv[2] < 0) {
      const q: V3[] = [
        [sd * w, 0, z0],
        [sd * w, hk, zk],
        [sd * w, 0, zk],
      ];
      nodes.push(<polygon key={'w' + sd} points={pts(q.map((v) => P(v)))} fill="#7a5a3a" />);
    }
  });
  nodes.push(<polygon key="t" points={pts(top.map((v) => P(v)))} fill="#e0b87a" stroke="#fff3cf" strokeWidth={2.5} />);
  for (let i = 1; i < 8; i++) {
    const a = lerp3(top[0], top[3], i / 8);
    const b = lerp3(top[1], top[2], i / 8);
    const pa = P(a);
    const pb = P(b);
    nodes.push(<line key={'l' + i} x1={pa[0]} y1={pa[1]} x2={pb[0]} y2={pb[1]} stroke="rgba(90,60,30,0.35)" strokeWidth={2} />);
  }
  return <g opacity={op}>{nodes}</g>;
};

const rampPathB = (s: number): {inner: V3; outer: V3} => {
  // jalur ramp mengelilingi dua sisi (depan lalu kanan); s = 0..1
  const wd = 0.3;
  const y1 = 0.36 * HH;
  const y2 = 0.84 * HH;
  const total = 0.4 + 2 + 2;
  const d = s * total;
  if (d < 2.4) {
    const x = -1.4 + d; // dari luar sudut kiri sampai x = +1
    const y = (y1 * d) / 2.4;
    const zf = -(1 - y / HH);
    return {inner: [x, y, zf], outer: [x, y, zf - wd]};
  }
  const e = d - 2.4;
  const y = y1 + ((y2 - y1) * e) / 2;
  const xf = 1 - y / HH;
  const z = -1 + e;
  return {inner: [xf, y, z], outer: [xf + wd, y, z]};
};

const rampBandB = (P: (v: V3) => [number, number], prog: number, op: number): React.ReactNode => {
  const n = 46;
  const segs: React.ReactNode[] = [];
  const upto = Math.floor(n * prog);
  const quad = (i: number) => {
    const a = rampPathB(i / n);
    const b = rampPathB((i + 1) / n);
    const top = [P(a.inner), P(a.outer), P(b.outer), P(b.inner)];
    const wallB = [P(a.outer), P(b.outer), P([b.outer[0], 0, b.outer[2]]), P([a.outer[0], 0, a.outer[2]])];
    return {top, wallB};
  };
  const order: number[] = [];
  const cornerI = Math.floor((2.4 / 4.4) * n);
  for (let i = Math.min(upto, n) - 1; i >= cornerI; i--) order.push(i);
  for (let i = 0; i < Math.min(upto, cornerI); i++) order.push(i);
  order.forEach((i) => {
    const q = quad(i);
    segs.push(<polygon key={'w' + i} points={pts(q.wallB as [number, number][])} fill="#7a5a3a" />);
    segs.push(<polygon key={'t' + i} points={pts(q.top as [number, number][])} fill={i % 2 ? '#e0b87a' : '#d8ad6c'} stroke="#fff3cf" strokeOpacity={0.5} strokeWidth={1.2} />);
  });
  return <g opacity={op}>{segs}</g>;
};

const S4: React.FC<{t: number}> = ({t}) => {
  const aO = t < 5.4 ? 1 : 0;
  const bO = ramp(t, 4.6, 5.4, 0, 1, lin) * (t < 10.4 ? 1 : 0);
  const cO = ramp(t, 9.6, 10.4, 0, 1, lin);
  const vg = 300;
  // --- fase A ---
  const gs = -(t * vg) % 120;
  const wetX = 630;
  // --- fase B ---
  const p1 = ramp(t, 5.9, 7.5, 0, 1, lin);
  const p2 = ramp(t, 5.9, 9.9, 0, 1, lin);
  const th1 = (40 * Math.PI) / 180;
  const th2 = (15 * Math.PI) / 180;
  const hh = 210;
  const slope = (x0: number, yb: number, th: number, p: number, label: string, big: boolean, o: number) => {
    const run = hh / Math.tan(th);
    const ex = x0 + run;
    const ey = yb - hh;
    const bxp = x0 + run * p;
    const byp = yb - hh * p;
    const ang = (-th * 180) / Math.PI;
    const fl = Math.sin(th) * 210;
    return (
      <g opacity={o}>
        <polygon points={`${x0},${yb} ${ex},${yb} ${ex},${ey}`} fill="rgba(242,193,78,0.12)" stroke={C.gold} strokeWidth={4} />
        <g transform={`translate(${bxp} ${byp}) rotate(${ang})`}>
          <rect x={-30} y={-58} width={60} height={58} fill="#ead9ac" stroke="#fff" strokeWidth={2} />
          <line x1={0} y1={-29} x2={fl} y2={-29} stroke="#ff7a5a" strokeWidth={8} strokeLinecap="round" />
          <polygon points={`${fl + 18},-29 ${fl - 2},-41 ${fl - 2},-17`} fill="#ff7a5a" />
        </g>
        <text x={x0} y={yb + 56} fontFamily={cond} fontWeight={700} fontSize={big ? 38 : 38} fill="#fff" letterSpacing="1">
          {label}
        </text>
      </g>
    );
  };
  // --- fase C ---
  const cx = 540;
  const cy = 1010;
  const S = 300;
  const yaw = 0.45;
  const pitch = 0.3;
  const {P, N} = makeCam(cx, cy, S, yaw, pitch);
  const prA = ramp(t, 10.4, 12.6, 0, 1, outC);
  const opA = 1 - ramp(t, 14.0, 14.8, 0, 1, lin);
  const prB = ramp(t, 14.4, 18.0, 0, 1, lin);
  const ants = (fn: (s: number) => [number, number], n: number, o: number, spd: number, reach: number) => (
    <g opacity={o}>
      {Array.from({length: n}, (_, i) => {
        const s = ((t * spd + i / n) % 1) * reach;
        const q = fn(s);
        return <circle key={i} cx={q[0]} cy={q[1] - 6} r={6} fill="#14100d" stroke="#fff" strokeWidth={2} />;
      })}
    </g>
  );
  const antA = (s: number): [number, number] => {
    const Hr = 0.86 * HH;
    const zc = -(1 - Hr / HH);
    const z0 = -1 - 1.8;
    return P([0, Hr * s, z0 + (zc - z0) * s]);
  };
  const antB = (s: number): [number, number] => P(rampPathB(s).inner);
  const sunX = 760;
  return (
    <AbsoluteFill style={{background: C.navy}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: aO}}>
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s4sky" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#e3a965" />
              <stop offset="0.7" stopColor="#f6dba4" />
              <stop offset="1" stopColor="#f9ecc8" />
            </linearGradient>
            <linearGradient id="s4g" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#dcb774" />
              <stop offset="1" stopColor="#a8793c" />
            </linearGradient>
          </defs>
          <rect width={W} height={H} fill="url(#s4sky)" />
          <circle cx={sunX} cy={560} r={84} fill="#fff6dc" opacity={0.9} />
          <g transform={`translate(${-(t * 12)} 0)`}>
            <Dune y={1060} amp={24} f={0.005} ph={0.8} color="#e6c88e" />
          </g>
          <g transform={`translate(${-(t * 8)} 0)`}>
            <polygon points="560,1180 1400,440 1900,440 1900,1180" fill="#e9d29c" />
            {Array.from({length: 14}, (_, i) => (
              <line key={i} x1={520 + i * 28} y1={1180 - i * 54} x2={1700} y2={1180 - i * 54} stroke="rgba(120,90,50,0.3)" strokeWidth={3} />
            ))}
          </g>
          <rect x={0} y={1170} width={W} height={780} fill="url(#s4g)" />
          {Array.from({length: 12}, (_, i) => (
            <ellipse key={i} cx={gs + i * 120} cy={1370 + (i % 3) * 70} rx={34} ry={7} fill="rgba(90,60,30,0.22)" />
          ))}
          <polygon points={`${wetX - 40},1262 ${wetX + 150},1262 ${wetX + 200},1290 ${wetX - 70},1290`} fill="rgba(90,60,30,0.35)" />
          <rect x={150} y={1262} width={380} height={16} rx={7} fill="#5b4430" />
          <path d="M 530 1262 Q 560 1262 556 1286 L 530 1278 Z" fill="#5b4430" />
          <Blk x={190} y={1118} w={270} h={144} dx={56} dy={34} c="#ead9ac" />
          <line x1={528} y1={1244} x2={640} y2={1222} stroke="#6b5130" strokeWidth={5} />
          <Man x={wetX + 20} y={1298} s={1.15} flip pose="pour" t={t} ph={0} sp={4} />
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const mx = 740 + (i % 3) * 120 - (Math.floor(i / 3) ? 40 : 0);
            const my = 1296 + Math.floor(i / 3) * 56 + (i % 3) * 4;
            return (
              <g key={i}>
                <line x1={528} y1={1240} x2={mx + PULL_HAND[0] * 1.1} y2={my - PULL_HAND[1] * -1.1} stroke="#6b5130" strokeWidth={4} />
                <Man x={mx} y={my} s={1.1} pose="pull" t={t} ph={i * 0.9} sp={4.4} />
              </g>
            );
          })}
          <Man x={120} y={1330} s={0.95} pose="stand" t={t} />
        </svg>
        <Big top={250} o={win(t, 0.8, 4.8, 0.5)} lines={['KERETA LUNCUR + TALI']} size={72} color={C.sandL} dy={24} />
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: bO}}>
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s4bg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#070d22" />
              <stop offset="1" stopColor="#142a5c" />
            </linearGradient>
          </defs>
          <rect width={W} height={H} fill="url(#s4bg)" />
          {Array.from({length: 14}, (_, i) => (
            <line key={'v' + i} x1={i * 90 - ((t * 6) % 90)} y1={0} x2={i * 90 - ((t * 6) % 90)} y2={H} stroke="#6f8fd0" strokeOpacity={0.09} strokeWidth={2} />
          ))}
          {Array.from({length: 24}, (_, i) => (
            <line key={'h' + i} x1={0} y1={i * 90} x2={W} y2={i * 90} stroke="#6f8fd0" strokeOpacity={0.09} strokeWidth={2} />
          ))}
          {slope(140, 830, th1, p1, 'CURAM · JALUR PENDEK · GAYA BESAR', true, ramp(t, 5.2, 6.0, 0, 1, lin))}
          {slope(120, 1290, th2, p2, 'LANDAI · JALUR PANJANG · GAYA KECIL', false, ramp(t, 5.4, 6.2, 0, 1, lin))}
        </svg>
        <Big top={240} o={win(t, 5.2, 10.0, 0.5)} lines={['PRINSIP BIDANG MIRING']} size={66} dy={24} />
        <div style={{position: 'absolute', left: 60, right: 60, top: 340, textAlign: 'center', opacity: win(t, 5.6, 10.0, 0.5), fontFamily: sans, fontWeight: 600, fontSize: 30, color: C.sandL, textShadow: TXT_SH}}>Panah merah = gaya tarik yang dibutuhkan (ilustrasi)</div>
      </div>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, opacity: cO}}>
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          <defs>
            <linearGradient id="s4cbg" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#0a1230" />
              <stop offset="0.7" stopColor="#1c3470" />
              <stop offset="1" stopColor="#0b1530" />
            </linearGradient>
          </defs>
          <rect width={W} height={H} fill="url(#s4cbg)" />
          {Array.from({length: 14}, (_, i) => (
            <line key={'v' + i} x1={i * 90 - ((t * 6) % 90)} y1={0} x2={i * 90 - ((t * 6) % 90)} y2={H} stroke="#6f8fd0" strokeOpacity={0.08} strokeWidth={2} />
          ))}
          <ellipse cx={cx} cy={cy + 70} rx={620} ry={230} fill="rgba(0,0,0,0.3)" />
          <Pyr cx={cx} cy={cy} S={S} yaw={yaw + 0.03 * Math.sin(t * 0.5)} pitch={pitch} fill={1} courses={30} lit="#e8cf92" dark="#3a2a1e" />
          {rampBandA(P, N, prA, opA)}
          {rampBandB(P, prB, ramp(t, 14.4, 14.9, 0, 1, lin))}
          {ants(antA, 5, ramp(t, 11.6, 12.4, 0, 1, lin) * opA, 0.14, 1)}
          {ants(antB, 6, ramp(t, 16.0, 16.8, 0, 1, lin), 0.1, Math.max(0.05, prB))}
        </svg>
        <div style={{position: 'absolute', left: 50, right: 50, top: 250, textAlign: 'center', fontFamily: cond, fontWeight: 700, fontSize: 70, lineHeight: 1.05, color: '#fff', textShadow: TXT_SH}}>
          <div style={{opacity: win(t, 10.4, 14.6, 0.4)}}>HIPOTESIS A: RAMP LURUS</div>
          <div style={{opacity: win(t, 14.6, 19, 0.4), marginTop: -74}}>HIPOTESIS B: RAMP MENGELILING</div>
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 1300, textAlign: 'center', fontFamily: cond, fontWeight: 700, fontSize: 120, color: C.gold, opacity: 0.9 * win(t, 15.0, 19, 0.5) * 0, textShadow: TXT_SH}}>?</div>
      </div>
      <div style={{position: 'absolute', left: 50, top: 190, opacity: ramp(t, 1.6, 2.2, 0, 1, lin) * ramp(t, 18.6, 19.0, 1, 0, lin), background: 'rgba(8,8,14,0.78)', borderRadius: 10, padding: '6px 16px', fontFamily: sans, fontWeight: 700, fontSize: 24, letterSpacing: '0.1em', color: '#fff'}}>ILUSTRASI HIPOTESIS KONSTRUKSI</div>
      <Disclaimer o={ramp(t, 1.8, 2.4, 0, 1, lin) * ramp(t, 18.6, 19.0, 1, 0, lin)} />
    </AbsoluteFill>
  );
};

/* ======================================================================
   SCENE 5 — SIAPA YANG MEMBANGUNNYA? (58–73 s)
   ====================================================================== */
const TW = 150;
const ZH = 70;
const iso = (x: number, y: number, z: number): [number, number] => [((x - y) * TW) / 2, ((x + y) * TW) / 4 - z * ZH];
const mY = (x: number, y: number, z: number, d: number) => {
  const [ox, oy] = iso(x, y + d, z);
  return `matrix(${TW / 2} ${TW / 4} 0 ${-ZH} ${ox.toFixed(1)} ${oy.toFixed(1)})`;
};
const shade = (c: string, k: number) => blend(c, '#000000', k);

const Box: React.FC<{x: number; y: number; z: number; w: number; d: number; h: number; c: string; top?: string}> = ({x, y, z, w, d, h, c, top}) => {
  const tp = pts([iso(x, y, z + h), iso(x + w, y, z + h), iso(x + w, y + d, z + h), iso(x, y + d, z + h)]);
  const lf = pts([iso(x, y + d, z + h), iso(x + w, y + d, z + h), iso(x + w, y + d, z), iso(x, y + d, z)]);
  const rt = pts([iso(x + w, y, z + h), iso(x + w, y + d, z + h), iso(x + w, y + d, z), iso(x + w, y, z)]);
  return (
    <g>
      <polygon points={lf} fill={shade(c, 0.14)} />
      <polygon points={rt} fill={shade(c, 0.34)} />
      <polygon points={tp} fill={top ?? blend(c, '#ffffff', 0.12)} />
    </g>
  );
};

type Draw = {key: number; node: React.ReactNode};
const ADOBE = ['#c79a5c', '#bf8f52', '#d0a76a', '#b98a50'];

const S5World = (() => {
  const items: Draw[] = [];
  const r = mulberry32(5);
  // rumah-rumah (barisan utara & selatan)
  [0, 6.4].forEach((yy, row) => {
    for (let i = 0; i < 3; i++) {
      const x = i * 3.2;
      const h = 1.0 + r() * 0.4;
      const c = ADOBE[(i + row) % ADOBE.length];
      items.push({
        key: x + 1.4 + yy + 1.2,
        node: (
          <g key={`h${row}_${i}`}>
            <Box x={x} y={yy} z={0} w={2.8} d={2.4} h={h} c={c} />
            <g transform={mY(x, yy, 0, 2.4)}>
              <rect x={0.55} y={0} width={0.7} height={0.85} fill="#3a2a1a" />
              <rect x={1.8} y={0.45} width={0.45} height={0.4} fill="#3a2a1a" />
            </g>
            <Box x={x + 0.3} y={yy + 0.3} z={h} w={0.7} d={0.7} h={0.18} c="#a87d48" />
          </g>
        ),
      });
    }
  });
  // lumbung / silo
  [0, 1, 2].forEach((i) => {
    const x = 9.6 + i * 1.7;
    const y = 0.4;
    const [px, py] = iso(x + 0.6, y + 0.6, 0);
    items.push({
      key: x + 0.6 + y + 0.6,
      node: (
        <g key={`silo${i}`}>
          <ellipse cx={px} cy={py + 6} rx={64} ry={32} fill="rgba(0,0,0,0.18)" />
          <path d={`M ${px - 58} ${py} L ${px - 58} ${py - 104} A 58 28 0 0 1 ${px + 58} ${py - 104} L ${px + 58} ${py} A 58 28 0 0 1 ${px - 58} ${py} Z`} fill="#c9a064" />
          <path d={`M ${px + 8} ${py + 28} A 58 28 0 0 0 ${px + 58} ${py} L ${px + 58} ${py - 104} L ${px + 8} ${py - 76} Z`} fill="rgba(0,0,0,0.22)" />
          <path d={`M ${px - 58} ${py - 104} A 58 28 0 0 1 ${px + 58} ${py - 104} A 58 52 0 0 0 ${px - 58} ${py - 104} Z`} fill="#dcb878" />
          <rect x={px - 11} y={py - 52} width={22} height={34} rx={4} fill="#3a2a1a" />
        </g>
      ),
    });
  });
  // dapur / tempat penyimpanan (selatan)
  items.push({
    key: 9.6 + 6.4 + 1.2,
    node: (
      <g key="store">
        <Box x={9.6} y={6.4} z={0} w={4.4} d={2.4} h={1.1} c="#b98a50" />
        <g transform={mY(9.6, 6.4, 0, 2.4)}>
          <rect x={0.5} y={0} width={0.8} height={0.9} fill="#3a2a1a" />
          <rect x={2.2} y={0} width={0.8} height={0.9} fill="#3a2a1a" />
        </g>
      </g>
    ),
  });
  // bengkel terbuka (tiang + atap anyaman)
  const wx = 24;
  const wy = 0.4;
  items.push({
    key: wx + wy + 0.1,
    node: (
      <g key="ws0">
        <Box x={wx} y={wy} z={0} w={0.16} d={0.16} h={1.7} c="#6b4a2e" />
        <Box x={wx + 4} y={wy} z={0} w={0.16} d={0.16} h={1.7} c="#6b4a2e" />
      </g>
    ),
  });
  items.push({
    key: wx + 2 + wy + 2.3,
    node: (
      <g key="wsblocks">
        <Box x={wx + 1} y={wy + 1.2} z={0} w={1.1} d={0.9} h={0.55} c="#e0cd9c" />
        <Box x={wx + 2.6} y={wy + 1.5} z={0} w={0.8} d={0.8} h={0.4} c="#d6c08e" />
      </g>
    ),
  });
  items.push({
    key: wx + 4 + wy + 2.5,
    node: (
      <g key="ws1">
        <Box x={wx} y={wy + 2.5} z={0} w={0.16} d={0.16} h={1.7} c="#6b4a2e" />
        <Box x={wx + 4} y={wy + 2.5} z={0} w={0.16} d={0.16} h={1.7} c="#6b4a2e" />
        <Box x={wx - 0.3} y={wy - 0.3} z={1.7} w={4.6} d={3.2} h={0.16} c="#a98a52" top="#c9a96a" />
      </g>
    ),
  });
  // pemakaman pekerja (teras kecil + mastaba kecil)
  const tx0 = 15.4;
  items.push({
    key: tx0 + 0 + 2,
    node: <Box key="terrace" x={tx0} y={-3} z={0} w={7} d={6.5} h={0.5} c="#c9a064" />,
  });
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 2; j++) {
      const x = tx0 + 0.6 + i * 2.1;
      const y = -2.5 + j * 2.5;
      items.push({
        key: x + y + 1,
        node: (
          <g key={`tomb${i}_${j}`}>
            <Box x={x} y={y} z={0.5} w={1.6} d={1.6} h={0.55} c="#d9bd86" />
            <Box x={x + 0.25} y={y + 0.25} z={1.05} w={1.1} d={1.1} h={0.28} c="#cfae74" />
          </g>
        ),
      });
    }
  }
  return items;
})();

const S5: React.FC<{t: number}> = ({t}) => {
  const fx = 3 + 23 * ramp(t, 0, 15, 0, 1, Easing.inOut(Easing.quad));
  const fy = 3.4;
  const zoom = 0.86 + 0.16 * ramp(t, 0, 15, 0, 1, lin);
  const [fix, fiy] = iso(fx, fy, 0);
  const wrap = `translate(540 1060) scale(${zoom}) translate(${-fix} ${-fiy})`;
  const S = (x: number, y: number, z: number): [number, number] => {
    const [a, b] = iso(x, y, z);
    return [540 + zoom * (a - fix), 1060 + zoom * (b - fiy)];
  };
  const peopleAt = (id: string, x: number, y: number, node: React.ReactNode): Draw => ({key: x + y + 0.02, node: <g key={id}>{node}</g>});
  const people: Draw[] = [];
  // pembawa keranjang di jalan
  [0, 1, 2, 3].forEach((i) => {
    const wxp = 2 + ((i * 5.6 + t * 0.9) % 16);
    const [px, py] = iso(wxp, 4.4 + (i % 2) * 0.5, 0);
    people.push(peopleAt(`car${i}`, wxp, 4.4, <Man x={px} y={py} s={0.5} pose="carry" t={t} ph={i * 1.7} sp={5} />));
  });
  [0, 1].forEach((i) => {
    const wxp = 16 - ((i * 7 + t * 0.7) % 14);
    const [px, py] = iso(wxp, 5.2, 0);
    people.push(peopleAt(`ret${i}`, wxp, 5.2, <Man x={px} y={py} s={0.5} flip pose="walk" t={t} ph={i * 2.3} sp={5} />));
  });
  // pengrajin di bengkel
  [[25.4, 1.6, false, 0], [27.4, 2.2, true, 1.9]].forEach(([x, y, fl, ph], i) => {
    const [px, py] = iso(x as number, y as number, 0);
    people.push(peopleAt(`cr${i}`, x as number, y as number, <Man x={px} y={py} s={0.5} flip={fl as boolean} pose="cut" t={t} ph={ph as number} sp={5.2} />));
  });
  // pengawas
  const [ox, oy] = iso(28.5, 4.6, 0);
  people.push(peopleAt('ov', 28.5, 4.6, <Man x={ox} y={oy} s={0.56} flip pose="stand" t={t} kilt="#ffffff" />));
  // penjaga lumbung
  const [gx, gy] = iso(11.6, 3.0, 0);
  people.push(peopleAt('gr', 11.6, 3.0, <Man x={gx} y={gy} s={0.5} pose="carry" t={t} ph={0.7} sp={0.1} />));
  const all = [...S5World, ...people].sort((a, b) => a.key - b.key);
  const smoke = Array.from({length: 5}, (_, i) => {
    const f = (t * 0.35 + i / 5) % 1;
    const [sx0, sy0] = iso(11.4, 7.2, 1.2);
    return <circle key={i} cx={sx0 + 6 * Math.sin(f * 6 + i)} cy={sy0 - f * 150} r={10 + f * 26} fill="#ddd" opacity={0.5 * (1 - f)} />;
  });
  const callout = (id: string, wx2: number, wy2: number, wz: number, a: number, b: number, title: string, side: 'L' | 'R', dyy: number) => {
    const [sx0, sy0] = S(wx2, wy2, wz);
    const o = win(t, a, b, 0.4);
    const bx = side === 'L' ? 50 : W - 50 - 520;
    const by = 330 + dyy;
    return (
      <g key={id} opacity={o}>
        <line x1={sx0} y1={sy0} x2={bx + 260} y2={by + 70} stroke={C.gold} strokeWidth={3} />
        <circle cx={sx0} cy={sy0} r={11} fill={C.gold} />
        <circle cx={sx0} cy={sy0} r={22 + 6 * Math.sin(t * 5)} fill="none" stroke={C.gold} strokeWidth={2.5} opacity={0.7} />
        <rect x={bx} y={by} width={520} height={70} rx={12} fill="rgba(8,10,22,0.86)" stroke={C.gold} strokeWidth={2.5} />
        <text x={bx + 260} y={by + 48} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={36} fill="#fff" letterSpacing="1.5">
          {title}
        </text>
      </g>
    );
  };
  return (
    <AbsoluteFill style={{background: '#101a3c'}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="s5sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#3b6fae" />
            <stop offset="0.5" stopColor="#f0cf94" />
            <stop offset="1" stopColor="#f8e6b8" />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill="url(#s5sky)" />
        <g transform={`translate(${-fix * 0.1} 0)`}>
          <Dune y={780} amp={34} f={0.005} ph={1} color="#e4c48a" />
        </g>
        <g transform={wrap}>
          <polygon points={pts([iso(-6, -6, 0), iso(46, -6, 0), iso(46, 15, 0), iso(-6, 15, 0)])} fill="#d3ad6c" />
          <polygon points={pts([iso(-6, 3.5, 0), iso(46, 3.5, 0), iso(46, 5.9, 0), iso(-6, 5.9, 0)])} fill="#bf9658" />
          {Array.from({length: 26}, (_, i) => {
            const [a, b] = iso(-4 + i * 2, 4.7, 0);
            return <ellipse key={i} cx={a} cy={b} rx={26} ry={5} fill="rgba(90,60,30,0.2)" />;
          })}
          {all.map((d, i) => (
            <g key={i}>{d.node}</g>
          ))}
          {smoke}
        </g>
        {callout('c1', 4.2, 1.2, 1.2, 0.8, 4.0, 'PERMUKIMAN PEKERJA', 'L', 0)}
        {callout('c2', 12.0, 1.0, 1.4, 4.1, 7.2, 'PENYIMPANAN MAKANAN', 'R', 120)}
        {callout('c3', 19, -0.5, 1.4, 7.2, 10.2, 'PEMAKAMAN PEKERJA', 'L', 0)}
        {callout('c4', 26.4, 1.8, 1.3, 10.4, 13.0, 'PENGRAJIN & BENGKEL', 'R', 120)}
        {callout('c5', 28.5, 4.6, 1.3, 13.2, 16.8, 'PENGAWAS', 'L', 0)}
      </svg>
    </AbsoluteFill>
  );
};

const PapyrusWipe: React.FC<{o: number}> = ({o}) => {
  if (o <= 0.001) return null;
  return (
    <AbsoluteFill style={{opacity: o, background: 'linear-gradient(135deg,#f3e4b6,#e6cf93 55%,#d8bb78)'}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        {Array.from({length: 40}, (_, i) => (
          <line key={i} x1={0} y1={i * 50 + 20} x2={W} y2={i * 50 + 20} stroke="rgba(120,90,40,0.12)" strokeWidth={4} />
        ))}
        {Array.from({length: 22}, (_, i) => (
          <rect key={i} x={120 + ((i * 137) % 760)} y={300 + i * 62} width={60 + ((i * 53) % 220)} height={16} rx={8} fill={i % 7 === 0 ? C.red : C.ink} opacity={0.35} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

/* ======================================================================
   SCENE 6 — PENUTUP (73–90 s)
   ====================================================================== */
const SKY_STOPS: [string, string][] = [
  ['#1a2a55', '#f0a860'],
  ['#3d7fc4', '#f6dcab'],
  ['#1e2350', '#e9744a'],
  ['#050914', '#16254d'],
];
const skyAt = (k: number): [string, string] => {
  const i = Math.max(0, Math.min(2, Math.floor(k)));
  const f = Math.max(0, Math.min(1, k - i));
  return [blend(SKY_STOPS[i][0], SKY_STOPS[i + 1][0], f), blend(SKY_STOPS[i][1], SKY_STOPS[i + 1][1], f)];
};
const CITY = (() => {
  const r = mulberry32(61);
  let x = 640;
  const out: {x: number; w: number; h: number; win: number[]}[] = [];
  while (x < 1100) {
    const w = 18 + r() * 30;
    out.push({x, w, h: 20 + r() * 80, win: Array.from({length: 6}, () => r())});
    x += w + 3;
  }
  return out;
})();

const S6: React.FC<{t: number}> = ({t}) => {
  const [top, hor] = skyAt(ramp(t, 0, 11.5, 0, 3, lin));
  const S = 760 - 430 * ramp(t, 0, 6.8, 0, 1, inOutC);
  const cx = 540;
  const cy = 1500 - 330 * ramp(t, 0, 6.8, 0, 1, inOutC);
  const yaw = 0.55 - 0.3 * ramp(t, 0, 9, 0, 1, lin);
  const pitch = 0.18 - 0.03 * ramp(t, 0, 7, 0, 1);
  const trunc = 0.55 + 0.45 * ramp(t, 1.0, 4.4, 0, 1, inOutC) - 0.055 * ramp(t, 6.8, 8.4, 0, 1);
  const age = ramp(t, 5.4, 8.8, 0, 1);
  const lit = blend('#f6ecc8', '#d3aa6a', age);
  const dark = blend('#7a6244', '#5a3d27', age);
  const sp = ramp(t, 0.4, 9.2, 0, 1, lin);
  const sunVis = sp > 0.001 && sp < 0.999;
  const sx = 80 + 920 * sp;
  const sy = 1090 - 720 * Math.sin(Math.PI * sp);
  const night = ramp(t, 8.6, 11.8, 0, 1);
  const {P, N} = makeCam(cx, cy, S, yaw, pitch);
  const flash = Math.max(0, 0.35 - Math.abs(t - 4.4) * 0.5);
  const constrO = 1 - ramp(t, 3.6, 5.0, 0, 1, lin);
  const hY = 1110;
  const a1 = t > 15.4 ? 1 : 0;
  void a1;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="s6sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={top} />
            <stop offset="0.7" stopColor={hor} />
            <stop offset="1" stopColor={hor} />
          </linearGradient>
          <radialGradient id="s6sun" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#fff2c8" stopOpacity="0.95" />
            <stop offset="1" stopColor="#ffb050" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="s6moon" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#dfe8ff" stopOpacity="0.6" />
            <stop offset="1" stopColor="#dfe8ff" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill="url(#s6sky)" />
        {STARS.map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y * 1.1} r={s.r} fill="#fff" opacity={night * (0.5 + 0.4 * Math.sin(t * 2 + s.ph))} />
        ))}
        {sunVis && (
          <g>
            <circle cx={sx} cy={sy} r={380} fill="url(#s6sun)" opacity={0.75} />
            <circle cx={sx} cy={sy} r={58} fill="#fff4d2" />
          </g>
        )}
        <circle cx={800} cy={480} r={300} fill="url(#s6moon)" opacity={night} />
        <circle cx={800} cy={480} r={46} fill="#eaf0ff" opacity={night} />
        <g transform={`translate(${-t * 4} 0)`}>
          <Dune y={hY} amp={22} f={0.005} ph={0.5} color={blend('#c79a68', '#0c1124', night * 0.85)} />
        </g>
        <g opacity={ramp(t, 10.2, 12.4, 0, 1)}>
          {CITY.map((b, i) => (
            <g key={i}>
              <rect x={b.x} y={hY - b.h + 6} width={b.w} height={b.h + 40} fill="#0a0f22" />
              {b.win.map((w, j) => (w > 0.45 ? <rect key={j} x={b.x + 4 + (j % 2) * (b.w / 2 - 2)} y={hY - b.h + 14 + Math.floor(j / 2) * 18} width={4} height={6} fill="#ffd27a" /> : null))}
            </g>
          ))}
          <ellipse cx={870} cy={hY + 4} rx={300} ry={40} fill="#ffb050" opacity={0.18} />
        </g>
        <ellipse cx={cx} cy={cy + 40} rx={S * 1.7} ry={S * 0.5} fill="rgba(30,18,10,0.35)" />
        <Pyr cx={cx} cy={cy} S={S} yaw={yaw} pitch={pitch} trunc={trunc} lit={lit} dark={dark} courses={Math.round(34 + 8 * age)} lineOp={0.22 + 0.14 * age} />
        {constrO > 0.01 && (
          <g>
            {rampBandB(P, 1, constrO * 0.95)}
            <g opacity={constrO}>
              {Array.from({length: 9}, (_, i) => {
                const s = (t * 0.08 + i / 9) % 1;
                const q = P(rampPathB(s).inner);
                return <circle key={i} cx={q[0]} cy={q[1] - 8} r={Math.max(4, S / 70)} fill="#14100d" stroke="#fff" strokeWidth={1.6} />;
              })}
            </g>
          </g>
        )}
        <Dune y={1250 + 60 * ramp(t, 0, 6, 0, 1)} amp={36} f={0.004} ph={1.4} color={blend('#8a5a3a', '#07091a', night * 0.9)} shift={t * 10} />
        <Dune y={1360 + 140 * ramp(t, 0, 6, 0, 1)} amp={44} f={0.0036} ph={0.2} color={blend('#5a3a28', '#04050f', night * 0.9)} shift={-t * 14} />
        <g opacity={ramp(t, 11.0, 12.6, 0, 1)}>
          {[0, 1, 2].map((i) => {
            const f = (t * 0.07 + i / 3) % 1;
            const x = 1120 - f * 1300;
            return (
              <g key={i}>
                <circle cx={x} cy={1180 + i * 4} r={26} fill="#fff1c0" opacity={0.25} />
                <circle cx={x} cy={1180 + i * 4} r={4} fill="#fff6d8" />
              </g>
            );
          })}
        </g>
        <rect width={W} height={H} fill="#fff4c8" opacity={flash} />
      </svg>
      <Big top={330} o={win(t, 9.4, 17.2, 0.7)} lines={['SEJARAH MENYIMPAN', 'LEBIH BANYAK DARI', 'YANG KITA KIRA.']} size={88} dy={30} color="#fff" />
      <div style={{position: 'absolute', left: 0, right: 0, top: 1235, display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: ramp(t, 13.4, 14.8, 0, 1, lin), transform: `translateY(${(1 - ramp(t, 13.4, 14.8)) * 20}px)`}}>
        <svg width={86} height={70}>
          <polygon points="43,4 82,66 4,66" fill={C.gold} />
          <polygon points="43,4 82,66 43,66" fill={C.goldD} />
        </svg>
        <div style={{fontFamily: cond, fontWeight: 700, fontSize: 112, letterSpacing: '0.1em', color: '#fff', textShadow: TXT_SH, lineHeight: 1}}>SemestaKita</div>
      </div>
    </AbsoluteFill>
  );
};

/* ======================================================================
   KOMPOSISI UTAMA
   ====================================================================== */
const TR = 1.6;

export const Piramida: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const vis = (i: number) => t >= SCENE_START[i] && (i === 5 || t < SCENE_START[i + 1] + TR);
  const lt = (i: number) => t - SCENE_START[i];
  const wt = (i: number) => lt(i) * WARP[i];

  // transisi tiap adegan
  const irisR = ramp(lt(1), 0, 1.4, 0, 1500, outC);
  const s2Clip = lt(1) < 1.4 ? `circle(${irisR}px at 540px 960px)` : 'none';
  const wipeL = -380 + (W + 380) * ramp(lt(2), 0, 1.4, 0, 1, inOutC);
  const s3Clip = lt(2) < 1.4 ? `inset(0px ${Math.max(0, W - wipeL)}px 0px 0px)` : 'none';
  const shut = ramp(lt(3), 0, 1.2, 0, 1, inOutC);
  const s4Clip = lt(3) < 1.2 ? `inset(${(1 - shut) * H}px 0px 0px 0px)` : 'none';
  const papO = ramp(t, SCENE_START[4] - 0.8, SCENE_START[4] + 0.1, 0, 1, lin) * (1 - ramp(t, SCENE_START[4] + 1.4, SCENE_START[4] + 1.8, 0, 1, lin));
  const irisR5 = ramp(lt(4), 0.5, 1.9, 0, 1700, inOutC);
  const s5Clip = lt(4) < 1.9 ? `circle(${irisR5}px at 540px 960px)` : 'none';
  const s6O = ramp(lt(5), 0, 1.6, 0, 1, lin);

  const tagIdx = SCENE_START.filter((a) => t >= a).length - 1;
  const tagO = tagIdx < 0 ? 0 : ramp(t, SCENE_START[tagIdx] + 0.9, SCENE_START[tagIdx] + 1.5, 0, 1, lin) * ramp(t, (SCENE_START[tagIdx + 1] ?? 90) - 0.6, (SCENE_START[tagIdx + 1] ?? 90) - 0.2, 1, 0, lin);

  return (
    <AbsoluteFill style={{background: '#000'}}>
      {vis(0) && <S1 t={wt(0)} />}
      {vis(1) && (
        <AbsoluteFill style={{clipPath: s2Clip}}>
          <S2 t={wt(1)} />
        </AbsoluteFill>
      )}
      {vis(2) && (
        <AbsoluteFill style={{clipPath: s3Clip}}>
          <S3 t={wt(2)} />
        </AbsoluteFill>
      )}
      {vis(2) && lt(2) < 1.4 && (
        <div style={{position: 'absolute', left: wipeL, top: 0, width: 380, height: H, background: 'linear-gradient(90deg,#c9b07a,#ead9ac 40%,#d8c28c)', borderLeft: '8px solid #fff3cf', borderRight: '10px solid #8a6a4a'}}>
          {Array.from({length: 9}, (_, i) => (
            <div key={i} style={{position: 'absolute', left: 0, right: 0, top: i * 220 + 40, height: 4, background: 'rgba(90,60,30,0.28)'}} />
          ))}
        </div>
      )}
      {vis(3) && (
        <AbsoluteFill style={{clipPath: s4Clip}}>
          <S4 t={wt(3)} />
        </AbsoluteFill>
      )}
      {vis(3) && lt(3) < 1.2 && <div style={{position: 'absolute', left: 0, right: 0, top: (1 - shut) * H - 4, height: 8, background: C.gold}} />}
      <PapyrusWipe o={papO} />
      {vis(4) && (
        <AbsoluteFill style={{clipPath: s5Clip}}>
          <S5 t={wt(4)} />
        </AbsoluteFill>
      )}
      {vis(5) && (
        <AbsoluteFill style={{opacity: s6O}}>
          <S6 t={wt(5)} />
        </AbsoluteFill>
      )}

      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 46%, rgba(0,0,0,0) 54%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none'}} />
      {t > 1.2 && (
        <div style={{position: 'absolute', left: 60, right: 60, top: 88, height: 5, background: 'rgba(255,255,255,0.2)', borderRadius: 3, opacity: ramp(t, 1.2, 2, 0, 1, lin) * ramp(t, 88.4, 89, 1, 0, lin)}}>
          <div style={{width: `${(t / 90) * 100}%`, height: 5, background: C.gold, borderRadius: 3}} />
        </div>
      )}
      {tagIdx >= 0 && tagIdx <= 5 && t > 1.2 && <Tag text={SCENES[tagIdx].tag} o={tagO} />}
      <Subtitles t={t} />
      <AbsoluteFill style={{background: '#000', opacity: ramp(t, 88.7, 90, 0, 1, lin), pointerEvents: 'none'}} />
      <Audio src={staticFile('audio.mp3')} />
    </AbsoluteFill>
  );
};
