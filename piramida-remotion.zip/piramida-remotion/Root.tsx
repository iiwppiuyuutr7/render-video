import React from 'react';
import {Composition} from 'remotion';
import {Piramida} from './Piramida';

// 90 detik x 30 fps = 2700 frame, 1080x1920 (9:16)
export const RemotionRoot: React.FC = () => (
  <Composition id="Piramida" component={Piramida} durationInFrames={2700} fps={30} width={1080} height={1920} />
);
