import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  BAGAIMANA ILMUWAN MENGETAHUI USIA FOSIL JUTAAN TAHUN?  (versi 3D voxel)
  91 detik, vertikal 1080x1920, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Dunia 3D voxel murni SVG (mesin render kecil dengan rotasi kamera), tanpa WebGL, jadi ringan.
  Waktu kalimat ada di SENT (sinkron dengan voice.mp3 yang sudah dirapikan); waktu scene ada di SCT.
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;
const DUR = 91;
const WM_BOTTOM = 270; // jarak watermark dari bawah (naikkan/turunkan di sini)

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  cyan: '#5ad1ff',
  bone: '#f4e8cf',
  ink: '#5a3d22',
  red: '#ff4d4d',
  green: '#6ee7a0',
};

// batas scene (detik)
const SCT = [0, 5.7, 18.6, 22.0, 43.3, 54.8, 70.7, 83.4];
const CHAPTERS = ['PEMBUKA', 'LAPISAN BATUAN', 'URUTAN, BUKAN ANGKA', 'RADIOMETRIK', 'KARBON-14', 'ABU VULKANIK', 'BUKTI', 'KESIMPULAN'];

const SENT: {a: number; b: number; t: string}[] = [
  {a: 0.00, b: 2.15, t: "Tidak ada manusia yang melihat dinosaurus hidup."},
  {a: 2.46, b: 5.43, t: "Lalu bagaimana ilmuwan tahu usia fosil jutaan tahun?"},
  {a: 5.74, b: 7.91, t: "Jawabannya ada di lapisan tanah."},
  {a: 8.22, b: 11.98, t: "Fosil terkubur di batuan sedimen yang menumpuk lapis demi lapis."},
  {a: 12.29, b: 14.33, t: "Lapisan paling bawah terbentuk lebih dulu,"},
  {a: 14.49, b: 16.56, t: "jadi lebih tua dari lapisan di atasnya."},
  {a: 16.87, b: 18.46, t: "Itu prinsip superposisi."},
  {a: 18.76, b: 21.84, t: "Tapi cara ini hanya memberi urutan, bukan angka pasti."},
  {a: 22.15, b: 25.74, t: "Untuk mendapatkan angka, ilmuwan memakai penanggalan radiometrik."},
  {a: 26.04, b: 30.02, t: "Atom radioaktif meluruh menjadi unsur lain dengan laju yang bisa diukur."},
  {a: 30.32, b: 33.15, t: "Waktu hingga setengahnya meluruh disebut waktu paruh."},
  {a: 33.46, b: 38.37, t: "Uranium-238, misalnya, sekitar 4,47 miliar tahun."},
  {a: 38.67, b: 41.38, t: "Dengan membandingkan atom induk dan hasil peluruhannya,"},
  {a: 41.54, b: 43.09, t: "usia mineral bisa dihitung."},
  {a: 43.40, b: 44.88, t: "Kenapa bukan karbon-14?"},
  {a: 45.19, b: 50.85, t: "Waktu paruhnya hanya 5.730 tahun, dan efektif sampai sekitar 50.000 tahun."},
  {a: 51.15, b: 54.63, t: "Sedangkan dinosaurus hidup puluhan hingga ratusan juta tahun lalu."},
  {a: 54.93, b: 56.72, t: "Solusinya abu vulkanik."},
  {a: 57.02, b: 62.14, t: "Mineral dari letusan gunung berapi bisa diuji dengan metode kalium-argon atau argon-argon."},
  {a: 62.44, b: 67.89, t: "Jika abu di bawah fosil berusia 100 juta tahun, dan abu di atasnya 95 juta tahun,"},
  {a: 68.05, b: 70.54, t: "fosil itu berasal dari rentang antara keduanya."},
  {a: 70.84, b: 72.98, t: "Hasilnya memang punya rentang ketidakpastian."},
  {a: 73.29, b: 75.75, t: "Karena itu ilmuwan menggabungkan banyak bukti:"},
  {a: 75.91, b: 80.32, t: "posisi lapisan, hasil radiometrik, mineral, dan fosil lain di sekitarnya."},
  {a: 80.62, b: 83.26, t: "Jika semuanya cocok, perkiraannya makin kuat."},
  {a: 83.56, b: 85.85, t: "Jadi, usia fosil bukan tebakan."},
  {a: 86.15, b: 89.60, t: "Itu rekonstruksi sejarah Bumi dari bukti yang saling mendukung."},
];


const CAPS = (() => {
  const out: {a: number; b: number; text: string}[] = [];
  for (const n of SENT) {
    const w = n.t.split(' ');
    const parts = Math.ceil(w.length / 8);
    const size = Math.ceil(w.length / parts);
    const pieces: string[] = [];
    for (let i = 0; i < w.length; i += size) pieces.push(w.slice(i, i + size).join(' '));
    const total = pieces.reduce((a, p) => a + p.length, 0);
    let cur = n.a;
    for (const p of pieces) {
      const d = ((n.b - n.a) * p.length) / total;
      out.push({a: cur, b: cur + d - 0.03, text: p});
      cur += d;
    }
  }
  return out;
})();

/* ---------- util ---------- */

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (
  t: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (x: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.4) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const rad = (d: number) => (d * Math.PI) / 180;
// pop dengan overshoot
const pop = (t: number, a: number, d = 0.5) => {
  const p = Math.min(1, Math.max(0, (t - a) / d));
  const c1 = 1.70158;
  return p <= 0 ? 0 : 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};

const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const shade = (h: string, k: number) => `rgb(${hex(h).map((v) => Math.max(0, Math.min(255, Math.round(v * k)))).join(',')})`;

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};


/* ---------- teks ---------- */

const Title: React.FC<{
  t: number;
  lines: string[];
  start: number;
  end: number;
  y: number;
  size: number;
  color?: string;
  step?: number;
}> = ({t, lines, start, end, y, size, color = '#fff', step = 0.1}) => {
  if (t < start - 0.1 || t > end + 0.1) return null;
  const outA = ramp(t, end - 0.45, end, 1, 0, lin);
  let idx = 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: 40,
        right: 40,
        top: y,
        textAlign: 'center',
        opacity: outA,
        fontFamily: cond,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 0.98,
        letterSpacing: '0.02em',
        color,
        textShadow: '0 0 36px rgba(255,122,26,0.38), 0 4px 30px rgba(0,0,0,0.8)',
      }}
    >
      {lines.map((ln, li) => (
        <div key={li} style={{display: 'flex', justifyContent: 'center', gap: size * 0.22}}>
          {ln.split(' ').map((w, wi) => {
            const i = idx++;
            const p = ramp(t, start + i * step, start + i * step + 0.45, 0, 1, outC);
            return (
              <span key={wi} style={{display: 'inline-block', opacity: p, transform: `translateY(${(1 - p) * 38}px) scale(${0.96 + 0.04 * p})`}}>
                {w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

const Caption: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find((x) => t >= x.a && t < x.b);
  if (!c) return null;
  const o = ramp(t, c.a, c.a + 0.16, 0, 1, lin) * ramp(t, c.b - 0.1, c.b, 1, 0, lin);
  return (
    <div
      style={{
        position: 'absolute',
        left: 90,
        right: 90,
        top: 1330,
        height: 230,
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center',
        opacity: o,
        transform: `translateY(${(1 - o) * 12}px)`,
        fontFamily: sans,
        fontWeight: 700,
        fontSize: 56,
        lineHeight: 1.22,
        color: '#fff',
        textShadow: '0 3px 22px rgba(0,0,0,0.95), 0 0 6px rgba(0,0,0,0.9)',
      }}
    >
      <span>{c.text}</span>
    </div>
  );
};


/* ================= mesin voxel 3D (SVG) ================= */

type Cam = {yaw: number; pitch: number; zoom: number; cx: number; cy: number; tx: number; ty: number; tz: number};
// x,y,z = pojok minimum; w,d,h = ukuran; e = emisif (tidak digelapkan); o = opacity; b = bias urutan gambar
type Bx = {x: number; y: number; z: number; w: number; d: number; h: number; c: string; e?: boolean; o?: number; b?: number};

const mk = (yaw: number, pitch: number, zoom: number, tx: number, ty: number, tz: number, cy = 820): Cam => ({yaw, pitch, zoom, cx: 540, cy, tx, ty, tz});

const proj = (c: Cam, x: number, y: number, z: number): [number, number, number] => {
  const cs = Math.cos(c.yaw);
  const sn = Math.sin(c.yaw);
  const sp = Math.sin(c.pitch);
  const cp = Math.cos(c.pitch);
  const dx = x - c.tx;
  const dy = y - c.ty;
  const dz = z - c.tz;
  const x1 = dx * cs - dy * sn;
  const y1 = dx * sn + dy * cs;
  return [c.cx + c.zoom * x1, c.cy + c.zoom * (y1 * sp - dz * cp), y1 * cp + dz * sp];
};

const rgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mul = (h: string, k: number) => {
  const v = rgb(h);
  return `rgb(${v.map((n) => Math.max(0, Math.min(255, Math.round(n * k)))).join(',')})`;
};
const LIGHT = (() => {
  const v = [0.55, -0.5, 0.9];
  const l = Math.hypot(v[0], v[1], v[2]);
  return v.map((a) => a / l);
})();

const FACES: {n: [number, number, number]; v: number[][]}[] = [
  {n: [0, 0, 1], v: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]]},
  {n: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]]},
  {n: [-1, 0, 0], v: [[0, 1, 0], [0, 0, 0], [0, 0, 1], [0, 1, 1]]},
  {n: [0, 1, 0], v: [[1, 1, 0], [0, 1, 0], [0, 1, 1], [1, 1, 1]]},
  {n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]]},
];

const Voxels: React.FC<{boxes: Bx[]; cam: Cam; edge?: number}> = ({boxes, cam, edge = 0.3}) => {
  const sn = Math.sin(cam.yaw);
  const cs = Math.cos(cam.yaw);
  const items: {d: number; pts: string; f: string; o: number}[] = [];
  for (const b of boxes) {
    if (b.o === 0 || b.h <= 0.001) continue;
    const d0 = proj(cam, b.x + b.w / 2, b.y + b.d / 2, b.z + b.h / 2)[2] + (b.b || 0);
    for (let fi = 0; fi < 5; fi++) {
      const f = FACES[fi];
      if (fi > 0 && f.n[0] * sn + f.n[1] * cs <= 0) continue;
      const dot = f.n[0] * LIGHT[0] + f.n[1] * LIGHT[1] + f.n[2] * LIGHT[2];
      const k = fi === 0 ? 1.08 : 0.5 + 0.5 * Math.max(0, dot) + 0.12;
      const pts = f.v
        .map((v) => {
          const p = proj(cam, b.x + v[0] * b.w, b.y + v[1] * b.d, b.z + v[2] * b.h);
          return p[0].toFixed(1) + ',' + p[1].toFixed(1);
        })
        .join(' ');
      items.push({d: d0 + (fi === 0 ? 0.0004 : 0), pts, f: b.e ? mul(b.c, fi === 0 ? 1.1 : 0.92) : mul(b.c, k), o: b.o === undefined ? 1 : b.o});
    }
  }
  items.sort((a, b) => a.d - b.d);
  return (
    <g stroke="rgba(0,0,0,0.28)" strokeWidth={edge} strokeLinejoin="round">
      {items.map((it, i) => (
        <polygon key={i} points={it.pts} fill={it.f} opacity={it.o} />
      ))}
    </g>
  );
};

const Shadow: React.FC<{cam: Cam; x: number; y: number; rx: number; ry: number; o?: number}> = ({cam, x, y, rx, ry, o = 0.35}) => {
  const p = proj(cam, x, y, 0);
  return <ellipse cx={p[0]} cy={p[1] + 40} rx={rx * cam.zoom} ry={ry * cam.zoom * 0.5} fill="#000" opacity={o} />;
};

const Label: React.FC<{cam: Cam; x: number; y: number; z: number; text: string; size?: number; color?: string; o?: number; dy?: number}> = ({cam, x, y, z, text, size = 40, color = '#fff', o = 1, dy = 0}) => {
  const p = proj(cam, x, y, z);
  return (
    <text x={p[0]} y={p[1] + dy} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
      {text}
    </text>
  );
};

const T2: React.FC<{x: number; y: number; text: string; size?: number; color?: string; o?: number; anchor?: 'start' | 'middle' | 'end'}> = ({x, y, text, size = 40, color = '#fff', o = 1, anchor = 'middle'}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
    {text}
  </text>
);

/* ---------- model ---------- */

const REX = {body: '#4f9d58', head: '#62b165', leg: '#3f8a4c', belly: '#b6d98a'};
const rex = (ox: number, oy: number, oz: number, s = 1, o: {bone?: boolean; phase?: number; alpha?: number; flip?: boolean} = {}): Bx[] => {
  const {bone = false, phase = 0, alpha = 1, flip = false} = o;
  const bs: Bx[] = [];
  const add = (x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: string) => {
    const xa = flip ? -x1 : x0;
    const xb = flip ? -x0 : x1;
    bs.push({x: ox + xa * s, y: oy + y0 * s, z: oz + z0 * s, w: (xb - xa) * s, d: (y1 - y0) * s, h: (z1 - z0) * s, c, o: alpha});
  };
  const sw = Math.sin(phase) * 0.35;
  if (!bone) {
    add(0, 2.2, -0.5, 0.5, 1.2, 2.3, REX.body);
    add(0, 2.2, -0.45, 0.45, 1.2, 1.5, REX.belly);
    add(-1.3, 0, -0.38, 0.38, 1.3, 2.1, REX.body);
    add(-2.4, -1.3, -0.28, 0.28, 1.4, 1.95, REX.body);
    add(-3.4, -2.4, -0.16, 0.16, 1.5, 1.8, REX.body);
    add(2.2, 2.9, -0.36, 0.36, 1.8, 2.8, REX.body);
    add(2.6, 4.1, -0.46, 0.46, 2.3, 3.2, REX.head);
    add(2.9, 4.1, -0.36, 0.36, 2.02, 2.3, REX.belly);
    add(3.0, 3.3, 0.45, 0.5, 2.8, 3.05, '#111111');
    add(3.0, 3.3, -0.5, -0.45, 2.8, 3.05, '#111111');
    add(3.5, 3.65, -0.3, 0.3, 2.22, 2.34, '#ffffff');
    add(3.8, 3.95, -0.3, 0.3, 2.22, 2.34, '#ffffff');
    add(1.9, 2.4, -0.62, -0.48, 1.45, 1.65, REX.head);
    add(1.9, 2.4, 0.48, 0.62, 1.45, 1.65, REX.head);
    add(0.5 + sw, 1.2 + sw, -0.45, -0.05, 0, 1.3, REX.leg);
    add(0.5 - sw, 1.2 - sw, 0.05, 0.45, 0, 1.3, REX.leg);
    add(0.8 + sw, 1.6 + sw, -0.45, -0.05, 0, 0.25, '#2f6e3b');
    add(0.8 - sw, 1.6 - sw, 0.05, 0.45, 0, 0.25, '#2f6e3b');
  } else {
    const B = C.bone;
    add(-3.4, 2.9, -0.12, 0.12, 1.9, 2.12, B);
    for (let i = 0; i < 6; i++) add(0.1 + i * 0.36, 0.24 + i * 0.36, -0.46, 0.46, 1.35, 1.9, B);
    add(2.4, 4.1, -0.46, 0.46, 2.3, 3.2, B);
    add(2.9, 4.1, -0.34, 0.34, 2.02, 2.3, B);
    add(3.0, 3.3, 0.45, 0.5, 2.8, 3.05, '#2a1a0e');
    add(3.0, 3.3, -0.5, -0.45, 2.8, 3.05, '#2a1a0e');
    add(0.5, 1.0, -0.3, -0.05, 0, 1.4, B);
    add(0.5, 1.0, 0.05, 0.3, 0, 1.4, B);
    add(0.6, 1.4, -0.3, -0.05, 0, 0.2, B);
    add(0.6, 1.4, 0.05, 0.3, 0, 0.2, B);
    add(-2.4, -1.0, -0.06, 0.06, 1.5, 1.7, B);
  }
  return bs;
};

const palm = (x: number, y: number, s = 1): Bx[] => [
  {x: x - 0.15 * s, y: y - 0.15 * s, z: 0, w: 0.3 * s, d: 0.3 * s, h: 2.2 * s, c: '#8a5a2b'},
  {x: x - 0.9 * s, y: y - 0.2 * s, z: 2.2 * s, w: 1.8 * s, d: 0.4 * s, h: 0.25 * s, c: '#3f9e4a'},
  {x: x - 0.2 * s, y: y - 0.9 * s, z: 2.2 * s, w: 0.4 * s, d: 1.8 * s, h: 0.25 * s, c: '#47ad52'},
  {x: x - 0.35 * s, y: y - 0.35 * s, z: 2.4 * s, w: 0.7 * s, d: 0.7 * s, h: 0.3 * s, c: '#3a8f45'},
];

const ammonite = (ox: number, oy: number, oz: number, s = 1): Bx[] => {
  const bs: Bx[] = [];
  for (let i = 0; i < 26; i++) {
    const th = i * 0.42;
    const r = 0.16 * Math.exp(0.2 * th);
    const sz = 0.13 + 0.06 * r;
    bs.push({x: ox + (Math.cos(th) * r - sz / 2) * s, y: oy - 0.18 * s, z: oz + (Math.sin(th) * r + 0.7 - sz / 2) * s, w: sz * s, d: 0.36 * s, h: sz * s, c: i % 2 ? '#f4e8cf' : '#e0cfa6'});
  }
  return bs;
};

const fishBone = (ox: number, oy: number, oz: number, s = 1): Bx[] => {
  const bs: Bx[] = [{x: ox - 1.2 * s, y: oy - 0.06 * s, z: oz + 0.1 * s, w: 2.4 * s, d: 0.12 * s, h: 0.12 * s, c: C.bone}];
  for (let i = 0; i < 6; i++) bs.push({x: ox - 0.9 * s + i * 0.28 * s, y: oy - 0.4 * s, z: oz + 0.1 * s, w: 0.08 * s, d: 0.8 * s, h: 0.1 * s, c: C.bone});
  bs.push({x: ox - 1.55 * s, y: oy - 0.3 * s, z: oz + 0.02 * s, w: 0.45 * s, d: 0.6 * s, h: 0.28 * s, c: C.bone});
  bs.push({x: ox + 1.2 * s, y: oy - 0.35 * s, z: oz + 0.05 * s, w: 0.3 * s, d: 0.7 * s, h: 0.12 * s, c: C.bone});
  return bs;
};

// pulau diorama (ubin 2x2)
const island = (x0: number, y0: number, nx: number, ny: number, c1: string, c2: string, tz = 0): Bx[] => {
  const bs: Bx[] = [];
  for (let i = 0; i < nx; i++)
    for (let j = 0; j < ny; j++) bs.push({x: x0 + i * 2, y: y0 + j * 2, z: tz - 1.0, w: 2, d: 2, h: 1.0, c: (i + j) % 2 ? c1 : c2});
  return bs;
};

// blok bertangga: lapisan 0 paling bawah (paling tua)
type SLayer = {c: string; fossil?: 'rex' | 'ammo' | 'fish' | 'bone' | 'none'; e?: number};
const stairs = (layers: SLayer[], prog: number[], gl: number[]): Bx[] => {
  const bs: Bx[] = [];
  const n = layers.length;
  const LH = 1.0;
  layers.forEach((l, i) => {
    const dep = 9.0 - 1.6 * i;
    const p = prog[i];
    if (p <= 0.001) return;
    const dz = (1 - p) * 9;
    const z = i * LH + dz;
    const col = gl[i] > 0 ? l.c : l.c;
    for (let k = 0; k < 2; k++) bs.push({x: k * 4, y: 0, z, w: 4, d: dep, h: LH, c: col, o: Math.min(1, p * 2), e: gl[i] > 0.5});
    if (gl[i] > 0.01) for (let k = 0; k < 2; k++) bs.push({x: k * 4, y: 0, z: z + LH + 0.01, w: 4, d: dep, h: 0.02, c: '#fff3c0', e: true, o: 0.55 * gl[i], b: 0.3});
    const tread = i < n - 1 ? 9.0 - 1.6 * (i + 1) : 0;
    const ty = i < n - 1 ? tread + 0.8 : dep / 2;
    const tz = z + LH - 0.05;
    if (l.fossil === 'rex') bs.push(...rex(5.0, ty, tz, 0.42, {bone: true, alpha: Math.min(1, p)}).map((b) => ({...b, b: 0.2})));
    if (l.fossil === 'ammo') bs.push(...ammonite(4, ty, tz, 1.4).map((b) => ({...b, b: 0.2})));
    if (l.fossil === 'fish') bs.push(...fishBone(4, ty, tz, 1.1).map((b) => ({...b, b: 0.2})));
    if (l.fossil === 'bone') {
      bs.push({x: 2.6, y: ty - 0.1, z: tz, w: 2.0, d: 0.22, h: 0.22, c: C.bone, b: 0.2}, {x: 2.4, y: ty - 0.2, z: tz, w: 0.35, d: 0.42, h: 0.35, c: C.bone, b: 0.2}, {x: 4.5, y: ty - 0.2, z: tz, w: 0.35, d: 0.42, h: 0.35, c: C.bone, b: 0.2});
    }
  });
  return bs;
};
/* ---------- maskot Fosi + meme ---------- */

type Mood = 'confused' | 'brow' | 'tired';

const Fosi: React.FC<{x: number; y: number; s?: number; mood: Mood; t: number}> = ({x, y, s = 1, mood, t}) => {
  const bob = Math.sin(t * 9) * 4;
  const body = '#f2dcae';
  const pup = mood === 'confused' ? [[-30, -18], [46, -28]] : mood === 'brow' ? [[-26, -20], [26, -20]] : [[-36, -8], [34, -8]];
  return (
    <g transform={`translate(${x},${y + bob}) scale(${s}) rotate(${mood === 'confused' ? Math.sin(t * 5) * 3 : 0})`}>
      <ellipse cx={0} cy={96} rx={92} ry={12} fill="#000" opacity={0.35} />
      <ellipse cx={-104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(25 -104 20)" />
      <ellipse cx={104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(-25 104 20)" />
      <ellipse cx={0} cy={0} rx={100} ry={90} fill={body} stroke={C.ink} strokeWidth={7} />
      <path d="M -78 30 Q 0 56 78 30" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      <path d="M -62 56 Q 0 78 62 56" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      {[-38, 38].map((ex, i) => (
        <g key={i}>
          <circle cx={ex} cy={-22} r={30} fill="#fff" stroke={C.ink} strokeWidth={5} />
          <circle cx={ex + pup[i][0] * 0.35 + (i ? 0 : 0)} cy={-22 + pup[i][1] * 0.35} r={11} fill="#2a1a0e" />
          {mood === 'tired' && <path d={`M ${ex - 30} -22 A 30 30 0 0 1 ${ex + 30} -22 Z`} fill={body} stroke={C.ink} strokeWidth={5} />}
        </g>
      ))}
      {mood === 'confused' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -66 L -16 -56" />
          <path d="M 66 -76 L 16 -62" />
        </g>
      )}
      {mood === 'brow' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -62 -50 L -14 -52" />
          <path d="M 14 -78 Q 40 -90 64 -70" />
        </g>
      )}
      {mood === 'tired' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -62 L -14 -52" />
          <path d="M 66 -62 L 14 -52" />
        </g>
      )}
      {mood === 'confused' && <path d="M -34 46 q 17 -16 34 0 t 34 0" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'brow' && <path d="M -24 48 L 24 48" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' && <path d="M -32 58 Q 0 30 32 58" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' &&
        [0, 1].map((k) => {
          const p = (t * 1.3 + k * 0.5) % 1;
          return <path key={k} d="M 0 -12 Q 12 8 0 16 Q -12 8 0 -12 Z" transform={`translate(${96 + k * 20},${-60 + p * 90})`} fill={C.cyan} opacity={1 - p} />;
        })}
      {mood === 'confused' &&
        [[-130, -110, 0], [140, -90, 1.3], [-40, -150, 2.4]].map(([qx, qy, ph], i) => (
          <text key={i} x={qx} y={qy + Math.sin(t * 4 + ph) * 8} fontFamily={cond} fontWeight={700} fontSize={84} fill={C.amber} stroke="#000" strokeWidth={8} paintOrder="stroke" textAnchor="middle">
            ?
          </text>
        ))}
    </g>
  );
};

const MemeText: React.FC<{lines: string[]; y: number; size: number; t: number; a: number}> = ({lines, y, size, t, a}) => {
  const p = pop(t, a + 0.05, 0.45);
  const sh = t - a < 0.5 ? Math.sin(t * 60) * 5 * (1 - (t - a) / 0.5) : 0;
  return (
    <g transform={`translate(${CX + sh},${y}) scale(${Math.max(0.01, p)})`}>
      {lines.map((ln, i) => (
        <text key={i} x={0} y={i * size * 0.98} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill="#fff" stroke="#000" strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke" letterSpacing="0.02em">
          {ln}
        </text>
      ))}
    </g>
  );
};

const Meme: React.FC<{t: number; a: number; b: number; mood: Mood; lines: string[]; ty: number; size?: number; fx?: number; fy?: number; fs?: number}> = ({
  t,
  a,
  b,
  mood,
  lines,
  ty,
  size = 112,
  fx = CX,
  fy = 1110,
  fs = 1.15,
}) => {
  if (t < a - 0.05 || t > b + 0.05) return null;
  const o = win(t, a, b, 0.25);
  const flash = ramp(t, a, a + 0.12, 0.55, 0, lin);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: '#000', opacity: 0.5 * o}} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: o}}>
        <g transform={`translate(${fx},${fy}) scale(${Math.max(0.01, pop(t, a, 0.5))}) translate(${-fx},${-fy})`}>
          <Fosi x={fx} y={fy} s={fs} mood={mood} t={t} />
        </g>
        <MemeText lines={lines} y={ty} size={size} t={t} a={a} />
      </svg>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </AbsoluteFill>
  );
};

/* ================= latar ================= */

const hexMix = (a: string, b: string, k: number) => {
  const A = rgb(a);
  const B = rgb(b);
  const kk = Math.max(0, Math.min(1, k));
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * kk).toString(16).padStart(2, '0')).join('');
};
const BGK: [number, string, string][] = [
  [0, '#241438', '#9a4a2c'],
  [5.7, '#120d0a', '#2e1f14'],
  [22.0, '#050a1c', '#0c1844'],
  [43.3, '#07060f', '#1a1236'],
  [54.8, '#1c0a0a', '#6a2410'],
  [62.2, '#14100c', '#2e1f14'],
  [70.7, '#0a1020', '#18264a'],
  [83.4, '#120a1c', '#40200f'],
];
const DUST = (() => {
  const r = mulberry32(5);
  return Array.from({length: 60}, () => ({x: r() * W, y: r() * H, s: r() * 2.4 + 0.8, o: r() * 0.35 + 0.1, v: 8 + r() * 24, p: r() * 6.28}));
})();

const Bg: React.FC<{t: number}> = ({t}) => {
  let i = 0;
  BGK.forEach((k, j) => {
    if (t >= k[0]) i = j;
  });
  const p = i > 0 ? ramp(t, BGK[i][0], BGK[i][0] + 0.8, 0, 1, lin) : 1;
  const prev = BGK[Math.max(0, i - 1)];
  const top = hexMix(prev[1], BGK[i][1], p);
  const bot = hexMix(prev[2], BGK[i][2], p);
  return (
    <AbsoluteFill>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <defs>
          <linearGradient id="bgg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={top} />
            <stop offset="0.7" stopColor={bot} />
            <stop offset="1" stopColor={top} />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill="url(#bgg)" />
        {DUST.map((d, k) => (
          <circle key={k} cx={(d.x + Math.sin(t * 0.3 + d.p) * 20) % W} cy={(((d.y - t * d.v) % H) + H) % H} r={d.s} fill="#ffd9a0" opacity={d.o * (0.6 + 0.4 * Math.sin(t * 1.5 + d.p))} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

const Stage: React.FC<{a: number; b: number; t: number; children: React.ReactNode}> = ({a, b, t, children}) => {
  if (t < a - 0.4 || t > b + 0.4) return null;
  const o = ramp(t, a - 0.35, a + 0.25, 0, 1, lin) * ramp(t, b - 0.25, b + 0.35, 1, 0, lin);
  return (
    <AbsoluteFill style={{opacity: o}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        {children}
      </svg>
    </AbsoluteFill>
  );
};

const rnd = (() => {
  const r = mulberry32(123);
  return Array.from({length: 400}, () => r());
})();
const R = (i: number) => rnd[i % 400];

/* ================= scene A: pembuka ================= */

const SceneA: React.FC<{t: number}> = ({t}) => {
  const rx = ramp(t, 0, 3.1, -4.5, 1.2, lin);
  const walking = t < 3.1;
  const cam = mk(ramp(t, 0, 5.8, -0.85, -0.12, lin), 0.6, ramp(t, 0, 5.8, 54, 80, lin), rx * 0.45 + 0.3, 0, 1.4, 860);
  const m = ramp(t, 3.2, 5.4, 0, 1, outC);
  const bs: Bx[] = [...island(-8, -6, 8, 6, '#6fa84e', '#7bb556'), ...palm(-5.5, -3, 1.1), ...palm(6, 3, 1.0), ...palm(-3, 3.6, 0.9), ...palm(7.2, -3.6, 1.2)];
  bs.push(...rex(rx, 0, 0, 1, {phase: walking ? t * 9 : 0}));
  bs.push({x: rx - 3.8, y: -2.4, z: 0, w: 8.4, d: 4.8, h: m * 3.6, c: '#d6b27a', b: 8});
  for (let k = 0; k < 46; k++) {
    const t0 = 3.2 + k * 0.045;
    const p = (t - t0) / 0.75;
    if (p <= 0 || p >= 1) continue;
    bs.push({x: rx - 3.2 + R(k) * 7, y: -2 + R(k + 50) * 4, z: 9 - (9 - m * 3.6) * p, w: 0.32, d: 0.32, h: 0.32, c: '#ebd096', b: 9});
  }
  const top = proj(cam, rx + 0.5, 0, m * 3.6 + 1.2);
  const q = pop(t, 4.7, 0.5);
  return (
    <g>
      <Shadow cam={cam} x={0} y={0} rx={9} ry={7} />
      <Voxels boxes={bs} cam={cam} />
      <g transform={`translate(${top[0]},${top[1]}) scale(${q})`}>
        <T2 x={0} y={0} text="?" size={190} color={C.amber} />
      </g>
    </g>
  );
};

/* ================= scene B+C: lapisan batuan ================= */

const LAYERS_B: SLayer[] = [
  {c: '#765536', fossil: 'ammo'},
  {c: '#a07a4c', fossil: 'rex'},
  {c: '#c9a468', fossil: 'fish'},
  {c: '#b08a55', fossil: 'bone'},
  {c: '#7fae4e', fossil: 'none'},
];

const SceneB: React.FC<{t: number}> = ({t}) => {
  const cam = mk(ramp(t, 5.7, 22, -0.55, 0.2, lin), 0.58, 68, 4, 4.4, 2.2, 830);
  const prog = LAYERS_B.map((_, i) => ramp(t, 7.2 + 0.95 * i, 7.9 + 0.95 * i, 0, 1, Easing.out(Easing.quad)));
  const gl = LAYERS_B.map((_, i) => win(t, 12.3 + 0.55 * i, 13.1 + 0.55 * i, 0.25));
  const bs: Bx[] = [{x: -0.6, y: -0.6, z: -0.7, w: 9.2, d: 10.2, h: 0.7, c: '#2b2118'}, ...stairs(LAYERS_B, prog, gl)];
  // debu jatuh
  for (let k = 0; k < 40; k++) {
    const ti = 7.0 + k * 0.1;
    const p = (t - ti) / 0.8;
    if (p <= 0 || p >= 1 || ti > 11.8) continue;
    bs.push({x: R(k) * 8, y: R(k + 40) * 8, z: 9 - 8 * p, w: 0.28, d: 0.28, h: 0.28, c: '#e3c48a', b: 5});
  }
  const num = (i: number) => {
    const dep = 9.0 - 1.6 * i;
    const p = proj(cam, 8.7, dep - 0.2, i + 0.5);
    const o = ramp(t, 13.4 + 0.55 * i, 13.9 + 0.55 * i, 0, 1, lin) * ramp(t, 21.4, 22.0, 1, 0, lin);
    return (
      <g key={i} opacity={o} transform={`translate(${p[0] + 30},${p[1]})`}>
        <circle r={26} fill="rgba(20,16,28,0.9)" stroke={C.amber} strokeWidth={4} />
        <T2 x={0} y={13} text={`${i + 1}`} size={40} color={C.amber} />
      </g>
    );
  };
  const arrow = ramp(t, 14.6, 15.3, 0, 1, lin) * ramp(t, 17.8, 18.6, 1, 0, lin);
  const tagP = (i: number) => {
    const dep = 9.0 - 1.6 * i;
    return proj(cam, -0.3, dep - 0.6, i + 0.6);
  };
  return (
    <g>
      <Voxels boxes={bs} cam={cam} />
      {[0, 1, 2, 3, 4].map(num)}
      <g opacity={arrow}>
        <line x1={110} y1={560} x2={110} y2={1130} stroke="#fff" strokeOpacity={0.6} strokeWidth={6} strokeDasharray="4 16" strokeDashoffset={-t * 40} strokeLinecap="round" />
        <path d="M 82 1100 L 110 1142 L 138 1100" fill="none" stroke="#fff" strokeOpacity={0.85} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
        <T2 x={110} y={520} text="MUDA" size={56} color={C.cyan} />
        <T2 x={110} y={1200} text="TUA" size={56} color={C.orange} />
      </g>
      {[0, 1, 2, 3, 4].map((i) => {
        const p = tagP(i);
        const s = pop(t, 18.9 + 0.25 * i, 0.45) * ramp(t, 21.4, 22.0, 1, 0, lin);
        return (
          <g key={'q' + i} transform={`translate(${Math.max(130, p[0] - 40)},${p[1]}) scale(${Math.max(0.001, s)})`}>
            <rect x={-80} y={-26} width={160} height={52} rx={26} fill="rgba(20,16,28,0.92)" stroke="#fff" strokeOpacity={0.5} strokeWidth={3} />
            <T2 x={0} y={11} text="? JUTA" size={32} />
          </g>
        );
      })}
    </g>
  );
};

/* ================= scene D: atom & radiometrik ================= */

const NUC = Array.from({length: 16}, (_, i) => {
  const zc = 1 - (2 * (i + 0.5)) / 16;
  const r = Math.sqrt(1 - zc * zc);
  const ph = i * 2.399963;
  return {x: 0.62 * Math.cos(ph) * r, y: 0.62 * Math.sin(ph) * r, z: 0.62 * zc};
});
// waktu lepas tiap inti
const NTE = [99, 99, 99, 99, 99, 99, 99, 99, 31.5, 31.62, 31.74, 31.86, 31.98, 29.3, 28.4, 27.0];

const ring3 = (cam: Cam, rad_: number, tilt: number, rot: number, n = 48) => {
  const pts: string[] = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    let x = Math.cos(a) * rad_;
    let y = Math.sin(a) * rad_;
    let z = 0;
    const y2 = y * Math.cos(tilt) - z * Math.sin(tilt);
    const z2 = y * Math.sin(tilt) + z * Math.cos(tilt);
    y = y2;
    z = z2;
    const x3 = x * Math.cos(rot) - y * Math.sin(rot);
    const y3 = x * Math.sin(rot) + y * Math.cos(rot);
    const p = proj(cam, x3, y3, z);
    pts.push(p[0].toFixed(1) + ',' + p[1].toFixed(1));
  }
  return pts.join(' ');
};

const SceneD: React.FC<{t: number}> = ({t}) => {
  // D1: batu dengan kristal (22-25.4) -> atom (24.8-38.6) -> menara (38.6-43.3)
  const atomOn = ramp(t, 24.8, 25.9, 0, 1, outC) * ramp(t, 38.2, 38.8, 1, 0, lin);
  const rockOn = ramp(t, 24.6, 25.2, 1, 0, lin);
  const towerOn = ramp(t, 38.5, 39.2, 0, 1, lin);
  const out: React.ReactNode[] = [];
  if (rockOn > 0.01) {
    const cam = mk(0.5, 0.55, ramp(t, 22, 25.2, 70, 230, Easing.in(Easing.cubic)), 0.8, 0.6, 1.0, 830);
    const bs: Bx[] = [
      {x: -2, y: -1.6, z: 0, w: 4, d: 3.2, h: 1.6, c: '#7d7468'},
      {x: -1.4, y: -1.2, z: 1.6, w: 2.8, d: 2.4, h: 1.0, c: '#8b8174'},
      {x: -0.8, y: -0.8, z: 2.6, w: 1.6, d: 1.6, h: 0.7, c: '#968c7e'},
      {x: 0.6, y: 1.2, z: 0.9, w: 0.5, d: 0.5, h: 0.9, c: '#a6efff', e: true},
      {x: 0.72, y: 1.32, z: 1.8, w: 0.26, d: 0.26, h: 0.25, c: '#d8f8ff', e: true},
    ];
    out.push(
      <g key="rock" opacity={rockOn}>
        <Shadow cam={cam} x={0} y={0} rx={3} ry={2.5} />
        <Voxels boxes={bs} cam={cam} />
        <Label cam={cam} x={0.8} y={1.4} z={3.3} text="KRISTAL ZIRKON" size={38} color={C.cyan} o={ramp(t, 22.6, 23.2, 0, 1, lin)} />
      </g>,
    );
  }
  if (atomOn > 0.01) {
    const cam = mk(0.35 * t, 0.5, 118 * (0.4 + 0.6 * atomOn), 0, 0, 0, 760);
    const bs: Bx[] = [];
    const tint = ramp(t, 35.4, 37.4, 0, 1, lin);
    NUC.forEach((p, i) => {
      const te = NTE[i];
      const sz = 0.5;
      if (t < te) {
        const c = hexMix(C.orange, '#6fd0ff', i < 8 ? tint : 0);
        bs.push({x: p.x - sz / 2, y: p.y - sz / 2, z: p.z - sz / 2, w: sz, d: sz, h: sz, c, e: true});
      } else {
        const s = t - te;
        const L = 4.6 * (1 - Math.exp(-s * 1.6));
        const dir = [Math.cos(i * 2.7), Math.sin(i * 2.7), Math.sin(i * 1.3) * 0.8];
        const o = ramp(s, 0.5, 1.6, 1, 0, lin);
        bs.push({x: p.x + dir[0] * L - 0.25, y: p.y + dir[1] * L - 0.25, z: p.z + dir[2] * L - 0.25, w: 0.5, d: 0.5, h: 0.5, c: '#6fd0ff', e: true, o});
      }
    });
    const rings: React.ReactNode[] = [];
    [0, 1, 2].forEach((k) => {
      const tilt = 1.05;
      const rot = (k * Math.PI) / 3 + 0.2;
      rings.push(<polyline key={'r' + k} points={ring3(cam, 2.7, tilt, rot)} fill="none" stroke="#9ad7ff" strokeOpacity={0.4} strokeWidth={3} />);
      for (let e = 0; e < 2; e++) {
        const a = t * (1.6 + 0.3 * k) + e * Math.PI + k;
        let x = Math.cos(a) * 2.7;
        let y = Math.sin(a) * 2.7;
        const y2 = y * Math.cos(tilt);
        const z2 = y * Math.sin(tilt);
        const x3 = x * Math.cos(rot) - y2 * Math.sin(rot);
        const y3 = x * Math.sin(rot) + y2 * Math.cos(rot);
        bs.push({x: x3 - 0.16, y: y3 - 0.16, z: z2 - 0.16, w: 0.32, d: 0.32, h: 0.32, c: '#ffffff', e: true});
      }
    });
    // percikan saat meluruh
    NTE.forEach((te, i) => {
      if (te > 90) return;
      const s = t - te;
      if (s > 0 && s < 0.5) {
        const p = proj(cam, NUC[i].x, NUC[i].y, NUC[i].z);
        out.push(<circle key={'f' + i} cx={p[0]} cy={p[1]} r={20 + s * 160} fill="none" stroke="#fff" strokeWidth={4} opacity={1 - s / 0.5} />);
      }
    });
    out.unshift(
      <g key="atom" opacity={atomOn}>
        {rings}
        <Voxels boxes={bs} cam={cam} edge={0.2} />
      </g>,
    );
    // jam waktu paruh
    const sw = ramp(t, 30.4, 31.5, 0, 1, Easing.inOut(Easing.cubic));
    const clk = ramp(t, 30.2, 30.6, 0, 1, lin) * ramp(t, 33.2, 33.6, 1, 0, lin);
    out.push(
      <g key="clock" opacity={clk} transform="translate(870,520)">
        <circle r={74} fill="rgba(20,16,28,0.9)" stroke="#fff" strokeOpacity={0.5} strokeWidth={4} />
        <path d={`M 0 0 L 0 -74 A 74 74 0 ${sw > 0.5 ? 1 : 0} 1 ${(Math.sin(sw * Math.PI) * 74).toFixed(1)} ${(-Math.cos(sw * Math.PI) * 74).toFixed(1)} Z`} fill={C.amber} opacity={0.9} />
        <T2 x={0} y={16} text="½" size={60} color="#fff" />
      </g>,
    );
    const u = ramp(t, 33.8, 34.4, 0, 1, outC);
    const isPb = t > 36.4;
    out.push(
      <g key="lab" opacity={ramp(t, 33.5, 34.0, 0, 1, lin) * ramp(t, 38.0, 38.6, 1, 0, lin)}>
        <T2 x={CX} y={1090} text={isPb ? 'TIMBAL-206' : 'URANIUM-238'} size={64} color={isPb ? C.cyan : C.orange} />
        <g transform={`translate(${CX},1190) scale(${u})`}>
          <T2 x={0} y={0} text="4,47 MILIAR TAHUN" size={76} color={C.amber} />
        </g>
      </g>,
    );
    out.push(
      <g key="iso" opacity={ramp(t, 26.3, 26.9, 0, 1, lin) * ramp(t, 29.9, 30.4, 1, 0, lin)}>
        <T2 x={CX} y={1120} text="ISOTOP RADIOAKTIF" size={56} color={C.orange} />
      </g>,
    );
  }
  if (towerOn > 0.01) {
    const cam = mk(ramp(t, 38.5, 43.3, 0.2, 0.9, lin), 0.55, 92, 0, 0, 1.6, 860);
    const bs: Bx[] = [{x: -3.6, y: -2.2, z: -0.6, w: 7.2, d: 4.4, h: 0.6, c: '#2c2740'}];
    const slot = (s: number, cx: number) => {
      const L = Math.floor(s / 4);
      const c = s % 4;
      return {x: cx + (c % 2) * 0.95 - 0.5, y: Math.floor(c / 2) * 0.95 - 0.5, z: L * 0.95};
    };
    for (let s = 0; s < 16; s++) {
      const ta = 39.0 + 0.17 * (15 - s);
      const home = slot(s, -1.9);
      const dest = slot(15 - s, 1.9);
      const p = ramp(t, ta, ta + 0.55, 0, 1, Easing.inOut(Easing.cubic));
      const cc = hexMix(C.orange, '#6fd0ff', p);
      const x = home.x + (dest.x - home.x) * p;
      const y = home.y + (dest.y - home.y) * p;
      const z = home.z + (dest.z - home.z) * p + Math.sin(p * Math.PI) * 2.2;
      bs.push({x, y, z, w: 0.85, d: 0.85, h: 0.85, c: cc, e: true});
    }
    const rr = ramp(t, 41.4, 42.0, 0, 1, lin);
    out.push(
      <g key="tw" opacity={towerOn}>
        <Voxels boxes={bs} cam={cam} />
        <Label cam={cam} x={-1.4} y={0} z={4.9} text="INDUK" size={50} color={C.orange} />
        <Label cam={cam} x={2.4} y={0} z={4.9} text="HASIL" size={50} color={C.cyan} />
        <g opacity={rr}>
          <T2 x={CX} y={1150} text="RASIO INDUK : HASIL" size={46} color="#fff" />
          <T2 x={CX} y={1215} text="= USIA MINERAL" size={64} color={C.amber} />
        </g>
      </g>,
    );
  }
  return <g>{out}</g>;
};

/* ================= scene E: jalan waktu karbon-14 ================= */

const GATES = [1, 2, 3, 4, 5, 6, 7, 8, 8.73];
const SceneE: React.FC<{t: number}> = ({t}) => {
  const tx = t < 50.9 ? ramp(t, 43.4, 50.8, 0, 30.5, Easing.inOut(Easing.cubic)) : ramp(t, 51.2, 54.4, 30.5, 66, Easing.inOut(Easing.cubic));
  const cam = mk(-0.78, 0.52, 62, tx, 0, 1.2, 860);
  const bs: Bx[] = [];
  const x0 = Math.floor(tx / 2) * 2 - 16;
  for (let x = x0; x < x0 + 40; x += 2) {
    if (x < -2 || x > 72) continue;
    const dark = x > 31.8;
    bs.push({x, y: -1.6, z: -0.4, w: 2, d: 3.2, h: 0.4, c: dark ? ((x / 2) % 2 ? '#1a1730' : '#221e3a') : (x / 2) % 2 ? '#3a3354' : '#453d63'});
  }
  const lab: React.ReactNode[] = [];
  GATES.forEach((h, gi) => {
    const x = 3.5 * h;
    const frac = Math.pow(0.5, h);
    const k = Math.max(0.28, Math.sqrt(frac));
    const col = hexMix('#1b2a3a', '#5ad1ff', k);
    const last = gi === GATES.length - 1;
    bs.push({x: x - 0.15, y: -1.6, z: 0, w: 0.3, d: 0.3, h: 3.2, c: col, e: true});
    bs.push({x: x - 0.15, y: 1.3, z: 0, w: 0.3, d: 0.3, h: 3.2, c: col, e: true});
    bs.push({x: x - 0.15, y: -1.6, z: 3.2, w: 0.3, d: 3.2, h: 0.3, c: col, e: true});
    const p = proj(cam, x, 0, 3.9);
    if (p[0] > 130 && p[0] < 950 && p[1] > 330 && p[1] < 1200) {
      const pct = (frac * 100).toFixed(frac < 0.02 ? 1 : frac < 0.1 ? 1 : 0).replace('.', ',');
      lab.push(
        <g key={gi}>
          <T2 x={p[0]} y={p[1] - 6} text={last ? '50.000 THN' : `${(h * 5730).toLocaleString('id-ID')} THN`} size={last ? 36 : 28} color={last ? C.red : '#fff'} />
          <T2 x={p[0]} y={p[1] + 32} text={`SISA C-14 ${last ? '±0,2' : pct}%`} size={26} color={C.cyan} />
        </g>,
      );
    }
  });
  // dinding batas
  const wallP = ramp(t, 49.6, 50.6, 0, 1, lin);
  bs.push({x: 31.6, y: -2.2, z: 0, w: 0.4, d: 4.4, h: 4.4, c: '#ff3b3b', e: true, o: 0.35 + 0.15 * Math.sin(t * 6)});
  // dinosaurus jauh
  const far = ramp(t, 51.0, 52.0, 0, 1, lin);
  const dino = rex(66, 0, 0, 1.0, {alpha: far});
  const dp = proj(cam, 68, 0, 5.2);
  return (
    <g>
      <Voxels boxes={[...bs, ...dino]} cam={cam} />
      {lab}
      <g opacity={far}>
        <T2 x={Math.min(dp[0], 800)} y={dp[1] - 30} text="DINOSAURUS" size={52} color={C.amber} />
        <T2 x={Math.min(dp[0], 800)} y={dp[1] + 22} text="JUTAAN TAHUN LALU" size={34} color="#fff" />
      </g>
      <g opacity={wallP * ramp(t, 51.0, 51.6, 1, 0, lin)}>
        <T2 x={CX} y={1130} text="BATAS ±50.000 TAHUN" size={60} color={C.red} />
      </g>
    </g>
  );
};

/* ================= scene F: gunung berapi + abu ================= */

const LAYERS_F: SLayer[] = [{c: '#765536'}, {c: '#d8d4cc'}, {c: '#c9a468', fossil: 'rex'}, {c: '#e4e1da'}, {c: '#8a6a47'}];

const SceneF: React.FC<{t: number}> = ({t}) => {
  const out: React.ReactNode[] = [];
  const vOn = ramp(t, 62.0, 62.6, 1, 0, lin);
  if (vOn > 0.01) {
    const sh = t > 55.4 && t < 57.2 ? Math.sin(t * 70) * 0.06 : 0;
    const cam = mk(0.3 * t, 0.55, ramp(t, 54.8, 62.2, 50, 60, lin), 0 + sh, 0, 2.4, 880);
    const bs: Bx[] = island(-8, -8, 8, 8, '#3d3a2e', '#464134');
    for (let i = 0; i < 6; i++) {
      const hw = 4.4 - 0.62 * i;
      bs.push({x: -hw, y: -hw, z: i * 0.85, w: 2 * hw, d: 2 * hw, h: 0.85, c: hexMix('#6b5242', '#3a2a22', i / 5)});
    }
    const er = ramp(t, 55.2, 56.0, 0, 1, lin);
    bs.push({x: -0.9, y: -0.9, z: 5.1, w: 1.8, d: 1.8, h: 0.2, c: '#ff6a1a', e: true});
    const PER = 2.2;
    for (let k = 0; k < 70; k++) {
      const s = (((t - 55.2) * 1 + k * 0.0314 * PER * 1.0) % PER + PER) % PER;
      if (t < 55.2) break;
      const vx = (R(k) - 0.5) * 3.2;
      const vy = (R(k + 70) - 0.5) * 3.2;
      const vz = 5 + R(k + 140) * 3;
      const z = 5.2 + vz * s - 3.4 * s * s;
      if (z < 5.0) continue;
      bs.push({x: vx * s - 0.2, y: vy * s - 0.2, z, w: 0.4, d: 0.4, h: 0.4, c: s < 1.0 ? '#ff7a1a' : '#6a625a', e: s < 1.0, o: er});
    }
    for (let k = 0; k < 6; k++) {
      const g = ramp(t, 55.6 + k * 0.25, 58.5 + k * 0.25, 0, 1, outC) * er;
      bs.push({x: -1.4 - g * 1.2 + (R(k) - 0.5) * 2, y: -1.4 - g * 1.2 + (R(k + 9) - 0.5) * 2, z: 5.6 + g * (2.2 + k * 0.45), w: 2.4 + g * 1.2, d: 2.4 + g * 1.2, h: 1.2 + g * 0.6, c: '#5c5650', o: 0.8 * g * ramp(t, 60, 62, 1, 0.4, lin), b: 6});
    }
    // kristal zirkon
    const zc = ramp(t, 58.4, 59.2, 0, 1, outC);
    bs.push({x: 6.2, y: -0.4, z: 0.2, w: 0.8, d: 0.8, h: 1.8 * zc, c: '#a6efff', e: true}, {x: 6.35, y: -0.25, z: 0.2 + 1.8 * zc, w: 0.5, d: 0.5, h: 0.4 * zc, c: '#e2faff', e: true});
    const cp = proj(cam, 6.6, 0, 3.0);
    out.push(
      <g key="v" opacity={vOn}>
        <Shadow cam={cam} x={0} y={0} rx={9} ry={9} />
        <Voxels boxes={bs} cam={cam} />
        <g opacity={zc}>
          <T2 x={cp[0]} y={cp[1] - 20} text="MINERAL ZIRKON" size={34} color={C.cyan} />
        </g>
        {[['KALIUM-ARGON', 60.1], ['ARGON-ARGON', 61.0]].map(([n, a], i) => {
          const s = pop(t, a as number, 0.45);
          return (
            <g key={n as string} transform={`translate(${CX},${1130 + i * 78}) scale(${s})`}>
              <rect x={-210} y={-30} width={420} height={60} rx={30} fill="rgba(20,16,28,0.92)" stroke={C.cyan} strokeWidth={4} />
              <T2 x={0} y={13} text={n as string} size={38} />
            </g>
          );
        })}
      </g>,
    );
  }
  const bOn = ramp(t, 62.0, 62.7, 0, 1, lin);
  if (bOn > 0.01) {
    const cam = mk(ramp(t, 62.2, 70.7, -0.5, 0.1, lin), 0.58, 60, 4, 4.4, 2.2, 840);
    const prog = LAYERS_F.map((_, i) => ramp(t, 62.2 + 0.1 * i, 62.9 + 0.1 * i, 0, 1, Easing.out(Easing.quad)));
    const gl = [0, 0, win(t, 68.1, 70.6, 0.3), 0, 0];
    const bs: Bx[] = [{x: -0.6, y: -0.6, z: -0.7, w: 9.2, d: 10.2, h: 0.7, c: '#2b2118'}, ...stairs(LAYERS_F, prog, gl)];
    const g1 = win(t, 62.9, 65.4, 0.3) + 0.35;
    const g2 = win(t, 65.4, 67.9, 0.3) + 0.35;
    for (let k = 0; k < 6; k++) {
      bs.push({x: 0.8 + k * 1.3, y: 6.5, z: 2.0, w: 0.3, d: 0.3, h: 0.45, c: '#aeeeff', e: true, b: 0.4, o: Math.min(1, g1)});
      bs.push({x: 0.8 + k * 1.3, y: 3.3, z: 4.0, w: 0.3, d: 0.3, h: 0.45, c: '#aeeeff', e: true, b: 0.4, o: Math.min(1, g2)});
    }
    const pill = (y: number, text: string, val: number, col: string, a: number, key: string) => {
      const s = pop(t, a, 0.5);
      return (
        <g key={key} transform={`translate(800,${y}) scale(${s})`}>
          <rect x={-225} y={-48} width={450} height={96} rx={22} fill="rgba(20,16,28,0.93)" stroke={col} strokeWidth={4} />
          <T2 x={0} y={-8} text={text} size={32} color="rgba(255,255,255,0.85)" />
          <T2 x={0} y={36} text={`${val} JUTA TAHUN`} size={42} color={col} />
        </g>
      );
    };
    const pb = proj(cam, 8, 6.6, 2.1);
    const pa = proj(cam, 8, 3.4, 4.1);
    const cb = Math.round(ramp(t, 63.0, 64.4, 0, 100, outC));
    const ca = Math.round(ramp(t, 65.6, 66.8, 0, 95, outC));
    const res = pop(t, 68.1, 0.6);
    out.push(
      <g key="b" opacity={bOn}>
        <Voxels boxes={bs} cam={cam} />
        {t > 63.0 && <line x1={pb[0]} y1={pb[1]} x2={600} y2={pb[1] + 40} stroke={C.orange} strokeWidth={3} strokeDasharray="6 6" />}
        {t > 65.6 && <line x1={pa[0]} y1={pa[1]} x2={600} y2={pa[1] - 10} stroke={C.cyan} strokeWidth={3} strokeDasharray="6 6" />}
        {pill(pb[1] + 60, 'ABU BAWAH', cb, C.orange, 63.0, 'pb')}
        {pill(pa[1] - 40, 'ABU ATAS', ca, C.cyan, 65.6, 'pa')}
        <g transform={`translate(${CX},1215) scale(${res})`}>
          <rect x={-440} y={-62} width={880} height={124} rx={28} fill="rgba(20,16,28,0.95)" stroke={C.green} strokeWidth={5} />
          <T2 x={0} y={-8} text="FOSIL DI ANTARA KEDUANYA" size={36} color="rgba(255,255,255,0.85)" />
          <T2 x={0} y={42} text="± 95–100 JUTA TAHUN" size={62} color={C.green} />
        </g>
      </g>,
    );
  }
  return <g>{out}</g>;
};

/* ================= scene G: ketidakpastian & bukti ================= */

const PIL = [
  {x: -4.5, c: '#c9a468', l: ['POSISI', 'LAPISAN'], a: 75.9},
  {x: -1.5, c: '#ff7a1a', l: ['HASIL', 'RADIOMETRIK'], a: 77.1},
  {x: 1.5, c: '#5ad1ff', l: ['KANDUNGAN', 'MINERAL'], a: 78.3},
  {x: 4.5, c: '#f4e8cf', l: ['FOSIL LAIN', 'DI SEKITAR'], a: 79.2},
];
const SceneG: React.FC<{t: number}> = ({t}) => {
  const cam = mk(ramp(t, 70.7, 83.4, -0.5, 0.35, lin), 0.6, 66, 0, 0, 1.5, 900);
  const bs: Bx[] = island(-7, -5, 7, 5, '#2c2740', '#352f4e');
  // penggaris
  bs.push({x: -6.5, y: -4.2, z: 0.1, w: 13, d: 0.4, h: 0.3, c: '#d8d2c0'});
  for (let i = 0; i <= 12; i++) bs.push({x: -6.5 + i, y: -4.2, z: 0.4, w: 0.12, d: 0.4, h: i % 4 === 0 ? 0.7 : 0.35, c: '#d8d2c0'});
  const narrow = ramp(t, 80.7, 82.4, 0, 1, Easing.inOut(Easing.cubic));
  const wob = Math.sin(t * 5) * 0.35 * (1 - narrow);
  const half = (2.0 + 1.6 * (1 - narrow) + wob);
  const bandOn = ramp(t, 71.0, 71.8, 0, 1, lin);
  bs.push({x: -half, y: -4.3, z: 0.4, w: 2 * half, d: 0.6, h: 1.6 * bandOn, c: '#ffb020', e: true, o: 0.6});
  PIL.forEach((p, i) => {
    const g = ramp(t, p.a, p.a + 0.9, 0, 1, Easing.out(Easing.back ? Easing.out(Easing.cubic) : Easing.cubic));
    bs.push({x: p.x - 0.8, y: 1.6, z: 0, w: 1.6, d: 1.6, h: 3.6 * g, c: p.c});
  });
  const roof = ramp(t, 80.7, 81.4, 9, 0, Easing.in(Easing.quad));
  if (t > 80.6) bs.push({x: -6, y: 1.0, z: 3.6 + roof, w: 12, d: 2.8, h: 0.4, c: '#ffd36a', e: true, b: 0.5});
  const lb = proj(cam, 0, -4.2, 2.4);
  return (
    <g>
      <Voxels boxes={bs} cam={cam} />
      {[0, 4, 8, 12].map((i) => {
        const p = proj(cam, -6.5 + i, -4.2, 0.1);
        return <T2 key={i} x={p[0]} y={p[1] + 56} text={`${90 + i * 1.25}`.replace('.', ',')} size={30} color="rgba(255,255,255,0.8)" />;
      })}
      <g opacity={bandOn * ramp(t, 75.2, 75.8, 1, 0.6, lin)}>
        <T2 x={lb[0]} y={lb[1] - 40} text={narrow > 0.6 ? 'RENTANG MENYEMPIT' : 'RENTANG KETIDAKPASTIAN'} size={36} color={C.amber} />
      </g>
      {PIL.map((p, i) => {
        const s = ramp(t, p.a + 0.5, p.a + 1.0, 0, 1, lin);
        const pt = proj(cam, p.x, 3.7, 0);
        return (
          <g key={i} opacity={s}>
            <T2 x={pt[0]} y={pt[1] + 36} text={p.l[0]} size={26} color={p.c} />
            <T2 x={pt[0]} y={pt[1] + 66} text={p.l[1]} size={26} color={p.c} />
          </g>
        );
      })}
      <g opacity={ramp(t, 81.2, 81.8, 0, 1, lin)}>
        <T2 x={CX} y={1290} text="PERKIRAAN MAKIN KUAT" size={56} color="#ffd36a" />
      </g>
    </g>
  );
};

/* ================= scene H: kesimpulan ================= */

const SceneH: React.FC<{t: number}> = ({t}) => {
  const cam = mk(0.45 * t, 0.56, 84, 1.2, 0, 1.6, 860);
  const flesh = ramp(t, 86.4, 87.6, 0, 1, lin);
  const bs: Bx[] = [...island(-6, -4, 6, 4, '#3a3156', '#433a63'), {x: -4.2, y: -2.2, z: 0, w: 9, d: 4.4, h: 0.5, c: '#5b4636'}];
  bs.push(...rex(1.0, 0, 0.5, 1, {bone: true, alpha: 1 - flesh}));
  bs.push(...rex(1.0, 0, 0.5, 1, {alpha: flesh, phase: 0}));
  for (let k = 0; k < 30; k++) {
    const s = (((t - 86.4) * 0.8 + k * 0.1) % 1.5 + 1.5) % 1.5;
    if (t < 86.2 || t > 89) continue;
    bs.push({x: -3 + R(k) * 8, y: -2 + R(k + 30) * 4, z: 0.5 + s * 4, w: 0.18, d: 0.18, h: 0.18, c: '#ffd36a', e: true, o: Math.max(0, 1 - s / 1.5)});
  }
  return (
    <g>
      <Shadow cam={cam} x={0} y={0} rx={7} ry={5} />
      <Voxels boxes={bs} cam={cam} />
    </g>
  );
};

/* ================= komposisi utama ================= */

const Hud: React.FC<{t: number}> = ({t}) => {
  let s = 0;
  SCT.forEach((a, i) => {
    if (t >= a) s = i;
  });
  const o = ramp(t, 0.6, 1.4, 0, 1, lin) * ramp(t, 88.2, 88.8, 1, 0, lin);
  return (
    <div style={{position: 'absolute', inset: 0, opacity: o}}>
      <div style={{position: 'absolute', left: 64, right: 64, top: 66, height: 4, background: 'rgba(255,255,255,0.18)', borderRadius: 2}}>
        <div style={{width: `${(t / DUR) * 100}%`, height: 4, background: C.orange, borderRadius: 2, boxShadow: `0 0 12px ${C.orange}`}} />
      </div>
      <div style={{position: 'absolute', left: 64, top: 92, fontFamily: cond, fontWeight: 600, fontSize: 30, letterSpacing: '0.16em', color: 'rgba(255,255,255,0.85)'}}>
        {`0${s + 1} / 08  ·  ${CHAPTERS[s]}`}
      </div>
      <div style={{position: 'absolute', left: 64, top: 130, fontFamily: sans, fontWeight: 600, fontSize: 20, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.42)'}}>
        ILUSTRASI ARTISTIK · ANGKA CONTOH BERLABEL
      </div>
    </div>
  );
};

const Watermark: React.FC<{t: number}> = ({t}) => (
  <div
    style={{
      position: 'absolute',
      right: 52,
      bottom: WM_BOTTOM,
      opacity: ramp(t, 0.2, 0.8, 0, 0.92, lin) * ramp(t, DUR - 0.8, DUR - 0.2, 1, 0, lin),
      fontFamily: cond,
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '0.06em',
      color: '#fff',
      textShadow: '0 2px 14px rgba(0,0,0,0.95), 0 0 4px rgba(0,0,0,0.9)',
    }}
  >
    Semesta<span style={{color: C.orange}}>Kita</span>
  </div>
);

const EndCard: React.FC<{t: number}> = ({t}) => {
  const e = ramp(t, 88.5, 89.3, 0, 1, outC);
  if (e <= 0) return null;
  return (
    <AbsoluteFill style={{opacity: e, background: 'rgba(0,0,0,0.6)'}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <text x={CX} y={820 + (1 - e) * 30} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={122} letterSpacing="0.05em" fill="#fff">
          SEMESTA<tspan fill={C.orange}>KITA</tspan>
        </text>
        <rect x={CX - 70} y={860} width={140} height={4} fill={C.orange} />
        <text x={CX} y={960} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={62} letterSpacing="0.05em" fill="rgba(255,255,255,0.92)">
          FOLLOW UNTUK FAKTA
        </text>
        <text x={CX} y={1032} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={62} letterSpacing="0.05em" fill="rgba(255,255,255,0.92)">
          SEMESTA LAINNYA
        </text>
      </svg>
    </AbsoluteFill>
  );
};

export const Fosil: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const fadeIn = ramp(t, 0, 0.25, 1, 0, lin);
  const fadeOut = ramp(t, DUR - 0.5, DUR, 0, 1, lin);
  const TT = (lines: string[], a: number, b: number, size: number, color = '#fff') => <Title t={t} lines={lines} start={a} end={b} y={190} size={size} color={color} />;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Bg t={t} />
      <Stage a={0} b={5.7} t={t}><SceneA t={t} /></Stage>
      <Stage a={5.7} b={22.0} t={t}><SceneB t={t} /></Stage>
      <Stage a={22.0} b={43.3} t={t}><SceneD t={t} /></Stage>
      <Stage a={43.3} b={54.8} t={t}><SceneE t={t} /></Stage>
      <Stage a={54.8} b={70.7} t={t}><SceneF t={t} /></Stage>
      <Stage a={70.7} b={83.4} t={t}><SceneG t={t} /></Stage>
      <Stage a={83.4} b={DUR} t={t}><SceneH t={t} /></Stage>

      {TT(['BAGAIMANA TAHU USIA', 'FOSIL JUTAAN TAHUN?'], 0.05, 5.6, 80)}
      {TT(['JAWABANNYA:', 'LAPISAN TANAH'], 5.8, 11.9, 104)}
      {TT(['LEBIH BAWAH =', 'LEBIH TUA'], 12.1, 16.7, 100)}
      {TT(['PRINSIP', 'SUPERPOSISI'], 16.9, 18.6, 104, C.amber)}
      {TT(['HANYA URUTAN,', 'BUKAN ANGKA'], 18.8, 21.9, 100, C.amber)}
      {TT(['PENANGGALAN', 'RADIOMETRIK'], 22.2, 25.9, 104)}
      {TT(['ATOM RADIOAKTIF', 'MELURUH'], 26.1, 30.2, 96)}
      {TT(['WAKTU PARUH', '= SETENGAH'], 30.4, 33.3, 108, C.amber)}
      {TT(['URANIUM-238', '→ TIMBAL-206'], 33.5, 38.5, 100)}
      {TT(['INDUK vs HASIL', '= USIA MINERAL'], 38.7, 43.2, 92)}
      {TT(['KENAPA BUKAN', 'KARBON-14?'], 43.4, 45.0, 104)}
      {TT(['BATAS KARBON-14:', '±50.000 TAHUN'], 45.2, 50.9, 96, C.red)}
      {TT(['DINOSAURUS:', 'JUTAAN TAHUN'], 51.2, 54.7, 104, C.amber)}
      {TT(['SOLUSINYA:', 'ABU VULKANIK'], 54.9, 62.1, 104)}
      {TT(['ABU DI ATAS &', 'DI BAWAH FOSIL'], 62.4, 70.6, 92)}
      {TT(['SELALU ADA RENTANG', 'KETIDAKPASTIAN'], 70.9, 75.8, 80)}
      {TT(['GABUNGKAN', 'BANYAK BUKTI'], 75.9, 83.3, 108, C.green)}
      {TT(['USIA FOSIL', 'BUKAN TEBAKAN'], 83.6, 88.4, 112)}

      <Meme t={t} a={19.2} b={21.7} mood="confused" lines={['TERUS GIMANA', 'NGITUNGNYA?!']} ty={800} />
      <Meme t={t} a={51.3} b={53.8} mood="tired" lines={['NGGAK KUAT', 'BOS']} ty={800} />

      <Audio src={staticFile('audio.mp3')} />
      <Caption t={t} />
      <Hud t={t} />
      <EndCard t={t} />
      <Watermark t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
