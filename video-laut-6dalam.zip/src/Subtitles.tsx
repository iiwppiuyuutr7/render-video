import React from "react";
import {C, prog, useT} from "./config";
import {FONT} from "./fonts";

// [mulai, selesai, teks] pada timeline 90 dtk (sama dengan semua animasi scene).
// Dipecah mengikuti jeda napas pada audio narasi.
const CUES: ReadonlyArray<readonly [number, number, string]> = [
  [0.05, 2.95, "Laut menutupi sekitar 71 persen permukaan Bumi,"],
  [3.29, 6.97, "dengan kedalaman rata-rata sekitar 3.682 meter."],
  [7.38, 10.63, "Semakin dalam, semakin sedikit cahaya Matahari yang menembus air."],
  [11.09, 12.73, "Laut dibagi menjadi lima zona."],
  [13.08, 15.5, "Sunlight Zone, 0 sampai 200 meter,"],
  [15.86, 18.1, "tempat cahaya masih cukup untuk fotosintesis."],
  [18.36, 20.8, "Twilight Zone, 200 sampai 1.000 meter, cahaya mulai menghilang."],
  [21.13, 25.09, "Midnight Zone, 1.000 sampai 4.000 meter, gelap dan dingin."],
  [25.35, 29.44, "Abyssal Zone, 4.000 sampai 6.000 meter, bersuhu mendekati titik beku."],
  [29.76, 32.19, "Hadal Zone, 6.000 meter ke bawah,"],
  [32.45, 34.93, "terutama di palung laut."],
  [35.36, 37.15, "Setiap kedalaman bertambah 10 meter,"],
  [37.44, 39.21, "tekanan naik sekitar 1 atmosfer."],
  [39.61, 43.08, "Di Challenger Deep, tekanannya sekitar 1.000 kali tekanan di permukaan."],
  [43.41, 47.5, "Di kegelapan, sebagian makhluk menghasilkan cahaya sendiri lewat reaksi kimia,"],
  [47.5, 48.95, "yang disebut bioluminesensi."],
  [49.32, 52.7, "Cahaya ini dipakai untuk menarik mangsa, membingungkan predator,"],
  [52.7, 54.61, "berkomunikasi, dan menarik pasangan."],
  [54.93, 58.36, "Anglerfish, comb jelly, dan ubur-ubur Atolla adalah contohnya."],
  [58.69, 61.87, "Tanpa fotosintesis, banyak makhluk bergantung pada marine snow,"],
  [62.2, 63.94, "butiran organik yang perlahan tenggelam,"],
  [64.2, 66.56, "dan whale fall, bangkai paus di dasar laut."],
  [66.89, 69.16, "Di ventilasi hidrotermal, mikroorganisme"],
  [69.16, 72.1, "memanfaatkan energi reaksi kimia lewat kemosintesis."],
  [72.38, 74.2, "Challenger Deep di Palung Mariana,"],
  [74.2, 76.0, "sekitar 10.935 meter menurut NOAA,"],
  [76.0, 77.7, "tetap dihuni amphipoda, mikroorganisme, dan ikan snailfish."],
  [78.03, 81.58, "Hingga Juni 2024, baru sekitar 26 persen dasar laut dunia"],
  [81.58, 83.3, "yang dipetakan dengan resolusi tinggi."],
  [83.61, 87.53, "Laut dalam masih menyimpan misteri."],
];

export const Subtitles: React.FC = () => {
  const t = useT();
  const cue = CUES.find((c) => t >= c[0] - 0.05 && t < c[1] + 0.12);
  if (!cue) return null;
  const o = Math.min(prog(t, cue[0] - 0.05, cue[0] + 0.1), 1 - prog(t, cue[1], cue[1] + 0.12));
  return (
    <div
      style={{
        position: "absolute",
        left: 80,
        width: 920,
        bottom: 190,
        display: "flex",
        justifyContent: "center",
        opacity: o,
      }}
    >
      <div
        style={{
          fontFamily: FONT,
          fontWeight: 600,
          fontSize: 44,
          lineHeight: 1.3,
          color: C.white,
          textAlign: "center",
          background: "rgba(2,8,23,0.62)",
          padding: "12px 30px",
          borderRadius: 26,
          textShadow: "0 2px 10px rgba(0,0,0,0.6)",
        }}
      >
        {cue[2]}
      </div>
    </div>
  );
};
