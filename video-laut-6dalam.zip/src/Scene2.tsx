import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {C, HEIGHT, WIDTH, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Particles, Txt} from "./common";
import {Angler, Dumbo, Lanternfish, SmallFish} from "./creatures";

type Zone = {
  word: string;
  range: string;
  note: string;
  t0: number;
  t1: number;
  c1: string;
  c2: string;
  label: string;
};

const ZONES: Zone[] = [
  {word: "Sunlight", range: "0–200 m", note: "Cahaya cukup untuk fotosintesis", t0: 13.08, t1: 18.36, c1: "#2aa8e0", c2: "#0f6fb5", label: "0"},
  {word: "Twilight", range: "200–1.000 m", note: "Cahaya mulai menghilang", t0: 18.36, t1: 21.13, c1: "#0f5fa0", c2: "#0a3a75", label: "200"},
  {word: "Midnight", range: "1.000–4.000 m", note: "Gelap dan dingin", t0: 21.13, t1: 25.35, c1: "#0a2f63", c2: "#061a40", label: "1.000"},
  {word: "Abyssal", range: "4.000–6.000 m", note: "Suhu mendekati titik beku", t0: 25.35, t1: 29.76, c1: "#071b3d", c2: "#040f26", label: "4.000"},
  {word: "Hadal", range: "6.000 m ke bawah", note: "Terutama di palung laut", t0: 29.76, t1: 35.2, c1: "#040d22", c2: "#02060f", label: "6.000"},
];

const GAUGE_X = 985;
const GAUGE_Y0 = 380;
const GAUGE_STEP = 285;

const Letters: React.FC<{text: string; t: number; start: number; size: number; color?: string}> = ({
  text,
  t,
  start,
  size,
  color = "#ffffff",
}) => (
  <div style={{display: "flex", justifyContent: "center", fontFamily: FONT, fontWeight: 800, fontSize: size, color}}>
    {text.split("").map((ch, i) => {
      const p = prog(t, start + i * 0.05, start + i * 0.05 + 0.45, Easing.out(Easing.back(1.5)));
      return (
        <span key={i} style={{display: "inline-block", transform: `translateY(${(1 - p) * 70}px)`, opacity: Math.min(1, p * 1.5)}}>
          {ch}
        </span>
      );
    })}
  </div>
);

const Trench: React.FC<{t: number}> = ({t}) => (
  <g>
    <path d="M-700 120 L-140 130 L-60 340 L0 380 L60 340 L140 130 L700 120 L700 900 L-700 900 Z" fill="#0b1a33" />
    <path d="M-700 120 L-140 130 L-60 340 L0 380 L60 340 L140 130 L700 120" fill="none" stroke="#2b5aa0" strokeWidth={5} />
    {[0, 1, 2, 3, 4, 5].map((i) => {
      const x = -50 + i * 20;
      const y = 120 + ((t * 40 + i * 70) % 220);
      return <circle key={i} cx={x} cy={y} r={4 + (i % 3)} fill="#7ff5ff" opacity={0.3 + 0.5 * Math.abs(Math.sin(t * 2 + i))} />;
    })}
    <path d="M-120 20 L-120 120 M120 20 L120 120" stroke="#2b5aa0" strokeWidth={3} strokeDasharray="8 10" opacity={0.6} />
    <circle cx={0} cy={-40} r={7} fill="#ffffff" opacity={0.35 + 0.35 * Math.sin(t * 3)} />
  </g>
);

const Organism: React.FC<{index: number; t: number; local: number}> = ({index, t, local}) => {
  const p = prog(local, 0.5, 1.3);
  const cx = 460;
  const cy = 1050;
  if (index === 0) {
    const fish: React.ReactNode[] = [];
    const colors = ["#ffd166", "#ff9f1c", "#ffe29a", "#ffb347"];
    for (let i = 0; i < 9; i++) {
      const row = i % 3;
      const col = Math.floor(i / 3);
      const x = -210 + col * 200 + row * 30 + Math.sin(t * 1.2 + i) * 25;
      const y = -190 + row * 190 + Math.sin(t * 1.6 + i * 2) * 14;
      const s = 1.1 + (i % 3) * 0.22;
      fish.push(
        <g key={i} transform={`translate(${x} ${y}) scale(${s})`}>
          <SmallFish t={t} color={colors[i % 4]} phase={i} />
        </g>,
      );
    }
    return (
      <g transform={`translate(${cx} ${cy + (1 - p) * 80})`} opacity={p}>
        {fish}
      </g>
    );
  }
  if (index === 1) {
    return (
      <g transform={`translate(${cx} ${cy + (1 - p) * 80 + Math.sin(t * 1.4) * 10}) scale(1.45)`} opacity={p}>
        <Lanternfish t={t} />
      </g>
    );
  }
  if (index === 2) {
    return (
      <g transform={`translate(${cx + 40} ${cy + (1 - p) * 80}) scale(1.05)`} opacity={p}>
        <Angler t={t} />
      </g>
    );
  }
  if (index === 3) {
    return (
      <g transform={`translate(${cx} ${cy + (1 - p) * 80 + Math.sin(t * 1.3) * 16}) scale(1.35)`} opacity={p}>
        <Dumbo t={t} />
      </g>
    );
  }
  return (
    <g transform={`translate(${cx} ${cy - 40 + (1 - p) * 80}) scale(1.6)`} opacity={p}>
      <Trench t={t} />
    </g>
  );
};

const Panel: React.FC<{zone: Zone; index: number; t: number}> = ({zone, index, t}) => {
  const local = t - zone.t0;
  const wipe = prog(t, zone.t0, zone.t0 + 0.7, Easing.inOut(Easing.cubic));
  if (wipe <= 0) return null;
  const rayStrength = Math.max(0, 0.16 - index * 0.04);
  const rays: React.ReactNode[] = [];
  if (rayStrength > 0) {
    for (let i = 0; i < 5; i++) {
      const x = -60 + i * 230;
      rays.push(
        <polygon
          key={i}
          points={`${x},0 ${x + 90},0 ${x + 520 + Math.sin(t * 0.6 + i) * 30},1920 ${x - 200},1920`}
          fill="#fff"
          opacity={rayStrength * (0.6 + 0.4 * Math.sin(t + i))}
        />,
      );
    }
  }
  const pill = prog(local, 0.65, 1.25, Easing.out(Easing.back(1.6)));
  const noteP = prog(local, 1.0, 1.6);
  return (
    <AbsoluteFill style={{clipPath: `inset(${(1 - wipe) * 100}% 0 0 0)`}}>
      <AbsoluteFill style={{background: `linear-gradient(180deg, ${zone.c1}, ${zone.c2})`}} />
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        {rays}
        <Organism index={index} t={t} local={local} />
      </svg>
      <Particles count={28} seed={`z${index}`} color="#cfefff" speed={18} dir={-1} opacity={0.35} maxR={3} />
      <Txt y={250} size={38} weight={600} spacing={12} color="#bdeeff" opacity={prog(local, 0.2, 0.7)} width={920}>
        ZONA {index + 1} / 5
      </Txt>
      <div style={{position: "absolute", top: 300, left: 0, width: 920}}>
        <Letters text={zone.word} t={local} start={0.3} size={150} />
        <div style={{textAlign: "center", marginTop: -6}}>
          <Letters text="ZONE" t={local} start={0.65} size={54} color={C.cyan} />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          top: 640,
          left: 0,
          width: 920,
          display: "flex",
          justifyContent: "center",
          transform: `scale(${0.7 + 0.3 * pill})`,
          opacity: Math.min(1, pill),
        }}
      >
        <div
          style={{
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 62,
            color: "#04112b",
            background: C.cyan,
            padding: "10px 44px",
            borderRadius: 60,
            boxShadow: "0 0 40px rgba(34,211,238,0.55)",
          }}
        >
          {zone.range}
        </div>
      </div>
      <Txt y={1470} size={48} weight={600} width={920} opacity={noteP} dy={(1 - noteP) * 30} color="#e6f7ff">
        {zone.note}
      </Txt>
    </AbsoluteFill>
  );
};

export const Scene2: React.FC = () => {
  const t = useT();

  // Intro: lima zona (10.9 - 13.1 dtk)
  const introO = prog(t, 10.9, 11.3);
  const bars: React.ReactNode[] = ZONES.map((z, i) => {
    const p = prog(t, 11.3 + i * 0.28, 11.3 + i * 0.28 + 0.55, Easing.out(Easing.cubic));
    return (
      <div
        key={z.word}
        style={{
          position: "absolute",
          left: 100,
          top: 640 + i * 168,
          width: 880,
          height: 140,
          borderRadius: 26,
          background: `linear-gradient(90deg, ${z.c1}, ${z.c2})`,
          border: "2px solid rgba(255,255,255,0.25)",
          transform: `translateX(${(1 - p) * -900}px)`,
          opacity: p,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 44px",
          boxSizing: "border-box",
          fontFamily: FONT,
          color: "#fff",
        }}
      >
        <span style={{fontSize: 52, fontWeight: 800}}>{z.word} Zone</span>
        <span style={{fontSize: 40, fontWeight: 600, color: "#bdeeff"}}>{z.range}</span>
      </div>
    );
  });

  // Indikator kedalaman di kanan
  const gaugeO = prog(t, 13.0, 13.7);
  let idx = 0;
  for (let i = 1; i < ZONES.length; i++) {
    idx += prog(t, ZONES[i].t0, ZONES[i].t0 + 0.7, Easing.inOut(Easing.cubic));
  }
  const markerY = GAUGE_Y0 + idx * GAUGE_STEP;

  return (
    <AbsoluteFill style={{background: "#031a3a"}}>
      <AbsoluteFill style={{background: "linear-gradient(180deg,#0a4a86,#031a3a)", opacity: introO}} />
      <Particles count={40} seed="s2" color="#bfe9ff" speed={20} dir={-1} opacity={0.3} maxR={3} />
      <Txt y={250} size={120} weight={800} opacity={introO} dy={(1 - introO) * 40} lineHeight={1.05}>
        5 ZONA
      </Txt>
      <Txt y={400} size={64} weight={700} opacity={introO} color={C.cyan} spacing={4}>
        KEDALAMAN LAUT
      </Txt>
      {bars}

      {ZONES.map((z, i) => (
        <Panel key={z.word} zone={z} index={i} t={t} />
      ))}

      {/* Indikator kedalaman */}
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}} opacity={gaugeO}>
        <line x1={GAUGE_X} x2={GAUGE_X} y1={GAUGE_Y0} y2={GAUGE_Y0 + GAUGE_STEP * 4} stroke="#ffffff" strokeOpacity={0.35} strokeWidth={4} />
        {ZONES.map((z, i) => (
          <g key={z.word}>
            <line x1={GAUGE_X - 14} x2={GAUGE_X + 14} y1={GAUGE_Y0 + i * GAUGE_STEP} y2={GAUGE_Y0 + i * GAUGE_STEP} stroke="#ffffff" strokeOpacity={0.6} strokeWidth={4} />
            <text
              x={GAUGE_X - 26}
              y={GAUGE_Y0 + i * GAUGE_STEP + 11}
              textAnchor="end"
              fontFamily={FONT}
              fontWeight={600}
              fontSize={30}
              fill="#ffffff"
              fillOpacity={0.8}
            >
              {z.label}
            </text>
          </g>
        ))}
        <circle cx={GAUGE_X} cy={markerY} r={34} fill={C.cyan} opacity={0.25} />
        <circle cx={GAUGE_X} cy={markerY} r={16} fill={C.cyan} />
      </svg>
    </AbsoluteFill>
  );
};
