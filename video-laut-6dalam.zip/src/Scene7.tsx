import React from "react";
import {AbsoluteFill, Easing, random} from "remotion";
import {C, HEIGHT, WIDTH, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Particles, Txt} from "./common";
import {Angler, CombJelly, Snailfish} from "./creatures";
import {EarthGlobe} from "./Scene1";

const COLS = 10;
const CELL = 86;
const GAP = 8;
const GRID_W = COLS * CELL + (COLS - 1) * GAP;

// Urutan sel yang "terpetakan": 26 sel acak yang tetap (deterministik).
const order: number[] = Array.from({length: 100}, (_, i) => i).sort((a, b) => random(`m-${a}`) - random(`m-${b}`));
const rankOf: number[] = new Array<number>(100).fill(0);
order.forEach((cell, rank) => {
  rankOf[cell] = rank;
});

const WORDS = [
  {w: "Laut", t0: 83.7},
  {w: "dalam", t0: 84.35},
  {w: "masih", t0: 85.0},
  {w: "menyimpan", t0: 85.65},
  {w: "misteri.", t0: 86.5},
];

export const Scene7: React.FC = () => {
  const t = useT();

  const gridIn = prog(t, 78.0, 78.5);
  const gridOut = 1 - prog(t, 83.1, 83.7);
  const lit = 26 * prog(t, 78.5, 81.8, Easing.inOut(Easing.cubic));
  const pct = 26 * prog(t, 78.5, 81.8, Easing.inOut(Easing.cubic));

  const cells: React.ReactNode[] = [];
  for (let i = 0; i < 100; i++) {
    const col = i % COLS;
    const row = Math.floor(i / COLS);
    const on = prog(lit, rankOf[i], rankOf[i] + 1, Easing.out(Easing.quad));
    const mapped = rankOf[i] < 26;
    cells.push(
      <rect
        key={i}
        x={col * (CELL + GAP)}
        y={row * (CELL + GAP)}
        width={CELL}
        height={CELL}
        rx={14}
        fill={mapped && on > 0 ? C.cyan : "#0d2a52"}
        opacity={mapped && on > 0 ? 0.35 + 0.65 * on : 0.55}
      />,
    );
  }

  // Penutup
  const closeP = prog(t, 83.2, 84.0);
  const shrink = prog(t, 83.2, 90, Easing.inOut(Easing.quad));
  const earthR = 220 - 70 * shrink;
  const fadeOut = prog(t, 89.1, 90);
  const srcP = prog(t, 87.8, 88.5);

  return (
    <AbsoluteFill style={{background: "linear-gradient(180deg,#04112b,#01040d)"}}>
      <Particles count={45} seed="s7" color="#9be7ff" speed={12} dir={-1} opacity={0.4} maxR={3} sway={28} />

      {/* Infografis 26% */}
      <AbsoluteFill style={{opacity: gridIn * gridOut}}>
        <Txt y={165} size={38} weight={600} spacing={8} color="#bdeeff">
          HINGGA JUNI 2024
        </Txt>
        <Txt y={215} size={210} weight={800} color={C.cyan}>
          {Math.round(pct)}%
        </Txt>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <g transform={`translate(${(WIDTH - GRID_W) / 2} 520)`}>{cells}</g>
        </svg>
        <Txt y={1468} size={44} weight={700} width={920} x={80} color="#ffffff">
          dasar laut dunia terpetakan
        </Txt>
        <Txt y={1524} size={44} weight={700} width={920} x={80} color="#ffffff">
          dengan resolusi tinggi
        </Txt>
      </AbsoluteFill>

      {/* Penutup */}
      <AbsoluteFill style={{opacity: closeP}}>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <g opacity={0.28}>
            <g transform="translate(180 1500) scale(0.38)">
              <Snailfish t={t} glow={0.5} />
            </g>
            <g transform="translate(880 1180) scale(0.4)">
              <CombJelly t={t} />
            </g>
            <g transform="translate(860 1650) scale(0.34)">
              <Angler t={t} glow={0.8} />
            </g>
          </g>
          <EarthGlobe cx={540} cy={430 - 20 * shrink} r={earthR} idp="e7" glow={0.8} />
        </svg>
        {WORDS.map((w, i) => {
          const p = prog(t, w.t0, w.t0 + 0.5, Easing.out(Easing.back(1.5)));
          const last = i === WORDS.length - 1;
          return (
            <div
              key={w.w}
              style={{
                position: "absolute",
                top: 760 + i * 150,
                left: 0,
                width: WIDTH,
                textAlign: "center",
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: last ? 150 : 128,
                color: last ? C.cyan : "#ffffff",
                opacity: Math.min(1, p * 1.4),
                transform: `translateY(${(1 - p) * 60}px) scale(${0.85 + 0.15 * p})`,
                textShadow: last ? "0 0 50px rgba(34,211,238,0.75)" : "0 4px 24px rgba(0,0,0,0.5)",
                lineHeight: 1.1,
              }}
            >
              {w.w}
            </div>
          );
        })}
        <Txt y={1570} size={30} weight={400} color="#8fb8d6" opacity={srcP}>
          Sumber: NOAA Ocean Exploration · MBARI
        </Txt>
      </AbsoluteFill>

      <AbsoluteFill style={{background: "#000", opacity: fadeOut}} />
    </AbsoluteFill>
  );
};
