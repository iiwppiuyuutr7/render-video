import React from "react";
import {AbsoluteFill, Easing, interpolateColors} from "remotion";
import {C, HEIGHT, WIDTH, fmt, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Particles, Txt} from "./common";

export const EarthGlobe: React.FC<{cx: number; cy: number; r: number; idp?: string; glow?: number}> = ({
  cx,
  cy,
  r,
  idp = "earth",
  glow = 1,
}) => (
  <g transform={`translate(${cx} ${cy}) scale(${r})`}>
    <defs>
      <clipPath id={`${idp}-clip`}>
        <circle r={1} />
      </clipPath>
      <radialGradient id={`${idp}-sea`} cx="0.35" cy="0.3" r="0.9">
        <stop offset="0" stopColor="#3db5f0" />
        <stop offset="0.6" stopColor="#0f6fb8" />
        <stop offset="1" stopColor="#063a78" />
      </radialGradient>
      <radialGradient id={`${idp}-shade`} cx="0.35" cy="0.3" r="0.95">
        <stop offset="0.55" stopColor="#000" stopOpacity={0} />
        <stop offset="1" stopColor="#000" stopOpacity={0.55} />
      </radialGradient>
    </defs>
    <circle r={1.1} fill="#22d3ee" opacity={0.1 * glow} />
    <circle r={1.05} fill="#22d3ee" opacity={0.12 * glow} />
    <circle r={1} fill={`url(#${idp}-sea)`} />
    <g clipPath={`url(#${idp}-clip)`}>
      <path
        d="M-1.05 -0.25 C-0.85 -0.55 -0.55 -0.6 -0.42 -0.32 C-0.36 -0.1 -0.58 0.08 -0.52 0.3 C-0.46 0.52 -0.8 0.56 -1.0 0.34 Z"
        fill="#34d399"
        opacity={0.9}
      />
      <path
        d="M-0.7 0.62 C-0.55 0.55 -0.35 0.62 -0.3 0.76 C-0.4 0.9 -0.65 0.85 -0.7 0.62 Z"
        fill="#34d399"
        opacity={0.9}
      />
      <path
        d="M1.05 -0.6 C0.8 -0.7 0.52 -0.5 0.58 -0.14 C0.64 0.2 0.84 0.28 0.78 0.62 C0.72 0.86 0.96 0.8 1.05 0.5 Z"
        fill="#34d399"
        opacity={0.9}
      />
      <path d="M-0.2 -0.9 C0 -0.82 0.25 -0.86 0.4 -0.95 L0.4 -1.1 L-0.2 -1.1 Z" fill="#e8f7ff" opacity={0.85} />
      <path d="M-0.5 0.2 C-0.3 0.1 -0.1 0.2 0.1 0.12" stroke="#fff" strokeWidth={0.015} fill="none" opacity={0.3} />
      <path d="M0.1 -0.3 C0.3 -0.38 0.5 -0.3 0.62 -0.4" stroke="#fff" strokeWidth={0.015} fill="none" opacity={0.3} />
    </g>
    <circle r={1} fill={`url(#${idp}-shade)`} />
  </g>
);

const wavePath = (base: number, amp: number, phase: number, k: number): string => {
  let d = "";
  for (let x = 0; x <= WIDTH + 20; x += 20) {
    const y = base + amp * Math.sin(x / 90 + phase + k) + amp * 0.5 * Math.sin(x / 40 - phase * 1.3);
    d += `${x === 0 ? "M" : "L"}${x} ${y.toFixed(1)} `;
  }
  return d;
};

export const Scene1: React.FC = () => {
  const t = useT();

  // Fase A: Bumi (0 - 3.8 dtk)
  const spaceO = 1 - prog(t, 2.9, 3.8);
  const earthIn = prog(t, 0, 1.0);
  const zoom = 1 + 8 * prog(t, 1.9, 3.8, Easing.in(Easing.cubic));
  const ringO = 1 - prog(t, 2.2, 2.9);
  const ringP = prog(t, 0.3, 2.3, Easing.inOut(Easing.cubic));
  const pct = 71 * prog(t, 0.3, 2.3, Easing.inOut(Easing.cubic));
  const circ = 2 * Math.PI * 400;
  const earthCx = 540;
  const earthCy = 900;

  // Fase B: menyelam (3.2 - 10.9 dtk)
  const waterO = prog(t, 2.9, 3.8);
  const depthF = prog(t, 3.2, 10.6, Easing.inOut(Easing.quad));
  const top = interpolateColors(depthF, [0, 0.35, 1], ["#49c6f2", "#0b5c9e", "#020a1f"]);
  const bot = interpolateColors(depthF, [0, 0.35, 1], ["#1d8fd0", "#06336a", "#04112b"]);
  const dive = prog(t, 3.3, 5.2, Easing.in(Easing.quad));
  const dy = 1000 * dive;
  const rayO = prog(t, 3.8, 4.6) * (1 - prog(t, 7.3, 10.4));
  const depthVal = 3682 * prog(t, 3.3, 7.0, Easing.inOut(Easing.cubic));
  const numPulse = 1 + 0.03 * Math.sin(t * 3) * prog(t, 7.0, 7.4);
  const lightBar = 1 - prog(t, 7.4, 10.5, Easing.inOut(Easing.cubic));
  const barO = prog(t, 7.2, 7.8) * (1 - prog(t, 10.5, 10.9));

  // Sinar cahaya
  const rays: React.ReactNode[] = [];
  for (let i = 0; i < 7; i++) {
    const x = -100 + i * 190;
    const w = 70 + (i % 3) * 30;
    const sway = Math.sin(t * 0.7 + i) * 40;
    rays.push(
      <polygon
        key={i}
        points={`${x},0 ${x + w},0 ${x + w * 2.6 + sway},1500 ${x - w * 0.8 + sway},1500`}
        fill="#ffffff"
        opacity={0.13 * (0.6 + 0.4 * Math.sin(t * 0.9 + i * 1.7))}
      />,
    );
  }

  // Indikator kedalaman di sisi kanan
  const ticks: React.ReactNode[] = [];
  const off = depthF * 4200;
  for (let i = 0; i < 24; i++) {
    const y = ((((i * 100 - off) % 2400) + 2400) % 2400) - 240;
    const long = i % 5 === 0;
    ticks.push(
      <line key={i} x1={1080 - (long ? 70 : 40)} x2={1080} y1={y} y2={y} stroke="#ffffff" strokeWidth={long ? 4 : 2} opacity={0.4} />,
    );
  }

  return (
    <AbsoluteFill style={{background: C.space}}>
      {/* Ruang angkasa + Bumi */}
      <AbsoluteFill style={{opacity: spaceO}}>
        <Particles count={90} seed="stars" color="#ffffff" speed={0} opacity={0.8} maxR={1.6} sway={0} />
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <g
            opacity={earthIn}
            transform={`translate(${earthCx} ${earthCy}) scale(${(0.8 + 0.2 * earthIn) * zoom}) translate(${-earthCx} ${-earthCy})`}
          >
            <EarthGlobe cx={earthCx} cy={earthCy} r={330} idp="e1" />
          </g>
          <g opacity={ringO * earthIn}>
            <circle cx={earthCx} cy={earthCy} r={400} fill="none" stroke="#ffffff" strokeOpacity={0.12} strokeWidth={14} />
            <circle
              cx={earthCx}
              cy={earthCy}
              r={400}
              fill="none"
              stroke={C.cyan}
              strokeWidth={14}
              strokeLinecap="round"
              strokeDasharray={`${circ * 0.71 * ringP} ${circ}`}
              transform={`rotate(-90 ${earthCx} ${earthCy})`}
            />
          </g>
        </svg>
        <Txt y={210} size={62} weight={800} opacity={prog(t, 0.2, 1.0) * ringO} spacing={2} lineHeight={1.2}>
          MISTERI KEHIDUPAN
          <br />
          <span style={{color: C.cyan}}>DI LAUT TERDALAM</span>
        </Txt>
        <Txt y={1320} size={200} weight={800} color={C.cyan} opacity={ringO * prog(t, 0.3, 0.9)}>
          {Math.round(pct)}%
        </Txt>
        <Txt y={1535} size={44} weight={600} opacity={ringO * prog(t, 0.8, 1.5)} color={C.white}>
          permukaan Bumi tertutup lautan
        </Txt>
      </AbsoluteFill>

      {/* Air laut */}
      <AbsoluteFill style={{opacity: waterO}}>
        <AbsoluteFill style={{background: `linear-gradient(180deg, ${top}, ${bot})`}} />
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <g opacity={rayO}>{rays}</g>
          <g transform={`translate(0 ${-dy})`}>
            <path
              d={`${wavePath(760, 18, t * 2, 0)} L${WIDTH} -1400 L0 -1400 Z`}
              fill="#d3f0ff"
              opacity={0.95}
            />
            <path d={wavePath(780, 14, t * 2.4, 1.5)} stroke="#ffffff" strokeWidth={5} fill="none" opacity={0.55} />
            <path d={wavePath(810, 12, t * 1.8, 3)} stroke="#ffffff" strokeWidth={4} fill="none" opacity={0.3} />
          </g>
          {ticks}
        </svg>
        <Particles count={45} seed="bub" color="#ffffff" speed={55} dir={-1} opacity={0.4} maxR={5} sway={26} />

        <Txt y={600} size={42} weight={600} spacing={10} color="#bdeeff" opacity={prog(t, 3.2, 3.9)}>
          KEDALAMAN RATA-RATA
        </Txt>
        <div
          style={{
            position: "absolute",
            top: 660,
            left: 0,
            width: WIDTH,
            textAlign: "center",
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 230,
            color: "#ffffff",
            opacity: prog(t, 3.2, 3.9),
            transform: `scale(${numPulse})`,
            textShadow: "0 6px 30px rgba(0,0,0,0.4)",
            lineHeight: 1.1,
          }}
        >
          {fmt(depthVal)}
          <span style={{fontSize: 100, fontWeight: 600, marginLeft: 16, color: C.cyan}}>m</span>
        </div>

        {/* Meter cahaya Matahari */}
        <div style={{position: "absolute", left: 150, top: 1290, width: 780, opacity: barO}}>
          <div
            style={{
              fontFamily: FONT,
              fontSize: 38,
              fontWeight: 600,
              letterSpacing: 6,
              color: "#ffe9a8",
              marginBottom: 22,
            }}
          >
            CAHAYA MATAHARI
          </div>
          <div style={{height: 34, borderRadius: 17, background: "rgba(255,255,255,0.15)", overflow: "hidden"}}>
            <div
              style={{
                width: `${lightBar * 100}%`,
                height: "100%",
                borderRadius: 17,
                background: "linear-gradient(90deg,#fde68a,#fbbf24)",
                boxShadow: "0 0 24px #fbbf24",
              }}
            />
          </div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
