import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, delayRender, continueRender} from 'remotion';

/* =====================================================================
   GEDUNG – animasi edukasi, 9:16 • 1080x1920 • 60 fps • 93.39 detik
   Gaya: motion graphics minimalis, gelap, satu warna aksen.
   Watermark @semestakita (kiri bawah). Audio: public/audio.mp3
   Font: Inter (public/fonts/*.otf)
   ===================================================================== */
export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_SECONDS = 93.39;

// waktu mulai tiap adegan (detik) – selaras dengan jeda narasi
const SCENES = [0, 11.89, 26.52, 34.12, 48.36, 55.32, 69.38, 78.56, 83.24, 87.2, TOTAL_SECONDS];

const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const sm = (p: number) => { const x = clamp(p); return x * x * (3 - 2 * x); };
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const ap = (t: number, a: number, d = 0.6) => sm(prog(t, a, a + d));
const TAU = Math.PI * 2;
const swy = (t: number, a: number, f = 0.32, ph = 0) => a * Math.sin(TAU * f * t + ph);

const C = {
  bg: '#0d0e12', surf: '#171a21', text: '#f4f1ea', muted: '#8d93a3', line: 'rgba(255,255,255,0.14)', accent: '#ff5b2e',
};
const HEAD = "'InterHead','Inter Display','Inter',-apple-system,'Helvetica Neue',Arial,sans-serif";
const BODY = "'InterBody','Inter',-apple-system,'Helvetica Neue',Arial,sans-serif";
const M = 80; // margin kiri

// ---------- teks ----------
const Head: React.FC<{t: number; a?: number; lines: string[]; size?: number; y?: number; color?: string}> = ({t, a = 0.2, lines, size = 100, y = 330, color = C.text}) => (
  <g>
    {lines.map((l, i) => {
      const p = ap(t, a + i * 0.14, 0.8);
      return <text key={i} x={M} y={y + i * size * 1.06 + (1 - p) * 50} opacity={p} fontFamily={HEAD} fontWeight={800} fontSize={size} letterSpacing={-size * 0.035} fill={color}>{l}</text>;
    })}
  </g>
);
const Kick: React.FC<{t: number; num?: string; label: string}> = ({t, num, label}) => {
  const p = ap(t, 0, 0.6);
  return (
    <g opacity={p} fontFamily={BODY} fontWeight={500} fontSize={28} letterSpacing={5}>
      <rect x={M} y={150} width={44} height={5} fill={C.accent} />
      <text x={M} y={205} fill={C.accent}>{num ? num + '  ' : ''}<tspan fill={C.muted}>{label.toUpperCase()}</tspan></text>
    </g>
  );
};
const Body: React.FC<{x?: number; y: number; lines: string[]; size?: number; fill?: string; p?: number; anchor?: 'start' | 'end' | 'middle'; w?: number; ls?: number}> = ({x = M, y, lines, size = 40, fill = C.muted, p = 1, anchor = 'start', w = 500, ls = 0}) => (
  <g opacity={p} transform={`translate(0 ${(1 - p) * 24})`}>
    {lines.map((l, i) => <text key={i} x={x} y={y + i * size * 1.35} fontFamily={w >= 700 ? HEAD : BODY} fontWeight={w >= 700 ? 800 : 500} fontSize={size} fill={fill} textAnchor={anchor} letterSpacing={ls || (w >= 700 ? -size * 0.025 : 0)}>{l}</text>)}
  </g>
);

const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; color?: string; w?: number; op?: number}> = ({x1, y1, x2, y2, color = C.text, w = 8, op = 1}) => {
  const a = Math.atan2(y2 - y1, x2 - x1), hs = w * 3;
  return (
    <g opacity={op} stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" fill="none">
      <line x1={x1} y1={y1} x2={x2} y2={y2} />
      <path d={`M${x2 - Math.cos(a - 0.6) * hs} ${y2 - Math.sin(a - 0.6) * hs} L${x2} ${y2} L${x2 - Math.cos(a + 0.6) * hs} ${y2 - Math.sin(a + 0.6) * hs}`} />
    </g>
  );
};

const Check: React.FC<{x: number; y: number; r?: number; p?: number; color?: string}> = ({x, y, r = 36, p = 1, color = C.accent}) => (
  <g opacity={p} transform={`translate(${x} ${y}) scale(${lerp(0.6, 1, p)})`}>
    <circle r={r} fill={color} />
    <path d={`M${-r * 0.42} ${r * 0.02} L${-r * 0.1} ${r * 0.34} L${r * 0.46} ${-r * 0.32}`} fill="none" stroke={C.bg} strokeWidth={r * 0.2} strokeLinecap="round" strokeLinejoin="round" />
  </g>
);

// ---------- latar ----------
const GROUND = 1480;
const Background: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={WIDTH} height={HEIGHT} fill={C.bg} />
    <rect width={WIDTH} height={HEIGHT} fill="url(#glow)" />
    <rect x={0} y={0} width={WIDTH * (t / TOTAL_SECONDS)} height={6} fill={C.accent} />
  </g>
);

// ---------- gedung (melentur: simpangan ~ tinggi^2) ----------
const offAt = (i: number, n: number, amp: number) => amp * Math.pow(i / n, 2);

const Building: React.FC<{cx: number; base?: number; w: number; h: number; amp: number; n?: number; ghost?: boolean; color?: string; cap?: boolean; sw?: number}> =
  ({cx, base = GROUND, w, h, amp, n = 20, ghost = false, color = C.accent, cap = true, sw = 3}) => {
    const dy = h / n;
    const L: string[] = [], R: string[] = [];
    for (let i = 0; i <= n; i++) { const y = base - i * dy, o = offAt(i, n, amp); L.push(`${cx - w / 2 + o},${y}`); R.push(`${cx + w / 2 + o},${y}`); }
    if (ghost) return <polygon points={[...L, ...[...R].reverse()].join(' ')} fill="none" stroke={color} strokeWidth={sw} strokeDasharray="14 14" strokeLinejoin="round" opacity={0.8} />;
    const body = [...L, ...[...R].reverse()].join(' ');
    const topL = L.slice(n - 2), topR = R.slice(n - 2);
    const capPts = [...topL, ...[...topR].reverse()].join(' ');
    return (
      <g>
        <polygon points={body} fill="url(#bld)" />
        {Array.from({length: n - 1}, (_, k) => { const i = k + 1, y = base - i * dy, o = offAt(i, n, amp); return <line key={k} x1={cx - w / 2 + o} y1={y} x2={cx + w / 2 + o} y2={y} stroke="#fff" strokeOpacity={0.07} strokeWidth={2} />; })}
        {[1, 2, 3].map(c => {
          const pts = Array.from({length: n + 1}, (_, i) => `${cx - w / 2 + (w * c) / 4 + offAt(i, n, amp)},${base - i * dy}`);
          return <polyline key={c} points={pts.join(' ')} fill="none" stroke="#fff" strokeOpacity={0.09} strokeWidth={2} />;
        })}
        {cap && <polygon points={capPts} fill={C.accent} />}
        <line x1={cx + amp} y1={base - h} x2={cx + amp * 1.05} y2={base - h - 110} stroke={C.text} strokeOpacity={0.7} strokeWidth={5} strokeLinecap="round" />
      </g>
    );
  };

const GroundLine: React.FC<{op?: number}> = ({op = 1}) => <line x1={0} y1={GROUND} x2={WIDTH} y2={GROUND} stroke="#fff" strokeOpacity={0.28 * op} strokeWidth={3} />;

// grafik simpangan puncak (jendela 5 detik)
const Trace: React.FC<{t: number; x: number; y: number; w: number; h: number; fn: (tt: number) => number; max: number; p: number; label: string}> = ({t, x, y, w, h, fn, max, p, label}) => {
  const win = 5, N = 120, pts: string[] = [];
  for (let i = 0; i <= N; i++) { const tt = t - win + (win * i) / N; pts.push(`${x + (w * i) / N},${y + h / 2 - (fn(tt) / max) * (h / 2)}`); }
  const cur = fn(t);
  return (
    <g opacity={p}>
      <text x={x} y={y - 26} fontFamily={BODY} fontWeight={500} fontSize={26} letterSpacing={4} fill={C.muted}>{label.toUpperCase()}</text>
      <line x1={x} y1={y + h / 2} x2={x + w} y2={y + h / 2} stroke="#fff" strokeOpacity={0.2} strokeWidth={2} strokeDasharray="6 8" />
      <polyline points={pts.join(' ')} fill="none" stroke={C.accent} strokeWidth={5} strokeLinejoin="round" strokeLinecap="round" />
      <circle cx={x + w} cy={y + h / 2 - (cur / max) * (h / 2)} r={11} fill={C.accent} />
    </g>
  );
};

// ---------- ADEGAN ----------
const BX = 540, BW = 230, BH = 820;

const S1: React.FC<{t: number}> = ({t}) => {
  const fn = (tt: number) => swy(tt, 80 * sm(prog(tt, 0, 2.5)));
  const am = fn(t);
  return (
    <g>
      <Kick t={t} label="Sains · Rekayasa" />
      <Head t={t} lines={['Mengapa gedung', 'tinggi bisa', 'bergoyang?']} size={112} y={340} />
      <Body y={720} lines={['Tanpa mengalami kerusakan.']} size={42} p={ap(t, 2)} />
      <GroundLine />
      <Building cx={BX + 250} base={GROUND} w={BW} h={BH - 120} amp={am} />
      <Trace t={t} x={M} y={1580} w={920} h={140} fn={fn} max={90} p={ap(t, 5.5)} label="Simpangan puncak gedung" />
    </g>
  );
};

const S2: React.FC<{t: number}> = ({t}) => {
  const A = 80, am = swy(t, A * ap(t, 0, 1.5));
  const cx = 650, top = GROUND - BH;
  return (
    <g>
      <Kick t={t} num="01" label="Dirancang begitu" />
      <Head t={t} lines={['Goyangan itu', 'sudah dihitung.']} size={96} y={330} />
      <GroundLine />
      <g opacity={ap(t, 1.5, 1)}>
        <Building cx={cx} w={BW} h={BH} amp={A} ghost />
        <Building cx={cx} w={BW} h={BH} amp={-A} ghost />
        <text x={cx + A + BW / 2 + 22} y={top + 8} fontFamily={BODY} fontWeight={500} fontSize={26} letterSpacing={3} fill={C.accent}>BATAS</text>
        <text x={cx - A - BW / 2 - 22} y={top + 8} fontFamily={BODY} fontWeight={500} fontSize={26} letterSpacing={3} fill={C.accent} textAnchor="end">BATAS</text>
      </g>
      <Building cx={cx} w={BW} h={BH} amp={am} />
      <Check x={M + 36} y={1640} p={ap(t, 6.5)} />
      <Body x={M + 100} y={1655} lines={['Bergoyang bukan berarti runtuh.']} size={46} fill={C.text} w={800} p={ap(t, 6.5)} />
      <Body y={1730} x={M + 100} lines={['Gerak terkendali = bagian dari keselamatan.']} size={32} p={ap(t, 9)} />
    </g>
  );
};

const S3: React.FC<{t: number}> = ({t}) => {
  const quake = ap(t, 2.4, 0.5);
  const am = swy(t, 55 * ap(t, 0, 1)) + swy(t, 9, 3.2) * quake;
  const cx = 760, base = GROUND, h = 760;
  const items = ['Angin', 'Getaran gempa', 'Pusaran udara'];
  const times = [0.5, 2.4, 4.3];
  const spiral = (r0: number, ph: number) => { let d = ''; for (let k = 0; k < 70; k++) { const a = k * 0.33 + ph, r = r0 + k * 2.6; d += `${k ? 'L' : 'M'}${cx + 170 + Math.cos(a) * r} ${base - h + 120 + Math.sin(a) * r * 0.7} `; } return d; };
  return (
    <g>
      <Kick t={t} num="02" label="Penyebab" />
      <Head t={t} lines={['Tiga sumber gaya.']} size={96} y={330} />
      {items.map((s, i) => {
        const p = ap(t, times[i]);
        return (
          <g key={i} opacity={p} transform={`translate(${(1 - p) * -40} 0)`}>
            <line x1={M} y1={470 + i * 110 - 56} x2={M + 420} y2={470 + i * 110 - 56} stroke="#fff" strokeOpacity={0.14} strokeWidth={2} />
            <text x={M} y={470 + i * 110} fontFamily={BODY} fontWeight={500} fontSize={28} fill={C.accent} letterSpacing={4}>0{i + 1}</text>
            <text x={M + 80} y={470 + i * 110} fontFamily={HEAD} fontWeight={800} fontSize={44} fill={C.text} letterSpacing={-1}>{s}</text>
          </g>
        );
      })}
      <GroundLine />
      <g opacity={ap(t, 0.4)}>
        {Array.from({length: 6}, (_, i) => {
          const f = i / 5, y = base - 110 - f * (h - 200), len = 70 + 260 * f, pulse = Math.sin(t * 5 + i) * 10, xe = cx - BW / 2 - 30 + offAt(f * 20 + 1, 20, am);
          return <Arrow key={i} x1={xe - len - pulse} y1={y} x2={xe} y2={y} color={f > 0.7 ? C.accent : C.text} w={6} op={0.45 + 0.55 * f} />;
        })}
      </g>
      <g opacity={quake} stroke={C.accent} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round">
        {[0, 1].map(i => <path key={i} d={`M${60 + i * 30} ${GROUND + 50 + i * 36} l30 -16 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 32 l30 -32 l30 16`} transform={`translate(${swy(t, 12, 3, i)} 0)`} />)}
      </g>
      <g opacity={ap(t, 4.3)} stroke={C.text} strokeOpacity={0.7} strokeWidth={4} fill="none" strokeLinecap="round" strokeDasharray="26 16" strokeDashoffset={-t * 120}>
        <path d={spiral(8, t * 3)} /><path d={spiral(34, t * 3 + 2)} strokeOpacity={0.4} />
      </g>
      <Building cx={cx} base={base} w={BW} h={h} amp={am} />
      <Body y={1690} lines={['Makin tinggi, angin makin kuat.']} size={50} fill={C.text} w={800} p={ap(t, 5.5)} />
    </g>
  );
};

const Row: React.FC<{y: number; title: string; sub: string; p: number; icon: React.ReactNode}> = ({y, title, sub, p, icon}) => (
  <g opacity={p} transform={`translate(${(1 - p) * -50} 0)`}>
    <line x1={M} y1={y} x2={WIDTH - M} y2={y} stroke="#fff" strokeOpacity={0.14} strokeWidth={2} />
    <g transform={`translate(${M + 70} ${y + 100})`}>{icon}</g>
    <text x={M + 220} y={y + 98} fontFamily={HEAD} fontWeight={800} fontSize={62} fill={C.text} letterSpacing={-2}>{title}</text>
    <text x={M + 220} y={y + 148} fontFamily={BODY} fontWeight={500} fontSize={34} fill={C.muted}>{sub}</text>
  </g>
);

const S4: React.FC<{t: number}> = ({t}) => {
  const k = Math.sin(t * 4);
  const bot = 52 + k * 14;
  let sp = `M0 -52`; for (let i = 1; i <= 7; i++) sp += ` L${i % 2 ? 30 : -30} ${-52 + (bot + 52) * (i / 8)}`; sp += ` L0 ${bot}`;
  const sx = t > 8 ? 540 + 340 * Math.exp(-0.55 * (t - 8)) * Math.cos(2.4 * (t - 8)) : 540;
  const st = {fill: 'none', stroke: C.text, strokeWidth: 6, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
  return (
    <g>
      <Kick t={t} num="03" label="Keseimbangan" />
      <Head t={t} lines={['Tiga hal yang', 'diseimbangkan.']} size={96} y={330} />
      <Row y={600} title="Kekakuan" sub="menahan perubahan bentuk" p={ap(t, 0.8)} icon={<path d={sp} {...st} stroke={C.accent} />} />
      <Row y={840} title="Massa" sub="memengaruhi respons gerakan" p={ap(t, 3.2)} icon={<g transform={`translate(0 ${k * 5})`}><path d="M-48 48 L-32 -22 H32 L48 48 Z" {...st} /><path d="M-14 -22 v-14 a14 14 0 0 1 28 0 v14" {...st} stroke={C.accent} /></g>} />
      <Row y={1080} title="Peredaman" sub="mengurangi getaran" p={ap(t, 5.6)} icon={<g><rect x={-24} y={-52} width={48} height={58} rx={6} {...st} /><line x1={0} y1={6 + k * 12} x2={0} y2={52 + k * 12} {...st} stroke={C.accent} /><line x1={-26} y1={52 + k * 12} x2={26} y2={52 + k * 12} {...st} stroke={C.accent} /></g>} />
      <g opacity={ap(t, 8)}>
        <line x1={M} y1={1420} x2={WIDTH - M} y2={1420} stroke="#fff" strokeOpacity={0.25} strokeWidth={6} strokeLinecap="round" />
        <line x1={380} y1={1420} x2={700} y2={1420} stroke={C.accent} strokeWidth={10} strokeLinecap="round" />
        <circle cx={sx} cy={1420} r={24} fill={C.text} />
        <text x={M} y={1500} fontFamily={HEAD} fontWeight={800} fontSize={38} fill={C.text} letterSpacing={-1}>Terlalu kaku</text>
        <text x={M} y={1544} fontFamily={BODY} fontWeight={500} fontSize={28} fill={C.muted}>desain tidak efisien</text>
        <text x={WIDTH - M} y={1500} fontFamily={HEAD} fontWeight={800} fontSize={38} fill={C.text} letterSpacing={-1} textAnchor="end">Terlalu fleksibel</text>
        <text x={WIDTH - M} y={1544} fontFamily={BODY} fontWeight={500} fontSize={28} fill={C.muted} textAnchor="end">tidak nyaman</text>
      </g>
      <Check x={M + 36} y={1700} p={ap(t, 11)} />
      <Body x={M + 100} y={1716} lines={['Seimbang: aman dan nyaman.']} size={46} fill={C.text} w={800} p={ap(t, 11)} />
    </g>
  );
};

const S5: React.FC<{t: number}> = ({t}) => {
  const f = 0.4, am = swy(t, 80, f), n = 20, w2 = 320, h2 = 900, base = GROUND, top = base - h2, fl = h2 / n;
  const o = (i: number) => offAt(i, n, am);
  const anchorX = BX + o(n - 0.4), anchorY = top + fl * 0.4 + 24, L = 150;
  const th = -0.5 * Math.sin(TAU * f * t - 0.15);
  const bx = anchorX + Math.sin(th) * L, by = anchorY + Math.cos(th) * L;
  const dir = Math.cos(TAU * f * t) >= 0 ? 1 : -1;
  const pl = [`${BX - w2 / 2 + o(n - 3) + 14},${top + fl * 3}`, `${BX + w2 / 2 + o(n - 3) - 14},${top + fl * 3}`, `${BX + w2 / 2 + o(n - 0.2) - 14},${top + fl * 0.2}`, `${BX - w2 / 2 + o(n - 0.2) + 14},${top + fl * 0.2}`].join(' ');
  return (
    <g>
      <Kick t={t} num="04" label="Solusi" />
      <Head t={t} lines={['Tuned Mass', 'Damper.']} size={110} y={340} />
      <GroundLine />
      <Building cx={BX} w={w2} h={h2} amp={am} cap={false} />
      <polygon points={pl} fill={C.bg} stroke={C.accent} strokeWidth={3} opacity={ap(t, 0.5, 0.8)} />
      <g opacity={ap(t, 0.8, 0.8)}>
        <rect x={anchorX - 56} y={anchorY - 12} width={112} height={12} rx={4} fill={C.muted} />
        <line x1={anchorX} y1={anchorY} x2={bx} y2={by} stroke={C.text} strokeWidth={4} />
        <circle cx={bx} cy={by} r={42} fill={C.accent} />
      </g>
      <g opacity={ap(t, 3)}>
        <text x={WIDTH - M} y={880} fontFamily={BODY} fontWeight={500} fontSize={28} letterSpacing={4} fill={C.muted} textAnchor="end">GEDUNG</text>
        <Arrow x1={WIDTH - M - 150 - dir * 55} y1={940} x2={WIDTH - M - 150 + dir * 55} y2={940} color={C.text} w={9} />
        <text x={WIDTH - M} y={1080} fontFamily={BODY} fontWeight={500} fontSize={28} letterSpacing={4} fill={C.accent} textAnchor="end">MASSA</text>
        <Arrow x1={WIDTH - M - 150 + dir * 55} y1={1140} x2={WIDTH - M - 150 - dir * 55} y2={1140} color={C.accent} w={9} />
      </g>
      <Body y={1690} lines={['Massa tambahan yang bergerak', 'melawan arah ayunan gedung.']} size={44} fill={C.text} w={800} p={ap(t, 4)} />
    </g>
  );
};

const S6: React.FC<{t: number}> = ({t}) => {
  const f = 0.4, am = swy(t, 80, f), cx = 250, base = GROUND;
  const off = (y: number) => am * Math.pow((base - y) / 1000, 2);
  const tiers: React.ReactNode[] = [];
  for (let i = 0; i < 8; i++) {
    const yb = base - 120 - i * 100, yt = yb - 100, b = 230 - 12 * i, tp = b * 1.2;
    tiers.push(<polygon key={i} points={`${cx - b / 2 + off(yb)},${yb - 3} ${cx + b / 2 + off(yb)},${yb - 3} ${cx + tp / 2 + off(yt)},${yt} ${cx - tp / 2 + off(yt)},${yt}`} fill="url(#bld)" stroke="#fff" strokeOpacity={0.12} strokeWidth={2} />);
  }
  const ys = base - 120 - 5.5 * 100;
  const th = -0.5 * Math.sin(TAU * f * t - 0.15);
  const ccx = 735, ccy = 760, R = 285;
  const ceilX = ccx + 70 * Math.sin(TAU * f * t), ceilY = ccy - 190;
  const bx = ceilX + Math.sin(th) * 220, by = ceilY + Math.cos(th) * 220;
  const dir = Math.cos(TAU * f * t) >= 0 ? 1 : -1;
  const sx = cx + off(ys) + Math.sin(th) * 26, sy = ys + 6;
  return (
    <g>
      <Kick t={t} num="05" label="Contoh nyata" />
      <Head t={t} lines={['Taipei 101']} size={132} y={350} />
      <Body y={420} lines={['Taiwan']} size={42} p={ap(t, 0.8)} />
      <GroundLine />
      <rect x={cx - 140 + off(base)} y={base - 120} width={280} height={120} fill={C.surf} />
      {tiers}
      <line x1={cx + off(base - 920)} y1={base - 920} x2={cx + off(base - 1050)} y2={base - 1050} stroke={C.text} strokeOpacity={0.7} strokeWidth={6} strokeLinecap="round" />
      <circle cx={sx} cy={sy} r={26} fill={C.accent} />
      <g opacity={ap(t, 1.2, 0.8)}>
        <line x1={sx + 26} y1={sy - 14} x2={ccx - R + 6} y2={ccy + 90} stroke={C.accent} strokeWidth={3} strokeDasharray="10 10" />
        <defs>
          <clipPath id="bub"><circle cx={ccx} cy={ccy} r={R} /></clipPath>
          <radialGradient id="ball" cx="0.35" cy="0.3" r="0.85"><stop offset="0" stopColor="#ff9a76" /><stop offset="0.7" stopColor={C.accent} /><stop offset="1" stopColor="#c93a14" /></radialGradient>
        </defs>
        <circle cx={ccx} cy={ccy} r={R} fill={C.surf} />
        <g clipPath="url(#bub)">
          <rect x={ceilX - 150} y={ceilY - 18} width={300} height={18} rx={5} fill={C.muted} />
          <line x1={ceilX} y1={ceilY} x2={bx} y2={by} stroke={C.text} strokeWidth={5} />
          <line x1={bx} y1={by} x2={ccx - 300 + 70 * Math.sin(TAU * f * t)} y2={by + 20} stroke={C.muted} strokeWidth={12} />
          <line x1={bx} y1={by} x2={ccx + 300 + 70 * Math.sin(TAU * f * t)} y2={by + 20} stroke={C.muted} strokeWidth={12} />
          <circle cx={bx} cy={by} r={88} fill="url(#ball)" />
        </g>
        <circle cx={ccx} cy={ccy} r={R} fill="none" stroke={C.accent} strokeWidth={4} />
      </g>
      <g opacity={ap(t, 4)}>
        <text x={ccx} y={1230} fontFamily={HEAD} fontWeight={800} fontSize={150} fill={C.text} letterSpacing={-6} textAnchor="middle">660</text>
        <text x={ccx} y={1290} fontFamily={BODY} fontWeight={500} fontSize={34} fill={C.muted} textAnchor="middle" letterSpacing={4}>TON · BOLA BAJA</text>
      </g>
      <g opacity={ap(t, 8.5)}>
        <text x={560} y={1400} fontFamily={BODY} fontWeight={500} fontSize={26} letterSpacing={4} fill={C.muted} textAnchor="middle">GEDUNG</text>
        <Arrow x1={560 - dir * 50} y1={1445} x2={560 + dir * 50} y2={1445} color={C.text} w={9} />
        <text x={850} y={1400} fontFamily={BODY} fontWeight={500} fontSize={26} letterSpacing={4} fill={C.accent} textAnchor="middle">BOLA</text>
        <Arrow x1={850 + dir * 50} y1={1445} x2={850 - dir * 50} y2={1445} color={C.accent} w={9} />
      </g>
      <Body y={1700} lines={['Arah berlawanan, ayunan berkurang.']} size={46} fill={C.text} w={800} p={ap(t, 10)} />
    </g>
  );
};

const S7: React.FC<{t: number}> = ({t}) => {
  const rot = swy(t, 3.5, 0.45);
  const slosh = -rot * 1.6 + swy(t, 6, 0.9);
  return (
    <g>
      <Kick t={t} num="06" label="Sisi manusia" />
      <Head t={t} lines={['Aman, tapi', 'belum tentu nyaman.']} size={88} y={330} />
      <g transform={`rotate(${rot} 540 1330)`}>
        <rect x={140} y={620} width={800} height={710} rx={28} fill="none" stroke="#fff" strokeOpacity={0.16} strokeWidth={3} />
        <line x1={140} y1={1210} x2={940} y2={1210} stroke="#fff" strokeOpacity={0.3} strokeWidth={4} />
        <g transform="translate(540 1210)">
          <clipPath id="gl"><path d="M-130 -400 H130 L104 0 H-104 Z" /></clipPath>
          <g clipPath="url(#gl)"><g transform={`rotate(${slosh} 0 -200)`}><rect x={-240} y={-230} width={480} height={300} fill={C.accent} opacity={0.9} /></g></g>
          <path d="M-130 -400 H130 L104 0 H-104 Z" fill="none" stroke={C.text} strokeWidth={5} strokeLinejoin="round" />
        </g>
      </g>
      {[['Keselamatan struktur', 'Aman', false, 1.2, 1500], ['Kenyamanan penghuni', 'Terasa', true, 4.5, 1620]].map(([a, b, acc, at, y], i) => {
        const p = ap(t, at as number);
        return (
          <g key={i} opacity={p}>
            <line x1={M} y1={(y as number) - 64} x2={WIDTH - M} y2={(y as number) - 64} stroke="#fff" strokeOpacity={0.14} strokeWidth={2} />
            <text x={M} y={y as number} fontFamily={BODY} fontWeight={500} fontSize={36} fill={C.muted}>{a as string}</text>
            <text x={WIDTH - M} y={y as number} fontFamily={HEAD} fontWeight={800} fontSize={52} fill={acc ? C.accent : C.text} textAnchor="end" letterSpacing={-1}>{b as string}</text>
          </g>
        );
      })}
    </g>
  );
};

const S8: React.FC<{t: number}> = ({t}) => {
  const am = swy(t, 100, 0.5);
  const cy = GROUND - 360, cxk = BX - 30 + offAt(8.5, 20, am);
  const mx = cxk + 70 + Math.sin(t * 1.6) * 40, my = cy - 10 + Math.cos(t * 1.3) * 30;
  return (
    <g>
      <Kick t={t} num="07" label="Pemeriksaan" />
      <Head t={t} lines={['Berlebihan atau', 'ada kerusakan?']} size={92} y={330} />
      <GroundLine />
      <Building cx={BX} w={BW} h={BH - 40} amp={am} cap={false} />
      <path d={`M${cxk - 30} ${cy - 90} l24 36 l-26 30 l30 36 l-18 40`} fill="none" stroke={C.accent} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
      <g opacity={ap(t, 1.2)}>
        <circle cx={mx} cy={my} r={104} fill={C.bg} fillOpacity={0.35} stroke={C.text} strokeWidth={8} />
        <line x1={mx + 74} y1={my + 74} x2={mx + 170} y2={my + 170} stroke={C.text} strokeWidth={16} strokeLinecap="round" />
      </g>
      <Body y={1700} lines={['Tetap perlu diperiksa.']} size={56} fill={C.accent} w={800} p={ap(t, 1.5)} />
    </g>
  );
};

const S9: React.FC<{t: number}> = ({t}) => {
  const am = swy(t, 26 * ap(t, 0, 0.6), 0.3);
  return (
    <g>
      <Kick t={t} label="Kesimpulan" />
      <Head t={t} lines={['Tidak harus diam', 'untuk berdiri', 'kokoh.']} size={104} y={340} />
      <GroundLine />
      <Building cx={BX} w={BW} h={BH - 140} amp={am} />
    </g>
  );
};

const S10: React.FC<{t: number}> = ({t}) => (
  <g>
    <Kick t={t} label="Catatan" />
    <Body y={430} lines={['Pembahasan ini', 'terutama tentang', 'angin.']} size={84} fill={C.text} w={800} p={ap(t, 0.4)} />
    <Body y={800} lines={['Respons terhadap gempa', 'memiliki pertimbangan', 'desain tambahan.']} size={58} fill={C.muted} p={ap(t, 2.2)} />
  </g>
);

const SCENE_FNS = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10];

// muat font Inter dari public/fonts
const useFonts = () => {
  const [handle] = useState(() => (typeof document === 'undefined' ? null : delayRender('fonts')));
  useEffect(() => {
    if (handle === null) return;
    const fonts = [
      new FontFace('InterHead', `url(${staticFile('fonts/InterDisplay-ExtraBold.otf')})`, {weight: '800'}),
      new FontFace('InterBody', `url(${staticFile('fonts/Inter-Medium.otf')})`, {weight: '500'}),
    ];
    Promise.all(fonts.map(f => f.load()))
      .then(fs => { fs.forEach(f => (document as any).fonts.add(f)); continueRender(handle); })
      .catch(() => continueRender(handle));
  }, [handle]);
};

export const Gedung: React.FC = () => {
  useFonts();
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <AbsoluteFill style={{backgroundColor: C.bg}}>
      <Audio src={staticFile('audio.mp3')} />
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="bld" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3a3f50" /><stop offset="1" stopColor="#1c1f29" /></linearGradient>
          <radialGradient id="glow" cx="0.5" cy="0.85" r="0.7"><stop offset="0" stopColor="#ff5b2e" stopOpacity="0.14" /><stop offset="1" stopColor="#ff5b2e" stopOpacity="0" /></radialGradient>
        </defs>
        <Background t={t} />
        {SCENE_FNS.map((Fn, i) => {
          const a = SCENES[i], b = SCENES[i + 1];
          if (t < a || t >= b) return null;
          const op = Math.min(i === 0 ? 1 : prog(t, a, a + 0.4), i === SCENE_FNS.length - 1 ? 1 : 1 - prog(t, b - 0.3, b));
          return <g key={i} opacity={op}><Fn t={t - a} /></g>;
        })}
        <text x={M} y={1850} fontFamily={BODY} fontWeight={500} fontSize={34} letterSpacing={1} fill={C.text} fillOpacity={0.7}>@semestakita</text>
      </svg>
    </AbsoluteFill>
  );
};
