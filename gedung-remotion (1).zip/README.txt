Gedung - animasi edukasi "Mengapa Gedung Tinggi Bisa Bergoyang Tanpa Mengalami Kerusakan?"
(portrait 9:16, 1080x1920, 60fps, 93.39 detik = sepanjang audio narasi)
File: Gedung.tsx, Root.tsx, public/audio.mp3, public/fonts/ (Inter, lisensi OFL)
Taruh Gedung.tsx & Root.tsx di src/ proyek Remotion; folder public/ digabung ke public/ proyek.
Render: npx remotion render Gedung out/gedung.mp4
Waktu mulai tiap adegan ada di konstanta SCENES (Gedung.tsx). Warna aksen di objek C.accent.
