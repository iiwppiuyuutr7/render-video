import React from 'react';
import {Composition} from 'remotion';
import {Fosil} from './Fosil';

export const RemotionRoot: React.FC = () => (
  <Composition id="Fosil" component={Fosil} durationInFrames={5400} fps={60} width={1080} height={1920} />
);
