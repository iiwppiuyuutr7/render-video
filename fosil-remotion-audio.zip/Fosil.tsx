import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  BAGAIMANA ILMUWAN MENGETAHUI USIA FOSIL JUTAAN TAHUN?
  90 detik, vertikal 1080x1920, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Gaya: motion graphics + blok bumi isometrik (pseudo-3D SVG), 3 momen meme orisinal (maskot "Fosi").
  Waktu narasi ada di SENT (ganti dengan waktu asli setelah suara jadi); waktu scene ada di SC.
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;
const WM_BOTTOM = 270; // jarak watermark dari bawah (naikkan/turunkan di sini)

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  cyan: '#5ad1ff',
  bone: '#f4e8cf',
  ink: '#5a3d22',
  sand: '#d9b87c',
  red: '#ff4d4d',
  green: '#6ee7a0',
};

// awal tiap scene (detik)
const SC = [0, 3.6, 13.0, 17.2, 36.0, 53.4, 65.6, 79.9];
const SD = [3.6, 9.4, 4.2, 18.8, 17.4, 12.2, 14.3, 10.1];
const CHAPTERS = ['PEMBUKA', 'PERTANYAAN', 'JAWABAN', 'PENANGGALAN RELATIF', 'PENANGGALAN RADIOMETRIK', 'KARBON-14', 'ABU VULKANIK', 'KESIMPULAN'];

/* ---------- narasi -> subtitle ---------- */

const SENT: {a: number; b: number; t: string}[] = [
  {a: 3.6, b: 12.46, t: "Pernahkah kamu bertanya-tanya, bagaimana ilmuwan bisa mengetahui usia fosil yang berusia jutaan tahun, padahal tidak ada manusia yang menyaksikan kapan organisme tersebut hidup?"},
  {a: 13.01, b: 16.65, t: "Jawabannya adalah melalui penelitian lapisan batuan dan metode penanggalan ilmiah."},
  {a: 17.2, b: 19.63, t: "Pertama, ilmuwan menggunakan metode penanggalan relatif."},
  {a: 20.18, b: 23.09, t: "Fosil biasanya ditemukan di dalam lapisan batuan sedimen."},
  {a: 23.64, b: 30.07, t: "Pada lapisan yang tidak mengalami gangguan geologi, lapisan lebih bawah umumnya lebih tua dibandingkan lapisan di atasnya."},
  {a: 30.62, b: 35.49, t: "Namun, metode ini hanya menunjukkan urutan usia, bukan angka tahun secara pasti."},
  {a: 36.04, b: 39.92, t: "Untuk mengetahui perkiraan usia dalam angka, ilmuwan menggunakan penanggalan radiometrik."},
  {a: 40.47, b: 46.29, t: "Metode ini memanfaatkan peluruhan isotop radioaktif yang berubah menjadi unsur lain dengan laju yang dapat diukur."},
  {a: 46.84, b: 52.91, t: "Setiap isotop memiliki waktu paruh, yaitu waktu yang diperlukan agar setengah dari jumlah isotop radioaktifnya meluruh."},
  {a: 53.46, b: 56.25, t: "Lalu, bagaimana cara menentukan usia fosil dinosaurus?"},
  {a: 56.8, b: 65.05, t: "Fosil dinosaurus umumnya tidak diuji langsung menggunakan karbon-14 karena metode tersebut hanya efektif untuk material yang relatif muda, hingga sekitar 50.000 tahun."},
  {a: 65.6, b: 72.76, t: "Sebagai gantinya, ilmuwan sering mengukur usia mineral dalam lapisan abu vulkanik yang berada di atas atau di bawah fosil."},
  {a: 73.31, b: 79.38, t: "Dengan menggabungkan hasil penanggalan radiometrik dan posisi lapisan batuan, ilmuwan dapat memperkirakan kapan organisme tersebut hidup."},
  {a: 79.93, b: 82.36, t: "Jadi, usia fosil bukan sekadar tebakan."},
  {a: 82.91, b: 86.69, t: "Semuanya didasarkan pada pengukuran, bukti geologi, dan penelitian ilmiah."},
];


const S = SENT.map((s) => s.a);

const CAPS = (() => {
  const out: {a: number; b: number; text: string}[] = [];
  for (const n of SENT) {
    const w = n.t.split(' ');
    const parts = Math.ceil(w.length / 9);
    const size = Math.ceil(w.length / parts);
    const pieces: string[] = [];
    for (let i = 0; i < w.length; i += size) pieces.push(w.slice(i, i + size).join(' '));
    const total = pieces.reduce((a, p) => a + p.length, 0);
    let cur = n.a;
    for (const p of pieces) {
      const d = ((n.b - n.a) * p.length) / total;
      out.push({a: cur, b: cur + d - 0.04, text: p});
      cur += d;
    }
  }
  return out;
})();

/* ---------- util ---------- */

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (
  t: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (x: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.4) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const rad = (d: number) => (d * Math.PI) / 180;
// pop dengan overshoot
const pop = (t: number, a: number, d = 0.5) => {
  const p = Math.min(1, Math.max(0, (t - a) / d));
  const c1 = 1.70158;
  return p <= 0 ? 0 : 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};

const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const shade = (h: string, k: number) => `rgb(${hex(h).map((v) => Math.max(0, Math.min(255, Math.round(v * k)))).join(',')})`;

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const DUST = (() => {
  const r = mulberry32(5);
  return Array.from({length: 70}, () => ({x: r() * W, y: r() * H, s: r() * 2.4 + 0.8, o: r() * 0.4 + 0.12, v: 8 + r() * 26, p: r() * 6.28}));
})();

/* ---------- latar & kamera ---------- */

const Bg: React.FC<{t: number}> = ({t}) => (
  <AbsoluteFill>
    <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
      <defs>
        <linearGradient id="bgg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0b1020" />
          <stop offset="0.55" stopColor="#151018" />
          <stop offset="1" stopColor="#1f140d" />
        </linearGradient>
        <radialGradient id="bgGlow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#ff7a1a" stopOpacity="0.22" />
          <stop offset="1" stopColor="#ff7a1a" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width={W} height={H} fill="url(#bgg)" />
      <ellipse cx={CX} cy={960 + Math.sin(t * 0.3) * 40} rx={620} ry={560} fill="url(#bgGlow)" />
      {DUST.map((d, i) => (
        <circle key={i} cx={(d.x + Math.sin(t * 0.3 + d.p) * 20) % W} cy={(((d.y - t * d.v) % H) + H) % H} r={d.s} fill="#ffd9a0" opacity={d.o * (0.6 + 0.4 * Math.sin(t * 1.5 + d.p))} />
      ))}
    </svg>
  </AbsoluteFill>
);

const Cam: React.FC<{t: number; amp?: number; children: React.ReactNode}> = ({t, amp = 1, children}) => (
  <AbsoluteFill style={{perspective: 1800, perspectiveOrigin: '50% 42%'}}>
    <AbsoluteFill
      style={{
        transform: `rotateY(${Math.sin(t * 0.4) * 2.2 * amp}deg) rotateX(${Math.cos(t * 0.3) * 1.6 * amp}deg) scale(1.03)`,
        transformOrigin: '50% 42%',
      }}
    >
      {children}
    </AbsoluteFill>
  </AbsoluteFill>
);

/* ---------- teks ---------- */

const Title: React.FC<{
  t: number;
  lines: string[];
  start: number;
  end: number;
  y: number;
  size: number;
  color?: string;
  step?: number;
}> = ({t, lines, start, end, y, size, color = '#fff', step = 0.1}) => {
  if (t < start - 0.1 || t > end + 0.1) return null;
  const outA = ramp(t, end - 0.45, end, 1, 0, lin);
  let idx = 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: 40,
        right: 40,
        top: y,
        textAlign: 'center',
        opacity: outA,
        fontFamily: cond,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 0.98,
        letterSpacing: '0.02em',
        color,
        textShadow: '0 0 36px rgba(255,122,26,0.38), 0 4px 30px rgba(0,0,0,0.8)',
      }}
    >
      {lines.map((ln, li) => (
        <div key={li} style={{display: 'flex', justifyContent: 'center', gap: size * 0.22}}>
          {ln.split(' ').map((w, wi) => {
            const i = idx++;
            const p = ramp(t, start + i * step, start + i * step + 0.45, 0, 1, outC);
            return (
              <span key={wi} style={{display: 'inline-block', opacity: p, transform: `translateY(${(1 - p) * 38}px) scale(${0.96 + 0.04 * p})`}}>
                {w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

const Caption: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find((x) => t >= x.a && t < x.b);
  if (!c) return null;
  const o = ramp(t, c.a, c.a + 0.16, 0, 1, lin) * ramp(t, c.b - 0.1, c.b, 1, 0, lin);
  return (
    <div
      style={{
        position: 'absolute',
        left: 90,
        right: 90,
        top: 1330,
        height: 230,
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center',
        opacity: o,
        transform: `translateY(${(1 - o) * 12}px)`,
        fontFamily: sans,
        fontWeight: 700,
        fontSize: 56,
        lineHeight: 1.22,
        color: '#fff',
        textShadow: '0 3px 22px rgba(0,0,0,0.95), 0 0 6px rgba(0,0,0,0.9)',
      }}
    >
      <span>{c.text}</span>
    </div>
  );
};

const Hud: React.FC<{t: number}> = ({t}) => {
  let s = 0;
  SC.forEach((a, i) => {
    if (t >= a) s = i;
  });
  const o = ramp(t, 0.6, 1.4, 0, 1, lin) * ramp(t, 87.2, 88.4, 1, 0, lin);
  return (
    <div style={{position: 'absolute', inset: 0, opacity: o}}>
      <div style={{position: 'absolute', left: 64, right: 64, top: 66, height: 4, background: 'rgba(255,255,255,0.18)', borderRadius: 2}}>
        <div style={{width: `${(t / 90) * 100}%`, height: 4, background: C.orange, borderRadius: 2, boxShadow: `0 0 12px ${C.orange}`}} />
      </div>
      <div style={{position: 'absolute', left: 64, top: 92, fontFamily: cond, fontWeight: 600, fontSize: 30, letterSpacing: '0.16em', color: 'rgba(255,255,255,0.85)'}}>
        {`0${s + 1} / 08  ·  ${CHAPTERS[s]}`}
      </div>
      <div style={{position: 'absolute', left: 64, top: 130, fontFamily: sans, fontWeight: 600, fontSize: 20, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.42)'}}>
        ILUSTRASI ARTISTIK · ANGKA CONTOH BERLABEL
      </div>
    </div>
  );
};

const Watermark: React.FC<{t: number}> = ({t}) => (
  <div
    style={{
      position: 'absolute',
      right: 52,
      bottom: WM_BOTTOM,
      opacity: ramp(t, 0.2, 0.8, 0, 0.92, lin) * ramp(t, 89.2, 89.8, 1, 0, lin),
      fontFamily: cond,
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '0.06em',
      color: '#fff',
      textShadow: '0 2px 14px rgba(0,0,0,0.95), 0 0 4px rgba(0,0,0,0.9)',
    }}
  >
    Semesta<span style={{color: C.orange}}>Kita</span>
  </div>
);

/* ---------- fosil & objek ---------- */

const Ammonite: React.FC<{x: number; y: number; s?: number; rot?: number; glow?: number}> = ({x, y, s = 1, rot = 0, glow = 0}) => {
  const pts = Array.from({length: 84}, (_, i) => {
    const th = i * 0.14;
    const r = 6 * Math.exp(0.19 * th);
    return {x: Math.cos(th) * r, y: Math.sin(th) * r, r: 0.3 * r + 2.2, th};
  });
  return (
    <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`}>
      {glow > 0 && <circle r={96} fill="url(#fGlow)" opacity={glow} />}
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={p.r} fill={C.bone} stroke={C.ink} strokeWidth={2.2} />
      ))}
      {pts.filter((_, i) => i % 3 === 0 && i > 12).map((p, i) => (
        <line key={'r' + i} x1={p.x} y1={p.y} x2={p.x * 1.0 + Math.cos(p.th) * p.r * 0.9} y2={p.y + Math.sin(p.th) * p.r * 0.9} stroke={C.ink} strokeWidth={2} opacity={0.7} />
      ))}
    </g>
  );
};

const FishBone: React.FC<{x: number; y: number; s?: number; rot?: number; glow?: number}> = ({x, y, s = 1, rot = 0, glow = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${s})`} stroke={C.ink} strokeLinecap="round" strokeLinejoin="round">
    {glow > 0 && <ellipse rx={150} ry={80} fill="url(#fGlow)" opacity={glow} />}
    <path d="M -110 0 L 70 0" stroke={C.bone} strokeWidth={9} />
    {Array.from({length: 9}, (_, i) => {
      const px = -80 + i * 17;
      const h = 34 - Math.abs(i - 3) * 3.2;
      return (
        <g key={i}>
          <path d={`M ${px} 0 Q ${px + 8} ${-h * 0.7} ${px + 22} ${-h}`} fill="none" stroke={C.bone} strokeWidth={5} />
          <path d={`M ${px} 0 Q ${px + 8} ${h * 0.7} ${px + 22} ${h}`} fill="none" stroke={C.bone} strokeWidth={5} />
        </g>
      );
    })}
    <path d="M -112 0 Q -100 -34 -70 -30 Q -52 -12 -56 0 Q -52 12 -70 30 Q -100 34 -112 0 Z" fill={C.bone} strokeWidth={4} />
    <circle cx={-86} cy={-8} r={6} fill={C.ink} stroke="none" />
    <path d="M 70 0 L 118 -34 L 104 0 L 118 34 Z" fill={C.bone} strokeWidth={4} />
  </g>
);

const DinoSkull: React.FC<{x: number; y: number; s?: number; rot?: number; glow?: number; flip?: boolean}> = ({x, y, s = 1, rot = 0, glow = 0, flip = false}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${flip ? -s : s},${s})`} stroke={C.ink} strokeLinejoin="round" strokeLinecap="round">
    {glow > 0 && <ellipse rx={170} ry={110} fill="url(#fGlow)" opacity={glow} />}
    {/* rahang bawah */}
    <path d="M -96 14 L -30 20 L 40 30 L 78 36 L 92 22 L 70 12 L -10 8 Z" fill={C.bone} strokeWidth={4} />
    {Array.from({length: 7}, (_, i) => (
      <path key={'lt' + i} d={`M ${-88 + i * 14} ${13 + i * 1.2} l 4 -13 l 5 13 Z`} fill="#fff7e6" strokeWidth={2} />
    ))}
    {/* tengkorak */}
    <path d="M -102 -6 L -92 -22 L -44 -34 L 8 -46 L 52 -56 L 84 -40 L 98 -8 L 90 22 L 60 30 L 26 14 L -10 8 L -70 8 L -98 6 Z" fill={C.bone} strokeWidth={4} />
    {Array.from({length: 7}, (_, i) => (
      <path key={'ut' + i} d={`M ${-92 + i * 14} ${6 + i * 0.6} l 4 12 l 5 -12 Z`} fill="#fff7e6" strokeWidth={2} />
    ))}
    <ellipse cx={-34} cy={-14} rx={20} ry={11} fill="#2a1a0e" strokeWidth={3} />
    <circle cx={32} cy={-18} r={15} fill="#2a1a0e" strokeWidth={3} />
    <circle cx={-84} cy={-12} r={3.5} fill="#2a1a0e" stroke="none" />
    <path d="M 54 -40 Q 74 -30 80 -6" fill="none" strokeWidth={3} opacity={0.6} />
  </g>
);

const Person: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#fff'}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={color}>
    <circle cx={0} cy={-62} r={26} />
    <path d="M -38 70 L -38 -14 Q -38 -30 -22 -30 L 22 -30 Q 38 -30 38 -14 L 38 70 L 14 70 L 14 20 L -14 20 L -14 70 Z" />
  </g>
);

const Eye: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#fff'}) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill="none" stroke={color} strokeWidth={9} strokeLinecap="round">
    <path d="M -80 0 Q 0 -70 80 0 Q 0 70 -80 0 Z" />
    <circle r={24} fill={color} />
  </g>
);

/* ---------- blok bumi isometrik ---------- */

type Layer = {h: number; c: string};

const wavy = (x0: number, x1: number, y: number, seed: number, amp = 5, n = 14) => {
  const pts: [number, number][] = [];
  for (let i = 0; i <= n; i++) {
    const x = x0 + ((x1 - x0) * i) / n;
    pts.push([x, y + Math.sin(i * 1.7 + seed) * amp + Math.sin(i * 0.7 + seed * 2) * amp * 0.6]);
  }
  return pts;
};
const P = (pts: [number, number][]) => pts.map((p) => `${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' L ');

const Block: React.FC<{
  x: number;
  y: number;
  w: number;
  d: number;
  layers: Layer[];
  t: number;
  prog?: number[];
  idp?: string;
}> = ({x, y, w, d, layers, t, prog, idp = 'b'}) => {
  const dx = d * (0.62 + 0.28 * Math.sin(t * 0.5));
  const dy = -d * 0.42;
  let yy = y;
  const tops = layers.map((l) => {
    const v = yy;
    yy += l.h;
    return v;
  });
  const total = yy - y;
  return (
    <g>
      {/* bayangan */}
      <ellipse cx={x + w / 2 + dx / 2} cy={y + total + 26} rx={w * 0.62} ry={34} fill="#000" opacity={0.35} />
      {/* top face */}
      <path d={`M ${x} ${y} L ${x + dx} ${y + dy} L ${x + w + dx} ${y + dy} L ${x + w} ${y} Z`} fill={shade(layers[0].c, 1.28)} stroke="rgba(0,0,0,0.35)" strokeWidth={2} opacity={prog ? prog[0] : 1} />
      {[...layers.keys()].reverse().map((i) => {
        const l = layers[i];
        const p = prog ? prog[i] : 1;
        const top = wavy(x, x + w, tops[i], i * 2.3);
        const bot = i < layers.length - 1 ? wavy(x, x + w, tops[i + 1], (i + 1) * 2.3) : [[x, y + total], [x + w, y + total]] as [number, number][];
        const r = mulberry32(31 + i * 7 + idp.length);
        return (
          <g key={i} opacity={p} transform={`translate(0,${(1 - p) * -130})`}>
            <path d={`M ${P(top)} L ${P([...bot].reverse())} Z`} fill={l.c} />
            {Array.from({length: 16}, (_, k) => (
              <ellipse key={k} cx={x + 14 + r() * (w - 28)} cy={tops[i] + 10 + r() * Math.max(4, l.h - 20)} rx={3 + r() * 7} ry={2 + r() * 3.5} fill={shade(l.c, 0.7)} opacity={0.5} />
            ))}
            <path d={`M ${P(top)}`} fill="none" stroke={shade(l.c, 1.35)} strokeWidth={2.5} opacity={0.8} />
            <path d={`M ${x + w} ${tops[i]} L ${x + w + dx} ${tops[i] + dy} L ${x + w + dx} ${tops[i] + l.h + dy} L ${x + w} ${tops[i] + l.h} Z`} fill={shade(l.c, 0.68)} stroke="rgba(0,0,0,0.3)" strokeWidth={1.5} />
          </g>
        );
      })}
      <path d={`M ${x} ${y} L ${x} ${y + total} L ${x + w} ${y + total} L ${x + w} ${y}`} fill="none" stroke="rgba(0,0,0,0.45)" strokeWidth={3} />
    </g>
  );
};

const FossilDefs: React.FC = () => (
  <defs>
    <radialGradient id="fGlow" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stopColor="#ffd27a" stopOpacity="0.95" />
      <stop offset="1" stopColor="#ffb020" stopOpacity="0" />
    </radialGradient>
  </defs>
);

/* ---------- maskot Fosi + meme ---------- */

type Mood = 'confused' | 'brow' | 'tired';

const Fosi: React.FC<{x: number; y: number; s?: number; mood: Mood; t: number}> = ({x, y, s = 1, mood, t}) => {
  const bob = Math.sin(t * 9) * 4;
  const body = '#f2dcae';
  const pup = mood === 'confused' ? [[-30, -18], [46, -28]] : mood === 'brow' ? [[-26, -20], [26, -20]] : [[-36, -8], [34, -8]];
  return (
    <g transform={`translate(${x},${y + bob}) scale(${s}) rotate(${mood === 'confused' ? Math.sin(t * 5) * 3 : 0})`}>
      <ellipse cx={0} cy={96} rx={92} ry={12} fill="#000" opacity={0.35} />
      <ellipse cx={-104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(25 -104 20)" />
      <ellipse cx={104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(-25 104 20)" />
      <ellipse cx={0} cy={0} rx={100} ry={90} fill={body} stroke={C.ink} strokeWidth={7} />
      <path d="M -78 30 Q 0 56 78 30" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      <path d="M -62 56 Q 0 78 62 56" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      {[-38, 38].map((ex, i) => (
        <g key={i}>
          <circle cx={ex} cy={-22} r={30} fill="#fff" stroke={C.ink} strokeWidth={5} />
          <circle cx={ex + pup[i][0] * 0.35 + (i ? 0 : 0)} cy={-22 + pup[i][1] * 0.35} r={11} fill="#2a1a0e" />
          {mood === 'tired' && <path d={`M ${ex - 30} -22 A 30 30 0 0 1 ${ex + 30} -22 Z`} fill={body} stroke={C.ink} strokeWidth={5} />}
        </g>
      ))}
      {mood === 'confused' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -66 L -16 -56" />
          <path d="M 66 -76 L 16 -62" />
        </g>
      )}
      {mood === 'brow' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -62 -50 L -14 -52" />
          <path d="M 14 -78 Q 40 -90 64 -70" />
        </g>
      )}
      {mood === 'tired' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -62 L -14 -52" />
          <path d="M 66 -62 L 14 -52" />
        </g>
      )}
      {mood === 'confused' && <path d="M -34 46 q 17 -16 34 0 t 34 0" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'brow' && <path d="M -24 48 L 24 48" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' && <path d="M -32 58 Q 0 30 32 58" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' &&
        [0, 1].map((k) => {
          const p = (t * 1.3 + k * 0.5) % 1;
          return <path key={k} d="M 0 -12 Q 12 8 0 16 Q -12 8 0 -12 Z" transform={`translate(${96 + k * 20},${-60 + p * 90})`} fill={C.cyan} opacity={1 - p} />;
        })}
      {mood === 'confused' &&
        [[-130, -110, 0], [140, -90, 1.3], [-40, -150, 2.4]].map(([qx, qy, ph], i) => (
          <text key={i} x={qx} y={qy + Math.sin(t * 4 + ph) * 8} fontFamily={cond} fontWeight={700} fontSize={84} fill={C.amber} stroke="#000" strokeWidth={8} paintOrder="stroke" textAnchor="middle">
            ?
          </text>
        ))}
    </g>
  );
};

const MemeText: React.FC<{lines: string[]; y: number; size: number; t: number; a: number}> = ({lines, y, size, t, a}) => {
  const p = pop(t, a + 0.05, 0.45);
  const sh = t - a < 0.5 ? Math.sin(t * 60) * 5 * (1 - (t - a) / 0.5) : 0;
  return (
    <g transform={`translate(${CX + sh},${y}) scale(${Math.max(0.01, p)})`}>
      {lines.map((ln, i) => (
        <text key={i} x={0} y={i * size * 0.98} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill="#fff" stroke="#000" strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke" letterSpacing="0.02em">
          {ln}
        </text>
      ))}
    </g>
  );
};

const Meme: React.FC<{t: number; a: number; b: number; mood: Mood; lines: string[]; ty: number; size?: number; fx?: number; fy?: number; fs?: number}> = ({
  t,
  a,
  b,
  mood,
  lines,
  ty,
  size = 112,
  fx = CX,
  fy = 1110,
  fs = 1.15,
}) => {
  if (t < a - 0.05 || t > b + 0.05) return null;
  const o = win(t, a, b, 0.25);
  const flash = ramp(t, a, a + 0.12, 0.55, 0, lin);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: '#000', opacity: 0.5 * o}} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: o}}>
        <g transform={`translate(${fx},${fy}) scale(${Math.max(0.01, pop(t, a, 0.5))}) translate(${-fx},${-fy})`}>
          <Fosi x={fx} y={fy} s={fs} mood={mood} t={t} />
        </g>
        <MemeText lines={lines} y={ty} size={size} t={t} a={a} />
      </svg>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </AbsoluteFill>
  );
};

/* ---------- scene ---------- */

const LAY = ['#8a6a47', '#b08a55', '#c9a468', '#9a7449', '#d6b27a', '#765536'];
const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
    <FossilDefs />
    {children}
  </svg>
);

const SceneLabel: React.FC<{x: number; y: number; text: string; size?: number; color?: string; o?: number; anchor?: 'start' | 'middle' | 'end'}> = ({x, y, text, size = 40, color = '#fff', o = 1, anchor = 'middle'}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.1} paintOrder="stroke">
    {text}
  </text>
);

const Scene0: React.FC<{t: number}> = ({t}) => {
  const z = 1 + 0.1 * ramp(t, 0, 3.9, 0, 1, lin);
  const beam = ramp(t, 0.5, 3.0, 0, 1, lin);
  const g = 0.55 + 0.3 * Math.sin(t * 5);
  const layers = [{h: 70, c: LAY[0]}, {h: 90, c: LAY[1]}, {h: 100, c: LAY[2]}, {h: 110, c: LAY[3]}, {h: 90, c: LAY[4]}, {h: 90, c: LAY[5]}];
  const o = ramp(t, 0, 0.3, 0, 1, lin);
  return (
    <Cam t={t}>
      <Svg>
        <g opacity={o} transform={`translate(570 1000) scale(${z}) translate(-570 -1000)`}>
          <Block x={190} y={760} w={560} d={240} layers={layers} t={t} idp="h" />
          <Ammonite x={330} y={985} s={0.8} glow={g} />
          <DinoSkull x={520} y={1075} s={0.5} glow={g} />
          <FishBone x={450} y={1175} s={0.55} glow={g * 0.7} />
          <rect x={190} y={760 + beam * 540} width={560} height={14} fill="#ffe2a0" opacity={0.55 * Math.sin(Math.PI * beam)} />
        </g>
      </Svg>
    </Cam>
  );
};

const Scene1: React.FC<{t: number}> = ({t}) => {
  const a = ramp(t, 3.6, 4.4, 0, 1, lin);
  const eye = pop(t, 8.5, 0.5);
  const slash = ramp(t, 9.0, 9.6, 0, 1, lin);
  return (
    <Cam t={t} amp={0.6}>
      <Svg>
        <g opacity={a}>
          <ellipse cx={250} cy={960} rx={150} ry={44} fill="#765536" stroke="#000" strokeOpacity={0.4} strokeWidth={3} />
          <ellipse cx={250} cy={944} rx={140} ry={36} fill="#9a7449" />
          <Ammonite x={250} y={850} s={1.5} glow={0.5 + 0.3 * Math.sin(t * 4)} rot={t * 4} />
          <SceneLabel x={270} y={1050} text="JUTAAN TAHUN LALU" size={34} color={C.amber} />
          <Person x={830} y={880} s={1.5} />
          <SceneLabel x={810} y={1050} text="KAMU, SEKARANG" size={34} color={C.cyan} />
          <line x1={370} y1={900} x2={720} y2={900} stroke="#fff" strokeOpacity={0.55} strokeWidth={6} strokeDasharray="4 18" strokeDashoffset={-t * 50} strokeLinecap="round" />
          <g transform={`translate(540,900) scale(${eye})`}>
            <Eye x={0} y={0} s={0.9} color="#fff" />
            <line x1={-72} y1={52} x2={-72 + 144 * slash} y2={52 - 104 * slash} stroke={C.red} strokeWidth={14} strokeLinecap="round" />
          </g>
          <SceneLabel x={540} y={1010} text="TIDAK ADA SAKSI" size={54} color={C.red} o={ramp(t, 9.3, 9.8, 0, 1, lin)} />
        </g>
      </Svg>
    </Cam>
  );
};

const Card: React.FC<{x: number; y: number; w: number; h: number; p: number; dir: number; title: string; sub: string; icon: React.ReactNode}> = ({x, y, w, h, p, dir, title, sub, icon}) => (
  <g opacity={Math.min(1, p * 1.6)} transform={`translate(${dir * (1 - Math.min(1, p)) * 500},0)`}>
    <rect x={x} y={y} width={w} height={h} rx={28} fill="rgba(20,16,28,0.82)" stroke={C.orange} strokeWidth={4} />
    <g transform={`translate(${x + 90},${y + h / 2})`}>{icon}</g>
    <text x={x + 190} y={y + h / 2 + 6} fontFamily={cond} fontWeight={700} fontSize={70} fill="#fff" letterSpacing="0.03em">
      {title}
    </text>
    <text x={x + 192} y={y + h / 2 + 52} fontFamily={sans} fontWeight={600} fontSize={30} fill="rgba(255,255,255,0.65)">
      {sub}
    </text>
  </g>
);

const Scene2: React.FC<{t: number}> = ({t}) => (
  <Cam t={t} amp={0.6}>
    <Svg>
      <Card
        x={100}
        y={540}
        w={880}
        h={250}
        p={pop(t, 13.4, 0.6)}
        dir={-1}
        title="LAPISAN BATUAN"
        sub="posisi fosil di dalam tanah"
        icon={
          <g>
            {[LAY[0], LAY[2], LAY[3], LAY[4]].map((c, i) => (
              <rect key={i} x={-52} y={-52 + i * 26} width={104} height={24} rx={4} fill={c} stroke="#000" strokeOpacity={0.4} strokeWidth={2} />
            ))}
          </g>
        }
      />
      <Card
        x={100}
        y={860}
        w={880}
        h={250}
        p={pop(t, 15.2, 0.6)}
        dir={1}
        title="PENANGGALAN ILMIAH"
        sub="mengukur usia dalam angka"
        icon={
          <g fill="none" stroke={C.cyan} strokeWidth={8} strokeLinecap="round">
            <circle r={50} />
            <path d={`M 0 0 L ${Math.sin(t * 3) * 34} ${-Math.cos(t * 3) * 34}`} />
            <path d="M 0 0 L 22 16" />
          </g>
        }
      />
    </Svg>
  </Cam>
);

const Scene3: React.FC<{t: number}> = ({t}) => {
  const layers = [0, 1, 2, 3, 4].map((i) => ({h: i === 0 ? 80 : 100, c: LAY[i]}));
  const prog = [0, 1, 2, 3, 4].map((i) => ramp(t, 17.4 + 0.45 * (4 - i), 17.4 + 0.45 * (4 - i) + 0.5, 0, 1, outC));
  const f1 = pop(t, 20.3, 0.5);
  const f2 = pop(t, 20.6, 0.5);
  const f3 = pop(t, 20.9, 0.5);
  const ring = win(t, 21.3, 23.6, 0.3);
  const arrows = win(t, 23.8, 30.3, 0.5);
  const centers = [660, 750, 850, 950, 1050];
  return (
    <Cam t={t} amp={0.7}>
      <Svg>
        <Block x={110} y={620} w={520} d={190} layers={layers} t={t} prog={prog} idp="rel" />
        <g opacity={prog[1]}>
          <g transform={`translate(240,750) scale(${f1}) translate(-240,-750)`}>
            <Ammonite x={240} y={750} s={0.5} />
          </g>
        </g>
        <g transform={`translate(400,850) scale(${f2}) translate(-400,-850)`}>
          <DinoSkull x={400} y={850} s={0.52} glow={ring * 0.8} />
        </g>
        <g transform={`translate(330,950) scale(${f3}) translate(-330,-950)`}>
          <FishBone x={330} y={950} s={0.5} />
        </g>
        {/* cincin fosil */}
        <g opacity={ring}>
          <ellipse cx={400} cy={850} rx={118} ry={66} fill="none" stroke={C.orange} strokeWidth={5} strokeDasharray="14 10" strokeDashoffset={-t * 30} />
          <line x1={518} y1={850} x2={830} y2={850} stroke={C.orange} strokeWidth={4} strokeDasharray="8 8" />
          <SceneLabel x={925} y={866} text="FOSIL" size={60} color={C.orange} />
        </g>
        {/* denyut lapisan atas -> bawah */}
        {[0, 1, 2, 3, 4].map((i) => {
          const top = 620 + (i === 0 ? 0 : 80 + (i - 1) * 100);
          return <rect key={i} x={110} y={top} width={520} height={i === 0 ? 80 : 100} fill="#fff" opacity={0.22 * win(t, 24.4 + i * 0.9, 25.4 + i * 0.9, 0.3)} />;
        })}
        {/* panah muda -> tua */}
        <g opacity={arrows}>
          <line x1={925} y1={740} x2={925} y2={970} stroke="#fff" strokeOpacity={0.6} strokeWidth={6} strokeDasharray="4 16" strokeDashoffset={-t * 40} strokeLinecap="round" />
          <path d="M 897 950 L 925 992 L 953 950" fill="none" stroke="#fff" strokeOpacity={0.8} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
          <SceneLabel x={925} y={660} text="LEBIH" size={32} color="rgba(255,255,255,0.8)" />
          <SceneLabel x={925} y={716} text="MUDA" size={64} color={C.cyan} />
          <SceneLabel x={925} y={1050} text="LEBIH" size={32} color="rgba(255,255,255,0.8)" />
          <SceneLabel x={925} y={1106} text="TUA" size={64} color={C.orange} />
        </g>
        {/* badge angka tidak diketahui */}
        {centers.map((cy, i) => {
          const p = pop(t, 30.8 + i * 0.28, 0.45);
          const x = ramp(t, 33.6 + i * 0.12, 34.0 + i * 0.12, 0, 1, lin);
          return (
            <g key={i} transform={`translate(925,${cy}) scale(${p})`}>
              <rect x={-105} y={-28} width={210} height={56} rx={28} fill="rgba(20,16,28,0.9)" stroke="#fff" strokeOpacity={0.5} strokeWidth={3} />
              <text y={12} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={32} fill="#fff" letterSpacing="0.03em">
                ? JUTA THN
              </text>
              <line x1={-105} y1={0} x2={-105 + 210 * x} y2={0} stroke={C.red} strokeWidth={7} strokeLinecap="round" />
            </g>
          );
        })}
      </Svg>
    </Cam>
  );
};

const NATOMS = 60;
const ATOMR = (() => {
  const r = mulberry32(77);
  return Array.from({length: NATOMS}, () => 0.03 + r() * 0.97);
})();

const hOf = (t: number) => {
  if (t < 40.9) return 0;
  if (t < 46.3) return ramp(t, 40.9, 46.3, 0, 0.4, lin);
  if (t < 49.0) return ramp(t, 46.3, 49.0, 0.4, 1, Easing.inOut(Easing.cubic));
  if (t < 50.1) return 1;
  if (t < 51.4) return ramp(t, 50.1, 51.4, 1, 2, Easing.inOut(Easing.cubic));
  if (t < 52.0) return 2;
  return ramp(t, 52.0, 53.2, 2, 3, Easing.inOut(Easing.cubic));
};

const Scene4: React.FC<{t: number}> = ({t}) => {
  const h = hOf(t);
  const frac = Math.pow(0.5, h);
  const pct = frac * 100;
  const pctTxt = (pct >= 10 ? pct.toFixed(0) : pct.toFixed(1)).replace('.', ',');
  const inA = ramp(t, 36.2, 37.0, 0, 1, lin);
  const gx = (hh: number) => 160 + hh * 240;
  const gy = (f: number) => 1280 - 150 * f;
  const curve = Array.from({length: 61}, (_, i) => {
    const hh = (i / 60) * Math.min(h, 3.25);
    return [gx(hh), gy(Math.pow(0.5, hh))] as [number, number];
  });
  const gOn = ramp(t, 46.6, 47.4, 0, 1, lin);
  return (
    <Cam t={t} amp={0.5}>
      <Svg>
        <g opacity={inA}>
          {ATOMR.map((r, i) => {
            const cxp = 198 + (i % 10) * 76;
            const cyp = 640 + Math.floor(i / 10) * 76;
            const hd = Math.log2(1 / r);
            const q = ramp(h, hd, hd + 0.06, 0, 1, lin);
            const sc = 1 + 0.45 * Math.sin(Math.PI * q);
            const col = q < 0.5 ? C.orange : C.cyan;
            const bob = Math.sin(t * 3 + i) * 2.5;
            return (
              <g key={i} transform={`translate(${cxp},${cyp + bob}) scale(${sc})`}>
                {q > 0 && q < 1 && <circle r={26 + q * 34} fill="none" stroke={C.cyan} strokeWidth={4} opacity={1 - q} />}
                <circle r={25} fill={col} stroke="#000" strokeOpacity={0.45} strokeWidth={3} />
                <circle cx={-8} cy={-9} r={7} fill="#fff" opacity={0.55} />
              </g>
            );
          })}
          <SceneLabel x={CX} y={450} text="SISA ISOTOP INDUK" size={34} color="rgba(255,255,255,0.75)" />
          <SceneLabel x={CX} y={545} text={`${pctTxt}%`} size={92} color={C.orange} />
          <g transform="translate(0,1074)">
            <circle cx={170} cy={0} r={13} fill={C.orange} />
            <text x={196} y={10} fontFamily={sans} fontWeight={600} fontSize={26} fill="#fff">ISOTOP INDUK</text>
            <circle cx={560} cy={0} r={13} fill={C.cyan} />
            <text x={586} y={10} fontFamily={sans} fontWeight={600} fontSize={26} fill="#fff">UNSUR HASIL</text>
          </g>
        </g>
        <g opacity={gOn}>
          <line x1={150} y1={1280} x2={950} y2={1280} stroke="#fff" strokeOpacity={0.5} strokeWidth={3} />
          <line x1={160} y1={1100} x2={160} y2={1286} stroke="#fff" strokeOpacity={0.5} strokeWidth={3} />
          {h > 0.01 && <path d={`M ${P(curve)}`} fill="none" stroke={C.amber} strokeWidth={7} strokeLinecap="round" />}
          {[1, 2, 3].map((k) => {
            const on = ramp(h, k - 0.03, k + 0.02, 0, 1, lin);
            return (
              <g key={k} opacity={on}>
                <line x1={gx(k)} y1={gy(Math.pow(0.5, k))} x2={gx(k)} y2={1280} stroke="#fff" strokeOpacity={0.4} strokeWidth={3} strokeDasharray="6 8" />
                <circle cx={gx(k)} cy={gy(Math.pow(0.5, k))} r={13} fill={C.amber} stroke="#000" strokeWidth={3} />
                <SceneLabel x={gx(k)} y={gy(Math.pow(0.5, k)) - 24} text={['50%', '25%', '12,5%'][k - 1]} size={36} color={C.amber} />
                <SceneLabel x={gx(k)} y={1316} text={`${k}×`} size={30} color="rgba(255,255,255,0.8)" />
              </g>
            );
          })}
        </g>
      </Svg>
    </Cam>
  );
};

const Scene5: React.FC<{t: number}> = ({t}) => {
  const bar = ramp(t, 53.8, 55.2, 0, 1, outC);
  const dino = pop(t, 55.6, 0.6);
  const call = pop(t, 57.4, 0.5);
  const dash = ramp(t, 59.6, 61.0, 0, 1, Easing.inOut(Easing.cubic));
  const x = pop(t, 61.1, 0.4);
  return (
    <Cam t={t} amp={0.5}>
      <Svg>
        <g opacity={ramp(t, 53.6, 54.2, 0, 1, lin)}>
          <rect x={120} y={880} width={840 * bar} height={70} rx={8} fill="#26202e" stroke="rgba(255,255,255,0.35)" strokeWidth={3} />
          <rect x={120} y={880} width={10} height={70} fill={C.cyan} opacity={0.7 + 0.3 * Math.sin(t * 6)} />
          <SceneLabel x={120} y={986} text="0" size={34} color="rgba(255,255,255,0.8)" anchor="start" />
          <SceneLabel x={960} y={986} text="JUTAAN TAHUN" size={34} color="rgba(255,255,255,0.8)" anchor="end" />
          <text x={120} y={1028} fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.5)">
            ilustrasi, bukan skala sebenarnya
          </text>
        </g>
        <g transform={`translate(860,770) scale(${dino}) translate(-860,-770)`}>
          <DinoSkull x={860} y={770} s={0.85} glow={0.6} flip />
        </g>
        <g opacity={dino}>
          <SceneLabel x={850} y={846} text="FOSIL DINOSAURUS" size={34} color={C.amber} />
        </g>
        <g transform={`translate(300,700) scale(${call}) translate(-300,-700)`}>
          <line x1={125} y1={880} x2={190} y2={760} stroke={C.cyan} strokeWidth={4} />
          <rect x={70} y={640} width={460} height={120} rx={22} fill="rgba(20,16,28,0.92)" stroke={C.cyan} strokeWidth={4} />
          <SceneLabel x={300} y={690} text="KARBON-14" size={40} color={C.cyan} />
          <SceneLabel x={300} y={738} text="MAKS. ±50.000 TAHUN" size={32} color="#fff" />
        </g>
        <line x1={150} y1={915} x2={150 + 650 * dash} y2={915} stroke={C.red} strokeWidth={8} strokeDasharray="14 10" strokeLinecap="round" />
        <g transform={`translate(520,915) scale(${x})`}>
          <circle r={46} fill="#1b0f12" stroke={C.red} strokeWidth={6} />
          <path d="M -22 -22 L 22 22 M 22 -22 L -22 22" stroke={C.red} strokeWidth={10} strokeLinecap="round" />
        </g>
        <SceneLabel x={520} y={1100} text="TIDAK JANGKAU" size={60} color={C.red} o={ramp(t, 61.3, 61.8, 0, 1, lin)} />
      </Svg>
    </Cam>
  );
};

const Hex: React.FC<{x: number; y: number; r: number; glow: number}> = ({x, y, r, glow}) => (
  <g transform={`translate(${x},${y})`}>
    {glow > 0 && <circle r={r * 2.6} fill="url(#fGlow)" opacity={glow} />}
    <path d={Array.from({length: 6}, (_, i) => `${i ? 'L' : 'M'} ${Math.cos(rad(60 * i + 30)) * r} ${Math.sin(rad(60 * i + 30)) * r}`).join(' ') + ' Z'} fill={glow > 0.3 ? '#fff6d8' : '#e8ddc5'} stroke="#5a3d22" strokeWidth={2.5} />
  </g>
);

const Scene6: React.FC<{t: number}> = ({t}) => {
  const layers = [
    {h: 70, c: '#8a6a47'},
    {h: 70, c: '#cfcac2'},
    {h: 170, c: '#c9a468'},
    {h: 70, c: '#bdb7ae'},
    {h: 100, c: '#765536'},
  ];
  const prog = [0, 1, 2, 3, 4].map((i) => ramp(t, 65.8 + 0.25 * i, 66.3 + 0.25 * i, 0, 1, outC));
  const zt = [170, 260, 350, 450, 530];
  const gTop = win(t, 67.6, 69.4, 0.3);
  const gBot = win(t, 69.4, 71.2, 0.3);
  const cTop = Math.round(ramp(t, 67.6, 69.0, 0, 148, outC));
  const cBot = Math.round(ramp(t, 69.4, 70.8, 0, 150, outC));
  const pTop = pop(t, 67.8, 0.5);
  const pBot = pop(t, 69.6, 0.5);
  const res = pop(t, 73.6, 0.6);
  const panel = (y: number, label: string, val: number, p: number, col: string) => (
    <g transform={`translate(905,${y}) scale(${p})`}>
      <rect x={-135} y={-62} width={270} height={124} rx={20} fill="rgba(20,16,28,0.92)" stroke={col} strokeWidth={4} />
      <SceneLabel x={0} y={-24} text={label} size={30} color="rgba(255,255,255,0.8)" />
      <SceneLabel x={0} y={26} text={`${val} JUTA`} size={50} color={col} />
      <text y={50} textAnchor="middle" fontFamily={sans} fontWeight={600} fontSize={20} fill="rgba(255,255,255,0.6)">
        TAHUN (CONTOH)
      </text>
    </g>
  );
  return (
    <Cam t={t} amp={0.6}>
      <Svg>
        <Block x={90} y={620} w={500} d={170} layers={layers} t={t} prog={prog} idp="ash" />
        <g opacity={prog[2]}>
          <DinoSkull x={330} y={845} s={0.75} glow={0.55 + 0.2 * Math.sin(t * 4)} />
        </g>
        <g opacity={prog[1]}>
          {zt.map((x, i) => (
            <Hex key={'a' + i} x={x} y={726 + (i % 2) * 6} r={9} glow={gTop * (0.6 + 0.4 * Math.sin(t * 8 + i))} />
          ))}
        </g>
        <g opacity={prog[3]}>
          {zt.map((x, i) => (
            <Hex key={'b' + i} x={x + 18} y={965 + (i % 2) * 6} r={9} glow={gBot * (0.6 + 0.4 * Math.sin(t * 8 + i))} />
          ))}
        </g>
        {panel(725, 'ABU ATAS', cTop, pTop, C.cyan)}
        {panel(965, 'ABU BAWAH', cBot, pBot, C.orange)}
        <g opacity={ramp(t, 71.4, 72.0, 0, 1, lin)}>
          <line x1={905} y1={795} x2={905} y2={895} stroke="#fff" strokeOpacity={0.5} strokeWidth={4} strokeDasharray="6 8" />
          <SceneLabel x={905} y={826} text="FOSIL" size={34} color={C.amber} />
          <SceneLabel x={905} y={866} text="DI ANTARA" size={34} color={C.amber} />
        </g>
        <g transform={`translate(${CX},1215) scale(${res})`} opacity={Math.min(1, res)}>
          <rect x={-450} y={-72} width={900} height={144} rx={28} fill="rgba(20,16,28,0.94)" stroke={C.green} strokeWidth={5} />
          <SceneLabel x={0} y={14} text="FOSIL ≈ 148–150 JUTA TAHUN" size={54} color={C.green} />
          <text y={52} textAnchor="middle" fontFamily={sans} fontWeight={600} fontSize={24} fill="rgba(255,255,255,0.6)">
            angka contoh untuk ilustrasi
          </text>
        </g>
      </Svg>
    </Cam>
  );
};

const Chip: React.FC<{x: number; y: number; p: number; text: string; icon: React.ReactNode}> = ({x, y, p, text, icon}) => (
  <g transform={`translate(${x},${y}) scale(${Math.max(0.01, p)})`} opacity={Math.min(1, p * 1.4)}>
    <rect x={-450} y={-70} width={900} height={140} rx={30} fill="rgba(20,16,28,0.9)" stroke={C.orange} strokeWidth={4} />
    <g transform="translate(-350,0)">{icon}</g>
    <text x={-270} y={22} fontFamily={cond} fontWeight={700} fontSize={66} fill="#fff" letterSpacing="0.04em">
      {text}
    </text>
  </g>
);

const Scene7: React.FC<{t: number}> = ({t}) => {
  const out = ramp(t, 86.7, 87.2, 1, 0, lin);
  const end = ramp(t, 87.0, 87.8, 0, 1, outC);
  return (
    <Cam t={t} amp={0.4}>
      <Svg>
        <g opacity={out}>
          <Chip
            x={CX}
            y={620}
            p={pop(t, 83.4, 0.5)}
            text="PENGUKURAN"
            icon={
              <g stroke={C.amber} strokeWidth={6} strokeLinecap="round" fill="none">
                <rect x={-44} y={-20} width={88} height={40} rx={6} />
                {[-28, -14, 0, 14, 28].map((k) => (
                  <line key={k} x1={k} y1={-20} x2={k} y2={k % 28 === 0 ? 2 : -6} />
                ))}
              </g>
            }
          />
          <Chip
            x={CX}
            y={800}
            p={pop(t, 84.5, 0.5)}
            text="BUKTI GEOLOGI"
            icon={
              <g>
                {[LAY[0], LAY[2], LAY[3], LAY[4]].map((c, i) => (
                  <rect key={i} x={-44} y={-40 + i * 20} width={88} height={18} rx={3} fill={c} stroke="#000" strokeOpacity={0.4} strokeWidth={2} />
                ))}
              </g>
            }
          />
          <Chip
            x={CX}
            y={980}
            p={pop(t, 85.5, 0.5)}
            text="PENELITIAN ILMIAH"
            icon={
              <g stroke={C.cyan} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" fill="none">
                <path d="M -14 -44 L -14 -8 L -42 40 L 42 40 L 14 -8 L 14 -44 Z" />
                <path d="M -30 18 L 30 18" />
              </g>
            }
          />
        </g>
        <g opacity={end}>
          <rect x={0} y={0} width={W} height={H} fill="#000" opacity={0.55} />
          <text x={CX} y={780 + (1 - end) * 30} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={118} letterSpacing="0.05em" fill="#fff">
            SEMESTA<tspan fill={C.orange}>KITA</tspan>
          </text>
          <rect x={CX - 70} y={820} width={140} height={4} fill={C.orange} />
          <text x={CX} y={930} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={64} letterSpacing="0.05em" fill="rgba(255,255,255,0.9)">
            FOLLOW UNTUK FAKTA
          </text>
          <text x={CX} y={1004} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={64} letterSpacing="0.05em" fill="rgba(255,255,255,0.9)">
            SEMESTA LAINNYA
          </text>
        </g>
      </Svg>
    </Cam>
  );
};

/* ---------- komposisi utama ---------- */

export const Fosil: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const on = (i: number, post = 0.8) => t >= SC[i] - 0.05 && t < SC[i] + SD[i] + post;
  const fadeIn = ramp(t, 0, 0.25, 1, 0, lin);
  const fadeOut = ramp(t, 89.2, 90, 0, 1, lin);

  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Bg t={t} />
      {on(0, 0.6) && <Scene0 t={t} />}
      {on(1) && <Scene1 t={t} />}
      {on(2) && <Scene2 t={t} />}
      {on(3) && <Scene3 t={t} />}
      {on(4) && <Scene4 t={t} />}
      {on(5) && <Scene5 t={t} />}
      {on(6) && <Scene6 t={t} />}
      {on(7, 1) && <Scene7 t={t} />}

      <Title t={t} lines={['BAGAIMANA ILMUWAN', 'TAHU USIA FOSIL', 'JUTAAN TAHUN?']} start={0.05} end={3.9} y={200} size={88} step={0.08} />
      <Title t={t} lines={['PERNAHKAH KAMU', 'BERTANYA-TANYA?']} start={3.9} end={8.2} y={190} size={96} />
      <Title t={t} lines={['PADAHAL TIDAK ADA', 'YANG MENYAKSIKANNYA']} start={8.5} end={13.0} y={190} size={80} color="#fff" />
      <Title t={t} lines={['JAWABANNYA:']} start={13.1} end={17.0} y={190} size={120} />
      <Title t={t} lines={['PENANGGALAN', 'RELATIF']} start={17.3} end={20.1} y={190} size={104} />
      <Title t={t} lines={['FOSIL DI DALAM', 'BATUAN SEDIMEN']} start={20.3} end={23.6} y={190} size={88} />
      <Title t={t} lines={['LAPISAN BAWAH =', 'LEBIH TUA']} start={23.8} end={30.4} y={190} size={88} />
      <Title t={t} lines={['HANYA URUTAN,', 'BUKAN ANGKA']} start={30.7} end={35.8} y={190} size={96} color={C.amber} />
      <Title t={t} lines={['PENANGGALAN', 'RADIOMETRIK']} start={36.1} end={40.3} y={190} size={100} />
      <Title t={t} lines={['PELURUHAN', 'ISOTOP RADIOAKTIF']} start={40.6} end={46.7} y={190} size={84} />
      <Title t={t} lines={['WAKTU PARUH']} start={47.0} end={53.3} y={190} size={120} color={C.amber} />
      <Title t={t} lines={['LALU, FOSIL', 'DINOSAURUS?']} start={53.5} end={56.7} y={190} size={104} />
      <Title t={t} lines={['KARBON-14 HANYA', 'UNTUK MATERIAL MUDA']} start={56.9} end={65.4} y={190} size={80} />
      <Title t={t} lines={['MINERAL DI ABU', 'VULKANIK']} start={65.7} end={73.1} y={190} size={92} />
      <Title t={t} lines={['GABUNGKAN', 'DUA BUKTI']} start={73.4} end={79.7} y={190} size={104} color={C.green} />
      <Title t={t} lines={['BUKAN SEKADAR', 'TEBAKAN']} start={80.0} end={86.9} y={190} size={104} />

      <Meme t={t} a={10.8} b={13.0} mood="confused" lines={['TERUS GIMANA', 'TAHUNNYA?!']} ty={800} />
      <Meme t={t} a={50.6} b={52.9} mood="brow" lines={['SETENGAH-', 'SETENGAH TERUS?']} ty={780} size={104} />
      <Meme t={t} a={62.0} b={64.6} mood="tired" lines={['NGGAK KUAT', 'BOS']} ty={800} />

      <Audio src={staticFile('audio.mp3')} />
      <Caption t={t} />
      <Hud t={t} />
      <Watermark t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
