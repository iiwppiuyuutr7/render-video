import {SONG_SECONDS} from "./config";

export type RawLine = {
  /** detik mulai baris */
  t: number;
  text: string;
  /** (opsional) lama baris "dinyanyikan" dalam detik */
  dur?: number;
};

export const RAW_LYRICS: RawLine[] = [
  {t: 15.76, text: "I'm scared (ooh-ooh-ooh)"},
  {t: 21.25, text: "It feels like you don't care (ooh-ooh)"},
  {t: 28.45, text: "Enlighten me, my dear (ooh-ooh-ooh)"},
  {t: 36.0, text: "Why am I still here? Mm (ooh-ooh)"},
  {t: 43.06, text: "I don't mean to be"},
  {t: 45.0, text: "Complacent with the decisions you made"},
  {t: 51.49, text: "But why? Mm", dur: 3.0},
  {t: 58.36, text: "In the back of my mind, you died"},
  {t: 65.18, text: "And I didn't even cry"},
  {t: 68.67, text: "No, not a single tear"},
  {t: 72.32, text: "And I'm sick of waiting patiently"},
  {t: 77.33, text: "For someone that won't even arrive"},
  {t: 88.77, text: "Oh-oh-oh-oh-oh-oh", dur: 7.0},
  {t: 101.96, text: "In the back of my mind, I killed you"},
  {t: 108.64, text: "And I didn't even regret it"},
  {t: 112.86, text: "I can't believe I said it"},
  {t: 116.41, text: "But it's true"},
  {t: 123.96, text: "I hate you", dur: 3.2},
];

export type Word = {
  text: string;
  adlib: boolean;
  /** detik mulai & selesai highlight kata */
  start: number;
  end: number;
};

export type LyricItem =
  | {kind: "dots"; start: number; end: number; height: number}
  | {
      kind: "line";
      start: number;
      end: number;
      rows: Word[][];
      height: number;
    };

export const LINE_HEIGHT = 82; // px per baris teks
export const ITEM_GAP = 46; // px jarak antar lirik
const SPLIT_OVER = 20; // karakter; lebih panjang dari ini dipecah jadi 2 baris

/** Pecah teks jadi 1-2 baris yang seimbang (tanpa mengukur DOM, supaya deterministik). */
function splitBalanced(words: string[]): string[][] {
  const full = words.join(" ");
  if (full.length <= SPLIT_OVER || words.length < 2) return [words];
  let best = 1;
  let bestScore = Infinity;
  for (let i = 1; i < words.length; i++) {
    const a = words.slice(0, i).join(" ").length;
    const b = words.slice(i).join(" ").length;
    const score = Math.max(a, b);
    if (score < bestScore) {
      bestScore = score;
      best = i;
    }
  }
  return [words.slice(0, best), words.slice(best)];
}

export function buildItems(): LyricItem[] {
  const items: LyricItem[] = [];
  const firstStart = RAW_LYRICS[0].t;

  // Interlude: tiga titik sebelum lirik pertama
  items.push({kind: "dots", start: 0, end: firstStart, height: 110});

  RAW_LYRICS.forEach((raw, i) => {
    const next = i + 1 < RAW_LYRICS.length ? RAW_LYRICS[i + 1].t : SONG_SECONDS;
    const gap = next - raw.t;
    const tokens = raw.text.split(/\s+/);
    const weights = tokens.map((w) => {
      const adlib = w.startsWith("(");
      const clean = w.replace(/[^A-Za-z']/g, "");
      return Math.max(2, clean.length) * (adlib ? 1.8 : 1) + 2;
    });
    const total = weights.reduce((a, b) => a + b, 0);
    const sing = Math.max(
      0.5,
      Math.min(gap - 0.12, raw.dur ?? 0.6 + total * 0.075),
    );

    let acc = 0;
    const timed: Word[] = tokens.map((w, k) => {
      const s = raw.t + (acc / total) * sing;
      acc += weights[k];
      const e = raw.t + (acc / total) * sing;
      return {text: w, adlib: w.startsWith("("), start: s, end: e};
    });

    // pecah baris tampilan berdasarkan teks, lalu petakan kembali ke kata ber-timing
    const rowsText = splitBalanced(tokens);
    const rows: Word[][] = [];
    let cursor = 0;
    for (const r of rowsText) {
      rows.push(timed.slice(cursor, cursor + r.length));
      cursor += r.length;
    }

    items.push({
      kind: "line",
      start: raw.t,
      end: raw.t + sing,
      rows,
      height: rows.length * LINE_HEIGHT + ITEM_GAP,
    });
  });

  return items;
}
