// Satu-satunya sumber FPS / ukuran / durasi untuk seluruh video.
export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Durasi lagu (detik) dari file MP3.
export const SONG_SECONDS = 132.68;
export const DURATION_IN_FRAMES = Math.ceil(SONG_SECONDS * FPS);

export const COMPOSITION_ID = "LyricVideo";

export const TITLE = "Romantic Homicide";
export const ARTIST = "d4vd";
