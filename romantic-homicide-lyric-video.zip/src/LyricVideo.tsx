import React, {useMemo} from "react";
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from "remotion";
import {loadFont as loadPlayfair} from "@remotion/google-fonts/PlayfairDisplay";
import {loadFont as loadInter} from "@remotion/google-fonts/Inter";
import {
  ARTIST,
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  TITLE,
  WIDTH,
} from "./config";
import {buildItems, ITEM_GAP, LyricItem, Word} from "./lyrics";

const playfair = loadPlayfair("normal", {
  weights: ["500", "600"],
  subsets: ["latin"],
});
loadPlayfair("italic", {weights: ["500"], subsets: ["latin"]});
const inter = loadInter("normal", {
  weights: ["400", "500"],
  subsets: ["latin"],
});

const SERIF = playfair.fontFamily;
const SANS = inter.fontFamily;

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const mod = (v: number, m: number) => ((v % m) + m) % m;

// ---------------------------------------------------------------------------
// Layout lirik (dihitung sekali)
// ---------------------------------------------------------------------------
const ITEMS: LyricItem[] = buildItems();
const TOPS: number[] = [];
const CENTERS: number[] = [];
{
  let y = 0;
  for (const it of ITEMS) {
    TOPS.push(y);
    const contentH = it.height - ITEM_GAP;
    CENTERS.push(y + contentH / 2);
    y += it.height;
  }
}

const LYRIC_LEFT = 985;
const LYRIC_WIDTH = 860;
const LYRIC_ANCHOR_Y = 485; // posisi vertikal baris aktif
const FONT_SIZE = 64;

const TRANSITION_SEC = 0.95;
const LEAD_SEC = 0.15;
const scrollEase = Easing.bezier(0.25, 0.8, 0.25, 1);

/** Posisi scroll pecahan (0 = item pertama aktif). */
function scrollPos(t: number): number {
  let pos = 0;
  for (let j = 1; j < ITEMS.length; j++) {
    const begin = ITEMS[j].start - LEAD_SEC;
    pos += scrollEase(clamp01((t - begin) / TRANSITION_SEC));
  }
  return pos;
}

// ---------------------------------------------------------------------------
// Latar sinematik
// ---------------------------------------------------------------------------
type Mote = {x: number; y: number; size: number; speed: number; phase: number};
const MOTES: Mote[] = Array.from({length: 54}, (_, i) => ({
  x: random(`mote-x-${i}`) * WIDTH,
  y: random(`mote-y-${i}`) * (HEIGHT + 120),
  size: 2 + random(`mote-s-${i}`) * 5,
  speed: 8 + random(`mote-v-${i}`) * 26,
  phase: random(`mote-p-${i}`) * Math.PI * 2,
}));

const Background: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const progress = frame / DURATION_IN_FRAMES;
  const scale = 1.05 + progress * 0.22;
  const rot = -4 + progress * 8;
  const driftX = Math.sin(t * 0.11) * 90;
  const driftY = Math.cos(t * 0.09) * 70;

  const wash1x = 28 + Math.sin(t * 0.17) * 14;
  const wash1y = 62 + Math.cos(t * 0.13) * 16;
  const wash2x = 76 + Math.cos(t * 0.15) * 12;
  const wash2y = 30 + Math.sin(t * 0.19) * 14;
  const leak = 0.2 + (Math.sin(t * 0.35) + 1) * 0.07;

  return (
    <AbsoluteFill style={{backgroundColor: "#050203", overflow: "hidden"}}>
      <Img
        src={staticFile("cover.png")}
        style={{
          position: "absolute",
          width: 2300,
          height: 2300,
          left: (WIDTH - 2300) / 2 + driftX,
          top: (HEIGHT - 2300) / 2 + driftY,
          transform: `rotate(${rot}deg) scale(${scale})`,
          filter: "blur(85px) saturate(1.5) brightness(0.55)",
          opacity: 0.92,
        }}
      />
      <AbsoluteFill
        style={{
          background: `radial-gradient(900px 700px at ${wash1x}% ${wash1y}%, rgba(160,18,34,0.34), transparent 70%), radial-gradient(1000px 800px at ${wash2x}% ${wash2y}%, rgba(110,10,24,0.38), transparent 72%)`,
        }}
      />
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(115deg, rgba(255,110,70,0.0) 30%, rgba(255,90,60,0.55) 78%, rgba(255,170,120,0.0) 100%)",
          mixBlendMode: "screen",
          opacity: leak,
        }}
      />
      {MOTES.map((m, i) => {
        const y = mod(m.y - t * m.speed, HEIGHT + 120) - 60;
        const x = m.x + Math.sin(t * 0.4 + m.phase) * 26;
        const flicker = 0.35 + 0.65 * ((Math.sin(t * 1.3 + m.phase * 3) + 1) / 2);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: m.size,
              height: m.size,
              borderRadius: "50%",
              background: "rgba(255,185,165,0.9)",
              opacity: flicker * (m.size > 5 ? 0.22 : 0.42),
              filter: `blur(${m.size > 5 ? 3 : 1}px)`,
              boxShadow: "0 0 12px rgba(255,120,100,0.6)",
            }}
          />
        );
      })}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 38%, rgba(0,0,0,0.78) 100%)",
        }}
      />
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.65) 0%, rgba(0,0,0,0) 17%, rgba(0,0,0,0) 83%, rgba(0,0,0,0.7) 100%)",
        }}
      />
    </AbsoluteFill>
  );
};

const Grain: React.FC<{frame: number}> = ({frame}) => {
  const seed = Math.floor(frame / 3) % 64;
  return (
    <AbsoluteFill style={{mixBlendMode: "overlay", opacity: 0.13}}>
      <svg width={WIDTH} height={HEIGHT}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.85"
            numOctaves={2}
            seed={seed}
            stitchTiles="stitch"
          />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------------------
// Cover + judul
// ---------------------------------------------------------------------------
const CoverBlock: React.FC<{t: number; frame: number}> = ({t, frame}) => {
  const COVER = 560;
  const enter = Easing.out(Easing.cubic)(clamp01(t / 2.2));
  const progress = frame / DURATION_IN_FRAMES;
  const scale = 1 + progress * 0.035 + Math.sin(t * 0.9) * 0.004;
  const floatY = Math.sin(t * 0.55) * 6;

  return (
    <div
      style={{
        position: "absolute",
        left: 190,
        top: 205,
        width: COVER,
        opacity: enter,
        transform: `translateY(${(1 - enter) * 36 + floatY}px)`,
      }}
    >
      <div
        style={{
          width: COVER,
          height: COVER,
          borderRadius: 14,
          overflow: "hidden",
          transform: `scale(${scale})`,
          boxShadow:
            "0 50px 130px rgba(0,0,0,0.75), 0 0 140px rgba(176,22,38,0.32), 0 0 0 1px rgba(255,255,255,0.07)",
        }}
      >
        <Img
          src={staticFile("cover.png")}
          style={{width: COVER, height: COVER, objectFit: "cover"}}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(135deg, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0) 38%)",
          }}
        />
      </div>
      <div style={{marginTop: 46}}>
        <div
          style={{
            fontFamily: SERIF,
            fontWeight: 600,
            fontSize: 46,
            letterSpacing: "0.01em",
            color: "#fff6f2",
            lineHeight: 1.1,
          }}
        >
          {TITLE}
        </div>
        <div
          style={{
            marginTop: 16,
            fontFamily: SANS,
            fontWeight: 500,
            fontSize: 21,
            letterSpacing: "0.28em",
            color: "rgba(255,225,215,0.58)",
          }}
        >
          {ARTIST}
        </div>
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// Lirik
// ---------------------------------------------------------------------------
const WordSpan: React.FC<{word: Word; t: number; emphasis: number}> = ({
  word,
  t,
  emphasis,
}) => {
  const span = Math.max(0.05, word.end - word.start);
  const p = clamp01((t - word.start) / span);
  const unsung = 1 - 0.64 * emphasis;
  const a = p * 112 - 12;
  const b = p * 112;
  return (
    <span
      style={{
        display: "inline-block",
        marginRight: "0.27em",
        fontStyle: word.adlib ? "italic" : "normal",
        fontWeight: word.adlib ? 500 : 600,
        fontSize: word.adlib ? "0.8em" : "1em",
        color: "transparent",
        backgroundImage: `linear-gradient(90deg, rgba(255,247,243,1) ${a}%, rgba(255,247,243,${unsung}) ${b}%)`,
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
      }}
    >
      {word.text}
    </span>
  );
};

const DotsItem: React.FC<{
  item: Extract<LyricItem, {kind: "dots"}>;
  t: number;
  dist: number;
}> = ({item, t, dist}) => {
  const vis = interpolate(dist, [0, 0.9], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const third = (item.end - item.start) / 3;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 26,
        height: "100%",
        opacity: vis,
        transform: `scale(${0.85 + vis * 0.15})`,
        transformOrigin: "left center",
      }}
    >
      {[0, 1, 2].map((k) => {
        const lit = clamp01((t - (item.start + k * third)) / third);
        const breathe = 1 + 0.14 * Math.sin(t * Math.PI * 1.2 + k * 0.9);
        return (
          <div
            key={k}
            style={{
              width: 24,
              height: 24,
              borderRadius: "50%",
              background: "#fff4ee",
              opacity: 0.28 + 0.72 * lit,
              transform: `scale(${(0.8 + 0.3 * lit) * breathe})`,
              boxShadow: `0 0 ${22 * lit}px rgba(255,140,120,${0.6 * lit})`,
            }}
          />
        );
      })}
    </div>
  );
};

const Lyrics: React.FC<{t: number}> = ({t}) => {
  const pos = scrollPos(t);
  const lo = Math.min(ITEMS.length - 1, Math.max(0, Math.floor(pos)));
  const hi = Math.min(ITEMS.length - 1, lo + 1);
  const frac = pos - lo;
  const center = CENTERS[lo] + (CENTERS[hi] - CENTERS[lo]) * frac;
  const translateY = LYRIC_ANCHOR_Y - center;

  const enter = Easing.out(Easing.cubic)(clamp01((t - 0.6) / 1.8));

  return (
    <div
      style={{
        position: "absolute",
        left: LYRIC_LEFT,
        top: 0,
        width: LYRIC_WIDTH,
        height: HEIGHT,
        opacity: enter,
        overflow: "hidden",
        WebkitMaskImage:
          "linear-gradient(180deg, transparent 0%, #000 20%, #000 78%, transparent 100%)",
        maskImage:
          "linear-gradient(180deg, transparent 0%, #000 20%, #000 78%, transparent 100%)",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          width: LYRIC_WIDTH,
          transform: `translateY(${translateY}px)`,
        }}
      >
        {ITEMS.map((item, i) => {
          const dist = Math.abs(i - pos);
          const contentH = item.height - ITEM_GAP;
          const base: React.CSSProperties = {
            position: "absolute",
            left: 0,
            top: TOPS[i],
            width: LYRIC_WIDTH,
            height: contentH,
          };
          if (item.kind === "dots") {
            return (
              <div key={i} style={base}>
                <DotsItem item={item} t={t} dist={dist} />
              </div>
            );
          }
          const emphasis = clamp01(1 - dist);
          const opacity = interpolate(dist, [0, 1, 2, 3], [1, 0.3, 0.17, 0.07], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          });
          const blur = interpolate(dist, [0, 1, 2, 3], [0, 1.4, 2.8, 4.2], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          });
          const scale = 0.93 + 0.07 * emphasis;
          return (
            <div
              key={i}
              style={{
                ...base,
                opacity,
                transform: `scale(${scale})`,
                transformOrigin: "left center",
                filter: `blur(${blur}px) drop-shadow(0 0 ${
                  26 * emphasis
                }px rgba(255,110,95,${0.42 * emphasis}))`,
                fontFamily: SERIF,
                fontSize: FONT_SIZE,
                lineHeight: `${contentH / item.rows.length}px`,
                whiteSpace: "nowrap",
              }}
            >
              {item.rows.map((row, r) => (
                <div key={r}>
                  {row.map((w, k) => (
                    <WordSpan key={k} word={w} t={t} emphasis={emphasis} />
                  ))}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ---------------------------------------------------------------------------
// Komposisi utama
// ---------------------------------------------------------------------------
export const LyricVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;

  const fadeIn = interpolate(frame, [0, 1.6 * FPS], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const fadeOut = interpolate(
    frame,
    [DURATION_IN_FRAMES - 2.4 * FPS, DURATION_IN_FRAMES],
    [0, 1],
    {extrapolateLeft: "clamp", extrapolateRight: "clamp"},
  );
  const blackout = Math.max(fadeIn, fadeOut);

  const volume = useMemo(
    () => (f: number) =>
      interpolate(f, [DURATION_IN_FRAMES - 1.6 * FPS, DURATION_IN_FRAMES], [1, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
    [],
  );

  return (
    <AbsoluteFill style={{backgroundColor: "#000"}}>
      <Audio src={staticFile("romantic-homicide.mp3")} volume={volume} />
      <Background t={t} frame={frame} />
      <CoverBlock t={t} frame={frame} />
      <Lyrics t={t} />
      <Grain frame={frame} />
      <AbsoluteFill style={{backgroundColor: "#000", opacity: blackout}} />
    </AbsoluteFill>
  );
};
