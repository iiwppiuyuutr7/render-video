import React from 'react';
import {Composition} from 'remotion';
import {Alam, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Alam';

export const RemotionRoot: React.FC = () => (
  <Composition id="Alam" component={Alam} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
