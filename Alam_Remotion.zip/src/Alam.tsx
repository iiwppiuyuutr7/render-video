import React from 'react';
import {AbsoluteFill, Audio, OffthreadVideo, Sequence, staticFile, useCurrentFrame} from 'remotion';

/* =====================================================================
   ALAM  –  Kokurikuler • Gaya Hidup Berkelanjutan • Hari Pertama
   1920x1080 • 30 fps • ±31 detik • audio klip asli DIBISUKAN
   Audio: public/audio.mp3 (sintetis, sinkron dengan transisi & teks)

   KLIP (taruh di folder public/):
     luar.mp4          -> klip OUTDOOR kerja bakti (pembuka)
     kelas-singkat.mp4 -> klip pendek 1 detik (kelas, wide)
     kelas.mp4         -> kelas, siswa memotong botol plastik
     gunting.mp4       -> close-up gunting & botol
     meja.mp4          -> siswa di meja (top-down)

   Mau ganti teks? Edit TITLE/SUBTITLE/BADGE dan daftar `caps` di SEGS.
   Tanda *kata* = kata yang di-highlight kuning.
   ===================================================================== */
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// ---------- ubah teks di sini ----------
const TITLE = 'KOKURIKULER';
const SUBTITLE = 'GAYA HIDUP BERKELANJUTAN';
const BADGE = 'HARI PERTAMA';
const BUG = 'KOKURIKULER  •  HARI 1';
const USE_AUDIO = true;
const GRAIN = true;
const OVERLAP = 0.6; // durasi transisi (detik)

const FONT = "'Poppins','Montserrat','Inter','Segoe UI','Helvetica Neue',Arial,sans-serif";

// ---------- palet ----------
const LIME = '#c8ff4d';
const GREEN = '#3ddc84';
const LEAF2 = '#1faa59';
const GOLD = '#ffe14d';
const DEEP = '#0a3d1c';
const WHITE = '#ffffff';

// ---------- util ----------
const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const sm = (p: number) => {
  const x = clamp(p);
  return x * x * (3 - 2 * x);
};
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const eo = (p: number) => 1 - Math.pow(1 - clamp(p), 3);
const ei = (p: number) => Math.pow(clamp(p), 3);
const eio = (p: number) => {
  const x = clamp(p);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
const back = (p: number) => {
  const x = clamp(p);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
const rnd = (seed: number) => {
  let a = seed * 9301 + 49297;
  a = Math.imul(a ^ (a >>> 15), 2246822507);
  a = Math.imul(a ^ (a >>> 13), 3266489909);
  return ((a ^ (a >>> 16)) >>> 0) / 4294967296;
};
const mod = (a: number, n: number) => ((a % n) + n) % n;
const gauss = (t: number, t0: number, w: number) => Math.exp(-Math.pow((t - t0) / w, 2));

// =====================================================================
// TIMELINE
// =====================================================================
type Kind = 'zoomBlur' | 'push' | 'iris' | 'diag' | 'flash';

interface Cap {
  t0: number; // detik, relatif awal segmen
  t1: number;
  text: string; // *kata* = highlight
  y?: number; // posisi tengah teks dari atas (px). kosong = bawah layar
  size?: number;
}

interface Seg {
  id: string;
  src?: string; // kosong = end card
  from?: number; // detik di klip sumber
  dur: number; // detik di timeline
  rate?: number;
  z: [number, number]; // zoom awal -> akhir (Ken Burns)
  drift?: [number, number]; // geser px (awal -> akhir)
  trans?: Kind; // transisi MASUK dari segmen sebelumnya
  caps: Cap[];
}

const SEGS: Seg[] = [
  {
    id: 'luar',
    src: 'luar.mp4',
    from: 0,
    dur: 7.9,
    z: [1.0, 1.1],
    caps: [{t0: 4.4, t1: 7.2, text: 'Mulai dari *lingkungan sekolah*'}],
  },
  {
    id: 'kelas-wide',
    src: 'kelas-singkat.mp4',
    from: 0,
    rate: 0.45, // klip cuma 1.1 dtk -> di-slow-mo
    dur: 2.4,
    z: [1.1, 1.0],
    trans: 'zoomBlur',
    caps: [{t0: 0.55, t1: 1.9, text: 'Lalu, *beraksi di kelas*'}],
  },
  {
    id: 'kelas',
    src: 'kelas.mp4',
    from: 4.5,
    dur: 6.5,
    z: [1.0, 1.12],
    drift: [0, -30],
    trans: 'push',
    caps: [
      {t0: 0.8, t1: 3.3, text: 'Botol plastik bekas, *bukan sampah*'},
      {t0: 3.6, t1: 5.8, text: 'tapi *bahan karya*'},
    ],
  },
  {
    id: 'gunting',
    src: 'gunting.mp4',
    from: 1.0,
    dur: 5.5,
    z: [1.12, 1.0],
    trans: 'iris',
    caps: [
      {t0: 0.8, t1: 2.8, text: 'Dipotong dengan *teliti*'},
      {t0: 3.0, t1: 4.9, text: 'dan *diolah ulang*'},
    ],
  },
  {
    id: 'meja',
    src: 'meja.mp4',
    from: 1.0,
    dur: 7.0,
    z: [1.0, 1.14],
    drift: [-40, 0],
    trans: 'diag',
    caps: [
      {t0: 0.8, t1: 3.4, text: 'Kerja sama *satu tim*'},
      {t0: 3.7, t1: 6.2, text: 'ide kreatif *tanpa batas*'},
    ],
  },
  {
    id: 'end',
    dur: 4.6,
    z: [1, 1],
    trans: 'flash',
    caps: [
      {t0: 1.0, t1: 4.3, text: 'Langkah kecil,', y: 330, size: 130},
      {t0: 1.7, t1: 4.3, text: 'dampak *besar*', y: 480, size: 130},
      {t0: 2.7, t1: 4.3, text: 'Kokurikuler • Gaya Hidup Berkelanjutan • Hari Pertama', y: 610, size: 40},
    ],
  },
];

const OV_F = Math.round(OVERLAP * FPS);
const SEG_FRAMES = SEGS.map((s) => Math.round(s.dur * FPS));
export const SEG_START: number[] = [];
SEGS.forEach((_, i) => {
  SEG_START.push(i === 0 ? 0 : SEG_START[i - 1] + SEG_FRAMES[i - 1] - OV_F);
});
export const TOTAL_FRAMES = SEG_START[SEGS.length - 1] + SEG_FRAMES[SEGS.length - 1];
export const TOTAL_SECONDS = TOTAL_FRAMES / FPS;

interface AbsCap extends Cap {
  a0: number; // detik absolut
  a1: number;
}
export const CAPS_ABS: AbsCap[] = SEGS.flatMap((s, i) =>
  s.caps.map((c) => ({...c, a0: SEG_START[i] / FPS + c.t0, a1: SEG_START[i] / FPS + c.t1}))
);
export const TRANSITIONS = SEGS.map((s, i) => ({i, kind: s.trans, t: SEG_START[i] / FPS})).filter((x) => x.i > 0);

// =====================================================================
// DEFS global
// =====================================================================
const FR = {filterUnits: 'userSpaceOnUse' as const, x: -500, y: -500, width: 2920, height: 2080};
const Defs: React.FC = () => (
  <svg width={0} height={0} style={{position: 'absolute'}}>
    <defs>
      <filter id="glow" {...FR}><feGaussianBlur stdDeviation="6" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      <filter id="glowL" {...FR}><feGaussianBlur stdDeviation="16" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      <filter id="blurM" {...FR}><feGaussianBlur stdDeviation="14" /></filter>
      <linearGradient id="streakG" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stopColor="#fff" stopOpacity="0" /><stop offset="0.5" stopColor="#fff" stopOpacity="1" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
      <radialGradient id="sunG"><stop offset="0" stopColor="#fff6dc" stopOpacity="1" /><stop offset="0.25" stopColor="#ffd98a" stopOpacity="0.75" /><stop offset="1" stopColor="#ff9a4a" stopOpacity="0" /></radialGradient>
    </defs>
  </svg>
);

const Full: React.FC<{children?: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0, ...style}}>
    {children}
  </svg>
);

// =====================================================================
// DAUN
// =====================================================================
const LEAF = 'M0 0C12-26 44-30 68-4C44 22 12 26 0 0Z';
const LEAF_RIB = 'M0 0C22-3 44-4 64-4';
const LEAF_COLORS = [LIME, GREEN, LEAF2, GOLD];

const Leaf: React.FC<{x: number; y: number; rot: number; s: number; c: string; op?: number}> = ({x, y, rot, s, c, op = 1}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} opacity={op}>
    <path d={LEAF} fill={c} />
    <path d={LEAF_RIB} stroke="rgba(0,40,10,0.45)" strokeWidth={2} fill="none" />
  </g>
);

const LeafSwarm: React.FC<{p: number; seed: number; count?: number; dir?: 1 | -1}> = ({p, seed, count = 26, dir = 1}) => (
  <Full>
    {Array.from({length: count}).map((_, i) => {
      const r1 = rnd(seed * 100 + i * 3 + 1);
      const r2 = rnd(seed * 100 + i * 3 + 2);
      const r3 = rnd(seed * 100 + i * 3 + 3);
      const delay = r1 * 0.35;
      const q = clamp((p - delay) / (1 - delay));
      const xs = dir === 1 ? -200 : WIDTH + 200;
      const xe = dir === 1 ? WIDTH + 200 : -200;
      const x = lerp(xs, xe, eio(q));
      const y = 100 + r2 * 880 + Math.sin(q * 6 + i) * 70;
      const rot = q * 360 * (r3 > 0.5 ? 1 : -1) + r1 * 360;
      return <Leaf key={i} x={x} y={y} rot={rot} s={0.7 + r2 * 1.3} c={LEAF_COLORS[i % 4]} op={0.95 * Math.sin(Math.PI * clamp(q * 0.98 + 0.01))} />;
    })}
  </Full>
);

// =====================================================================
// TRANSISI (efek pada layer segmen)
// =====================================================================
interface FX {
  tf: string;
  fl: string;
  op: number;
  clip?: string;
}
const NONE: FX = {tf: '', fl: '', op: 1};
const SLANT = 320;

const fxIn = (k: Kind, p: number): FX => {
  if (p >= 1) return NONE;
  switch (k) {
    case 'zoomBlur':
      return {tf: `scale(${1 + 0.45 * (1 - eo(p))})`, fl: `blur(${22 * (1 - p)}px) brightness(${1 + 0.5 * (1 - p)})`, op: sm(prog(p, 0.1, 0.55))};
    case 'push': {
      const s = Math.sin(Math.PI * p);
      return {tf: `translateX(${(1 - eio(p)) * WIDTH}px) skewX(${-10 * s}deg) scale(${1 + 0.06 * (1 - eio(p))})`, fl: `blur(${26 * s}px)`, op: 1};
    }
    case 'iris':
      return {tf: `scale(${1 + 0.12 * (1 - eo(p))})`, fl: '', op: 1, clip: `circle(${lerp(0, 1300, eio(p))}px at 50% 50%)`};
    case 'diag': {
      const x = lerp(-SLANT, WIDTH + SLANT, eio(p));
      return {tf: '', fl: '', op: 1, clip: `polygon(0px 0px, ${x}px 0px, ${x - SLANT}px ${HEIGHT}px, 0px ${HEIGHT}px)`};
    }
    case 'flash':
      return {tf: `scale(${1 + 0.12 * (1 - eo(p))})`, fl: `blur(${10 * (1 - p)}px)`, op: sm(prog(p, 0.35, 0.85))};
  }
};

const fxOut = (k: Kind, p: number): FX => {
  if (p <= 0) return NONE;
  switch (k) {
    case 'zoomBlur':
      return {tf: `scale(${1 + 0.8 * ei(p)})`, fl: `blur(${24 * p}px)`, op: 1 - sm(prog(p, 0.45, 0.95))};
    case 'push': {
      const s = Math.sin(Math.PI * p);
      return {tf: `translateX(${-eio(p) * WIDTH}px) skewX(${-10 * s}deg)`, fl: `blur(${26 * s}px)`, op: 1};
    }
    case 'iris':
      return {tf: `scale(${1 + 0.15 * eo(p)})`, fl: `brightness(${1 - 0.35 * p})`, op: 1};
    case 'diag':
      return {tf: `translateX(${-80 * eio(p)}px)`, fl: `brightness(${1 - 0.3 * p})`, op: 1};
    case 'flash':
      return {tf: `scale(${1 + 0.14 * ei(p)})`, fl: `blur(${12 * p}px) brightness(${1 + 0.8 * p})`, op: 1 - sm(prog(p, 0.6, 1))};
  }
};

// efek global di atas transisi (garis kecepatan, cincin, daun, flash)
const TransitionFX: React.FC<{frame: number}> = ({frame}) => (
  <>
    {TRANSITIONS.map(({i, kind}) => {
      const p = prog(frame, SEG_START[i], SEG_START[i] + OV_F);
      if (p <= 0 || p >= 1 || !kind) return null;
      const g = gauss(p, 0.5, 0.22);
      if (kind === 'zoomBlur') {
        const r0 = lerp(160, 760, eo(p));
        return (
          <React.Fragment key={i}>
            <Full>
              {Array.from({length: 44}).map((_, n) => {
                const a = (n / 44) * Math.PI * 2 + rnd(n + 3) * 0.1;
                const len = 220 + rnd(n + 9) * 520;
                const ra = r0 + rnd(n + 20) * 140;
                return <line key={n} x1={960 + Math.cos(a) * ra} y1={540 + Math.sin(a) * ra} x2={960 + Math.cos(a) * (ra + len)} y2={540 + Math.sin(a) * (ra + len)} stroke="#fff" strokeWidth={2 + rnd(n + 31) * 4} opacity={0.65 * g} strokeLinecap="round" />;
              })}
            </Full>
            <AbsoluteFill style={{background: '#fff', opacity: 0.5 * gauss(p, 0.5, 0.12)}} />
          </React.Fragment>
        );
      }
      if (kind === 'push') {
        return (
          <React.Fragment key={i}>
            <Full>
              {Array.from({length: 8}).map((_, n) => {
                const w = 700 + rnd(n + 5) * 900;
                const x = lerp(-w, WIDTH + 300, eio(clamp(p * 1.1 - rnd(n + 11) * 0.15)));
                return <rect key={n} x={x} y={80 + n * 120 + rnd(n + 2) * 40} width={w} height={6 + rnd(n + 7) * 10} fill="url(#streakG)" opacity={0.8 * Math.sin(Math.PI * p)} />;
              })}
            </Full>
            <LeafSwarm p={p} seed={3} />
          </React.Fragment>
        );
      }
      if (kind === 'iris') {
        const R = lerp(0, 1300, eio(p));
        return (
          <Full key={i}>
            <circle cx={960} cy={540} r={R} fill="none" stroke={LIME} strokeWidth={14 * (1 - p) + 3} filter="url(#glow)" opacity={0.95} />
            <circle cx={960} cy={540} r={Math.max(0, R - 70)} fill="none" stroke="#fff" strokeWidth={4 * (1 - p) + 1} opacity={0.7} />
          </Full>
        );
      }
      if (kind === 'diag') {
        const x = lerp(-SLANT, WIDTH + SLANT, eio(p));
        return (
          <React.Fragment key={i}>
            <Full>
              <line x1={x} y1={0} x2={x - SLANT} y2={HEIGHT} stroke="#fff" strokeWidth={10} filter="url(#glowL)" opacity={0.95} />
              <line x1={x + 26} y1={0} x2={x + 26 - SLANT} y2={HEIGHT} stroke={LIME} strokeWidth={5} opacity={0.9} />
            </Full>
            <LeafSwarm p={p} seed={7} count={20} />
          </React.Fragment>
        );
      }
      // flash (light leak hangat)
      return (
        <React.Fragment key={i}>
          <Full>
            <ellipse cx={1500} cy={260} rx={lerp(300, 1500, p)} ry={lerp(260, 1200, p)} fill="url(#sunG)" opacity={0.95 * g} />
          </Full>
          <AbsoluteFill style={{background: '#fff', opacity: 0.85 * gauss(p, 0.5, 0.16)}} />
        </React.Fragment>
      );
    })}
  </>
);

// =====================================================================
// END CARD (background)
// =====================================================================
const EndBg: React.FC = () => {
  const f = useCurrentFrame();
  const t = f / FPS;
  const stem = eo(prog(t, 0.3, 1.7));
  const L = 420;
  const popA = back(prog(t, 1.4, 2.0));
  const popB = back(prog(t, 1.65, 2.25));
  const popC = back(prog(t, 1.0, 1.6));
  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 75%, #1f8a45 0%, #0b4a25 45%, #04180d 100%)'}}>
      <Full style={{opacity: 0.14}}>
        {Array.from({length: 9}).map((_, i) => {
          const a = -2.2 + i * 0.34 + Math.sin(t * 0.35) * 0.08;
          const x1 = 1500 + Math.cos(a) * 2400;
          const y1 = -140 + Math.sin(a) * 2400;
          const x2 = 1500 + Math.cos(a + 0.12) * 2400;
          const y2 = -140 + Math.sin(a + 0.12) * 2400;
          return <polygon key={i} points={`1500,-140 ${x1},${y1} ${x2},${y2}`} fill="#fff" />;
        })}
      </Full>
      <Full>
        {Array.from({length: 46}).map((_, i) => (
          <circle key={i} cx={rnd(i * 2 + 1) * WIDTH + Math.sin(t + i) * 20} cy={mod(rnd(i * 2 + 2) * HEIGHT - t * (12 + rnd(i + 90) * 22), HEIGHT)} r={2 + rnd(i + 50) * 4} fill={LIME} opacity={0.15 + 0.3 * rnd(i + 70)} />
        ))}
        {Array.from({length: 14}).map((_, i) => {
          const sp = 60 + rnd(i + 5) * 70;
          const y = mod(rnd(i + 11) * 1300 + t * sp, 1300) - 110;
          const x = rnd(i + 21) * WIDTH + Math.sin(t * 1.3 + i) * 80;
          return <Leaf key={i} x={x} y={y} rot={t * 60 * (i % 2 ? 1 : -1) + i * 40} s={0.8 + rnd(i + 31) * 0.9} c={LEAF_COLORS[i % 4]} op={0.75} />;
        })}
        <ellipse cx={960} cy={1090} rx={520} ry={60} fill="#03110a" />
        <g filter="url(#glow)">
          <path d="M960 1090C955 960 978 880 960 760" fill="none" stroke={LIME} strokeWidth={14} strokeLinecap="round" strokeDasharray={L} strokeDashoffset={L * (1 - stem)} />
        </g>
        <g transform="translate(960 790)">
          <g transform={`scale(${popA})`}><Leaf x={0} y={0} rot={-30} s={3.4} c={GREEN} /></g>
          <g transform={`scale(${popB})`}><Leaf x={0} y={0} rot={-150} s={3.4} c={LIME} /></g>
        </g>
        <g transform="translate(962 930)">
          <g transform={`scale(${popC})`}><Leaf x={0} y={0} rot={-20} s={2.2} c={LEAF2} /></g>
          <g transform={`scale(${popC})`}><Leaf x={0} y={0} rot={-160} s={2.2} c={GREEN} /></g>
        </g>
      </Full>
    </AbsoluteFill>
  );
};

// =====================================================================
// LAYER SEGMEN
// =====================================================================
const SegLayer: React.FC<{seg: Seg; idx: number; frames: number; outKind?: Kind}> = ({seg, idx, frames, outKind}) => {
  const f = useCurrentFrame();
  const pIn = idx > 0 ? prog(f, 0, OV_F) : 1;
  const pOut = outKind ? prog(f, frames - OV_F, frames) : 0;
  const a = seg.trans && idx > 0 ? fxIn(seg.trans, pIn) : NONE;
  const b = outKind ? fxOut(outKind, pOut) : NONE;
  const k = sm(prog(f, 0, frames));
  const z = lerp(seg.z[0], seg.z[1], k);
  const dx = lerp(0, seg.drift ? seg.drift[0] : 0, k);
  const dy = lerp(0, seg.drift ? seg.drift[1] : 0, k);
  const filter = [a.fl, b.fl].filter(Boolean).join(' ') || undefined;
  return (
    <AbsoluteFill
      style={{
        transform: [a.tf, b.tf].filter(Boolean).join(' ') || undefined,
        filter,
        opacity: a.op * b.op,
        clipPath: a.clip || b.clip,
        overflow: 'hidden',
        backgroundColor: '#000',
      }}
    >
      {seg.src ? (
        <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px) scale(${z})`}}>
          <OffthreadVideo
            src={staticFile(seg.src)}
            muted
            startFrom={Math.round((seg.from || 0) * FPS)}
            playbackRate={seg.rate || 1}
            style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'saturate(1.18) contrast(1.06) brightness(1.02)'}}
          />
        </AbsoluteFill>
      ) : (
        <EndBg />
      )}
      {seg.src && (
        <>
          <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(40,130,70,0.10), rgba(255,170,60,0.12))', mixBlendMode: 'soft-light'}} />
          <AbsoluteFill style={{background: 'linear-gradient(0deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0) 40%)'}} />
        </>
      )}
    </AbsoluteFill>
  );
};

// =====================================================================
// CAPTION kinetic
// =====================================================================
const parse = (text: string) => {
  const out: {w: string; hi: boolean}[] = [];
  text.split(/(\*[^*]+\*)/).forEach((part) => {
    if (!part) return;
    const hi = part.startsWith('*');
    (hi ? part.slice(1, -1) : part).split(/\s+/).filter(Boolean).forEach((w) => out.push({w, hi}));
  });
  return out;
};

const CaptionView: React.FC<{cap: AbsCap; t: number}> = ({cap, t}) => {
  if (t < cap.a0 || t > cap.a1) return null;
  const words = parse(cap.text);
  const local = t - cap.a0;
  const exit = eo(prog(t, cap.a1 - 0.28, cap.a1));
  const size = cap.size || 96;
  const pos: React.CSSProperties =
    cap.y === undefined
      ? {bottom: 140}
      : {top: cap.y - size * 0.6};
  return (
    <div style={{position: 'absolute', left: 0, right: 0, display: 'flex', justifyContent: 'center', ...pos}}>
      <div
        style={{
          maxWidth: 1560,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: `0 ${size * 0.28}px`,
          transform: `rotate(-1.4deg) translateY(${-30 * exit}px)`,
          opacity: 1 - exit,
          filter: exit > 0 ? `blur(${exit * 10}px)` : undefined,
        }}
      >
        {words.map((w, i) => {
          const tw = local - i * 0.1;
          const sc = back(prog(tw, 0, 0.34));
          const op = clamp(tw / 0.1);
          const y = (1 - eo(prog(tw, 0, 0.3))) * 46;
          return (
            <span
              key={i}
              style={{
                position: 'relative',
                display: 'inline-block',
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: size,
                lineHeight: 1.12,
                color: w.hi ? GOLD : WHITE,
                opacity: op,
                transform: `translateY(${y}px) scale(${sc})`,
                textShadow: '0 6px 26px rgba(0,0,0,0.6), 0 2px 4px rgba(0,0,0,0.5)',
              }}
            >
              {w.hi && (
                <span
                  style={{
                    position: 'absolute',
                    left: -10,
                    right: -10,
                    bottom: size * 0.06,
                    height: '34%',
                    background: 'rgba(120,200,40,0.45)',
                    transform: `scaleX(${eo(prog(tw, 0.1, 0.5))})`,
                    transformOrigin: 'left',
                    zIndex: -1,
                    borderRadius: 6,
                  }}
                />
              )}
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};

// =====================================================================
// JUDUL PEMBUKA
// =====================================================================
const Sparkle: React.FC<{x: number; y: number; s: number; t: number; t0: number}> = ({x, y, s, t, t0}) => {
  const q = prog(t, t0, t0 + 0.5);
  const k = Math.sin(Math.PI * q) * s;
  return <path d={`M${x} ${y - k}Q${x} ${y} ${x + k} ${y}Q${x} ${y} ${x} ${y + k}Q${x} ${y} ${x - k} ${y}Q${x} ${y} ${x} ${y - k}Z`} fill="#fff" filter="url(#glow)" />;
};

const Title: React.FC<{t: number}> = ({t}) => {
  if (t < 0.3 || t > 4.7) return null;
  const out = eo(prog(t, 3.9, 4.5));
  const sub = eo(prog(t, 1.6, 2.2));
  const badge = back(prog(t, 2.4, 2.85));
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 48%, rgba(0,25,10,0.55) 0%, rgba(0,25,10,0) 65%)', opacity: sm(prog(t, 0.3, 1)) * (1 - out)}} />
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + 0.12 * out})`, opacity: 1 - out, filter: out > 0 ? `blur(${out * 14}px)` : undefined}}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: -30}}>
          <div style={{display: 'flex', fontFamily: FONT, fontWeight: 900, fontSize: 196, letterSpacing: 10, color: WHITE, textShadow: '0 8px 40px rgba(0,0,0,0.55), 0 0 60px rgba(200,255,77,0.35)'}}>
            {TITLE.split('').map((ch, i) => {
              const q = prog(t, 0.5 + i * 0.055, 0.5 + i * 0.055 + 0.5);
              return (
                <span key={i} style={{display: 'inline-block', transform: `translateY(${(1 - eo(q)) * 170}px)`, opacity: sm(q * 1.6), filter: `blur(${(1 - q) * 16}px)`}}>
                  {ch}
                </span>
              );
            })}
          </div>
          <div style={{display: 'flex', alignItems: 'center', gap: 28, marginTop: 8, opacity: sub, transform: `translateY(${(1 - sub) * 30}px)`}}>
            <div style={{height: 4, width: 170 * sub, background: LIME, borderRadius: 2}} />
            <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 50, letterSpacing: 14, color: WHITE, textShadow: '0 4px 20px rgba(0,0,0,0.6)'}}>{SUBTITLE}</div>
            <div style={{height: 4, width: 170 * sub, background: LIME, borderRadius: 2}} />
          </div>
          <div
            style={{
              marginTop: 54,
              padding: '14px 52px',
              borderRadius: 999,
              background: LIME,
              color: DEEP,
              fontFamily: FONT,
              fontWeight: 900,
              fontSize: 56,
              letterSpacing: 8,
              transform: `rotate(-3deg) scale(${badge})`,
              boxShadow: '0 12px 40px rgba(0,0,0,0.45), 0 0 40px rgba(200,255,77,0.5)',
            }}
          >
            {BADGE}
          </div>
        </div>
      </AbsoluteFill>
      <Full>
        <Sparkle x={520} y={380} s={26} t={t} t0={2.7} />
        <Sparkle x={1420} y={640} s={20} t={t} t0={2.95} />
        <Sparkle x={1160} y={330} s={16} t={t} t0={3.15} />
      </Full>
    </AbsoluteFill>
  );
};

// =====================================================================
// BUG pojok kiri atas
// =====================================================================
const Bug: React.FC<{t: number}> = ({t}) => {
  const endT = SEG_START[SEGS.length - 1] / FPS;
  const a = eo(prog(t, 4.9, 5.6)) * (1 - sm(prog(t, endT, endT + 0.4)));
  if (a <= 0) return null;
  return (
    <div style={{position: 'absolute', left: 64, top: 56, display: 'flex', alignItems: 'center', gap: 16, padding: '10px 26px 10px 18px', borderRadius: 999, background: 'rgba(5,30,15,0.55)', border: '2px solid rgba(200,255,77,0.55)', opacity: a, transform: `translateX(${(1 - a) * -60}px)`}}>
      <svg width={44} height={30} viewBox="0 0 70 40">
        <g transform="translate(4 20)"><path d={LEAF} fill={LIME} /></g>
      </svg>
      <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 26, letterSpacing: 4, color: WHITE, whiteSpace: 'pre'}}>{BUG}</div>
    </div>
  );
};

// =====================================================================
// KOMPOSISI UTAMA
// =====================================================================
export const Alam: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const endStart = SEG_START[SEGS.length - 1] / FPS;
  const fade = 1 - sm(prog(t, 0, 0.7)) + sm(prog(t, TOTAL_SECONDS - 0.9, TOTAL_SECONDS));
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Defs />
      {USE_AUDIO && <Audio src={staticFile('audio.mp3')} />}
      {SEGS.map((s, i) => (
        <Sequence key={s.id} from={SEG_START[i]} durationInFrames={SEG_FRAMES[i]}>
          <SegLayer seg={s} idx={i} frames={SEG_FRAMES[i]} outKind={SEGS[i + 1] ? SEGS[i + 1].trans : undefined} />
        </Sequence>
      ))}
      <TransitionFX frame={frame} />
      {CAPS_ABS.map((c, i) => (
        <CaptionView key={i} cap={c} t={t} />
      ))}
      <Title t={t} />
      <Bug t={t} />
      <div style={{position: 'absolute', left: 0, bottom: 0, height: 6, width: `${(frame / TOTAL_FRAMES) * 100}%`, background: LIME, boxShadow: '0 0 14px rgba(200,255,77,0.9)', opacity: 1 - sm(prog(t, endStart, endStart + 0.4))}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)'}} />
      {GRAIN && (
        <svg width={WIDTH} height={HEIGHT} style={{position: 'absolute', left: 0, top: 0, opacity: 0.08, mixBlendMode: 'overlay'}}>
          <filter id="grainF"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={frame % 11} stitchTiles="stitch" /><feColorMatrix type="saturate" values="0" /></filter>
          <rect width="100%" height="100%" filter="url(#grainF)" />
        </svg>
      )}
      <AbsoluteFill style={{background: '#000', opacity: clamp(fade)}} />
    </AbsoluteFill>
  );
};
