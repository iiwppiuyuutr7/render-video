ALAM - Kokurikuler Gaya Hidup Berkelanjutan, Hari Pertama
16:9 (1920x1080), 30 fps, +-31 detik, suara asli klip DIBISUKAN (muted)

PASANG
  src/Alam.tsx, src/Root.tsx  -> taruh di src/ proyek Remotion
  public/audio.mp3            -> taruh di public/ (audio sintetis, sinkron dgn transisi & teks)

KLIP -> taruh di public/ dengan NAMA INI (rename dari file aslinya):
  VID202611091101332.mp4  ->  luar.mp4           (outdoor kerja bakti, PEMBUKA)
  1000222997.mp4          ->  kelas-singkat.mp4  (1 detik, kelas wide, di-slow-mo 0.45x)
  1000222998.mp4          ->  kelas.mp4          (siswa memotong botol, dipakai dari detik 4.5)
  1000222996.mp4          ->  gunting.mp4        (close-up gunting, dari detik 1.0)
  1000222995.mp4          ->  meja.mp4           (top-down meja, dari detik 1.0)

Preview: npx remotion studio      Render: npx remotion render Alam out/alam.mp4

TIMELINE (detik)
   0.0 -  7.9  luar.mp4   judul KOKURIKULER + badge HARI PERTAMA, lalu caption
   7.3 -  9.7  kelas-singkat  (transisi: zoom blur + speed lines)
   9.1 - 15.6  kelas      (transisi: whip push + daun)
  15.0 - 20.5  gunting    (transisi: iris cincin hijau)
  19.9 - 26.9  meja       (transisi: diagonal wipe + daun)
  26.3 - 30.9  end card   (transisi: light leak / flash) "Langkah kecil, dampak besar"

UBAH TEKS: bagian atas Alam.tsx (TITLE, SUBTITLE, BADGE, BUG) dan daftar `caps` di SEGS.
  *kata* = kata yang di-highlight kuning. Waktu t0/t1 = detik relatif awal segmen.
UBAH DURASI/POTONGAN: field `from` (detik di klip sumber) dan `dur` di SEGS. Total durasi otomatis.
CATATAN
  - Klip kelas/gunting/meja resolusinya 854x480, jadi di-upscale ke 1080p (agak lembut). Grain & grade membantu.
  - Font: Poppins/Montserrat kalau terpasang. Mau pasti: npm i @remotion/google-fonts lalu load Poppins.
  - Kalau muncul warning `startFrom` deprecated di versi Remotion baru, ganti jadi `trimBefore`.
  - Mau tanpa audio sintetis: USE_AUDIO = false.
