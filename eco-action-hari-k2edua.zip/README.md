# ECO-ACTION 4 DAYS — Hari kedua (Remotion)

Taruh Root.tsx dan EcoActionHari2.tsx di src/, isi public/ ke public/ project Remotion.

    npm i @remotion/google-fonts
    npx remotion studio
    npx remotion render EcoActionHari2 out/hari-kedua.mp4

- 1920x1080, 30 fps (ubah di Root.tsx: OUT_FPS), 44 detik
- 4 klip dipakai sekali, utuh, kecepatan asli. Audio klip dimatikan.
- Backsound: h2_backsound.mp3 = lanjutan lagu Strawberry Guy dari detik 75,4 (tempat hari pertama berhenti), mengecil otomatis saat SFX (ducking, array DUCK).
- Atur urutan/durasi klip di array SHOTS.
- Kalau digabung dengan project hari pertama: file media memakai awalan h2_ jadi tidak bentrok; daftarkan <Composition> hari kedua di Root.tsx hari pertama.
