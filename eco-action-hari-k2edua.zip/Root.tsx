import React from 'react';
import {Composition} from 'remotion';
import {EcoActionHari2, TOTAL_SECONDS} from './EcoActionHari2';

// Satu-satunya tempat mengatur fps. Durasi (frame) ikut otomatis. Disarankan 30.
const OUT_FPS = 30;

export const RemotionRoot: React.FC = () => (
  <Composition id="EcoActionHari2" component={EcoActionHari2} durationInFrames={Math.round(TOTAL_SECONDS * OUT_FPS)} fps={OUT_FPS} width={1920} height={1080} />
);
