/**

 * ECO-ACTION 4 DAYS — Hari kedua: Aksi nyata dan eksekusi (Do & Create)
 * SMA Negeri 1 Doro · Kelas X E7 · Kelompok 5 — Video Kampanye
 * 1920x1080 (16:9) · 30 fps · 44 detik
 *
 * Footage asli di public/h2_clip1..h2_clip4.mp4 (audio klip dimatikan). Backsound: public/h2_backsound.mp3 (lanjutan lagu hari 1: detik 75,4 dst)
 * SFX: whoosh.mp3, transition.mp3. Semua waktu dalam DETIK. Ubah urutan/durasi di array SHOTS.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Freeze,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';


const {fontFamily} = loadFont('normal', {weights: ['400', '500', '600', '700', '800'], subsets: ['latin']});
const FONT = `${fontFamily}, 'Segoe UI', Arial, sans-serif`;

/* ───────────────────────── konfigurasi ───────────────────────── */
export const FPS = 30;
export const TOTAL_SECONDS = 44.0;

// Penanda awal tiap bagian (detik)
const S = {s2: 14.7, s3: 22.3, s4: 29.8, s5: 35.8};

const C = {
  forest: '#1f5130',
  deep: '#0d2817',
  sage: '#9fcf9f',
  beige: '#efe6d2',
  white: '#ffffff',
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.bezier(0.22, 1, 0.36, 1);
// fps aktual komposisi (diisi saat render) — supaya timing tetap benar di 30 maupun 60 fps
let RT_FPS = FPS;
const sec = (s: number) => Math.round(s * RT_FPS);
const OV = 0.6; // lama dissolve antar klip


/* ───────────────────────── daftar footage ─────────────────────────
 * Semua klip dipakai SEKALI, utuh, kecepatan asli (1x), tanpa diulang.
 * at     : detik mulai di timeline
 * start  : detik mulai di klip asli
 * dur    : lama tampil (sedikit di bawah panjang klip asli)
 * hold   : tahan frame terakhir (freeze) sekian detik setelah klip habis
 * z0→z1  : zoom sangat halus (1 = tanpa zoom)
 */
type Shot = {src: string; at: number; start: number; dur: number; hold?: number; z0?: number; z1?: number};

const SHOTS: Shot[] = [
  {src: 'h2_clip1.mp4', at: 0, start: 0, dur: 15.2, z0: 1, z1: 1}, // opening: lingkungan sekolah -> persiapan (kamera asli, tanpa zoom)
  {src: 'h2_clip2.mp4', at: 14.7, start: 0, dur: 8.1, z0: 1, z1: 1.05}, // aksi tamanisasi (ruang kerja)
  {src: 'h2_clip3.mp4', at: 22.3, start: 0, dur: 8.0, z0: 1.04, z1: 1}, // kerja bersama menyiapkan media
  {src: 'h2_clip4.mp4', at: 29.8, start: 0, dur: 9.9, hold: 3.7, z0: 1, z1: 1.06}, // penanaman & penataan taman + penutup
];

/* ───────────────────────── komponen dasar ───────────────────────── */
const ShotView: React.FC<{s: Shot; first: boolean}> = ({s, first}) => {
  const f = useCurrentFrame();
  const d = sec(s.dur);
  const total = sec(s.dur + (s.hold ?? 0) + OV);
  const op = first ? interpolate(f, [0, sec(1.2)], [0, 1], clamp) : interpolate(f, [0, sec(OV)], [0, 1], clamp);
  const sc = interpolate(f, [0, total], [s.z0 ?? 1, s.z1 ?? 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const from = sec(s.start);
  return (
    <AbsoluteFill style={{opacity: op, backgroundColor: '#000'}}>
      {/* Freeze: setelah klip habis, frame terakhir ditahan (tidak ada frame kosong/hitam) */}
      <Freeze frame={Math.min(f, d - 2)}>
        <OffthreadVideo
          src={staticFile(s.src)}
          startFrom={from}
          endAt={from + d}
          muted
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transform: `scale(${sc})`,
          }}
        />
      </Freeze>
    </AbsoluteFill>
  );
};

const Footage: React.FC = () => (
  <AbsoluteFill style={{filter: 'saturate(1.06) contrast(1.05) sepia(0.09) brightness(0.98)'}}>
    {SHOTS.map((s, i) => (
      <Sequence key={i} from={sec(s.at)} durationInFrames={sec(s.dur + (s.hold ?? 0) + OV)} layout="none">
        <ShotView s={s} first={i === 0} />
      </Sequence>
    ))}
  </AbsoluteFill>
);

/** Vignette + gradasi halus agar teks terbaca tanpa menutup footage */
const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(5,20,10,0.45) 100%), linear-gradient(to top, rgba(5,20,10,0.35) 0%, rgba(0,0,0,0) 35%)',
    }}
  />
);

/** Lapisan teks: fade + naik halus, muncul `at` detik selama `dur` detik */
const Layer: React.FC<{at: number; dur: number; children: React.ReactNode; rise?: number}> = ({at, dur, children, rise = 24}) => (
  <Sequence from={sec(at)} durationInFrames={sec(dur)} layout="none">
    <LayerInner dur={dur} rise={rise}>{children}</LayerInner>
  </Sequence>
);
const LayerInner: React.FC<{dur: number; rise: number; children: React.ReactNode}> = ({dur, rise, children}) => {
  const f = useCurrentFrame();
  const d = sec(dur);
  const i = interpolate(f, [0, sec(0.8)], [0, 1], {...clamp, easing: ease});
  const o = interpolate(f, [d - sec(0.7), d], [1, 0], clamp);
  return (
    <AbsoluteFill style={{opacity: Math.min(i, o), transform: `translateY(${(1 - i) * rise}px)`}}>{children}</AbsoluteFill>
  );
};

/** Muncul bertahap di dalam Layer (frame lokal) */
const Rise: React.FC<{delay: number; children: React.ReactNode; style?: React.CSSProperties; x?: number}> = ({delay, children, style, x = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.8)], [0, 1], {...clamp, easing: ease});
  return <div style={{opacity: p, transform: `translate(${(1 - p) * x}px, ${(1 - p) * 26}px)`, ...style}}>{children}</div>;
};

const Glass: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      background: 'rgba(13,40,23,0.66)',
      backdropFilter: 'blur(16px)',
      border: '1px solid rgba(239,230,210,0.26)',
      borderRadius: 24,
      boxShadow: '0 18px 60px rgba(0,0,0,0.35)',
      ...style,
    }}
  >
    {children}
  </div>
);

/* ───────────────────────── ikon sederhana ───────────────────────── */
const Leaf: React.FC<{size?: number; color?: string}> = ({size = 40, color = C.sage}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <path d="M20 3C10 3 4 8 4 15c0 2 .6 3.6 1.6 5C7 14 11 10 16 8c-4 3-7 7-8.4 12.2C9 21 10.4 21 12 21c6 0 8-6 8-18z" fill={color} />
  </svg>
);

const Check: React.FC<{size?: number; delay?: number}> = ({size = 44, delay = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.6)], [0, 1], {...clamp, easing: ease});
  return (
    <svg width={size} height={size} viewBox="0 0 44 44">
      <circle cx="22" cy="22" r="20" fill={C.forest} stroke={C.sage} strokeWidth="2" />
      <path d="M12 23l7 7 13-15" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="40" strokeDashoffset={40 * (1 - p)} />
    </svg>
  );
};

const Chip: React.FC<{children: React.ReactNode; light?: boolean; style?: React.CSSProperties}> = ({children, light, style}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 14,
      padding: '12px 28px',
      borderRadius: 999,
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 30,
      letterSpacing: 0.3,
      background: light ? C.beige : C.forest,
      color: light ? C.deep : C.beige,
      border: light ? 'none' : `1.5px solid ${C.sage}`,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Logo kecil di pojok setelah opening */
const Bug: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(0.8), sec(1.8), sec(TOTAL_SECONDS - 4), sec(TOTAL_SECONDS - 2.5)], [0, 0.95, 0.95, 0], clamp);
  return (
    <div style={{position: 'absolute', top: 44, left: 56, opacity: o, display: 'flex', alignItems: 'center', gap: 12, fontFamily: FONT, color: C.white, fontWeight: 700, fontSize: 24, letterSpacing: 2, textShadow: '0 2px 10px rgba(0,0,0,0.6)'}}>
      <Leaf size={30} color={C.sage} />
      ECO-ACTION 4 DAYS
    </div>
  );
};

const ProgressBar: React.FC = () => {
  const f = useCurrentFrame();
  const w = interpolate(f, [0, sec(TOTAL_SECONDS)], [0, 100], clamp);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, height: 5, width: `${w}%`, background: `linear-gradient(90deg, ${C.forest}, ${C.sage})`, opacity: 0.9}} />
  );
};


/* ───────────────────────── kartu bab "Hari kedua" ─────────────────────────
 * Sengaja dibuat sama strukturnya dengan panel "Hari pertama" di video hari 1
 * (lingkaran angka + judul + subjudul + chip), supaya terasa satu seri.
 */
const ChapterCard: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-end', padding: '0 80px', fontFamily: FONT}}>
    <Glass style={{padding: '48px 56px', width: 860}}>
      <Rise delay={0}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.sage, fontWeight: 700, fontSize: 28, marginBottom: 22, letterSpacing: 4}}>
          <Leaf size={34} /> ECO-ACTION 4 DAYS
        </div>
      </Rise>
      <Rise delay={0.3}>
        <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
          <div style={{width: 112, height: 112, borderRadius: '50%', background: C.beige, color: C.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 64, flexShrink: 0}}>2</div>
          <div>
            <div style={{fontWeight: 800, fontSize: 62, color: C.white, lineHeight: 1.05}}>Hari kedua</div>
            <div style={{fontWeight: 500, fontSize: 34, color: C.beige, marginTop: 8}}>Aksi nyata dan eksekusi</div>
          </div>
        </div>
      </Rise>
      <Rise delay={1.0}>
        <div style={{margin: '28px 0 0', display: 'flex', gap: 16, flexWrap: 'wrap'}}>
          <Chip style={{fontSize: 28}}>Do &amp; Create</Chip>
          <Chip light style={{fontSize: 28}}>SMA Negeri 1 Doro</Chip>
        </div>
      </Rise>
    </Glass>
  </AbsoluteFill>
);

/* ───────────────────────── panel teks umum ───────────────────────── */
const TextPanel: React.FC<{kicker: string; title: string; chip: string}> = ({kicker, title, chip}) => (
  <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 0 110px 90px', fontFamily: FONT}}>
    <Glass style={{padding: '44px 60px', width: 1120}}>
      <Rise delay={0}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.sage, fontWeight: 600, fontSize: 28, marginBottom: 14, letterSpacing: 1}}>
          <Leaf size={34} /> {kicker}
        </div>
      </Rise>
      <Rise delay={0.3}>
        <div style={{fontWeight: 800, fontSize: 66, lineHeight: 1.1, color: C.white}}>{title}</div>
      </Rise>
      <Rise delay={1.3}>
        <div style={{marginTop: 26}}>
          <Chip light>{chip}</Chip>
        </div>
      </Rise>
    </Glass>
  </AbsoluteFill>
);

/* ───────────────────────── penutup ───────────────────────── */
const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const dim = interpolate(f, [0, sec(1.6)], [0, 1], {...clamp});
  return (
    <AbsoluteFill style={{fontFamily: FONT, justifyContent: 'center', alignItems: 'center', textAlign: 'center'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(13,40,23,0.78) 0%, rgba(8,28,15,0.9) 100%)', opacity: dim}} />
      <div style={{position: 'relative', maxWidth: 1600}}>
        <Rise delay={0.3}>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 22}}>
            <Leaf size={80} />
          </div>
        </Rise>
        <Rise delay={0.6}>
          <div style={{fontWeight: 800, fontSize: 88, lineHeight: 1.15, color: C.white, textShadow: '0 6px 30px rgba(0,0,0,0.5)'}}>Aksi hari ini, perubahan untuk masa depan.</div>
        </Rise>
        <Rise delay={1.6}>
          <div style={{fontWeight: 500, fontSize: 42, color: C.beige, marginTop: 26}}>Hari kedua — Do &amp; Create</div>
        </Rise>
        <Rise delay={2.8}>
          <div style={{height: 2, width: 420, background: C.sage, margin: '44px auto 30px'}} />
          <div style={{fontWeight: 800, fontSize: 54, letterSpacing: 10, color: C.white}}>ECO-ACTION 4 DAYS</div>
          <div style={{fontWeight: 500, fontSize: 32, color: C.beige, marginTop: 14}}>Kelas X E7 — Kelompok 5 — Video Kampanye</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── fade out akhir ───────────────────────── */
const EndFade: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(TOTAL_SECONDS - 2.0), sec(TOTAL_SECONDS)], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  return <AbsoluteFill style={{background: '#000', opacity: o}} />;
};


/* ───────────────────────── komposisi ───────────────────────── */
const WHOOSH_AT = [S.s2, S.s3, S.s4, S.s5].map((t) => t - 0.6);
const TRANS_AT = [1.2, 8.0, S.s2 + 0.8, S.s4 + 0.6];

/** Ducking: backsound mengecil saat SFX bunyi, lalu naik pelan ke volume normal. */
const DUCK: Array<{t: number; d: number; depth: number}> = [
  ...WHOOSH_AT.map((t) => ({t, d: 2.2, depth: 0.4})),
  ...TRANS_AT.map((t) => ({t, d: 0.45, depth: 0.5})),
];
const duckGain = (time: number) =>
  DUCK.reduce((g, e) => {
    const v = interpolate(time, [e.t - 0.12, e.t + 0.03, e.t + e.d, e.t + e.d + 0.7], [1, e.depth, e.depth, 1], clamp);
    return Math.min(g, v);
  }, 1);

export const EcoActionHari2: React.FC = () => {
  const {fps} = useVideoConfig();
  RT_FPS = fps;
  const musicVol = (frame: number) =>
    interpolate(frame, [sec(TOTAL_SECONDS - 4), sec(TOTAL_SECONDS)], [0.8, 0], clamp) /* tanpa fade in: lanjutan musik hari pertama; fade out akhir dihapus nanti kalau ada hari 3 */ * duckGain(frame / fps);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Footage />
      <Vignette />

      {/* Adegan 1 — opening */}
      <Layer at={1.2} dur={5.8}>
        <ChapterCard />
      </Layer>
      {/* Adegan 2 — persiapan kegiatan */}
      <Layer at={8.0} dur={6.4}>
        <TextPanel kicker="Persiapan kegiatan" title="Dari rencana menuju aksi nyata" chip="Persiapan menjadi langkah awal perubahan" />
      </Layer>
      {/* Adegan 3 — aksi tamanisasi */}
      <Layer at={S.s2 + 0.8} dur={6.6}>
        <TextPanel kicker="Aksi tamanisasi" title="Aksi nyata pelajar hijau" chip="Bersama menciptakan lingkungan sekolah yang asri" />
      </Layer>
      {/* Adegan 4 — penanaman dan penataan taman */}
      <Layer at={S.s4 + 0.6} dur={5.0}>
        <TextPanel kicker="Penanaman dan penataan taman" title="Menanam, menata, dan merawat" chip="Membangun lingkungan yang lebih berkelanjutan" />
      </Layer>
      {/* Adegan 7 — closing */}
      <Layer at={S.s5} dur={8.0} rise={0}>
        <Closing />
      </Layer>

      <Bug />
      <ProgressBar />
      <EndFade />

      {/* Audio: backsound + sound effect */}
      <Audio src={staticFile('h2_backsound.mp3')} volume={musicVol} />
      {WHOOSH_AT.map((t, i) => (
        <Sequence key={`w${i}`} from={sec(t)}>
          <Audio src={staticFile('whoosh.mp3')} volume={0.8} />
        </Sequence>
      ))}
      {TRANS_AT.map((t, i) => (
        <Sequence key={`t${i}`} from={sec(t)}>
          <Audio src={staticFile('transition.mp3')} volume={0.8} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
