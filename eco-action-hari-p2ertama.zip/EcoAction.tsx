/**

 * ECO-ACTION 4 DAYS — Video dokumentasi kokurikuler
 * SMA Negeri 1 Doro · Kelas X E7 · Kelompok 5 — Video kampanye
 * 1920x1080 (16:9) · 30 fps · 75,4 detik
 *
 * Footage asli di public/clip1..clip9.mp4 (audio klip dimatikan, tanpa suara orang bicara).
 * Backsound: public/backsound.mp3 (Strawberry Guy - Mrs Magic, dipotong 75,4 dtk). SFX: whoosh.mp3, transition.mp3, click.mp3
 * Semua waktu di file ini dalam DETIK.
 *
 * Mau ganti klip / urutan? Edit array SHOTS di bawah.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Freeze,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';

const {fontFamily} = loadFont('normal', {weights: ['400', '500', '600', '700', '800'], subsets: ['latin']});
const FONT = `${fontFamily}, 'Segoe UI', Arial, sans-serif`;

/* ───────────────────────── konfigurasi ───────────────────────── */
export const FPS = 30;
export const TOTAL_SECONDS = 75.4;

// Penanda awal tiap scene (detik)
const S = {s2: 13.7, s3: 34.0, s4: 47.1, s5: 59.0, s6: 67.6};

const C = {
  forest: '#1f5130',
  deep: '#0d2817',
  sage: '#9fcf9f',
  beige: '#efe6d2',
  white: '#ffffff',
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.bezier(0.22, 1, 0.36, 1);
// fps aktual komposisi (diisi saat render) — supaya timing tetap benar di 30 maupun 60 fps
let RT_FPS = FPS;
const sec = (s: number) => Math.round(s * RT_FPS);
const OV = 0.6; // lama dissolve antar klip

/* ───────────────────────── daftar footage ─────────────────────────
 * Semua klip dipakai SEKALI, utuh, kecepatan asli (1x), tanpa diulang.
 * at     : detik mulai di timeline
 * start  : detik mulai di klip asli
 * dur    : lama tampil (sedikit di bawah panjang klip asli)
 * hold   : tahan frame terakhir (freeze) sekian detik setelah klip habis
 * z0→z1  : zoom sangat halus (1 = tanpa zoom)
 */
type Shot = {src: string; at: number; start: number; dur: number; hold?: number; z0?: number; z1?: number};

const SHOTS: Shot[] = [
  {src: 'clip1.mp4', at: 0, start: 0, dur: 14.2, z0: 1, z1: 1}, // S1 opening (kamera turun, tanpa zoom)
  {src: 'clip6.mp4', at: 13.7, start: 0, dur: 7.8, z0: 1, z1: 1.05}, // S2 pengenalan
  {src: 'clip8.mp4', at: 21.0, start: 0, dur: 5.1, z0: 1, z1: 1.04}, // S2 suasana parkiran
  {src: 'clip9.mp4', at: 25.6, start: 0, dur: 8.9, z0: 1, z1: 1.04}, // S2 area taman & pohon
  {src: 'clip5.mp4', at: 34.0, start: 0, dur: 13.6, z0: 1.03, z1: 1}, // S3 agenda
  {src: 'clip2.mp4', at: 47.1, start: 0, dur: 11.9, z0: 1, z1: 1.05}, // S4 diskusi
  {src: 'clip4.mp4', at: 58.5, start: 0, dur: 1.0, z0: 1, z1: 1}, // S4 potongan singkat kelas
  {src: 'clip3.mp4', at: 59.0, start: 0, dur: 9.1, z0: 1, z1: 1.05}, // S5 preview kegiatan (tanpa teks)
  {src: 'clip7.mp4', at: 67.6, start: 0, dur: 7.2, z0: 1, z1: 1.05}, // S6 penutup (klip masih bergerak)
];

/* ───────────────────────── komponen dasar ───────────────────────── */
const ShotView: React.FC<{s: Shot; first: boolean}> = ({s, first}) => {
  const f = useCurrentFrame();
  const d = sec(s.dur);
  const total = sec(s.dur + (s.hold ?? 0) + OV);
  const op = first ? interpolate(f, [0, sec(1.2)], [0, 1], clamp) : interpolate(f, [0, sec(OV)], [0, 1], clamp);
  const sc = interpolate(f, [0, total], [s.z0 ?? 1, s.z1 ?? 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const from = sec(s.start);
  return (
    <AbsoluteFill style={{opacity: op, backgroundColor: '#000'}}>
      {/* Freeze: setelah klip habis, frame terakhir ditahan (tidak ada frame kosong/hitam) */}
      <Freeze frame={Math.min(f, d - 2)}>
        <OffthreadVideo
          src={staticFile(s.src)}
          startFrom={from}
          endAt={from + d}
          muted
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transform: `scale(${sc})`,
          }}
        />
      </Freeze>
    </AbsoluteFill>
  );
};

const Footage: React.FC = () => (
  <AbsoluteFill style={{filter: 'saturate(1.06) contrast(1.05) sepia(0.09) brightness(0.98)'}}>
    {SHOTS.map((s, i) => (
      <Sequence key={i} from={sec(s.at)} durationInFrames={sec(s.dur + (s.hold ?? 0) + OV)} layout="none">
        <ShotView s={s} first={i === 0} />
      </Sequence>
    ))}
  </AbsoluteFill>
);

/** Vignette + gradasi halus agar teks terbaca tanpa menutup footage */
const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(5,20,10,0.45) 100%), linear-gradient(to top, rgba(5,20,10,0.35) 0%, rgba(0,0,0,0) 35%)',
    }}
  />
);

/** Lapisan teks: fade + naik halus, muncul `at` detik selama `dur` detik */
const Layer: React.FC<{at: number; dur: number; children: React.ReactNode; rise?: number}> = ({at, dur, children, rise = 24}) => (
  <Sequence from={sec(at)} durationInFrames={sec(dur)} layout="none">
    <LayerInner dur={dur} rise={rise}>{children}</LayerInner>
  </Sequence>
);
const LayerInner: React.FC<{dur: number; rise: number; children: React.ReactNode}> = ({dur, rise, children}) => {
  const f = useCurrentFrame();
  const d = sec(dur);
  const i = interpolate(f, [0, sec(0.8)], [0, 1], {...clamp, easing: ease});
  const o = interpolate(f, [d - sec(0.7), d], [1, 0], clamp);
  return (
    <AbsoluteFill style={{opacity: Math.min(i, o), transform: `translateY(${(1 - i) * rise}px)`}}>{children}</AbsoluteFill>
  );
};

/** Muncul bertahap di dalam Layer (frame lokal) */
const Rise: React.FC<{delay: number; children: React.ReactNode; style?: React.CSSProperties; x?: number}> = ({delay, children, style, x = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.8)], [0, 1], {...clamp, easing: ease});
  return <div style={{opacity: p, transform: `translate(${(1 - p) * x}px, ${(1 - p) * 26}px)`, ...style}}>{children}</div>;
};

const Glass: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      background: 'rgba(13,40,23,0.66)',
      backdropFilter: 'blur(16px)',
      border: '1px solid rgba(239,230,210,0.26)',
      borderRadius: 24,
      boxShadow: '0 18px 60px rgba(0,0,0,0.35)',
      ...style,
    }}
  >
    {children}
  </div>
);

/* ───────────────────────── ikon sederhana ───────────────────────── */
const Leaf: React.FC<{size?: number; color?: string}> = ({size = 40, color = C.sage}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <path d="M20 3C10 3 4 8 4 15c0 2 .6 3.6 1.6 5C7 14 11 10 16 8c-4 3-7 7-8.4 12.2C9 21 10.4 21 12 21c6 0 8-6 8-18z" fill={color} />
  </svg>
);

const Check: React.FC<{size?: number; delay?: number}> = ({size = 44, delay = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.6)], [0, 1], {...clamp, easing: ease});
  return (
    <svg width={size} height={size} viewBox="0 0 44 44">
      <circle cx="22" cy="22" r="20" fill={C.forest} stroke={C.sage} strokeWidth="2" />
      <path d="M12 23l7 7 13-15" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="40" strokeDashoffset={40 * (1 - p)} />
    </svg>
  );
};

const Chip: React.FC<{children: React.ReactNode; light?: boolean; style?: React.CSSProperties}> = ({children, light, style}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 14,
      padding: '12px 28px',
      borderRadius: 999,
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 30,
      letterSpacing: 0.3,
      background: light ? C.beige : C.forest,
      color: light ? C.deep : C.beige,
      border: light ? 'none' : `1.5px solid ${C.sage}`,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Logo kecil di pojok setelah opening */
const Bug: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(S.s2), sec(S.s2 + 1), sec(TOTAL_SECONDS - 4), sec(TOTAL_SECONDS - 2.5)], [0, 0.95, 0.95, 0], clamp);
  return (
    <div style={{position: 'absolute', top: 44, left: 56, opacity: o, display: 'flex', alignItems: 'center', gap: 12, fontFamily: FONT, color: C.white, fontWeight: 700, fontSize: 24, letterSpacing: 2, textShadow: '0 2px 10px rgba(0,0,0,0.6)'}}>
      <Leaf size={30} color={C.sage} />
      ECO-ACTION 4 DAYS
    </div>
  );
};

const ProgressBar: React.FC = () => {
  const f = useCurrentFrame();
  const w = interpolate(f, [0, sec(TOTAL_SECONDS)], [0, 100], clamp);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, height: 5, width: `${w}%`, background: `linear-gradient(90deg, ${C.forest}, ${C.sage})`, opacity: 0.9}} />
  );
};

/* ───────────────────────── SCENE 1 — opening ───────────────────────── */
const Opening: React.FC = () => {
  const f = useCurrentFrame();
  const line = interpolate(f, [sec(0.3), sec(1.6)], [0, 1], {...clamp, easing: ease});
  const letter = interpolate(f, [0, sec(2.4)], [26, 8], {...clamp, easing: ease});
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', fontFamily: FONT, color: C.white, textAlign: 'center'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(5,25,12,0.62) 0%, rgba(5,25,12,0.15) 62%, rgba(0,0,0,0) 100%)'}} />
      <div style={{position: 'relative'}}>
        <Rise delay={0}>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 20}}>
            <Leaf size={74} color={C.sage} />
          </div>
        </Rise>
        <Rise delay={0.2}>
          <div style={{fontWeight: 800, fontSize: 118, letterSpacing: letter, textShadow: '0 6px 30px rgba(0,0,0,0.55)', paddingLeft: letter}}>ECO-ACTION 4 DAYS</div>
        </Rise>
        <div style={{height: 3, width: `${line * 760}px`, background: C.beige, margin: '26px auto 26px', borderRadius: 2}} />
        <Rise delay={1.2}>
          <div style={{fontWeight: 500, fontSize: 40, color: C.beige, textShadow: '0 3px 16px rgba(0,0,0,0.6)'}}>Aksi nyata pelajar hijau untuk sekolah asri dan berkelanjutan</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};
const OpeningFooter: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', fontFamily: FONT, paddingBottom: 70}}>
    <Rise delay={0}>
      <div style={{display: 'flex', gap: 20}}>
        <Chip light>Kelas X E7</Chip>
        <Chip>Kelompok 5 — video kampanye</Chip>
      </div>
    </Rise>
  </AbsoluteFill>
);

/* ───────────────────────── SCENE 2 — pengenalan ───────────────────────── */
const Intro: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 0 110px 90px', fontFamily: FONT}}>
    <Glass style={{padding: '44px 60px', width: 1040}}>
      <Rise delay={0}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.sage, fontWeight: 600, fontSize: 28, marginBottom: 14, letterSpacing: 1}}>
          <Leaf size={34} /> Pengenalan kegiatan
        </div>
      </Rise>
      <Rise delay={0.3}>
        <div style={{fontWeight: 800, fontSize: 68, lineHeight: 1.1, color: C.white}}>Kokurikuler gaya hidup berkelanjutan</div>
      </Rise>
      <Rise delay={1.4}>
        <div style={{marginTop: 26}}>
          <Chip light>Fokus kegiatan: tamanisasi</Chip>
        </div>
      </Rise>
    </Glass>
  </AbsoluteFill>
);

/* ───────────────────────── SCENE 3 — agenda hari pertama ───────────────────────── */
const Agenda: React.FC = () => {
  const items = ['Pengamatan lingkungan', 'Identifikasi permasalahan', 'Analisis kondisi lingkungan'];
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-end', padding: '0 80px', fontFamily: FONT}}>
      <Glass style={{padding: '48px 56px', width: 860}}>
        <Rise delay={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
            <div style={{width: 112, height: 112, borderRadius: '50%', background: C.beige, color: C.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 64, flexShrink: 0}}>1</div>
            <div>
              <div style={{fontWeight: 800, fontSize: 62, color: C.white, lineHeight: 1.05}}>Hari pertama</div>
              <div style={{fontWeight: 500, fontSize: 34, color: C.beige, marginTop: 8}}>Audit dan diagnosa lingkungan</div>
            </div>
          </div>
        </Rise>
        <Rise delay={0.7}>
          <div style={{margin: '26px 0 6px'}}>
            <Chip style={{fontSize: 28}}>Discover &amp; Brainstorm</Chip>
          </div>
        </Rise>
        <div style={{marginTop: 24, display: 'flex', flexDirection: 'column', gap: 18}}>
          {items.map((t, i) => (
            <Rise key={t} delay={1.6 + i * 1.0} x={60}>
              <div style={{display: 'flex', alignItems: 'center', gap: 22, fontWeight: 600, fontSize: 38, color: C.white}}>
                <Check delay={2.0 + i * 1.0} />
                {t}
              </div>
            </Rise>
          ))}
        </div>
      </Glass>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 4 — diskusi dan perencanaan ───────────────────────── */
const Discuss: React.FC = () => {
  const f = useCurrentFrame();
  const steps = ['Observasi', 'Analisis', 'Diskusi', 'Perencanaan'];
  const dim = interpolate(f, [0, sec(1)], [0, 1], {...clamp});
  return (
    <AbsoluteFill style={{fontFamily: FONT, justifyContent: 'center', alignItems: 'center'}}>
      <AbsoluteFill style={{background: 'rgba(10,36,20,0.62)', backdropFilter: 'blur(10px)', opacity: dim}} />
      <div style={{position: 'relative', textAlign: 'center', width: 1640}}>
        <Rise delay={0.3}>
          <div style={{fontWeight: 800, fontSize: 84, color: C.white}}>Diskusi dan perencanaan</div>
        </Rise>
        <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: 70}}>
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <Rise delay={1.4 + i * 1.0}>
                <div style={{width: 300, padding: '34px 10px', borderRadius: 22, background: i === 3 ? C.beige : 'rgba(31,81,48,0.9)', border: `2px solid ${C.sage}`, color: i === 3 ? C.deep : C.white}}>
                  <div style={{fontSize: 24, fontWeight: 600, opacity: 0.8, marginBottom: 8}}>Langkah {i + 1}</div>
                  <div style={{fontSize: 40, fontWeight: 800}}>{s}</div>
                </div>
              </Rise>
              {i < 3 && (
                <Rise delay={1.9 + i * 1.0}>
                  <svg width="70" height="30" viewBox="0 0 70 30" style={{margin: '0 6px'}}>
                    <path d="M4 15h54M46 5l14 10-14 10" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </Rise>
              )}
            </React.Fragment>
          ))}
        </div>
        <Rise delay={5.8}>
          <div style={{marginTop: 70, fontWeight: 500, fontSize: 42, color: C.beige, lineHeight: 1.35}}>Menentukan permasalahan dan merancang solusi<br />untuk lingkungan sekolah.</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 5 — Kelompok 5 ───────────────────────── */
const Group: React.FC = () => {
  const items = ['Menentukan target audiens', 'Menentukan tema kampanye', 'Menyusun pesan utama', 'Membuat konsep dan storyboard'];
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-start', padding: '0 0 0 90px', fontFamily: FONT}}>
      <Glass style={{padding: '48px 60px', width: 960}}>
        <Rise delay={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
            <div style={{position: 'relative', width: 150, height: 150, flexShrink: 0}}>
              <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: `4px solid ${C.sage}`}} />
              <div style={{position: 'absolute', inset: 14, borderRadius: '50%', background: C.beige, color: C.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 88}}>5</div>
            </div>
            <div>
              <div style={{fontWeight: 800, fontSize: 76, color: C.white, lineHeight: 1}}>Kelompok 5</div>
              <div style={{fontWeight: 500, fontSize: 36, color: C.beige, marginTop: 10}}>Video kampanye lingkungan</div>
            </div>
          </div>
        </Rise>
        <div style={{height: 2, background: 'rgba(239,230,210,0.3)', margin: '34px 0 28px'}} />
        <div style={{display: 'flex', flexDirection: 'column', gap: 20}}>
          {items.map((t, i) => (
            <Rise key={t} delay={1.4 + i * 1.1} x={-60}>
              <div style={{display: 'flex', alignItems: 'center', gap: 22, fontWeight: 600, fontSize: 40, color: C.white}}>
                <Check delay={1.8 + i * 1.1} />
                {t}
              </div>
            </Rise>
          ))}
        </div>
      </Glass>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 6 — ending (menyambung ke hari kedua) ───────────────────────── */
const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const dim = interpolate(f, [0, sec(1.6)], [0, 1], {...clamp});
  return (
    <AbsoluteFill style={{fontFamily: FONT, justifyContent: 'center', alignItems: 'center', textAlign: 'center'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(13,40,23,0.78) 0%, rgba(8,28,15,0.9) 100%)', opacity: dim}} />
      <div style={{position: 'relative', maxWidth: 1600}}>
        <Rise delay={0.3}>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 22}}>
            <Leaf size={80} />
          </div>
        </Rise>
        <Rise delay={0.6}>
          <div style={{fontWeight: 800, fontSize: 100, color: C.white, textShadow: '0 6px 30px rgba(0,0,0,0.5)'}}>Hari pertama selesai.</div>
        </Rise>
        <Rise delay={1.6}>
          <div style={{fontWeight: 500, fontSize: 42, color: C.beige, marginTop: 24}}>Rencana sudah disusun, saatnya beraksi.</div>
        </Rise>
        <Rise delay={2.8}>
          <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 18, marginTop: 48}}>
            <Chip style={{fontSize: 32}}>Berlanjut ke hari kedua</Chip>
            <svg width="70" height="30" viewBox="0 0 70 30">
              <path d="M4 15h54M46 5l14 10-14 10" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <Chip light style={{fontSize: 32}}>Aksi nyata dan eksekusi</Chip>
          </div>
          <div style={{fontWeight: 700, fontSize: 28, letterSpacing: 6, color: C.sage, marginTop: 40}}>ECO-ACTION 4 DAYS · Kelas X E7 — Kelompok 5</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── fade out akhir ───────────────────────── */
const EndFade: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(TOTAL_SECONDS - 2.0), sec(TOTAL_SECONDS)], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  return <AbsoluteFill style={{background: '#000', opacity: o}} />;
};

/* ───────────────────────── komposisi ───────────────────────── */
const CLICK_TIMES: number[] = [
  // S3: tiga poin agenda
  ...[0, 1, 2].map((i) => S.s3 + 0.7 + 2.0 + i * 1.0),
  // S4: empat langkah alur
  ...[0, 1, 2, 3].map((i) => S.s4 + 0.5 + 1.4 + i * 1.0),
];

// Waktu tiap sound effect (detik)
const WHOOSH_AT = [S.s2, S.s3, S.s4, S.s5, S.s6].map((t) => t - 0.6);
const TRANS_AT = [1.2, S.s2 + 0.9, S.s3 + 0.7, S.s4 + 0.5];

/**
 * Ducking: backsound mengecil saat SFX bunyi, lalu naik pelan ke volume normal.
 * depth = sisa volume saat ditekan (0.45 = turun ke 45%), d = lama SFX.
 */
const DUCK: Array<{t: number; d: number; depth: number}> = [
  ...WHOOSH_AT.map((t) => ({t, d: 2.2, depth: 0.4})),
  ...TRANS_AT.map((t) => ({t, d: 0.45, depth: 0.5})),
  ...CLICK_TIMES.map((t) => ({t, d: 0.37, depth: 0.78})),
];
const duckGain = (time: number) =>
  DUCK.reduce((g, e) => {
    const v = interpolate(time, [e.t - 0.12, e.t + 0.03, e.t + e.d, e.t + e.d + 0.7], [1, e.depth, e.depth, 1], clamp);
    return Math.min(g, v);
  }, 1);

export const EcoAction: React.FC = () => {
  const {fps} = useVideoConfig();
  RT_FPS = fps;
  const musicVol = (frame: number) =>
    interpolate(frame, [0, sec(2)], [0, 0.8], clamp) /* tanpa fade out: musik lanjut mulus ke hari kedua */ * duckGain(frame / fps);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Footage />
      <Vignette />

      {/* Scene 1 — opening */}
      <Layer at={1.2} dur={12.3} rise={30}>
        <Opening />
      </Layer>
      <Layer at={5.5} dur={7.8} rise={20}>
        <OpeningFooter />
      </Layer>
      {/* Scene 2 — pengenalan */}
      <Layer at={S.s2 + 0.9} dur={6.4}>
        <Intro />
      </Layer>
      {/* Scene 3 — agenda hari pertama */}
      <Layer at={S.s3 + 0.7} dur={12}>
        <Agenda />
      </Layer>
      {/* Scene 4 — diskusi dan perencanaan */}
      <Layer at={S.s4 + 0.5} dur={11.2} rise={0}>
        <Discuss />
      </Layer>
      {/* Scene 5 — preview kegiatan (tanpa teks, footage saja) */}
      {/* Scene 6 — closing */}
      <Layer at={S.s6 + 0.2} dur={7.4} rise={0}>
        <Closing />
      </Layer>

      <Bug />
      <ProgressBar />
      <EndFade />

      {/* Audio: backsound + sound effect */}
      <Audio src={staticFile('backsound.mp3')} volume={musicVol} />
      {/* whoosh: pergantian scene */}
      {WHOOSH_AT.map((t, i) => (
        <Sequence key={`w${i}`} from={sec(t)}>
          <Audio src={staticFile('whoosh.mp3')} volume={0.8} />
        </Sequence>
      ))}
      {/* transition: judul / panel teks muncul */}
      {TRANS_AT.map((t, i) => (
        <Sequence key={`t${i}`} from={sec(t)}>
          <Audio src={staticFile('transition.mp3')} volume={0.8} />
        </Sequence>
      ))}
      {/* click: tiap poin / langkah muncul */}
      {CLICK_TIMES.map((t, i) => (
        <Sequence key={`c${i}`} from={sec(t)}>
          <Audio src={staticFile('click.mp3')} volume={1} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
