import React from 'react';
import {Composition} from 'remotion';
import {Teardown} from './Teardown';

export const RemotionRoot: React.FC = () => (
  <Composition id="Teardown" component={Teardown} durationInFrames={3990} fps={60} width={1920} height={1080} />
);
