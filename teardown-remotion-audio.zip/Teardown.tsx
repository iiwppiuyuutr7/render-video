import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  BONGKAR ISI HP FLAGSHIP  (teardown 3D, tanpa narasi, label + panah)
  66,5 detik, landscape 1920x1080, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Model HP generik (desain orisinal, tanpa logo/merek) dibuat dari kotak 3D, dirender SVG murni (tanpa WebGL).
  Satuan model: 1 unit = 10 mm. Layar menghadap atas (+z), sumbu panjang = x.
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']}).fontFamily;

const W = 1920;
const H = 1080;
const CX = 960;
const DUR = 66.5;

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  cyan: '#5ad1ff',
  red: '#ff4d4d',
  green: '#6ee7a0',
  ink: '#5a3d22',
};

/* ---------- util ---------- */

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (
  t: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (x: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.4) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const rad = (d: number) => (d * Math.PI) / 180;
// pop dengan overshoot
const pop = (t: number, a: number, d = 0.5) => {
  const p = Math.min(1, Math.max(0, (t - a) / d));
  const c1 = 1.70158;
  return p <= 0 ? 0 : 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};

const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const shade = (h: string, k: number) => `rgb(${hex(h).map((v) => Math.max(0, Math.min(255, Math.round(v * k)))).join(',')})`;

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};


/* ================= mesin voxel 3D (SVG) ================= */

type Cam = {yaw: number; pitch: number; zoom: number; cx: number; cy: number; tx: number; ty: number; tz: number};
// x,y,z = pojok minimum; w,d,h = ukuran; e = emisif (tidak digelapkan); o = opacity; b = bias urutan gambar
type Bx = {x: number; y: number; z: number; w: number; d: number; h: number; c: string; e?: boolean; o?: number; b?: number};

const mk = (yaw: number, pitch: number, zoom: number, tx: number, ty: number, tz: number, cy = 820): Cam => ({yaw, pitch, zoom, cx: 540, cy, tx, ty, tz});

const proj = (c: Cam, x: number, y: number, z: number): [number, number, number] => {
  const cs = Math.cos(c.yaw);
  const sn = Math.sin(c.yaw);
  const sp = Math.sin(c.pitch);
  const cp = Math.cos(c.pitch);
  const dx = x - c.tx;
  const dy = y - c.ty;
  const dz = z - c.tz;
  const x1 = dx * cs - dy * sn;
  const y1 = dx * sn + dy * cs;
  return [c.cx + c.zoom * x1, c.cy + c.zoom * (y1 * sp - dz * cp), y1 * cp + dz * sp];
};

const rgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mul = (h: string, k: number) => {
  const v = rgb(h);
  return `rgb(${v.map((n) => Math.max(0, Math.min(255, Math.round(n * k)))).join(',')})`;
};
const LIGHT = (() => {
  const v = [0.55, -0.5, 0.9];
  const l = Math.hypot(v[0], v[1], v[2]);
  return v.map((a) => a / l);
})();

const FACES: {n: [number, number, number]; v: number[][]}[] = [
  {n: [0, 0, 1], v: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]]},
  {n: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]]},
  {n: [-1, 0, 0], v: [[0, 1, 0], [0, 0, 0], [0, 0, 1], [0, 1, 1]]},
  {n: [0, 1, 0], v: [[1, 1, 0], [0, 1, 0], [0, 1, 1], [1, 1, 1]]},
  {n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]]},
];

const Voxels: React.FC<{boxes: Bx[]; cam: Cam; edge?: number}> = ({boxes, cam, edge = 0.3}) => {
  const sn = Math.sin(cam.yaw);
  const cs = Math.cos(cam.yaw);
  const items: {d: number; pts: string; f: string; o: number}[] = [];
  for (const b of boxes) {
    if (b.o === 0 || b.h <= 0.001) continue;
    const d0 = proj(cam, b.x + b.w / 2, b.y + b.d / 2, b.z + b.h / 2)[2] + (b.b || 0);
    for (let fi = 0; fi < 5; fi++) {
      const f = FACES[fi];
      if (fi > 0 && f.n[0] * sn + f.n[1] * cs <= 0) continue;
      const dot = f.n[0] * LIGHT[0] + f.n[1] * LIGHT[1] + f.n[2] * LIGHT[2];
      const k = fi === 0 ? 1.08 : 0.5 + 0.5 * Math.max(0, dot) + 0.12;
      const pts = f.v
        .map((v) => {
          const p = proj(cam, b.x + v[0] * b.w, b.y + v[1] * b.d, b.z + v[2] * b.h);
          return p[0].toFixed(1) + ',' + p[1].toFixed(1);
        })
        .join(' ');
      items.push({d: d0 + (fi === 0 ? 0.0004 : 0), pts, f: b.e ? mul(b.c, fi === 0 ? 1.1 : 0.92) : mul(b.c, k), o: b.o === undefined ? 1 : b.o});
    }
  }
  items.sort((a, b) => a.d - b.d);
  return (
    <g stroke="rgba(0,0,0,0.28)" strokeWidth={edge} strokeLinejoin="round">
      {items.map((it, i) => (
        <polygon key={i} points={it.pts} fill={it.f} opacity={it.o} />
      ))}
    </g>
  );
};

const Shadow: React.FC<{cam: Cam; x: number; y: number; rx: number; ry: number; o?: number}> = ({cam, x, y, rx, ry, o = 0.35}) => {
  const p = proj(cam, x, y, 0);
  return <ellipse cx={p[0]} cy={p[1] + 40} rx={rx * cam.zoom} ry={ry * cam.zoom * 0.5} fill="#000" opacity={o} />;
};

const Label: React.FC<{cam: Cam; x: number; y: number; z: number; text: string; size?: number; color?: string; o?: number; dy?: number}> = ({cam, x, y, z, text, size = 40, color = '#fff', o = 1, dy = 0}) => {
  const p = proj(cam, x, y, z);
  return (
    <text x={p[0]} y={p[1] + dy} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
      {text}
    </text>
  );
};

const T2: React.FC<{x: number; y: number; text: string; size?: number; color?: string; o?: number; anchor?: 'start' | 'middle' | 'end'}> = ({x, y, text, size = 40, color = '#fff', o = 1, anchor = 'middle'}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
    {text}
  </text>
);

/* ================= model HP ================= */

const hexMix = (a: string, b: string, k: number) => {
  const A = rgb(a);
  const B = rgb(b);
  const kk = Math.max(0, Math.min(1, k));
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * kk).toString(16).padStart(2, '0')).join('');
};
const sm = (x: number) => x * x * (3 - 2 * x);
const seg01 = (t: number, a: number, b: number) => Math.min(1, Math.max(0, (t - a) / (b - a)));

type Ex = {e?: boolean; o?: number; b?: number};
const bx = (x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, c: string, ex: Ex = {}): Bx => ({x: x0, y: y0, z: z0, w: x1 - x0, d: y1 - y0, h: z1 - z0, c, ...ex});
// kotak dengan sudut membulat (pendekatan bertangga)
const rr = (x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, r: number, c: string, ex: Ex = {}): Bx[] => {
  const N = 4;
  const out: Bx[] = [bx(x0, x1, y0 + r, y1 - r, z0, z1, c, ex)];
  for (let k = 0; k < N; k++) {
    const dyc = r - (r * (k + 0.5)) / N;
    const ins = r - Math.sqrt(Math.max(0, r * r - dyc * dyc));
    out.push(bx(x0 + ins, x1 - ins, y0 + (r * k) / N, y0 + (r * (k + 1)) / N, z0, z1, c, ex));
    out.push(bx(x0 + ins, x1 - ins, y1 - (r * (k + 1)) / N, y1 - (r * k) / N, z0, z1, c, ex));
  }
  return out;
};
const ringCubes = (cx: number, cy: number, r: number, n: number, s: number, z0: number, z1: number, c: string, ex: Ex = {}): Bx[] => {
  const out: Bx[] = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    out.push(bx(cx + Math.cos(a) * r - s / 2, cx + Math.cos(a) * r + s / 2, cy + Math.sin(a) * r - s / 2, cy + Math.sin(a) * r + s / 2, z0, z1, c, ex));
  }
  return out;
};

const X0 = -8.15;
const X1 = 8.15;
const Y0 = -3.85;
const Y1 = 3.85;
const RC = 1.0;

// bingkai logam (cincin)
const frameRing = (c: string): Bx[] => {
  const tw = 0.4;
  const out: Bx[] = [];
  const z0 = 0;
  const z1 = 0.74;
  const xc = X1 - RC;
  const yc = Y1 - RC;
  out.push(bx(X0, X0 + tw, -yc, yc, z0, z1, c), bx(X1 - tw, X1, -yc, yc, z0, z1, c));
  out.push(bx(-xc, xc, Y1 - tw, Y1, z0, z1, c), bx(-xc, xc, Y0, Y0 + tw, z0, z1, c));
  const N = 4;
  for (const sx of [-1, 1])
    for (const sy of [-1, 1])
      for (let k = 0; k < N; k++) {
        const dy = (RC * (k + 0.5)) / N;
        const xo = Math.sqrt(RC * RC - dy * dy);
        const xi = Math.sqrt(Math.max(0, (RC - tw) * (RC - tw) - dy * dy));
        const ya = (RC * k) / N;
        const yb = (RC * (k + 1)) / N;
        const xa = sx > 0 ? xc + xi : xc - xo;
        const xb = sx > 0 ? xc + xo : xc - xi;
        const y0 = sy > 0 ? yc + ya : yc * -1 - yb;
        const y1 = sy > 0 ? yc + yb : yc * -1 - ya;
        out.push(bx(xa, xb, y0, y1, z0, z1, c));
      }
  return out;
};

const L_NAMES = ['KACA BELAKANG', 'KOIL CHARGING', 'MODUL KAMERA', 'BATERAI & PERANGKAT', 'PAPAN SIRKUIT', 'BINGKAI LOGAM', 'PANEL OLED', 'KACA PELINDUNG'];
const SP = 2.0;

const phoneParts = (t: number): Bx[][] => {
  const L: Bx[][] = [[], [], [], [], [], [], [], []];
  // L0 kaca belakang
  L[0].push(...rr(X0 + 0.15, X1 - 0.15, Y0 + 0.15, Y1 - 0.15, 0, 0.1, RC - 0.1, '#26344f'));
  L[0].push(bx(-7.4, -3.6, 0.0, 3.5, 0.1, 0.103, '#0b0e14'));
  L[0].push(bx(-1.4, 1.6, -0.6, 0.6, 0.1, 0.103, '#3d4f78'));
  // L1 koil + magnet
  L[1].push(...rr(-2.4, 4.0, -3.2, 3.2, 0.1, 0.12, 1.4, '#3b4252'));
  L[1].push(...ringCubes(0.8, 0, 1.2, 22, 0.24, 0.12, 0.17, '#d9893a'));
  L[1].push(...ringCubes(0.8, 0, 1.7, 30, 0.24, 0.12, 0.17, '#e39a4a'));
  L[1].push(...ringCubes(0.8, 0, 2.2, 38, 0.24, 0.12, 0.17, '#d9893a'));
  L[1].push(...ringCubes(0.8, 0, 2.85, 26, 0.32, 0.12, 0.2, '#9aa3b2'));
  L[1].push(bx(0.55, 1.05, -0.25, 0.25, 0.12, 0.18, '#b9c0cc'));
  // L2 kamera
  L[2].push(...rr(-7.5, -3.5, 0.0, 3.6, 0.1, 0.3, 0.6, '#171b22'));
  const lens = (x0: number, x1: number, y0: number, y1: number, h: number) => {
    const r = Math.min(x1 - x0, y1 - y0) / 2;
    L[2].push(...rr(x0, x1, y0, y1, 0.3, 0.3 + h, r, '#3a4252'));
    L[2].push(...rr(x0 + 0.12, x1 - 0.12, y0 + 0.12, y1 - 0.12, 0.3 + h, 0.34 + h, r - 0.1, '#232a36'));
    L[2].push(...rr(x0 + 0.26, x1 - 0.26, y0 + 0.26, y1 - 0.26, 0.34 + h, 0.37 + h, r - 0.2, '#16306e'));
    L[2].push(bx(x0 + 0.34, x0 + 0.54, y1 - 0.5, y1 - 0.34, 0.37 + h, 0.375 + h, '#9fd0ff', {e: true}));
  };
  lens(-7.0, -5.0, 1.0, 3.0, 0.2);
  lens(-5.05, -3.75, 2.05, 3.35, 0.12);
  lens(-5.05, -3.75, 0.25, 1.55, 0.14);
  L[2].push(bx(-6.35, -5.85, 0.35, 0.85, 0.3, 0.36, '#fff3b0', {e: true}));
  L[2].push(bx(-5.75, -5.35, 0.35, 0.75, 0.3, 0.38, '#0f1218'));
  // L3 baterai + perangkat
  L[3].push(...rr(-1.2, 4.4, -2.7, 2.7, 0.16, 0.46, 0.5, '#c7ccd4'));
  L[3].push(bx(-0.6, 3.8, -1.4, 1.4, 0.46, 0.47, '#e9edf2'));
  for (let i = 0; i < 5; i++) {
    const on = 0.5 + 0.5 * Math.sin(t * 2.5 - i * 0.9);
    L[3].push(bx(-0.4 + i * 0.84, 0.3 + i * 0.84, -0.9, 0.9, 0.47, 0.48, hexMix('#1f6b45', '#6ee7a0', on), {e: true}));
  }
  L[3].push(bx(4.4, 5.0, -0.6, 0.6, 0.16, 0.2, '#e0e5ea'));
  L[3].push(bx(4.8, 6.0, 0.9, 3.1, 0.16, 0.44, '#7a828f'), bx(4.9, 5.9, 1.0, 3.0, 0.44, 0.48, '#aab2bf'));
  L[3].push(...rr(6.1, 7.7, -3.2, -1.2, 0.16, 0.44, 0.4, '#2a2f3a'));
  for (let i = 0; i < 4; i++) L[3].push(bx(6.35 + i * 0.35, 6.55 + i * 0.35, -3.0, -1.4, 0.44, 0.46, '#59606e'));
  L[3].push(bx(7.2, 8.0, -0.7, 0.7, 0.2, 0.42, '#c7ccd4'), bx(7.96, 8.02, -0.5, 0.5, 0.25, 0.37, '#0b0e14'));
  L[3].push(bx(-3.0, -0.6, 3.0, 3.6, 0.2, 0.42, '#aab2bf'), bx(-1.9, -1.7, 3.55, 3.62, 0.3, 0.34, '#2a2f3a'));
  // L4 papan sirkuit
  const PCB = '#1f7a4a';
  L[4].push(...rr(-7.6, -1.6, -3.4, 3.4, 0.16, 0.2, 0.6, PCB));
  L[4].push(...rr(5.0, 7.7, -3.4, 3.4, 0.16, 0.2, 0.6, PCB));
  L[4].push(bx(-1.6, 5.0, -3.4, -2.85, 0.16, 0.2, PCB));
  const tr = '#2fae6e';
  for (const [x0, x1, y0, y1] of [[-3.4, -1.7, -0.6, -0.5], [-3.4, -2.3, 0.0, 0.1], [-5.6, -5.5, -3.0, 1.0], [-6.2, -3.6, 1.8, 1.9], [-2.0, -1.9, -2.2, 2.6], [-6.5, -5.5, -1.8, -1.7], [-4.4, -3.0, -2.4, -2.3], [-1.6, 5.0, -3.1, -3.0]]) L[4].push(bx(x0, x1, y0, y1, 0.2, 0.205, tr));
  // pulsa data di jalur
  for (let i = 0; i < 4; i++) {
    const p = (t * 0.7 + i * 0.25) % 1;
    L[4].push(bx(-3.4 + p * 1.7 - 0.12, -3.4 + p * 1.7 + 0.12, -0.62, -0.48, 0.2, 0.215, '#9ff0ff', {e: true}));
  }
  const glow = 0.5 + 0.5 * Math.sin(t * 4);
  L[4].push(bx(-5.4, -3.4, -1.4, 0.6, 0.2, 0.3, '#20242d'), bx(-5.3, -3.5, -1.3, 0.5, 0.3, 0.33, '#d4dae3'), bx(-4.9, -3.9, -0.9, 0.1, 0.33, 0.335, hexMix('#2a2f3a', '#5ad1ff', glow), {e: true}));
  L[4].push(bx(-5.0, -3.8, -0.9, 0.1, 0.335, 0.4, '#3a3f4b'), bx(-4.8, -4.0, -0.7, -0.1, 0.4, 0.405, '#6b7384'));
  L[4].push(bx(-3.0, -1.9, 0.9, 2.4, 0.2, 0.27, '#2d333f'), bx(-2.85, -2.05, 1.05, 2.25, 0.27, 0.275, '#7f8898'));
  L[4].push(bx(-3.1, -2.0, -2.6, -1.1, 0.2, 0.26, '#3b4150'), bx(-2.95, -2.15, -2.45, -1.25, 0.26, 0.265, '#8b93a3'));
  L[4].push(bx(-6.9, -5.8, 1.1, 2.5, 0.2, 0.25, '#2d333f'), bx(-6.9, -6.0, -2.9, -1.7, 0.2, 0.25, '#4a4f5c'));
  for (const [x, y] of [[-6.7, -2.6], [-6.4, -2.2], [-6.5, -1.9]]) L[4].push(bx(x, x + 0.2, y, y + 0.2, 0.25, 0.28, '#e0b44a'));
  L[4].push(bx(-1.4, -1.0, -0.8, 0.8, 0.2, 0.26, '#caa24a'));
  for (const y of [-1.0, 0.0, 1.0]) L[4].push(bx(-7.2, -6.8, y - 0.3, y + 0.3, 0.2, 0.27, '#171b22'));
  L[4].push(bx(-7.7, -7.4, -1.2, 1.2, 0.2, 0.4, '#2a2f3a'));
  L[4].push(bx(5.7, 6.5, 0.8, 1.8, 0.2, 0.26, '#2d333f'));
  for (const [x, y] of [[5.4, -2.6], [5.7, -2.2], [6.2, 2.5], [6.6, 2.9], [5.3, 2.8]]) L[4].push(bx(x, x + 0.22, y, y + 0.22, 0.2, 0.28, '#e0b44a'));
  // L5 bingkai
  L[5].push(...frameRing('#9097a3'));
  for (const [x0, x1] of [[-5.3, -5.0], [4.6, 4.9]]) L[5].push(bx(x0, x1, Y1 - 0.4, Y1 + 0.005, 0, 0.74, '#1c1f26'));
  for (const [x0, x1] of [[-3.6, -3.3], [3.8, 4.1]]) L[5].push(bx(x0, x1, Y0 - 0.005, Y0 + 0.4, 0, 0.74, '#1c1f26'));
  L[5].push(bx(0.4, 2.4, Y1, Y1 + 0.25, 0.3, 0.55, '#aeb5c2'));
  L[5].push(bx(-2.8, -1.5, Y0 - 0.25, Y0, 0.3, 0.55, '#aeb5c2'), bx(-1.2, 0.1, Y0 - 0.25, Y0, 0.3, 0.55, '#aeb5c2'), bx(-4.6, -3.8, Y0 - 0.25, Y0, 0.3, 0.55, '#e08a3a'));
  L[5].push(bx(X1, X1 + 0.06, -0.6, 0.6, 0.25, 0.5, '#0b0e14'));
  for (let i = 0; i < 5; i++) L[5].push(bx(X1, X1 + 0.06, -2.9 + i * 0.3, -2.75 + i * 0.3, 0.3, 0.45, '#0b0e14'));
  // L6 panel OLED
  L[6].push(...rr(-8.0, 8.0, -3.7, 3.7, 0.74, 0.8, 0.95, '#141c33'));
  L[6].push(bx(-7.6, 7.6, -3.3, 3.3, 0.8, 0.802, '#1d2a55'));
  const px = exK(6, t);
  if (px > 0.05)
  for (let i = 0; i < 9; i++)
    for (let j = 0; j < 4; j++)
      for (let c = 0; c < 3; c++) {
        const ph = 0.5 + 0.5 * Math.sin(t * 3 + i * 0.7 + j);
        const col = ['#ff3b3b', '#3bff6a', '#3b6bff'][c];
        L[6].push(bx(1.6 + i * 0.3 + c * 0.09, 1.6 + i * 0.3 + c * 0.09 + 0.07, 1.8 + j * 0.3, 1.8 + j * 0.3 + 0.24, 0.802, 0.806, hexMix('#0b0d12', col, 0.4 + 0.6 * ph), {e: true, o: px}));
      }
  L[6].push(bx(7.5, 7.9, -1.0, 1.0, 0.45, 0.8, '#c98a3a'), bx(7.1, 7.9, -1.0, 1.0, 0.45, 0.5, '#c98a3a'));
  // L7 kaca pelindung
  L[7].push(...rr(X0, X1, Y0, Y1, 0.8, 0.88, RC, '#bcd2ff', {o: 0.2}));
  L[7].push(bx(-8.0, 8.0, 3.5, 3.7, 0.88, 0.885, '#06080c'), bx(-8.0, 8.0, -3.7, -3.5, 0.88, 0.885, '#06080c'), bx(-8.0, -7.8, -3.5, 3.5, 0.88, 0.885, '#06080c'), bx(7.8, 8.0, -3.5, 3.5, 0.88, 0.885, '#06080c'));
  L[7].push(bx(-7.35, -6.95, -0.5, 0.5, 0.885, 0.89, '#05070a'), bx(-7.22, -7.12, 0.1, 0.25, 0.89, 0.892, '#3a5a9a', {e: true}));
  L[7].push(bx(-7.75, -7.65, -0.9, 0.9, 0.885, 0.887, '#06080c'));
  const sx = -9 + ((t * 4.5) % 22);
  const a0 = Math.max(-7.8, sx);
  const a1 = Math.min(7.8, sx + 1.3);
  if (a1 > a0) L[7].push(bx(a0, a1, -3.3, 3.3, 0.89, 0.8905, '#ffffff', {e: true, o: 0.22}));
  return L;
};
const LBASE = [0.05, 0.13, 0.33, 0.33, 0.33, 0.37, 0.77, 0.84];

/* ================= linimasa ================= */

type Tour = {k: number; a: number; b: number};
const TOUR: Tour[] = [
  {k: 7, a: 15.0, b: 19.0},
  {k: 6, a: 19.0, b: 23.5},
  {k: 5, a: 23.5, b: 27.8},
  {k: 4, a: 27.8, b: 33.5},
  {k: 3, a: 33.5, b: 38.5},
  {k: 2, a: 38.5, b: 43.5},
  {k: 1, a: 43.5, b: 47.5},
  {k: 0, a: 47.5, b: 51.0},
];
const EX_A = 10.2;
const RE_A = 51.8;
const zc = (k: number) => k * SP + LBASE[k];

const exK = (k: number, t: number) => {
  const up = sm(seg01(t, EX_A + (7 - k) * 0.28, EX_A + (7 - k) * 0.28 + 1.5));
  const dn = sm(seg01(t, RE_A + k * 0.28, RE_A + k * 0.28 + 1.5));
  return up * (1 - dn);
};

const layerOpacity = (k: number, t: number) => {
  if (t < TOUR[0].a || t >= RE_A) {
    if (t >= RE_A) {
      const last = k === 0 ? 1 : 0.3;
      const f = k === 0 ? 1 : 0;
      return f + (1 - f) * sm(seg01(t, RE_A - 0.3, RE_A + 0.4)) * 1 + (k === 0 ? 0 : 0) * last;
    }
    return 1;
  }
  let i = 0;
  TOUR.forEach((s, j) => {
    if (t >= s.a) i = j;
  });
  const st = (j: number) => (j < 0 ? 1 : k === TOUR[j].k ? 1 : k < TOUR[j].k ? 0.3 : 0);
  const bl = sm(seg01(t, TOUR[i].a, TOUR[i].a + 0.6));
  return st(i - 1) * (1 - bl) + st(i) * bl;
};

// kamera: [t, yaw, pitch, zoom, tx, ty, tz]
const CAM_K: number[][] = (() => {
  const K: number[][] = [
    [0, -1.1, 0.95, 60, 0, 0, 0.4],
    [5.0, -0.5, 0.62, 74, 0, 0, 0.4],
    [9.8, -0.15, 0.6, 76, 0, 0, 0.4],
    [14.2, -0.3, 0.52, 48, 0, 0, 7.4],
  ];
  const fx: Record<number, [number, number, number, number]> = {
    7: [0, 0, 66, 0.55],
    6: [0, 0, 66, 0.58],
    5: [0, 0, 66, 0.6],
    4: [-3.2, 0, 92, 0.62],
    3: [2.0, 0, 70, 0.6],
    2: [-5.4, 1.8, 118, 0.62],
    1: [0.8, 0, 82, 0.62],
    0: [0, 0, 66, 0.6],
  };
  TOUR.forEach((s, i) => {
    const [x, y, z, p] = fx[s.k];
    const sgn = i % 2 ? 1 : -1;
    K.push([s.a + 1.0, -0.38 * sgn, p, z, x, y, zc(s.k)]);
    K.push([s.b - 0.3, 0.28 * sgn, p + 0.05, z * 1.04, x, y, zc(s.k)]);
  });
  K.push([54.0, -0.2, 0.5, 50, 0, 0, 5.5]);
  K.push([58.0, -0.6, 0.6, 72, 0, 0, 0.4]);
  K.push([63.0, 0.5, 0.5, 66, 0, 0, 0.4]);
  K.push([66.5, 0.8, 0.5, 66, 0, 0, 0.4]);
  return K;
})();

const camAt = (t: number): Cam => {
  const K = CAM_K;
  let v: number[];
  if (t <= K[0][0]) v = K[0].slice(1);
  else if (t >= K[K.length - 1][0]) v = K[K.length - 1].slice(1);
  else {
    let i = 0;
    while (i < K.length - 2 && t > K[i + 1][0]) i++;
    const k = sm(seg01(t, K[i][0], K[i + 1][0]));
    v = K[i].slice(1).map((a, j) => a + (K[i + 1][j + 1] - a) * k);
  }
  const c = mk(v[0], v[1], v[2], v[3], v[4], v[5], 580);
  return {...c, cx: CX};
};

/* ================= callout ================= */

type Call = {t: string; p: [number, number, number]; k: number};
type Group = {a: number; b: number; col: string; calls: Call[]};
const GROUPS: Group[] = [
  {
    a: 5.2, b: 9.9, col: '#5ad1ff', calls: [
      {t: 'LAYAR OLED', p: [3.5, 1.2, 0.89], k: 7},
      {t: 'KAMERA DEPAN', p: [-7.15, 0, 0.89], k: 7},
      {t: 'TOMBOL DAYA', p: [1.4, 4.1, 0.45], k: 5},
      {t: 'TOMBOL VOLUME', p: [-2.1, -4.1, 0.45], k: 5},
      {t: 'TOMBOL AKSI', p: [-4.2, -4.1, 0.45], k: 5},
      {t: 'PORT USB-C', p: [8.2, 0, 0.38], k: 5},
      {t: 'LUBANG SPEAKER', p: [8.2, -2.2, 0.38], k: 5},
    ],
  },
  {
    a: 15.0, b: 19.0, col: '#bcd2ff', calls: [
      {t: 'KACA PELINDUNG', p: [3.0, 2.0, 0.88], k: 7},
      {t: 'LUBANG KAMERA DEPAN', p: [-7.15, 0, 0.89], k: 7},
      {t: 'SLOT SPEAKER ATAS', p: [-7.7, 0.7, 0.887], k: 7},
    ],
  },
  {
    a: 19.0, b: 23.5, col: '#6ee7a0', calls: [
      {t: 'PANEL OLED', p: [-3.0, 1.5, 0.8], k: 6},
      {t: 'PIKSEL RGB', p: [2.8, 2.3, 0.806], k: 6},
      {t: 'KABEL FLEX LAYAR', p: [7.7, 0, 0.8], k: 6},
    ],
  },
  {
    a: 23.5, b: 27.8, col: '#c9ced8', calls: [
      {t: 'BINGKAI LOGAM', p: [6.0, -3.85, 0.74], k: 5},
      {t: 'GARIS ANTENA', p: [-5.15, 3.85, 0.74], k: 5},
      {t: 'TOMBOL DAYA', p: [1.4, 4.1, 0.55], k: 5},
      {t: 'TOMBOL VOLUME', p: [-2.1, -4.1, 0.55], k: 5},
      {t: 'TOMBOL AKSI', p: [-4.2, -4.1, 0.55], k: 5},
      {t: 'LUBANG USB-C', p: [8.2, 0, 0.5], k: 5},
    ],
  },
  {
    a: 27.8, b: 33.5, col: '#6ee7a0', calls: [
      {t: 'PAPAN SIRKUIT UTAMA', p: [-2.2, -1.0, 0.2], k: 4},
      {t: 'CHIP UTAMA (SoC)', p: [-4.4, -0.4, 0.335], k: 4},
      {t: 'RAM', p: [-4.4, -0.3, 0.405], k: 4},
      {t: 'MODEM 5G', p: [-2.45, 1.7, 0.275], k: 4},
      {t: 'PENYIMPANAN (NAND)', p: [-2.5, -1.8, 0.265], k: 4},
      {t: 'IC MANAJEMEN DAYA', p: [-6.3, 1.8, 0.25], k: 4},
      {t: 'SENSOR WAJAH', p: [-7.0, 0.0, 0.27], k: 4},
      {t: 'SPEAKER ATAS', p: [-7.55, 0, 0.4], k: 4},
    ],
  },
  {
    a: 33.5, b: 38.5, col: '#ffd45a', calls: [
      {t: 'BATERAI LI-ION', p: [1.6, 0.0, 0.48], k: 3},
      {t: 'TAB PELEPAS BATERAI', p: [4.7, 0, 0.2], k: 3},
      {t: 'MOTOR GETAR (TAPTIC)', p: [5.4, 2.0, 0.48], k: 3},
      {t: 'SPEAKER BAWAH', p: [6.9, -2.2, 0.46], k: 3},
      {t: 'PORT USB-C', p: [7.6, 0, 0.42], k: 3},
      {t: 'NAMPAN SIM', p: [-1.8, 3.3, 0.42], k: 3},
    ],
  },
  {
    a: 38.5, b: 43.5, col: '#5ad1ff', calls: [
      {t: 'KAMERA UTAMA', p: [-6.0, 2.0, 0.57], k: 2},
      {t: 'KAMERA ULTRAWIDE', p: [-4.4, 2.7, 0.49], k: 2},
      {t: 'KAMERA TELE', p: [-4.4, 0.9, 0.51], k: 2},
      {t: 'LAMPU FLASH', p: [-6.1, 0.6, 0.36], k: 2},
      {t: 'SENSOR LIDAR', p: [-5.55, 0.55, 0.38], k: 2},
    ],
  },
  {
    a: 43.5, b: 47.5, col: '#ff9a5a', calls: [
      {t: 'KOIL CHARGING NIRKABEL', p: [0.8, 2.2, 0.17], k: 1},
      {t: 'CINCIN MAGNET', p: [3.65, 0, 0.2], k: 1},
    ],
  },
  {
    a: 47.5, b: 51.0, col: '#9fb4e8', calls: [
      {t: 'KACA BELAKANG', p: [4.5, -2.0, 0.1], k: 0},
      {t: 'LUBANG MODUL KAMERA', p: [-5.5, 1.8, 0.103], k: 0},
    ],
  },
];

const Callouts: React.FC<{t: number; cam: Cam; g: Group}> = ({t, cam, g}) => {
  if (t < g.a || t > g.b + 0.4) return null;
  const fade = ramp(t, g.b - 0.35, g.b, 1, 0, lin);
  const items = g.calls.map((c, i) => {
    const pr_ = proj(cam, c.p[0], c.p[1], c.p[2] + c.k * SP * exK(c.k, t));
    const ai = g.a + 0.5 + i * 0.36;
    const prog = ramp(t, ai, ai + 0.45, 0, 1, outC);
    return {c, ax: pr_[0], ay: pr_[1], prog, side: pr_[0] < CX ? 'L' : 'R', ly: 0};
  });
  for (const side of ['L', 'R']) {
    const s = items.filter((x) => x.side === side).sort((a, b) => a.ay - b.ay);
    let prev = 120;
    s.forEach((x) => {
      x.ly = Math.max(x.ay, prev + 92);
      prev = x.ly;
    });
    if (s.length && s[s.length - 1].ly > 1000) {
      const sh = s[s.length - 1].ly - 1000;
      s.forEach((x) => (x.ly -= sh));
      let up = 120;
      s.forEach((x) => {
        x.ly = Math.max(x.ly, up);
        up = x.ly + 92;
      });
    }
  }
  return (
    <g opacity={fade}>
      {items.map((it, i) => {
        if (it.prog <= 0) return null;
        const w = it.c.t.length * 19.5 + 64;
        const left = it.side === 'L';
        const edge = left ? 56 + w : 1864 - w;
        const elbow = left ? edge + 46 : edge - 46;
        const pts = [[it.ax, it.ay], [elbow, it.ly], [edge, it.ly]];
        const full = Math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1]) + 46;
        const dash = full * it.prog;
        const px = left ? 56 : 1864 - w;
        const pulse = 1 + 0.6 * ((t * 1.4 + i * 0.3) % 1);
        return (
          <g key={i}>
            <polyline points={pts.map((p) => p.join(',')).join(' ')} fill="none" stroke="#ffffff" strokeWidth={3} strokeDasharray={`${dash} ${full + 10}`} strokeLinecap="round" strokeLinejoin="round" opacity={0.95} />
            <circle cx={it.ax} cy={it.ay} r={8 * Math.min(1, it.prog * 2)} fill="#fff" stroke={g.col} strokeWidth={3} />
            <circle cx={it.ax} cy={it.ay} r={8 * pulse} fill="none" stroke={g.col} strokeWidth={2} opacity={0.7 - 0.4 * (pulse - 1)} />
            <g transform={`translate(${px},${it.ly - 31}) ${left ? '' : ''}`} opacity={Math.max(0, (it.prog - 0.5) * 2)}>
              <rect width={w} height={62} rx={14} fill="rgba(8,14,30,0.88)" stroke={g.col} strokeWidth={2.5} />
              <rect width={9} height={62} rx={4} fill={g.col} />
              <text x={26} y={43} fontFamily={cond} fontWeight={700} fontSize={36} letterSpacing="0.05em" fill="#fff">
                {it.c.t}
              </text>
            </g>
          </g>
        );
      })}
    </g>
  );
};

/* ================= latar & HUD ================= */

const DUST = (() => {
  const r = mulberry32(9);
  return Array.from({length: 70}, () => ({x: r() * W, y: r() * H, s: r() * 2.4 + 0.8, o: r() * 0.35 + 0.1, v: 6 + r() * 20, p: r() * 6.28}));
})();

const Bg: React.FC<{t: number; cam: Cam}> = ({t, cam}) => {
  const c = proj(cam, 0, 0, 7);
  return (
    <AbsoluteFill>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <defs>
          <radialGradient id="bgr" cx="50%" cy="48%" r="75%">
            <stop offset="0" stopColor="#1b2c55" />
            <stop offset="0.6" stopColor="#0c1330" />
            <stop offset="1" stopColor="#05070f" />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill="url(#bgr)" />
        {Array.from({length: 14}).map((_, i) => (
          <line key={i} x1={0} y1={H * 0.62 + i * i * 3.2} x2={W} y2={H * 0.62 + i * i * 3.2} stroke="#5ad1ff" strokeOpacity={0.05} />
        ))}
        <circle cx={CX} cy={560} r={520} fill="#5ad1ff" opacity={0.05} />
        <circle cx={CX} cy={560} r={360} fill="#5ad1ff" opacity={0.05} />
        {DUST.map((d, k) => (
          <circle key={k} cx={(d.x + Math.sin(t * 0.3 + d.p) * 20) % W} cy={(((d.y - t * d.v) % H) + H) % H} r={d.s} fill="#bfe9ff" opacity={d.o * (0.6 + 0.4 * Math.sin(t * 1.5 + d.p))} />
        ))}
        {c[0] < -9999 && null}
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{t: number}> = ({t}) => {
  let s = -1;
  TOUR.forEach((x, i) => {
    if (t >= x.a) s = i;
  });
  const o = ramp(t, 14.6, 15.2, 0, 1, lin) * ramp(t, 51.0, 51.6, 1, 0, lin);
  if (s < 0 || o <= 0) return null;
  return (
    <div style={{position: 'absolute', left: 56, top: 44, opacity: o}}>
      <div style={{fontFamily: cond, fontWeight: 600, fontSize: 30, letterSpacing: '0.16em', color: 'rgba(255,255,255,0.7)'}}>{`LAPISAN ${s + 1} / 8`}</div>
      <div style={{fontFamily: cond, fontWeight: 700, fontSize: 64, letterSpacing: '0.04em', color: '#fff', lineHeight: 1}}>{L_NAMES[TOUR[s].k]}</div>
      <div style={{display: 'flex', gap: 8, marginTop: 14}}>
        {TOUR.map((_, i) => (
          <div key={i} style={{width: 52, height: 6, borderRadius: 3, background: i <= s ? C.orange : 'rgba(255,255,255,0.2)'}} />
        ))}
      </div>
    </div>
  );
};

const TitleCard: React.FC<{t: number}> = ({t}) => {
  const o = ramp(t, 0.3, 1.0, 0, 1, lin) * ramp(t, 4.4, 5.0, 1, 0, lin);
  const o2 = ramp(t, 10.0, 10.4, 0, 1, lin) * ramp(t, 12.4, 13.2, 1, 0, lin);
  return (
    <>
      {o > 0 && (
        <div style={{position: 'absolute', left: 90, top: 120, opacity: o, transform: `translateY(${(1 - o) * 24}px)`, fontFamily: cond, fontWeight: 700, color: '#fff', textShadow: '0 4px 30px rgba(0,0,0,0.8)'}}>
          <div style={{fontSize: 40, letterSpacing: '0.2em', color: C.cyan}}>TEARDOWN 3D</div>
          <div style={{fontSize: 150, lineHeight: 0.95}}>ISI HP</div>
          <div style={{fontSize: 150, lineHeight: 0.95, color: C.orange}}>FLAGSHIP</div>
        </div>
      )}
      {o2 > 0 && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 70, textAlign: 'center', opacity: o2, fontFamily: cond, fontWeight: 700, fontSize: 110, letterSpacing: '0.1em', color: '#fff', textShadow: '0 4px 30px rgba(0,0,0,0.8)', transform: `scale(${0.9 + 0.1 * o2})`}}>
          BONGKAR!
        </div>
      )}
    </>
  );
};

const Watermark: React.FC<{t: number}> = ({t}) => (
  <div style={{position: 'absolute', right: 60, bottom: 40, opacity: ramp(t, 0.2, 0.8, 0, 0.92, lin) * ramp(t, DUR - 0.8, DUR - 0.2, 1, 0, lin), fontFamily: cond, fontWeight: 700, fontSize: 44, letterSpacing: '0.06em', color: '#fff', textShadow: '0 2px 14px rgba(0,0,0,0.95), 0 0 4px rgba(0,0,0,0.9)'}}>
    Semesta<span style={{color: C.orange}}>Kita</span>
  </div>
);

const EndCard: React.FC<{t: number}> = ({t}) => {
  const e = ramp(t, 63.3, 64.2, 0, 1, outC);
  if (e <= 0) return null;
  return (
    <AbsoluteFill style={{opacity: e, background: 'rgba(0,0,0,0.62)'}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <text x={CX} y={470 + (1 - e) * 30} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={150} letterSpacing="0.05em" fill="#fff">
          SEMESTA<tspan fill={C.orange}>KITA</tspan>
        </text>
        <rect x={CX - 80} y={510} width={160} height={5} fill={C.orange} />
        <text x={CX} y={620} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={64} letterSpacing="0.05em" fill="rgba(255,255,255,0.92)">
          FOLLOW UNTUK BONGKAR BENDA LAINNYA
        </text>
      </svg>
    </AbsoluteFill>
  );
};

export const Teardown: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const cam = camAt(t);
  const parts = phoneParts(t);
  const boxes: Bx[] = [];
  parts.forEach((L, k) => {
    const dz = k * SP * exK(k, t);
    const lo = layerOpacity(k, t);
    if (lo <= 0.01) return;
    for (const b of L) boxes.push({...b, z: b.z + dz, o: (b.o === undefined ? 1 : b.o) * lo, b: k * 1000 + b.z * 300 + (b.b || 0)});
  });
  const fadeIn = ramp(t, 0, 0.3, 1, 0, lin);
  const fadeOut = ramp(t, DUR - 0.5, DUR, 0, 1, lin);
  const gp = proj(cam, 0, 0, 0.4);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Bg t={t} cam={cam} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <ellipse cx={gp[0]} cy={gp[1] + 260 - Math.max(0, 7 * exK(0, t)) * 0} rx={620} ry={90} fill="#5ad1ff" opacity={0.08} />
        <Voxels boxes={boxes} cam={cam} edge={0.35} />
        {GROUPS.map((g, i) => (
          <Callouts key={i} t={t} cam={cam} g={g} />
        ))}
      </svg>
      <TitleCard t={t} />
      <Hud t={t} />
      <Audio src={staticFile('audio.mp3')} />
      <EndCard t={t} />
      <Watermark t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 60%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
