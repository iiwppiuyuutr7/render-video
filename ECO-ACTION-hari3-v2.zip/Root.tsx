import React from 'react';
import {Composition} from 'remotion';
import {EcoActionDay3, ECO3_TOTAL_SECONDS} from './EcoActionDay3';

const FPS = 60;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EcoActionDay3"
    component={EcoActionDay3}
    durationInFrames={Math.round(ECO3_TOTAL_SECONDS * FPS)}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
