import React from 'react';
import {Composition} from 'remotion';
import {Asteroid} from './Asteroid';

export const RemotionRoot: React.FC = () => (
  <Composition id="Asteroid" component={Asteroid} durationInFrames={7596} fps={60} width={1080} height={1920} />
);
