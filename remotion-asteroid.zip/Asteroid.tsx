/**
 * SemestaKita – "Bagaimana Jika Asteroid Raksasa Menabrak Bumi?"
 * 1080x1920 (9:16) · 60 fps · 126,6 detik (7596 frame)
 * Audio: public/audio.mp3 (voiceover + efek suara sudah digabung)
 * Semua waktu di file ini dalam DETIK pada audio.
 */
import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;

const FPS = 60;
const WIDTH = 1080;
const HEIGHT = 1920;
const TOTAL_SECONDS = 126.6;

const OUT = '#2a1a2c';
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;

/* ───────────────── timestamp kata [kata, mulai, selesai] ───────────────── */
const WORDS: Array<[string, number, number]> = [
  ["Bayangkan", 0.00, 0.58],
  ["sebuah", 0.58, 1.00],
  ["batu", 1.00, 1.32],
  ["seukuran", 1.32, 1.85],
  ["gunung", 1.85, 2.27],
  ["melesat", 2.27, 2.75],
  ["ke", 2.75, 2.96],
  ["arah", 2.96, 3.28],
  ["Bumi", 3.28, 3.60],
  ["dengan", 3.60, 4.02],
  ["kecepatan", 4.02, 4.60],
  ["puluhan", 4.60, 5.08],
  ["kilometer", 5.08, 5.66],
  ["per", 5.66, 5.92],
  ["detik.", 5.92, 6.29],
  ["Apa", 6.74, 6.99],
  ["yang", 6.99, 7.28],
  ["sebenarnya", 7.28, 7.87],
  ["terjadi", 7.87, 8.31],
  ["kalau", 8.31, 8.65],
  ["ia", 8.65, 8.85],
  ["menabrak", 8.85, 9.34],
  ["planet", 9.34, 9.73],
  ["kita?", 9.73, 10.02],
  ["Asteroid", 10.61, 11.12],
  ["adalah", 11.12, 11.53],
  ["benda", 11.53, 11.89],
  ["langit", 11.89, 12.30],
  ["berbatu", 12.30, 12.76],
  ["yang", 12.76, 13.07],
  ["mengorbit", 13.07, 13.63],
  ["Matahari.", 13.63, 14.14],
  ["Saat", 14.61, 14.95],
  ["memasuki", 14.95, 15.52],
  ["atmosfer,", 15.52, 16.08],
  ["udara", 16.39, 16.75],
  ["di", 16.75, 16.95],
  ["depannya", 16.95, 17.47],
  ["terkompresi", 17.47, 18.14],
  ["dan", 18.14, 18.39],
  ["memanas", 18.39, 18.85],
  ["ekstrem.", 18.85, 19.32],
  ["Benda", 19.71, 20.07],
  ["kecil", 20.07, 20.42],
  ["biasanya", 20.42, 20.92],
  ["hancur", 20.92, 21.32],
  ["sebelum", 21.32, 21.77],
  ["mencapai", 21.77, 22.28],
  ["tanah.", 22.28, 22.63],
  ["Cahayanya", 23.02, 23.66],
  ["kita", 23.66, 24.01],
  ["sebut", 24.01, 24.41],
  ["meteor,", 24.41, 24.88],
  ["dan", 25.23, 25.49],
  ["sisa", 25.49, 25.81],
  ["yang", 25.81, 26.13],
  ["sampai", 26.13, 26.56],
  ["ke", 26.56, 26.77],
  ["permukaan", 26.77, 27.35],
  ["disebut", 27.35, 27.83],
  ["meteorit.", 27.83, 28.36],
  ["Tapi", 28.76, 29.09],
  ["asteroid", 29.09, 29.65],
  ["yang", 29.65, 29.98],
  ["cukup", 29.98, 30.37],
  ["besar", 30.37, 30.76],
  ["bisa", 30.76, 31.10],
  ["menembus", 31.10, 31.65],
  ["atmosfer", 31.65, 32.21],
  ["dan", 32.21, 32.49],
  ["menghantam", 32.49, 33.16],
  ["Bumi.", 33.16, 33.49],
  ["Saat", 33.90, 34.22],
  ["menumbuk,", 34.22, 34.77],
  ["seluruh", 34.95, 35.43],
  ["energinya", 35.43, 36.02],
  ["dilepas", 36.02, 36.50],
  ["dalam", 36.50, 36.88],
  ["sekejap:", 36.88, 37.36],
  ["kawah,", 37.63, 38.16],
  ["gelombang", 38.44, 38.88],
  ["kejut,", 38.88, 39.17],
  ["panas", 39.60, 39.97],
  ["ekstrem,", 39.97, 40.43],
  ["dan", 40.56, 40.87],
  ["gempa.", 40.87, 41.30],
  ["Jika", 41.70, 41.95],
  ["jatuh", 41.95, 42.25],
  ["di", 42.25, 42.41],
  ["laut,", 42.41, 42.67],
  ["bisa", 42.93, 43.26],
  ["memicu", 43.26, 43.70],
  ["tsunami.", 43.70, 44.19],
  ["Tapi", 44.60, 44.91],
  ["tidak", 44.91, 45.28],
  ["semuanya", 45.28, 45.80],
  ["sama.", 45.80, 46.11],
  ["Asteroid", 46.53, 47.05],
  ["10", 47.05, 47.51],
  ["meter", 47.51, 47.88],
  ["cukup", 47.88, 48.24],
  ["menghasilkan", 48.24, 48.97],
  ["bola", 48.97, 49.28],
  ["api,", 49.28, 49.54],
  ["1", 49.92, 50.26],
  ["kilometer", 50.26, 50.87],
  ["bisa", 50.87, 51.21],
  ["berdampak", 51.21, 51.82],
  ["global,", 51.82, 52.27],
  ["dan", 52.60, 52.89],
  ["10", 52.89, 53.41],
  ["kilometer", 53.41, 54.05],
  ["berpotensi", 54.05, 54.74],
  ["menyebabkan", 54.74, 55.49],
  ["kepunahan", 55.49, 56.13],
  ["massal.", 56.13, 56.59],
  ["Ini", 56.99, 57.29],
  ["bukan", 57.29, 57.70],
  ["sekadar", 57.70, 58.23],
  ["teori.", 58.23, 58.64],
  ["Sekitar", 58.98, 59.41],
  ["66", 59.41, 60.24],
  ["juta", 60.24, 60.53],
  ["tahun", 60.53, 60.88],
  ["lalu,", 60.88, 61.17],
  ["asteroid", 61.42, 61.95],
  ["selebar", 61.95, 62.43],
  ["10", 62.43, 62.91],
  ["kilometer", 62.91, 63.49],
  ["menghantam", 63.49, 64.13],
  ["Semenanjung", 64.13, 64.82],
  ["Yucatán", 64.82, 65.30],
  ["di", 65.30, 65.51],
  ["Meksiko,", 65.51, 65.98],
  ["membentuk", 66.23, 66.80],
  ["kawah", 66.80, 67.16],
  ["Chicxulub", 67.16, 67.72],
  ["berdiameter", 67.72, 68.39],
  ["sekitar", 68.39, 68.85],
  ["200", 68.85, 69.41],
  ["kilometer.", 69.41, 69.98],
  ["Debu,", 70.37, 70.87],
  ["jelaga,", 71.04, 72.95],
  ["dan", 73.07, 73.21],
  ["aerosol", 73.21, 73.45],
  ["sulfur", 73.45, 73.66],
  ["terlempar", 73.66, 73.96],
  ["ke", 73.96, 74.06],
  ["atmosfer,", 74.06, 74.33],
  ["menghalangi", 74.62, 75.32],
  ["sinar", 75.32, 75.70],
  ["Matahari", 75.70, 76.23],
  ["dan", 76.23, 76.50],
  ["menghambat", 76.50, 77.15],
  ["fotosintesis.", 77.15, 77.90],
  ["Rantai", 78.19, 78.59],
  ["makanan", 78.59, 79.04],
  ["pun", 79.04, 79.29],
  ["runtuh.", 79.29, 79.69],
  ["Sekitar", 80.05, 80.50],
  ["75", 80.50, 81.40],
  ["persen", 81.40, 81.81],
  ["spesies", 81.81, 82.26],
  ["punah,", 82.26, 82.61],
  ["termasuk", 82.88, 83.50],
  ["seluruh", 83.50, 84.06],
  ["dinosaurus", 84.06, 84.81],
  ["non-unggas.", 84.81, 85.56],
  ["Kabar", 85.95, 86.30],
  ["baiknya,", 86.30, 86.75],
  ["manusia", 86.92, 87.38],
  ["mulai", 87.38, 87.74],
  ["punya", 87.74, 88.09],
  ["jawabannya.", 88.09, 88.71],
  ["Pada", 89.08, 89.35],
  ["26", 89.35, 90.07],
  ["September", 90.07, 90.57],
  ["2022,", 90.57, 91.65],
  ["pesawat", 91.89, 92.43],
  ["DART", 92.43, 92.79],
  ["milik", 92.79, 93.21],
  ["NASA", 93.21, 93.57],
  ["sengaja", 93.57, 94.12],
  ["menabrak", 94.12, 94.72],
  ["Dimorphos,", 94.72, 95.38],
  ["asteroid", 95.58, 96.12],
  ["kecil", 96.12, 96.49],
  ["yang", 96.49, 96.81],
  ["mengorbit", 96.81, 97.40],
  ["Didymos.", 97.40, 97.88],
  ["Hasilnya,", 98.19, 98.81],
  ["periode", 99.02, 99.48],
  ["orbitnya", 99.48, 99.99],
  ["berubah.", 99.99, 100.45],
  ["Teknik", 100.82, 101.26],
  ["ini", 101.26, 101.53],
  ["disebut", 101.53, 102.03],
  ["penumbuk", 102.03, 102.58],
  ["kinetik.", 102.58, 103.07],
  ["Meski", 103.46, 103.82],
  ["begitu,", 103.82, 104.24],
  ["tidak", 104.42, 104.77],
  ["semua", 104.77, 105.11],
  ["asteroid", 105.11, 105.61],
  ["bisa", 105.61, 105.91],
  ["dialihkan", 105.91, 106.46],
  ["semudah", 106.46, 106.91],
  ["itu.", 106.91, 107.16],
  ["Jadi,", 107.58, 108.01],
  ["adakah", 108.19, 108.52],
  ["yang", 108.52, 108.76],
  ["mengarah", 108.76, 109.17],
  ["ke", 109.17, 109.33],
  ["kita?", 109.33, 109.58],
  ["Menurut", 109.95, 110.47],
  ["NASA,", 110.47, 110.81],
  ["belum", 110.94, 111.28],
  ["ada", 111.28, 111.52],
  ["asteroid", 111.52, 112.00],
  ["di", 112.00, 112.19],
  ["atas", 112.19, 112.48],
  ["140", 112.48, 113.49],
  ["meter", 113.49, 113.82],
  ["yang", 113.82, 114.11],
  ["diketahui", 114.11, 114.64],
  ["berpeluang", 114.64, 115.22],
  ["signifikan", 115.22, 115.80],
  ["menabrak", 115.80, 116.28],
  ["Bumi", 116.28, 116.56],
  ["dalam", 116.56, 116.90],
  ["100", 116.90, 117.33],
  ["tahun", 117.33, 117.67],
  ["ke", 117.67, 117.86],
  ["depan.", 117.86, 118.20],
  ["Ancamannya", 118.57, 119.24],
  ["nyata,", 119.24, 119.63],
  ["tapi", 119.89, 120.21],
  ["bukan", 120.21, 120.59],
  ["sesuatu", 120.59, 121.08],
  ["yang", 121.08, 121.40],
  ["pasti", 121.40, 121.78],
  ["terjadi.", 121.78, 122.27],
  ["Dan", 122.65, 122.92],
  ["para", 122.92, 123.25],
  ["ilmuwan", 123.25, 123.75],
  ["terus", 123.75, 124.13],
  ["mengawasi", 124.13, 124.74],
  ["langit", 124.74, 125.18],
  ["untuk", 125.18, 125.56],
  ["kita.", 125.56, 125.89],
];

/* ───────────────────────── util ───────────────────────── */
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const easeIn = Easing.in(Easing.cubic);
const easeInOut = Easing.inOut(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9áéíóúñ-]/g, '');
/** waktu mulai kata ke-`nth` yang cocok dengan `text` */
const W = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, s] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return s;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};

/* ───────────────────────── konteks waktu ───────────────────────── */
const TCtx = createContext(0); // detik-audio absolut
const LCtx = createContext(0); // detik sejak scene mulai
const useT = () => useContext(TCtx);
const useLT = () => useContext(LCtx);

const Scene: React.FC<{a: number; b: number; fade?: number; children?: React.ReactNode}> = ({
  a,
  b,
  fade = 0.2,
  children,
}) => {
  const t = useT();
  if (t < a || t >= b + fade + 0.05) return null;
  const lt = t - a;
  return (
    <LCtx.Provider value={lt}>
      <AbsoluteFill style={{opacity: fade > 0 ? clamp(lt / fade) : 1, overflow: 'hidden'}}>
        {children}
      </AbsoluteFill>
    </LCtx.Provider>
  );
};

type Shake = {a: number; d: number; amp: number};
const Cam: React.FC<{
  z0?: number;
  z1?: number;
  dur?: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  r0?: number;
  r1?: number;
  shakes?: Shake[];
  children?: React.ReactNode;
}> = ({z0 = 1, z1 = 1, dur = 5, x0 = 0, x1 = 0, y0 = 0, y1 = 0, r0 = 0, r1 = 0, shakes = [], children}) => {
  const lt = useLT();
  const t = useT();
  const p = easeInOut(prog(lt, 0, dur));
  let sx = 0;
  let sy = 0;
  for (const s of shakes) {
    const q = prog(t, s.a, s.d);
    if (q > 0 && q < 1) {
      const k = (1 - q) * s.amp;
      sx += Math.sin(t * 93) * k;
      sy += Math.cos(t * 71) * k;
    }
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${lerp(x0, x1, p) + sx}px,${lerp(y0, y1, p) + sy}px) scale(${lerp(z0, z1, p)}) rotate(${lerp(r0, r1, p)}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── SVG dasar ───────────────────────── */
const Defs = () => (
  <defs>
    <radialGradient id="glowOrange">
      <stop offset="0" stopColor="#fff1b0" stopOpacity="0.95" />
      <stop offset="0.35" stopColor="#ff9a2e" stopOpacity="0.65" />
      <stop offset="1" stopColor="#ff5a1f" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowWhite">
      <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowBlue">
      <stop offset="0.72" stopColor="#7ccfff" stopOpacity="0.6" />
      <stop offset="1" stopColor="#7ccfff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowGreen">
      <stop offset="0" stopColor="#7dffb0" stopOpacity="0.9" />
      <stop offset="1" stopColor="#7dffb0" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="earthShade" cx="0.35" cy="0.3" r="0.9">
      <stop offset="0.5" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#000" stopOpacity="0.5" />
    </radialGradient>
    <linearGradient id="flameGrad" x1="1" y1="0" x2="0" y2="0">
      <stop offset="0" stopColor="#fff6c0" />
      <stop offset="0.3" stopColor="#ffb02e" />
      <stop offset="1" stopColor="#ff4b1f" stopOpacity="0" />
    </linearGradient>
    <pattern id="hatch" width="16" height="16" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
      <rect width="16" height="16" fill="#2f4380" />
      <line x1="0" y1="0" x2="0" y2="16" stroke="#1d2a58" strokeWidth="7" />
    </pattern>
  </defs>
);

const S: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    width={WIDTH}
    height={HEIGHT}
    style={{position: 'absolute', left: 0, top: 0}}
  >
    <Defs />
    {children}
  </svg>
);

/* ───────────────────────── background ───────────────────────── */
const Stars: React.FC<{n?: number}> = ({n = 80}) => {
  const t = useT();
  return (
    <S>
      {Array.from({length: n}).map((_, i) => {
        const x = random(`sx${i}`) * WIDTH;
        const y = (random(`sy${i}`) * HEIGHT + t * (4 + random(`sv${i}`) * 8)) % HEIGHT;
        const r = 1.5 + random(`sr${i}`) * 3.2;
        const o = 0.45 + 0.55 * Math.abs(Math.sin(t * (0.8 + random(`sf${i}`) * 2) + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#fff" opacity={o} />;
      })}
    </S>
  );
};

const SpaceBG: React.FC<{tone?: 'blue' | 'purple' | 'black'}> = ({tone = 'blue'}) => {
  const g =
    tone === 'blue'
      ? 'radial-gradient(120% 80% at 50% 30%, #1f2570 0%, #0d123f 55%, #04061a 100%)'
      : tone === 'purple'
      ? 'radial-gradient(120% 80% at 50% 30%, #3a1d6b 0%, #1a0f40 55%, #07041a 100%)'
      : 'radial-gradient(120% 80% at 50% 30%, #101440 0%, #050722 60%, #02030e 100%)';
  return (
    <>
      <AbsoluteFill style={{background: g}} />
      <Stars />
    </>
  );
};

const SkyBG = () => (
  <AbsoluteFill
    style={{background: 'linear-gradient(180deg,#05071a 0%,#0f1f5c 42%,#2a6fc4 72%,#8fcdf5 100%)'}}
  />
);

const Vignette = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
    }}
  />
);

/* ───────────────────────── objek ───────────────────────── */
const ROCK_PTS = [92, 84, 97, 88, 79, 94, 86, 98, 82, 90, 96, 83, 93, 87]
  .map((r, i) => {
    const a = (i / 14) * Math.PI * 2;
    return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
  })
  .join(' ');

const Rock: React.FC<{
  x: number;
  y: number;
  s?: number;
  rot?: number;
  tint?: string;
  glow?: number;
}> = ({x, y, s = 1, rot = 0, tint = '#8d7b78', glow = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {glow > 0 && <circle r={190} fill="url(#glowOrange)" opacity={glow} />}
    <polygon points={ROCK_PTS} fill={tint} stroke={OUT} strokeWidth={5.5 / s} strokeLinejoin="round" />
    <path d="M-70,-45 Q-30,-85 20,-80 Q-20,-60 -70,-45Z" fill="#b3a29d" opacity={0.8} />
    <ellipse cx={-30} cy={-14} rx={20} ry={15} fill="#6c5c5b" stroke={OUT} strokeWidth={3.5 / s} />
    <ellipse cx={35} cy={30} rx={26} ry={18} fill="#6c5c5b" stroke={OUT} strokeWidth={3.5 / s} />
    <ellipse cx={42} cy={-34} rx={11} ry={8} fill="#6c5c5b" stroke={OUT} strokeWidth={3 / s} />
    <ellipse cx={-48} cy={42} rx={12} ry={9} fill="#6c5c5b" stroke={OUT} strokeWidth={3 / s} />
  </g>
);

const Flame: React.FC<{x: number; y: number; ang: number; len: number; w?: number; t: number}> = ({
  x,
  y,
  ang,
  len,
  w = 1,
  t,
}) => {
  const fl = 1 + 0.07 * Math.sin(t * 37) + 0.04 * Math.sin(t * 61);
  const L = len * fl;
  const layer = (k: number, o: number) => (
    <path
      d={`M20,${-70 * w * k} C-120,${-130 * w * k} ${-L * 0.55},${-90 * w * k} ${-L * k},0 C${-L * 0.55},${90 * w * k} -120,${130 * w * k} 20,${70 * w * k}Z`}
      fill="url(#flameGrad)"
      opacity={o}
    />
  );
  return (
    <g transform={`translate(${x} ${y}) rotate(${ang})`}>
      {layer(1.15, 0.5)}
      {layer(0.9, 0.85)}
      {layer(0.55, 1)}
    </g>
  );
};

const Earth: React.FC<{x: number; y: number; r: number; rot?: number}> = ({x, y, r, rot = 0}) => {
  const k = r / 100;
  const o = ((rot % 220) + 220) % 220;
  const cont = (dx: number) => (
    <g transform={`translate(${dx} 0)`}>
      <path
        d="M-70,-30 C-50,-70 0,-60 12,-25 C22,10 -8,30 -30,42 C-58,32 -78,0 -70,-30Z"
        fill="#62b85c"
        stroke={OUT}
        strokeWidth={2.5}
      />
      <path
        d="M30,8 C52,-12 86,8 74,40 C62,72 30,62 24,40 C21,26 25,14 30,8Z"
        fill="#62b85c"
        stroke={OUT}
        strokeWidth={2.5}
      />
      <ellipse cx={-10} cy={-62} rx={28} ry={7} fill="#fff" opacity={0.85} />
      <ellipse cx={50} cy={-30} rx={22} ry={6} fill="#fff" opacity={0.85} />
    </g>
  );
  return (
    <g transform={`translate(${x} ${y}) scale(${k})`}>
      <circle r={122} fill="url(#glowBlue)" />
      <circle r={100} fill="#2f7fd6" />
      <clipPath id="earthclip">
        <circle r={100} />
      </clipPath>
      <g clipPath="url(#earthclip)">
        {cont(-o)}
        {cont(220 - o)}
        <circle r={100} fill="url(#earthShade)" />
      </g>
      <circle r={100} fill="none" stroke={OUT} strokeWidth={4 / k > 8 ? 8 : 4 / k} />
    </g>
  );
};

const Sun: React.FC<{x: number; y: number; r: number; t: number}> = ({x, y, r, t}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={r * 2.4} fill="url(#glowOrange)" />
    <g transform={`rotate(${t * 12})`}>
      {Array.from({length: 12}).map((_, i) => (
        <rect key={i} x={-9} y={-r * 1.45} width={18} height={r * 0.4} rx={9} fill="#ffd45a" transform={`rotate(${i * 30})`} />
      ))}
    </g>
    <circle r={r} fill="#ffcf4a" stroke={OUT} strokeWidth={6} />
    <circle r={r * 0.7} fill="#ffe27a" />
  </g>
);

const Person: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  shirt?: string;
  pants?: string;
  hair?: string;
  hat?: boolean;
  coat?: boolean;
  glasses?: boolean;
  armL?: number;
  armR?: number;
  mouth?: 'smile' | 'o' | 'flat';
  look?: number;
}> = ({
  x,
  y,
  s = 1,
  flip = false,
  shirt = '#4a7bb5',
  pants = '#2b2f55',
  hair = '#4a2f22',
  hat = false,
  coat = false,
  glasses = false,
  armL = 15,
  armR = 15,
  mouth = 'smile',
  look = 0,
}) => {
  const arm = (ang: number, side: number) => {
    const sx = side * 36;
    const sy = -172;
    const a = (ang * side * Math.PI) / 180;
    const L = 88;
    const ex = sx + Math.sin(a) * L;
    const ey = sy + Math.cos(a) * L;
    const col = coat ? '#fff' : shirt;
    return (
      <g>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={OUT} strokeWidth={31} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={col} strokeWidth={20} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={13} fill="#f7efe4" stroke={OUT} strokeWidth={4} />
      </g>
    );
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={60} ry={10} fill="#000" opacity={0.2} />
      <rect x={-29} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <rect x={6} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <ellipse cx={-20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      <ellipse cx={20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      {arm(armL, -1)}
      <rect x={-42} y={-195} width={84} height={112} rx={28} fill={coat ? '#fff' : shirt} stroke={OUT} strokeWidth={6} />
      {coat && (
        <>
          <path d="M-14,-193 L0,-140 L14,-193" fill="none" stroke={OUT} strokeWidth={4} />
          <line x1={0} y1={-140} x2={0} y2={-86} stroke={OUT} strokeWidth={3} />
        </>
      )}
      {arm(armR, 1)}
      <circle cx={look * 5} cy={-248} r={50} fill="#f7efe4" stroke={OUT} strokeWidth={6} />
      {hair && !hat && (
        <path
          d={`M${-50 + look * 5},-252 A50,50 0 0 1 ${50 + look * 5},-252 Q${look * 5},-292 ${-50 + look * 5},-252Z`}
          fill={hair}
          stroke={OUT}
          strokeWidth={4}
        />
      )}
      {hat && (
        <g transform={`translate(${look * 5} 0)`}>
          <ellipse cx={0} cy={-286} rx={66} ry={11} fill="#1d1b2b" stroke={OUT} strokeWidth={4} />
          <path d="M-40,-286 Q-40,-336 0,-336 Q40,-336 40,-286Z" fill="#1d1b2b" stroke={OUT} strokeWidth={4} />
        </g>
      )}
      <circle cx={-17 + look * 6} cy={-250} r={6} fill={OUT} />
      <circle cx={17 + look * 6} cy={-250} r={6} fill={OUT} />
      {glasses && (
        <g fill="none" stroke={OUT} strokeWidth={4}>
          <circle cx={-17 + look * 6} cy={-250} r={14} />
          <circle cx={17 + look * 6} cy={-250} r={14} />
          <line x1={-3 + look * 6} y1={-250} x2={3 + look * 6} y2={-250} />
        </g>
      )}
      {mouth === 'smile' && (
        <path d={`M${-14 + look * 5},-226 Q${look * 5},-212 ${14 + look * 5},-226`} fill="none" stroke={OUT} strokeWidth={4} strokeLinecap="round" />
      )}
      {mouth === 'o' && <ellipse cx={look * 5} cy={-222} rx={8} ry={10} fill={OUT} />}
      {mouth === 'flat' && (
        <line x1={-12 + look * 5} y1={-222} x2={12 + look * 5} y2={-222} stroke={OUT} strokeWidth={4} strokeLinecap="round" />
      )}
    </g>
  );
};

const Dino: React.FC<{x: number; y: number; s?: number; color?: string; flip?: boolean; bob?: number}> = ({
  x,
  y,
  s = 1,
  color = '#2c1634',
  flip = false,
  bob = 0,
}) => (
  <g transform={`translate(${x} ${y + bob}) scale(${flip ? -s : s} ${s})`}>
    <path d="M-95,-125 C-160,-105 -230,-75 -300,-22 C-210,-62 -150,-60 -82,-72Z" fill={color} />
    <rect x={-72} y={-80} width={32} height={80} rx={10} fill={color} />
    <rect x={-22} y={-80} width={32} height={80} rx={10} fill={color} />
    <rect x={38} y={-80} width={32} height={80} rx={10} fill={color} />
    <rect x={76} y={-80} width={32} height={80} rx={10} fill={color} />
    <ellipse cx={0} cy={-115} rx={118} ry={62} fill={color} />
    <path d="M60,-150 C112,-205 132,-255 150,-305 L184,-300 C172,-240 162,-190 130,-120Z" fill={color} />
    <ellipse cx={174} cy={-306} rx={32} ry={17} fill={color} />
  </g>
);

const Leaf: React.FC<{x: number; y: number; s?: number; wilt?: number}> = ({x, y, s = 1, wilt = 0}) => {
  const c1 = `rgb(${Math.round(lerp(88, 128, wilt))},${Math.round(lerp(176, 92, wilt))},${Math.round(lerp(84, 52, wilt))})`;
  return (
    <g transform={`translate(${x} ${y}) scale(${s}) rotate(${wilt * 30})`}>
      <path d={`M0,0 Q${3 + wilt * 10},-60 ${wilt * 40},-110`} stroke={OUT} strokeWidth={14} fill="none" strokeLinecap="round" />
      <path d={`M0,0 Q${3 + wilt * 10},-60 ${wilt * 40},-110`} stroke={c1} strokeWidth={7} fill="none" strokeLinecap="round" />
      <path d={`M${wilt * 40},-110 C${40 + wilt * 20},-140 ${80 + wilt * 20},-110 ${70 + wilt * 20},${-80 + wilt * 30} C${40},-80 ${wilt * 40},-110 ${wilt * 40},-110Z`} fill={c1} stroke={OUT} strokeWidth={4} />
      <path d={`M${wilt * 40},-110 C${-40 + wilt * 20},-140 ${-80 + wilt * 20},-110 ${-70 + wilt * 20},${-80 + wilt * 40} C${-40},-80 ${wilt * 40},-110 ${wilt * 40},-110Z`} fill={c1} stroke={OUT} strokeWidth={4} />
    </g>
  );
};

/* ───────────────────────── efek ───────────────────────── */
const Sparks: React.FC<{
  x: number;
  y: number;
  t0: number;
  n?: number;
  speed?: number;
  life?: number;
  g?: number;
  color?: string;
  size?: number;
  seed?: string;
}> = ({x, y, t0, n = 30, speed = 500, life = 1.2, g = 600, color = '#ffc85a', size = 7, seed = 'sp'}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0 || age > life) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const v = (0.3 + random(`${seed}v${i}`) * 0.7) * speed;
        const px = x + Math.cos(a) * v * age;
        const py = y + Math.sin(a) * v * age + 0.5 * g * age * age;
        const o = 1 - age / life;
        return <circle key={i} cx={px} cy={py} r={size * (0.5 + random(`${seed}r${i}`)) * o} fill={color} opacity={o} />;
      })}
    </g>
  );
};

const Shock: React.FC<{x: number; y: number; t0: number; max?: number; flat?: number; dur?: number; color?: string; w?: number}> = ({
  x,
  y,
  t0,
  max = 900,
  flat = 0.3,
  dur = 1.4,
  color = '#fff',
  w = 14,
}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (p <= 0 || p >= 1) return null;
  const r = max * easeOut(p);
  return <ellipse cx={x} cy={y} rx={r} ry={r * flat} fill="none" stroke={color} strokeWidth={w * (1 - p)} opacity={1 - p * 0.8} />;
};

const Smoke: React.FC<{x: number; y: number; t0: number; n?: number; color?: string; spread?: number; rise?: number; life?: number}> = ({
  x,
  y,
  t0,
  n = 7,
  color = '#6a5560',
  spread = 120,
  rise = 300,
  life = 3,
}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const p = clamp(age / life);
        const o = Math.sin(Math.PI * clamp(age / life)) * 0.85;
        const dx = (random(`smx${i}`) - 0.5) * spread * 2 * (0.4 + p);
        return <circle key={i} cx={x + dx} cy={y - rise * easeOut(p) * (0.5 + random(`smy${i}`) * 0.7)} r={40 + p * 90 + random(`smr${i}`) * 40} fill={color} opacity={o} stroke={OUT} strokeWidth={3} />;
      })}
    </g>
  );
};

const Flash: React.FC<{t0: number; dur?: number; color?: string}> = ({t0, dur = 0.6, color = '#fff'}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (t < t0 || p >= 1) return null;
  return <AbsoluteFill style={{background: color, opacity: 1 - easeOut(p)}} />;
};

/* ───────────────────────── UI: label, caption ───────────────────────── */
const Pill: React.FC<{
  x: number;
  y: number;
  text: string;
  at: number;
  color?: string;
  size?: number;
  rot?: number;
  sub?: string;
  until?: number;
}> = ({x, y, text, at, color = '#ffb84d', size = 54, rot = 0, sub, until}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const p = pop(t, at, 0.4);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`,
        background: 'rgba(18,12,30,0.85)',
        border: `5px solid ${color}`,
        color: '#fff',
        padding: sub ? '12px 38px' : '14px 36px',
        borderRadius: sub ? 44 : 999,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: 2,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {text}
      {sub && <div style={{fontSize: size * 0.52, fontWeight: 600, opacity: 0.85, letterSpacing: 1}}>{sub}</div>}
    </div>
  );
};

const Caption: React.FC = () => {
  const t = useT();
  let idx = -1;
  for (let i = 0; i < WORDS.length; i++) {
    if (WORDS[i][1] <= t) idx = i;
    else break;
  }
  if (idx < 0) return null;
  const [w, s, e] = WORDS[idx];
  if (t > e + 0.28) return null;
  const sc = 0.82 + 0.18 * backOut(prog(t, s, 0.16));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '46%',
        textAlign: 'center',
        transform: `translateY(-50%) scale(${sc})`,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 92,
        color: '#fff',
        letterSpacing: -1,
        WebkitTextStroke: '12px rgba(22,12,34,0.9)',
        paintOrder: 'stroke fill',
        textShadow: '0 6px 14px rgba(0,0,0,0.55)',
        padding: '0 40px',
      }}
    >
      {w}
    </div>
  );
};

/* ═══════════════════════════ SCENES ═══════════════════════════ */

/* 1 ─ hook (0 – 10.3) */
const SceneHook = () => {
  const t = useT();
  const p = prog(t, 0, 10.2);
  const e = easeIn(p);
  const ax = lerp(150, 470, e * 0.9 + p * 0.1);
  const ay = lerp(300, 1040, e * 0.9 + p * 0.1);
  const sc = 0.1 + 1.55 * e;
  const dx = 320;
  const dy = 740;
  const nrm = Math.hypot(dx, dy);
  const rad = 60 + 130 * e;
  const titleO = Math.min(eo(t, 0.3, 0.6), 1 - prog(t, 6, 0.6));
  return (
    <>
      <SpaceBG />
      <Cam z0={1} z1={1.1} dur={10.3}>
        <S>
          <Earth x={830} y={1620} r={470} rot={t * 8} />
          {Array.from({length: 9}).map((_, i) => (
            <circle
              key={i}
              cx={ax - (dx / nrm) * i * rad * 0.7}
              cy={ay - (dy / nrm) * i * rad * 0.7}
              r={rad * (1 - i / 10)}
              fill="url(#glowOrange)"
              opacity={0.5 * (1 - i / 9) * clamp(p * 4)}
            />
          ))}
          <Rock x={ax} y={ay} s={sc} rot={t * 22} glow={0.35} />
        </S>
      </Cam>
      <div
        style={{
          position: 'absolute',
          top: 190,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: titleO,
          transform: `translateY(${(1 - titleO) * -30}px)`,
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          textShadow: '0 6px 18px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{fontSize: 52, letterSpacing: 8, color: '#ffc85a'}}>BAGAIMANA JIKA</div>
        <div style={{fontSize: 104, marginTop: 10}}>ASTEROID</div>
        <div style={{fontSize: 104}}>RAKSASA</div>
        <div style={{fontSize: 70, marginTop: 6, color: '#ff7a4a'}}>MENABRAK BUMI?</div>
      </div>
    </>
  );
};

/* 2 ─ orbit mengelilingi Matahari (10.3 – 14.4) */
const SceneOrbit = () => {
  const t = useT();
  const lt = useLT();
  const cx = 540;
  const cy = 800;
  const ang = 2.4 + lt * 0.95;
  const rx = 400;
  const ry = 190;
  const rx2 = Math.cos(ang) * rx;
  const ry2 = Math.sin(ang) * ry;
  return (
    <>
      <SpaceBG tone="purple" />
      <Cam z0={1.08} z1={1} dur={4.1}>
        <S>
          <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="none" stroke="#fff" strokeOpacity={0.35} strokeWidth={4} strokeDasharray="14 16" />
          {Array.from({length: 46}).map((_, i) => {
            const a = (i / 46) * Math.PI * 2 + lt * 0.05;
            const j = 0.78 + random(`bj${i}`) * 0.12;
            return (
              <circle
                key={i}
                cx={cx + Math.cos(a) * rx * j * 0.8}
                cy={cy + Math.sin(a) * ry * j * 0.8}
                r={4 + random(`bs${i}`) * 7}
                fill="#a89592"
                stroke={OUT}
                strokeWidth={2}
              />
            );
          })}
          <Sun x={cx} y={cy} r={95} t={t} />
          <Rock x={cx + rx2} y={cy + ry2} s={0.42} rot={t * 60} />
        </S>
      </Cam>
      <Pill x={cx} y={cy + 270} text="MATAHARI" at={W('Matahari', 0)} color="#ffd45a" />
      <Pill x={540} y={440} text="ASTEROID" at={W('Asteroid', 0)} color="#c7b0ff" />
    </>
  );
};

/* 3 ─ masuk atmosfer (14.4 – 19.7) */
const Horizon: React.FC<{up?: number}> = ({up = 0}) => (
  <S>
    <circle cx={540} cy={2780 - up} r={1330} fill="url(#glowBlue)" />
    <circle cx={540} cy={2800 - up} r={1280} fill="#2f7fd6" stroke={OUT} strokeWidth={10} />
    <path d={`M-100,${1700 - up} C200,${1640 - up} 420,${1700 - up} 700,${1650 - up} C900,${1620 - up} 1100,${1660 - up} 1200,${1650 - up} L1200,2100 L-100,2100Z`} fill="#62b85c" opacity={0.9} />
    <ellipse cx={200} cy={1560 - up} rx={170} ry={20} fill="#fff" opacity={0.55} />
    <ellipse cx={860} cy={1520 - up} rx={150} ry={16} fill="#fff" opacity={0.5} />
  </S>
);

const SceneEntry = () => {
  const t = useT();
  const lt = useLT();
  const q = Easing.in(Easing.quad)(prog(lt, 0, 5.3));
  const x = lerp(300, 640, q);
  const y = lerp(120, 1250, q);
  const ang = (Math.atan2(1130, 340) * 180) / Math.PI;
  const heat = clamp(lt / 3);
  return (
    <>
      <SkyBG />
      <Cam z0={1} z1={1.12} dur={5.3} shakes={[{a: 14.4, d: 5.3, amp: 4 + heat * 6}]}>
        <Horizon />
        <S>
          <Flame x={x} y={y} ang={ang} len={420 + 350 * heat} w={0.5 + heat * 0.7} t={t} />
          <g transform={`translate(${x} ${y}) rotate(${ang})`}>
            {[0, 1, 2].map((i) => (
              <path
                key={i}
                d={`M${120 + i * 45},${-110 - i * 20} Q${175 + i * 55},0 ${120 + i * 45},${110 + i * 20}`}
                fill="none"
                stroke="#ffe3b0"
                strokeWidth={9 - i * 2}
                strokeLinecap="round"
                opacity={(0.8 - i * 0.2) * clamp(lt / 1.5)}
              />
            ))}
          </g>
          <Rock x={x} y={y} s={1.15} rot={t * 40} glow={0.5 + heat * 0.5} tint={`rgb(${Math.round(lerp(141, 200, heat))},${Math.round(lerp(123, 110, heat))},${Math.round(lerp(120, 80, heat))})`} />
        </S>
      </Cam>
    </>
  );
};

/* 4 ─ benda kecil hancur (19.7 – 22.9) */
const SceneSmallBurn = () => {
  const t = useT();
  const lt = useLT();
  const tb = 1.5;
  const q = easeIn(prog(lt, 0, tb));
  const x = lerp(330, 600, q);
  const y = lerp(150, 880, q);
  const ang = (Math.atan2(730, 270) * 180) / Math.PI;
  return (
    <>
      <SkyBG />
      <Cam z0={1.05} z1={1} dur={3.2}>
        <Horizon />
        <S>
          {lt < tb && (
            <>
              <Flame x={x} y={y} ang={ang} len={300} w={0.5} t={t} />
              <Rock x={x} y={y} s={0.38} rot={t * 90} glow={0.7} />
            </>
          )}
          {lt >= tb &&
            Array.from({length: 8}).map((_, i) => {
              const age = lt - tb;
              const a = random(`sh${i}`) * Math.PI * 2;
              const v = 150 + random(`shv${i}`) * 260;
              const o = clamp(1 - age / 1.1);
              return (
                <polygon
                  key={i}
                  points="-14,-10 14,-16 18,10 -8,16"
                  fill="#8d7b78"
                  stroke={OUT}
                  strokeWidth={3}
                  opacity={o}
                  transform={`translate(${600 + Math.cos(a) * v * age + 40 * age} ${880 + Math.sin(a) * v * age + 260 * age * age}) rotate(${age * 400 * (i % 2 ? 1 : -1)}) scale(${0.8 + random(`shs${i}`)})`}
                />
              );
            })}
          <Sparks x={600} y={880} t0={19.7 + tb} n={40} speed={520} life={1.3} g={500} seed="burn" />
          <Sparks x={600} y={880} t0={19.7 + tb + 0.05} n={20} speed={300} life={1.0} g={300} color="#ff6a2a" size={10} seed="burn2" />
        </S>
        {lt >= tb && <Flash t0={19.7 + tb} dur={0.35} color="#ffd9a0" />}
      </Cam>
    </>
  );
};

/* 5 ─ meteor (22.9 – 25.2) */
const NightHill: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <>
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#02030e 0%,#0b1240 60%,#1b2a66 100%)'}} />
    <Stars n={110} />
    <S>
      <path d="M0,1500 C250,1420 520,1490 780,1440 C920,1415 1020,1440 1080,1430 L1080,1920 L0,1920Z" fill="#12163a" stroke={OUT} strokeWidth={6} />
      <path d="M0,1640 C300,1590 600,1650 1080,1600 L1080,1920 L0,1920Z" fill="#0b0e2b" />
      {children}
    </S>
  </>
);

const SceneMeteor = () => {
  const lt = useLT();
  const p = easeIn(prog(lt, 0.1, 1.4));
  const hx = lerp(1050, 150, p);
  const hy = lerp(160, 920, p);
  const tl = 520;
  const dirx = -900 / Math.hypot(900, 760);
  const diry = 760 / Math.hypot(900, 760);
  const fade = 1 - prog(lt, 1.5, 0.6);
  return (
    <>
      <NightHill>
        <g opacity={fade}>
          <line x1={hx - dirx * tl} y1={hy - diry * tl} x2={hx} y2={hy} stroke="url(#glowWhite)" strokeWidth={26} strokeLinecap="round" opacity={0.5} />
          <line x1={hx - dirx * tl * 0.8} y1={hy - diry * tl * 0.8} x2={hx} y2={hy} stroke="#ffe3b0" strokeWidth={10} strokeLinecap="round" />
          <circle cx={hx} cy={hy} r={70} fill="url(#glowOrange)" />
          <circle cx={hx} cy={hy} r={14} fill="#fff" />
        </g>
        <Person x={300} y={1560} s={0.9} shirt="#c4613b" armR={150} armL={20} mouth="o" look={-1} />
      </NightHill>
      <Pill x={300} y={560} text="METEOR" at={W('meteor', 0)} color="#ffc85a" size={70} />
    </>
  );
};

/* 6 ─ meteorit (25.2 – 28.6) */
const SceneMeteorit = () => {
  const t = useT();
  const lt = useLT();
  const fallEnd = 1.3;
  const p = easeIn(prog(lt, 0, fallEnd));
  const x = lerp(700, 640, p);
  const y = lerp(-80, 1470, p);
  const landed = lt >= fallEnd;
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#2b2f7a 0%,#7c5aa8 45%,#f09a6a 85%)'}} />
      <S>
        <path d="M0,1480 C250,1410 520,1480 780,1430 C920,1405 1020,1430 1080,1420 L1080,1920 L0,1920Z" fill="#5a3d4e" stroke={OUT} strokeWidth={6} />
        <path d="M0,1640 C300,1590 600,1650 1080,1600 L1080,1920 L0,1920Z" fill="#43293d" />
        <ellipse cx={640} cy={1500} rx={120} ry={26} fill="#2a1626" />
        {!landed && (
          <>
            <Flame x={x} y={y} ang={92} len={260} w={0.3} t={t} />
            <Rock x={x} y={y} s={0.32} rot={t * 70} glow={0.8} />
          </>
        )}
        {landed && <Rock x={640} y={1480} s={0.5} rot={14} tint="#6e5f66" glow={Math.max(0, 0.6 - (lt - fallEnd) * 0.35)} />}
        <Sparks x={640} y={1480} t0={19.7 + 5.5 + fallEnd} n={24} speed={380} life={1.0} g={700} seed="land" />
        <Smoke x={640} y={1470} t0={25.2 + fallEnd} n={6} spread={60} rise={260} life={2.2} color="#7a6470" />
        <Person x={300} y={1590} s={0.95} shirt="#4a8f6a" armR={60} armL={15} mouth="o" look={1} flip={false} />
      </S>
      <Pill x={640} y={1060} text="METEORIT" at={W('meteorit', 0)} color="#7dffb0" size={70} />
    </>
  );
};

/* 7 ─ asteroid besar menembus (28.6 – 33.6) */
const SceneBigEntry = () => {
  const t = useT();
  const lt = useLT();
  const q = Easing.in(Easing.quad)(prog(lt, 0, 4.9));
  const x = lerp(330, 560, q);
  const y = lerp(60, 1330, q);
  const ang = (Math.atan2(1270, 230) * 180) / Math.PI;
  const heat = clamp(lt / 2);
  return (
    <>
      <SkyBG />
      <Cam z0={1} z1={1.18} dur={5} shakes={[{a: 28.6, d: 5, amp: 10}]}>
        <Horizon />
        <S>
          <Flame x={x} y={y} ang={ang} len={800} w={1.5 + heat * 0.6} t={t} />
          <g transform={`translate(${x} ${y}) rotate(${ang})`}>
            {[0, 1, 2, 3].map((i) => (
              <path
                key={i}
                d={`M${230 + i * 70},${-220 - i * 30} Q${320 + i * 90},0 ${230 + i * 70},${220 + i * 30}`}
                fill="none"
                stroke="#ffe3b0"
                strokeWidth={14 - i * 2.5}
                strokeLinecap="round"
                opacity={0.8 - i * 0.15}
              />
            ))}
          </g>
          <Rock x={x} y={y} s={2.3} rot={t * 24} glow={0.8} tint="#c77a55" />
        </S>
      </Cam>
      <Flash t0={32.9} dur={0.7} color="#fff" />
    </>
  );
};

/* 8 ─ dampak tumbukan (33.6 – 41.5) */
const Chip: React.FC<{i: number; text: string; at: number; color: string; icon: React.ReactNode}> = ({i, text, at, color, icon}) => {
  const t = useT();
  if (t < at) return null;
  const p = pop(t, at, 0.4);
  return (
    <div
      style={{
        position: 'absolute',
        left: 60,
        top: 220 + i * 128,
        transform: `scale(${p})`,
        transformOrigin: 'left center',
        display: 'flex',
        alignItems: 'center',
        gap: 22,
        background: 'rgba(18,12,30,0.85)',
        border: `5px solid ${color}`,
        borderRadius: 999,
        padding: '10px 40px 10px 16px',
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 50,
        color: '#fff',
        letterSpacing: 1,
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      <svg width={76} height={76} viewBox="-38 -38 76 76">
        <circle r={36} fill={color} stroke={OUT} strokeWidth={4} />
        {icon}
      </svg>
      {text}
    </div>
  );
};

const SceneImpact = () => {
  const t = useT();
  const lt = useLT();
  const tKawah = W('kawah', 0);
  const tShock = W('gelombang');
  const tHeat = W('panas');
  const tQuake = W('gempa');
  const gx = 540;
  const gy = 1330;
  const fb = prog(lt, 0, 1.6);
  const fbO = 1 - prog(t, 36.0, 1.6);
  const heatO = Math.sin(clamp((t - tHeat) / 1.6) * Math.PI) * 0.55;
  return (
    <>
      <Cam z0={1.1} z1={1} dur={7.9} shakes={[{a: tQuake, d: 1.4, amp: 24}, {a: 33.6, d: 1.0, amp: 30}]}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#3a1c4a 0%,#b23d4f 38%,#f68a45 62%,#ffb347 80%)'}} />
        <S>
          <path d="M0,1330 C250,1290 520,1340 780,1300 C920,1280 1020,1305 1080,1295 L1080,1920 L0,1920Z" fill="#5a2a45" stroke={OUT} strokeWidth={6} />
          <path d="M0,1520 C300,1480 600,1540 1080,1490 L1080,1920 L0,1920Z" fill="#43203a" />
          {t >= tKawah && (
            <ellipse cx={gx} cy={gy + 40} rx={260 * eo(t, tKawah, 0.8)} ry={60 * eo(t, tKawah, 0.8)} fill="#1c0d1f" stroke={OUT} strokeWidth={6} />
          )}
          <g opacity={fbO}>
            <circle cx={gx} cy={gy - 120 * easeOut(fb)} r={90 + 330 * easeOut(fb)} fill="url(#glowOrange)" />
            <circle cx={gx} cy={gy - 120 * easeOut(fb)} r={60 + 210 * easeOut(fb)} fill="#ff9a2e" stroke={OUT} strokeWidth={6} opacity={0.95} />
            <circle cx={gx} cy={gy - 150 * easeOut(fb)} r={30 + 130 * easeOut(fb)} fill="#fff1a8" />
          </g>
          <Shock x={gx} y={gy} t0={tShock} max={900} />
          <Shock x={gx} y={gy} t0={tShock + 0.35} max={900} />
          <Shock x={gx} y={gy} t0={tShock + 0.7} max={900} />
          <Sparks x={gx} y={gy - 80} t0={33.6} n={60} speed={900} life={2.2} g={800} seed="boom" size={9} />
          <Smoke x={gx} y={gy - 40} t0={34.4} n={9} spread={150} rise={520} life={5} />
          {t >= tQuake && (
            <g stroke="#1c0d1f" strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round">
              {[-1, 1].map((sd) => (
                <polyline
                  key={sd}
                  points={`${gx},${gy + 60} ${gx + sd * 120 * eo(t, tQuake, 0.5)},${gy + 110} ${gx + sd * 90 * eo(t, tQuake, 0.5)},${gy + 190} ${gx + sd * 260 * eo(t, tQuake, 0.7)},${gy + 260}`}
                />
              ))}
            </g>
          )}
        </S>
        <AbsoluteFill style={{background: '#ff3a1a', opacity: heatO, mixBlendMode: 'overlay'}} />
      </Cam>
      <Flash t0={33.6} dur={0.9} color="#fff" />
      <Chip i={0} text="KAWAH" at={tKawah} color="#c7a05a" icon={<circle r={14} fill="#3a2230" stroke={OUT} strokeWidth={3} />} />
      <Chip i={1} text="GELOMBANG KEJUT" at={tShock} color="#7ccfff" icon={<g fill="none" stroke="#fff" strokeWidth={4}><circle r={8} /><circle r={16} /><circle r={24} opacity={0.6} /></g>} />
      <Chip i={2} text="PANAS EKSTREM" at={tHeat} color="#ff7a4a" icon={<g><rect x={-5} y={-22} width={10} height={32} rx={5} fill="#fff" stroke={OUT} strokeWidth={3} /><circle cy={14} r={11} fill="#ff3a1a" stroke={OUT} strokeWidth={3} /></g>} />
      <Chip i={3} text="GEMPA" at={tQuake} color="#c7b0ff" icon={<polyline points="-22,0 -12,-14 -2,12 8,-14 18,10 24,0" fill="none" stroke="#fff" strokeWidth={5} strokeLinejoin="round" />} />
    </>
  );
};

/* 9 ─ tsunami (41.5 – 44.5) */
const SceneTsunami = () => {
  const t = useT();
  const lt = useLT();
  const tT = W('tsunami');
  const amp = lerp(30, 520, easeInOut(prog(t, 41.9, 2.2)));
  const wave = (off: number, base: number, color: string, k: number) => {
    let d = `M0,1920 L0,${base}`;
    for (let x = 0; x <= 1080; x += 20) {
      const hump = Math.exp(-Math.pow((x - (300 + lt * 140)) / 260, 2));
      const y = base - amp * k * hump - 22 * Math.sin(x / 70 + lt * 3 + off);
      d += ` L${x},${y.toFixed(1)}`;
    }
    d += ' L1080,1920Z';
    return <path d={d} fill={color} stroke={OUT} strokeWidth={6} strokeLinejoin="round" />;
  };
  return (
    <>
      <Cam z0={1} z1={1.08} dur={3} shakes={[{a: 41.5, d: 1.2, amp: 10}]}>
        <AbsoluteFill style={{background: 'linear-gradient(180deg,#3a1c4a 0%,#b23d4f 38%,#f68a45 62%,#ffb347 80%)'}} />
        <S>
          <circle cx={820} cy={1180} r={160} fill="url(#glowOrange)" />
          <path d="M600,1430 L1080,1380 L1080,1920 L600,1920Z" fill="#4d2a45" stroke={OUT} strokeWidth={6} />
          {[640, 730, 820, 910, 990].map((bx, i) => (
            <g key={i}>
              <rect x={bx} y={1300 - (i % 3) * 50} width={68} height={130 + (i % 3) * 50} fill="#2c1634" stroke={OUT} strokeWidth={4} />
              <rect x={bx + 16} y={1320 - (i % 3) * 50} width={14} height={16} fill="#ffd45a" />
            </g>
          ))}
          {wave(0, 1530, '#2f7fd6', 0.9)}
          {wave(1.5, 1600, '#2a6cc0', 0.6)}
          {wave(3, 1680, '#1f55a0', 0.35)}
        </S>
      </Cam>
      <Pill x={540} y={560} text="TSUNAMI" at={tT} color="#7ccfff" size={76} />
    </>
  );
};

/* 10 ─ buku catatan (44.5 – 56.8) */
const Notebook: React.FC<{children?: React.ReactNode; rot?: number; top?: number}> = ({children, rot = -2.2, top = 300}) => (
  <div
    style={{
      position: 'absolute',
      left: 100,
      top,
      width: 880,
      height: 1300,
      background:
        'repeating-linear-gradient(180deg, transparent 0 64px, rgba(90,120,170,0.38) 64px 66px), #f2e3b9',
      transform: `rotate(${rot}deg)`,
      boxShadow: '0 30px 60px rgba(0,0,0,0.55), inset 0 0 80px rgba(150,110,50,0.25)',
      borderRadius: 8,
    }}
  >
    <div style={{position: 'absolute', left: 92, top: 0, bottom: 0, width: 3, background: 'rgba(200,70,70,0.55)'}} />
    {children}
  </div>
);

const WoodBG = () => (
  <AbsoluteFill
    style={{
      background:
        'repeating-linear-gradient(90deg, rgba(0,0,0,0.12) 0 4px, transparent 4px 140px), linear-gradient(180deg,#5a3d2b,#3d2819)',
    }}
  />
);

const Hand: React.FC<{children: React.ReactNode; size?: number; color?: string; style?: React.CSSProperties}> = ({
  children,
  size = 90,
  color = '#27344f',
  style,
}) => <div style={{fontFamily: HAND, fontStyle: 'italic', fontWeight: 700, fontSize: size, color, ...style}}>{children}</div>;

const SceneNotebook = () => {
  const t = useT();
  const bars = [
    {at: W('10', 0), h: 150, label: '10 m', note: 'bola api', cx: 250},
    {at: W('1', 0), h: 430, label: '1 km', note: 'global', cx: 460},
    {at: W('10', 1), h: 760, label: '10 km', note: 'kepunahan massal', cx: 670},
  ];
  const base = 1090;
  const titleA = 1 - prog(t, 46.0, 0.4);
  const titleB = prog(t, 46.4, 0.5);
  const reveal = eo(t, 44.6, 0.9);
  return (
    <>
      <WoodBG />
      <Cam z0={1.05} z1={1} dur={12.3}>
        <Notebook top={280 + (1 - eo(t, 44.5, 0.6)) * 400}>
          <Hand size={100} style={{position: 'absolute', left: 130, top: 70, opacity: titleA, clipPath: `inset(0 ${(1 - reveal) * 100}% 0 0)`}}>
            tidak semuanya sama
          </Hand>
          <Hand size={92} style={{position: 'absolute', left: 130, top: 70, opacity: titleB}}>
            ukuran → dampak
          </Hand>
          <svg width={880} height={1300} style={{position: 'absolute', left: 0, top: 0}}>
            <Defs />
            <line x1={150} y1={base} x2={820} y2={base} stroke="#27344f" strokeWidth={5} strokeLinecap="round" />
            <line x1={150} y1={base} x2={150} y2={300} stroke="#27344f" strokeWidth={5} strokeLinecap="round" />
            {bars.map((b, i) => {
              const g = eo(t, b.at, 0.7);
              const h = b.h * g;
              return (
                <g key={i}>
                  <rect x={b.cx - 70} y={base - h} width={140} height={h} fill="url(#hatch)" stroke="#162040" strokeWidth={5} />
                </g>
              );
            })}
          </svg>
          {bars.map((b, i) => (
            <React.Fragment key={i}>
              <Hand
                size={62}
                color="#c2402e"
                style={{position: 'absolute', left: b.cx - 100, top: base + 20, width: 200, textAlign: 'center', opacity: prog(t, b.at + 0.4, 0.3)}}
              >
                {b.label}
              </Hand>
              <Hand
                size={56}
                color="#1f6b3a"
                style={{
                  position: 'absolute',
                  left: b.cx - 190 - (i === 2 ? 110 : 0),
                  top: base - b.h - 160 + (i === 2 ? 40 : 0),
                  width: 380,
                  whiteSpace: 'nowrap',
                  textAlign: 'center',
                  opacity: prog(t, b.at + 0.5, 0.3),
                }}
              >
                {b.note}
              </Hand>
            </React.Fragment>
          ))}
        </Notebook>
      </Cam>
    </>
  );
};

/* 11 ─ kalender 66 juta tahun (56.8 – 61.4) */
const Dusk: React.FC<{dark?: number; sun?: number; sunY?: number; children?: React.ReactNode; over?: React.ReactNode}> = ({
  dark = 0,
  sun = 1,
  sunY = 1060,
  children,
  over,
}) => (
  <>
    <AbsoluteFill style={{background: 'linear-gradient(180deg,#3a1c4a 0%,#8a2f55 28%,#f0603a 55%,#ffb347 74%)'}} />
    <S>
      <circle cx={760} cy={sunY} r={190} fill="url(#glowOrange)" opacity={sun} />
      <circle cx={760} cy={sunY} r={92} fill="#ffe9a8" opacity={sun} />
      <path d="M-20,1320 L210,1010 L270,1040 L360,1320Z" fill="#3b1d3d" />
      <path d="M0,1290 C200,1240 420,1300 640,1260 C860,1220 980,1270 1080,1250 L1080,1920 L0,1920Z" fill="#4a2342" />
      <path d="M0,1520 C300,1480 600,1540 1080,1490 L1080,1920 L0,1920Z" fill="#35192f" />
      {children}
    </S>
    <AbsoluteFill style={{background: `rgba(8,4,20,${dark * 0.85})`}} />
    {over}
  </>
);

const DinoField: React.FC<{t: number; color?: string}> = ({t, color = '#2c1634'}) => (
  <>
    <Dino x={230} y={1440} s={0.95} color={color} bob={Math.sin(t * 2) * 4} />
    <Dino x={640} y={1500} s={0.7} color={color} flip bob={Math.sin(t * 2 + 1) * 4} />
    <Dino x={920} y={1420} s={0.55} color={color} bob={Math.sin(t * 2 + 2) * 4} />
  </>
);

const CalendarCard: React.FC<{x: number; y: number; s?: number; big: string; small?: string; rot?: number; mark?: number}> = ({
  x,
  y,
  s = 1,
  big,
  small,
  rot = 0,
  mark,
}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-230} y={-230} width={460} height={470} rx={28} fill="#f8f4ec" stroke={OUT} strokeWidth={8} />
    <path d="M-230,-170 L-230,-202 Q-230,-230 -202,-230 L202,-230 Q230,-230 230,-202 L230,-170Z" fill="#d5352b" stroke={OUT} strokeWidth={8} />
    <rect x={-230} y={-230} width={460} height={78} rx={28} fill="#d5352b" stroke={OUT} strokeWidth={8} />
    {[-130, 130].map((rx) => (
      <rect key={rx} x={rx - 12} y={-262} width={24} height={64} rx={12} fill="#cfd3de" stroke={OUT} strokeWidth={6} />
    ))}
    <text x={0} y={25} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={190} fill="#1d1b2b">
      {big}
    </text>
    {small && (
      <text x={0} y={140} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={44} fill="#d5352b">
        {small}
      </text>
    )}
    {mark !== undefined && <circle cx={0} cy={0} r={0} />}
  </g>
);

const SceneCalendar = () => {
  const t = useT();
  const tc = W('Sekitar', 0) - 0.15;
  const n = Math.round(66 * easeOut(prog(t, tc + 0.2, 1.3)));
  const p = pop(t, tc, 0.5);
  return (
    <>
      <Cam z0={1.06} z1={1} dur={4.6}>
        <Dusk>
          <DinoField t={t} />
        </Dusk>
      </Cam>
      {t >= tc && (
        <S>
          <CalendarCard x={540} y={520} s={p * 0.95} big={String(n)} small="JUTA TAHUN LALU" rot={-3} />
        </S>
      )}
    </>
  );
};

/* 12 ─ tumbukan Chicxulub (61.4 – 66.1) */
const SceneStrike = () => {
  const t = useT();
  const lt = useLT();
  const tHit = W('menghantam', 1);
  const p = easeIn(prog(t, 61.4, tHit - 61.4));
  const x = lerp(1000, 330, p);
  const y = lerp(120, 1230, p);
  const hit = t >= tHit;
  return (
    <>
      <Cam z0={1} z1={1.12} dur={4.7} shakes={[{a: tHit, d: 1.6, amp: 26}]}>
        <Dusk sun={1 - clamp((t - tHit) / 2) * 0.5}>
          <DinoField t={t} />
          {!hit && (
            <>
              <Flame x={x} y={y} ang={(Math.atan2(1110, -670) * 180) / Math.PI} len={560} w={0.7} t={t} />
              <Rock x={x} y={y} s={0.7} rot={t * 40} glow={0.9} />
            </>
          )}
          {hit && (
            <>
              <circle cx={330} cy={1230 - 120 * eo(t, tHit, 1)} r={40 + 240 * eo(t, tHit, 1.2)} fill="url(#glowOrange)" opacity={1 - prog(t, tHit + 1.4, 1.2)} />
              <Shock x={330} y={1270} t0={tHit} max={1100} />
              <Shock x={330} y={1270} t0={tHit + 0.3} max={1100} />
              <Sparks x={330} y={1230} t0={tHit} n={50} speed={900} life={2} g={800} seed="chx" size={9} />
              <Smoke x={330} y={1260} t0={tHit + 0.2} n={8} spread={140} rise={560} life={4} color="#4a2f3a" />
            </>
          )}
        </Dusk>
      </Cam>
      {hit && <Flash t0={tHit} dur={0.8} />}
      <Pill x={330} y={660} text="YUCATÁN" sub="Meksiko" at={W('Yucatán')} color="#ffb84d" size={60} />
    </>
  );
};

/* 13 ─ kawah (66.1 – 70.0) */
const SceneCrater = () => {
  const t = useT();
  const lt = useLT();
  const g = eo(t, 66.15, 1.2);
  const tm = W('Chicxulub');
  return (
    <>
      <Cam z0={1.15} z1={1} dur={3.9}>
        <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #8a6540 0%, #5d4128 70%, #3e2a1a 100%)'}} />
        <S>
          {Array.from({length: 40}).map((_, i) => (
            <ellipse
              key={i}
              cx={random(`tx${i}`) * 1080}
              cy={random(`ty${i}`) * 1920}
              rx={30 + random(`tw${i}`) * 80}
              ry={12 + random(`th${i}`) * 40}
              fill={i % 2 ? '#6e4e30' : '#4d3622'}
              opacity={0.5}
            />
          ))}
          <circle cx={540} cy={900} r={430 * g} fill="#a37b4e" stroke={OUT} strokeWidth={8} />
          <circle cx={540} cy={900} r={360 * g} fill="#4a301e" stroke={OUT} strokeWidth={6} />
          <circle cx={540} cy={900} r={250 * g} fill="#2c1b11" />
          <circle cx={540} cy={900} r={110 * g} fill="#170d08" />
          <circle cx={540} cy={900} r={500 * g} fill="none" stroke="#ffcf6a" strokeWidth={6} strokeDasharray="4 18" opacity={0.7 * (1 - g * 0.3)} strokeLinecap="round" />
          <g opacity={prog(t, tm, 0.4)}>
            <line x1={110} y1={1400} x2={970} y2={1400} stroke="#fff" strokeWidth={8} strokeLinecap="round" />
            <polyline points="150,1370 110,1400 150,1430" fill="none" stroke="#fff" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="930,1370 970,1400 930,1430" fill="none" stroke="#fff" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </S>
      </Cam>
      <Pill x={540} y={1330} text="± 200 km" at={W('200')} color="#ffcf6a" size={64} />
      <Pill x={540} y={300} text="KAWAH CHICXULUB" at={tm} color="#ff7a4a" size={56} />
    </>
  );
};

/* 14 ─ langit gelap (70.0 – 78.2) */
const SceneDarken = () => {
  const t = useT();
  const lt = useLT();
  const dark = clamp((t - 70) / 7);
  const tF = W('fotosintesis');
  const wilt = clamp((t - 74.8) / 2.4);
  return (
    <>
      <Cam z0={1} z1={1.08} dur={8.2}>
        <Dusk dark={dark} sun={1 - clamp((t - 73.5) / 2.5)}>
          {[130, 280, 440, 600, 760, 920].map((lx, i) => (
            <Leaf key={i} x={lx} y={1560 + (i % 2) * 40} s={1.15} wilt={wilt} />
          ))}
          {Array.from({length: 9}).map((_, i) => {
            const k = eo(t, 70 + i * 0.25, 2.2);
            const bx = 60 + i * 125;
            return (
              <circle
                key={i}
                cx={bx}
                cy={lerp(1500, 330 + (i % 3) * 120, k)}
                r={110 + (i % 3) * 40}
                fill={i % 2 ? '#3d3238' : '#52444b'}
                stroke={OUT}
                strokeWidth={5}
                opacity={0.95}
              />
            );
          })}
          {Array.from({length: 60}).map((_, i) => {
            const y = ((random(`ay${i}`) * 2000 + t * (80 + random(`av${i}`) * 140)) % 2000) - 40;
            return <circle key={i} cx={random(`ax${i}`) * 1080} cy={y} r={3 + random(`ar${i}`) * 5} fill="#9a8a90" opacity={clamp((t - 71) / 2) * 0.8} />;
          })}
        </Dusk>
      </Cam>
      <Pill x={300} y={560} text="DEBU" at={W('Debu')} color="#c9b6a8" size={64} />
      <Pill x={780} y={700} text="JELAGA" at={W('jelaga')} color="#9a9a9a" size={64} />
      <Pill x={540} y={1160} text="AEROSOL SULFUR" at={W('aerosol')} color="#ffe34a" size={60} />
      <Pill x={540} y={1300} text="FOTOSINTESIS ✕" at={tF} color="#7dffb0" size={56} />
    </>
  );
};

/* 15 ─ rantai makanan (78.2 – 80.2) */
const SceneChain = () => {
  const t = useT();
  const tr = W('runtuh');
  const broke = clamp((t - tr) / 0.6);
  const sh = broke > 0 && broke < 1 ? Math.sin(t * 90) * 10 : 0;
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#1f1a2a 0%,#3b3040 60%,#4b3a44 100%)'}} />
      <S>
        <g transform="translate(540 930) scale(1.22) translate(-540 -930)">
        <g transform={`translate(${sh} ${broke * 40})`}>
          <Leaf x={190} y={960} s={1.5} wilt={broke} />
          <ellipse cx={540} cy={920} rx={90} ry={70} fill="#8ab8d9" stroke={OUT} strokeWidth={6} />
          <circle cx={575} cy={895} r={9} fill={OUT} />
          <circle cx={600} cy={905} r={9} fill={OUT} />
          <Dino x={880} y={990} s={0.38} color="#c2402e" flip />
        </g>
        {[0, 1].map((i) => {
          const ax = i ? 700 : 370;
          return (
            <g key={i} opacity={1}>
              <line x1={ax - 60} y1={900} x2={ax + 60} y2={900} stroke={broke > 0.3 ? '#c2402e' : '#fff'} strokeWidth={14} strokeLinecap="round" />
              <polyline points={`${ax + 30},${870} ${ax + 70},${900} ${ax + 30},${930}`} fill="none" stroke={broke > 0.3 ? '#c2402e' : '#fff'} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
              {broke > 0.3 && (
                <g stroke="#ff4a3a" strokeWidth={16} strokeLinecap="round" transform={`translate(${ax} 810) scale(${pop(t, tr + 0.2, 0.3)})`}>
                  <line x1={-32} y1={-32} x2={32} y2={32} />
                  <line x1={32} y1={-32} x2={-32} y2={32} />
                </g>
              )}
            </g>
          );
        })}
        </g>
      </S>
    </>
  );
};

/* 16 ─ 75 persen (80.2 – 85.8) */
const ScenePercent = () => {
  const t = useT();
  const t75 = W('75');
  const tD = W('dinosaurus');
  const n = Math.round(75 * easeOut(prog(t, t75 - 0.2, 1.4)));
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#171320 0%,#2a2233 100%)'}} />
      <Cam z0={1.05} z1={1} dur={5.6}>
        <S>
          {Array.from({length: 100}).map((_, i) => {
            const col = i % 10;
            const row = Math.floor(i / 10);
            const idx = 99 - i;
            const gone = t > t75 + idx * 0.012 + 0.1 && idx < 75 ? 1 : 0;
            const sc = pop(t, 80.2 + i * 0.004, 0.4);
            return (
              <circle key={i} cx={150 + col * 85} cy={420 + row * 85} r={30 * sc} fill={gone ? '#4b4452' : '#59d6a2'} stroke={OUT} strokeWidth={4} />
            );
          })}
          {t >= tD && <Dino x={300} y={1830} s={0.42} color="#6a5f72" bob={0} />}
          {t >= tD && (
            <g stroke="#ff4a3a" strokeWidth={22} strokeLinecap="round" transform={`translate(330 1720) scale(${pop(t, tD + 0.3, 0.35)})`}>
              <line x1={-50} y1={-50} x2={50} y2={50} />
              <line x1={50} y1={-50} x2={-50} y2={50} />
            </g>
          )}
        </S>
      </Cam>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 1290,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 190,
          color: '#ff7a4a',
          WebkitTextStroke: '10px #1a1020',
          paintOrder: 'stroke fill',
          opacity: prog(t, t75 - 0.2, 0.3),
        }}
      >
        {n}%
      </div>
      <Pill x={540} y={310} text="SPESIES PUNAH" at={t75 + 1.2} color="#ff7a4a" size={50} />
    </>
  );
};

/* 17 ─ lab & lampu ide (85.8 – 89.0) */
const LabBG: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <>
    <AbsoluteFill style={{background: '#3f8f8a'}} />
    <S>
      <rect x={0} y={1180} width={1080} height={740} fill="#d9c9a0" />
      <rect x={0} y={1170} width={1080} height={16} fill="#2f6f6b" />
      {Array.from({length: 7}).map((_, i) => (
        <line key={i} x1={0} y1={420 + i * 110} x2={1080} y2={420 + i * 110} stroke="#2f7a76" strokeWidth={4} />
      ))}
      {Array.from({length: 12}).map((_, i) => (
        <line key={i} x1={i * 100} y1={420} x2={i * 100} y2={1170} stroke="#2f7a76" strokeWidth={4} />
      ))}
      {Array.from({length: 8}).map((_, i) => (
        <line key={i} x1={i * 160 - 200} y1={1920} x2={i * 160 + 300} y2={1186} stroke="#bfae82" strokeWidth={4} />
      ))}
      {children}
    </S>
  </>
);

const SceneLab = () => {
  const t = useT();
  const tj = W('jawabannya');
  const bounce = Math.sin(t * 6) * 6;
  return (
    <>
      <Cam z0={1} z1={1.1} dur={3.2}>
        <LabBG>
          <Person x={540} y={1480} s={1.5} coat glasses hair="#7a4a2a" armR={160} armL={20} mouth="smile" />
          {t >= tj - 0.4 && (
            <g transform={`translate(540 ${650 + bounce}) scale(${pop(t, tj - 0.4, 0.5)})`}>
              <circle r={150} fill="url(#glowOrange)" />
              <path d="M-52,-18 A60,60 0 1 1 52,-18 C40,10 40,30 30,50 L-30,50 C-40,30 -40,10 -52,-18Z" fill="#ffe27a" stroke={OUT} strokeWidth={7} />
              <rect x={-30} y={50} width={60} height={20} rx={6} fill="#9aa3b5" stroke={OUT} strokeWidth={6} />
              <rect x={-22} y={70} width={44} height={14} rx={6} fill="#6a738a" stroke={OUT} strokeWidth={6} />
            </g>
          )}
        </LabBG>
      </Cam>
    </>
  );
};

/* 18 ─ kalender 26 Sep 2022 (89.0 – 91.8) */
const SceneDate = () => {
  const t = useT();
  const lt = useLT();
  const p = pop(t, 89.05, 0.5);
  const yearP = eo(t, 90.2, 0.6);
  return (
    <>
      <LabBG />
      <Cam z0={1} z1={1.12} dur={2.8}>
        <S>
          <CalendarCard x={540} y={640} s={1.05 * p} big="26" small="SEPTEMBER" rot={-2} />
          <g opacity={yearP} transform={`translate(540 ${1150 + (1 - yearP) * 40})`}>
            <rect x={-170} y={-60} width={340} height={110} rx={30} fill="#1d1b2b" stroke="#fff" strokeWidth={6} />
            <text x={0} y={22} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={84} fill="#ffd45a">
              2022
            </text>
          </g>
        </S>
      </Cam>
    </>
  );
};

/* 19 ─ DART menabrak Dimorphos (91.8 – 98.2) */
const dimPos = (t: number) => {
  const a = t * 1.5;
  return {x: 640 + Math.cos(a) * 300, y: 880 + Math.sin(a) * 120, z: Math.sin(a)};
};
const Dart: React.FC<{x: number; y: number; ang: number; s?: number}> = ({x, y, ang, s = 1}) => (
  <g transform={`translate(${x} ${y}) rotate(${ang}) scale(${s})`}>
    <rect x={-90} y={-14} width={80} height={28} fill="#2c3f7a" stroke={OUT} strokeWidth={4} />
    <rect x={-90} y={-70} width={16} height={140} fill="#2c3f7a" stroke={OUT} strokeWidth={3} />
    <rect x={-10} y={-34} width={60} height={68} rx={10} fill="#e9d9a8" stroke={OUT} strokeWidth={5} />
    <polygon points="50,-22 90,-8 90,8 50,22" fill="#cfd3de" stroke={OUT} strokeWidth={4} />
    <circle cx={90} cy={0} r={8} fill="#ffd45a" />
  </g>
);

const SceneDart = () => {
  const t = useT();
  const lt = useLT();
  const tDim = W('Dimorphos');
  const tHit = tDim + 0.55;
  const t0 = 91.8;
  const hit = t >= tHit;
  const target = dimPos(tHit);
  const dim = hit ? dimPos(t) : dimPos(t);
  const pr = easeIn(prog(t, t0, tHit - t0));
  const dx = lerp(-80, target.x, pr);
  const dy = lerp(1650, target.y, pr);
  const ang = (Math.atan2(target.y - 1650, target.x + 80) * 180) / Math.PI;
  return (
    <>
      <SpaceBG tone="black" />
      <Cam z0={1.1} z1={1} dur={6.4} shakes={[{a: tHit, d: 0.9, amp: 18}]}>
        <S>
          <ellipse cx={640} cy={880} rx={300} ry={120} fill="none" stroke="#fff" strokeOpacity={0.3} strokeWidth={4} strokeDasharray="12 14" />
          <Rock x={640} y={880} s={1.5} rot={t * 6} tint="#9a8884" />
          <Rock x={dim.x} y={dim.y} s={0.42} rot={t * 30} tint="#a8968f" />
          {!hit && (
            <>
              <line x1={-80} y1={1650} x2={dx} y2={dy} stroke="#fff" strokeOpacity={0.4} strokeWidth={4} strokeDasharray="10 14" />
              <Dart x={dx} y={dy} ang={ang} s={0.7} />
            </>
          )}
          {hit && (
            <>
              <circle cx={target.x} cy={target.y} r={40 + 180 * eo(t, tHit, 0.5)} fill="url(#glowWhite)" opacity={1 - prog(t, tHit, 0.7)} />
              <Sparks x={dim.x} y={dim.y} t0={tHit} n={40} speed={400} life={1.8} g={0} color="#d8c8c0" size={8} seed="ej" />
              <path
                d={`M${dim.x},${dim.y} L${dim.x - 420},${dim.y - 260} L${dim.x - 380},${dim.y - 120}Z`}
                fill="#d8c8c0"
                opacity={0.25 * (1 - prog(t, tHit, 2.4)) * (t > tHit ? 1 : 0)}
              />
            </>
          )}
        </S>
      </Cam>
      <Pill x={220} y={1500} text="DART" at={W('DART')} color="#7ccfff" size={58} />
      <Pill x={880} y={560} text="DIMORPHOS" at={tDim} color="#ffb84d" size={50} />
      <Pill x={540} y={1280} text="DIDYMOS" at={W('Didymos')} color="#c7b0ff" size={50} />
    </>
  );
};

/* 20 ─ orbit berubah (98.2 – 100.8) */
const SceneOrbit2 = () => {
  const t = useT();
  const lt = useLT();
  const tp = W('periode');
  const k = easeInOut(prog(t, tp + 0.3, 1.1));
  const rx = lerp(320, 270, k);
  const ry = lerp(150, 120, k);
  const sp = lerp(1.3, 1.65, k);
  const a = lt * sp * 2.4;
  return (
    <>
      <SpaceBG tone="black" />
      <S>
        <ellipse cx={540} cy={880} rx={320} ry={150} fill="none" stroke="#fff" strokeOpacity={0.4} strokeWidth={5} strokeDasharray="12 14" />
        <ellipse cx={540} cy={880} rx={rx} ry={ry} fill="none" stroke="#7dffb0" strokeWidth={7} opacity={prog(t, tp + 0.2, 0.3)} />
        <Rock x={540} y={880} s={1.15} rot={t * 6} tint="#9a8884" />
        <Rock x={540 + Math.cos(a) * rx} y={880 + Math.sin(a) * ry} s={0.36} rot={t * 30} tint="#a8968f" />
      </S>
      <Pill x={540} y={440} text="PERIODE ORBIT" sub="berubah" at={tp} color="#7dffb0" size={58} />
    </>
  );
};

/* 21 ─ penumbuk kinetik (100.8 – 103.4) */
const SceneKinetic = () => {
  const t = useT();
  const lt = useLT();
  const tp = W('penumbuk');
  const cyc = (lt * 0.9) % 1;
  const dx = lerp(110, 640, easeIn(cyc));
  return (
    <>
      <SpaceBG tone="purple" />
      <S>
        {Array.from({length: 5}).map((_, i) => (
          <line key={i} x1={dx - 240 - i * 40} y1={900 + (i - 2) * 22} x2={dx - 130} y2={900 + (i - 2) * 22} stroke="#fff" strokeOpacity={0.35 - i * 0.05} strokeWidth={5} strokeLinecap="round" />
        ))}
        <Rock x={820} y={900} s={1.8} rot={t * 5} tint="#9a8884" />
        <Dart x={dx} y={900} ang={0} s={0.8} />
        <circle cx={650} cy={900} r={cyc > 0.92 ? 120 : 0} fill="url(#glowWhite)" />
      </S>
      <Pill x={540} y={440} text="PENUMBUK KINETIK" at={tp} color="#ffcf6a" size={58} sub="kinetic impactor" />
    </>
  );
};

/* 22 ─ tidak semudah itu (103.4 – 107.6) */
const SceneNotEasy = () => {
  const t = useT();
  const lt = useLT();
  const hitT = 103.4 + 1.2;
  const p = prog(t, 103.4, 1.2);
  const hit = t >= hitT;
  const rx = hit ? 480 + (t - hitT) * 14 : 480;
  return (
    <>
      <SpaceBG tone="black" />
      <Cam z0={1} z1={1.06} dur={4.2} shakes={[{a: hitT, d: 0.6, amp: 14}]}>
        <S>
          <Rock x={rx} y={900} s={4.2} rot={t * 2} tint="#8d7b78" />
          {!hit && <Dart x={lerp(-40, 90, easeIn(p))} y={900} ang={0} s={0.55} />}
          {hit && <Dart x={90 - (t - hitT) * 400} y={900 - (t - hitT) * 240} ang={-30 + (t - hitT) * 300} s={0.55} />}
          <circle cx={150} cy={900} r={hit ? 90 * (1 - prog(t, hitT, 0.5)) : 0} fill="url(#glowWhite)" />
        </S>
      </Cam>
      {hit && (
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 1180,
            textAlign: 'center',
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 280,
            color: '#ffcf6a',
            WebkitTextStroke: '12px #1a1020',
            paintOrder: 'stroke fill',
            transform: `scale(${pop(t, hitT + 0.3, 0.5)})`,
          }}
        >
          ?
        </div>
      )}
    </>
  );
};

/* 23 ─ radar pemantauan (107.6 – 118.4) */
const SceneRadar = () => {
  const t = useT();
  const lt = useLT();
  const cx = 540;
  const cy = 900;
  const t140 = W('140');
  const t100 = W('100');
  const tB = W('belum');
  const years = prog(t, t100, 2.4);
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #14423f 0%, #0a1f27 70%, #050d14 100%)'}} />
      <Cam z0={1.05} z1={1} dur={10.8}>
        <S>
          {[430, 320, 210, 100].map((r) => (
            <circle key={r} cx={cx} cy={cy} r={r} fill="none" stroke="#3dd68c" strokeOpacity={0.55} strokeWidth={4} />
          ))}
          <line x1={cx - 430} y1={cy} x2={cx + 430} y2={cy} stroke="#3dd68c" strokeOpacity={0.4} strokeWidth={3} />
          <line x1={cx} y1={cy - 430} x2={cx} y2={cy + 430} stroke="#3dd68c" strokeOpacity={0.4} strokeWidth={3} />
          <g transform={`rotate(${lt * 120} ${cx} ${cy})`}>
            <path d={`M${cx},${cy} L${cx + 430},${cy} A430,430 0 0 0 ${cx + 430 * Math.cos(-0.6)},${cy + 430 * Math.sin(-0.6)}Z`} fill="#3dd68c" opacity={0.28} />
            <line x1={cx} y1={cy} x2={cx + 430} y2={cy} stroke="#7dffb0" strokeWidth={6} strokeLinecap="round" />
          </g>
          {Array.from({length: 18}).map((_, i) => {
            const a = random(`ra${i}`) * Math.PI * 2 + lt * 0.05 * (1 + random(`rs${i}`));
            const r = 90 + random(`rr${i}`) * 330;
            const blink = 0.5 + 0.5 * Math.sin(t * 3 + i);
            return <circle key={i} cx={cx + Math.cos(a) * r} cy={cy + Math.sin(a) * r} r={9 + (i % 3) * 3} fill="#c9ffe0" opacity={0.5 + blink * 0.5} />;
          })}
          <Earth x={cx} y={cy} r={62} rot={t * 14} />
          {t >= t140 && <circle cx={cx} cy={cy} r={430 * eo(t, t140, 0.8)} fill="none" stroke="#ffcf6a" strokeWidth={8} strokeDasharray="14 12" opacity={1 - prog(t, t140 + 1, 1) * 0.6} />}
        </S>
      </Cam>
      <Pill x={540} y={260} text="PEMANTAUAN NASA" at={W('Menurut') + 0.0} color="#7dffb0" size={52} />
      <Pill x={540} y={1450} text="> 140 METER" at={t140} color="#ffcf6a" size={62} />
      {t >= t100 && (
        <div style={{position: 'absolute', left: 120, right: 120, top: 1580, transform: `scale(${pop(t, t100, 0.4)})`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 48,
              color: '#fff',
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: 14,
            }}
          >
            <span>2026</span>
            <span style={{color: '#7dffb0'}}>100 TAHUN</span>
            <span>2126</span>
          </div>
          <div style={{height: 28, borderRadius: 14, background: 'rgba(255,255,255,0.18)', border: '4px solid #1a1020', overflow: 'hidden'}}>
            <div style={{height: '100%', width: `${years * 100}%`, background: '#3dd68c'}} />
          </div>
        </div>
      )}
      {t >= tB && (
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 380,
            textAlign: 'center',
            transform: `rotate(-6deg) scale(${pop(t, tB, 0.4)})`,
          }}
        >
          <span
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 96,
              color: '#7dffb0',
              border: '10px solid #7dffb0',
              borderRadius: 24,
              padding: '6px 40px',
              background: 'rgba(5,20,20,0.7)',
            }}
          >
            BELUM ADA
          </span>
        </div>
      )}
    </>
  );
};

/* 24 ─ gauge risiko (118.6 – 122.6) */
const SceneGauge = () => {
  const t = useT();
  const tn = W('nyata');
  const tp = W('pasti');
  const need = lerp(-70, -22, backOut(prog(t, tn, 0.7)));
  const jitter = t > tp ? Math.sin(t * 40) * 1.2 : 0;
  const cx = 540;
  const cy = 980;
  const ang = need + jitter;
  return (
    <>
      <LabBG>
        <g transform="translate(540 1150) scale(1.28) translate(-540 -940)">
        <rect x={190} y={620} width={700} height={640} rx={40} fill="#6b3f24" stroke={OUT} strokeWidth={10} />
        <rect x={250} y={670} width={580} height={110} rx={18} fill="#1d1b2b" stroke={OUT} strokeWidth={6} />
        <text x={540} y={750} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={58} fill="#fff" letterSpacing={4}>
          RISIKO TUMBUKAN
        </text>
        <rect x={250} y={810} width={580} height={380} rx={26} fill="#f2e3b9" stroke={OUT} strokeWidth={8} />
        <path d="M300,1120 A240,240 0 0 1 780,1120" fill="none" stroke="#3dd68c" strokeWidth={26} strokeLinecap="butt" strokeDasharray="250 1000" />
        <path d="M300,1120 A240,240 0 0 1 780,1120" fill="none" stroke="#ffcf6a" strokeWidth={26} strokeDasharray="0 250 250 1000" />
        <path d="M300,1120 A240,240 0 0 1 780,1120" fill="none" stroke="#d5352b" strokeWidth={26} strokeDasharray="0 500 260 1000" />
        {Array.from({length: 11}).map((_, i) => {
          const a = (-90 - 80 + (i / 10) * 160) * (Math.PI / 180);
          return <line key={i} x1={540 + Math.cos(a) * 205} y1={1120 + Math.sin(a) * 205} x2={540 + Math.cos(a) * 235} y2={1120 + Math.sin(a) * 235} stroke={OUT} strokeWidth={5} />;
        })}
        <g transform={`rotate(${ang} 540 1120)`}>
          <line x1={540} y1={1120} x2={540} y2={900} stroke={OUT} strokeWidth={16} strokeLinecap="round" />
          <line x1={540} y1={1120} x2={540} y2={905} stroke="#d5352b" strokeWidth={8} strokeLinecap="round" />
        </g>
        <circle cx={540} cy={1120} r={26} fill="#4b4b58" stroke={OUT} strokeWidth={6} />
        </g>
      </LabBG>
      <Pill x={300} y={330} text="NYATA" at={tn} color="#ffcf6a" size={66} />
      <Pill x={540} y={1640} text="BUKAN PASTI" at={tp} color="#7dffb0" size={62} />
    </>
  );
};

/* 25 ─ penutup (122.6 – 126.6) */
const SceneOutro = () => {
  const t = useT();
  const lt = useLT();
  const out = prog(t, 126.0, 0.6);
  const sx = lerp(1100, 80, prog(lt, 0.4, 1.6));
  const sy = lerp(120, 700, prog(lt, 0.4, 1.6));
  const tl = 300;
  return (
    <>
      <Cam z0={1.08} z1={1} dur={4}>
        <NightHill>
          <g opacity={1 - prog(lt, 2.0, 0.5)}>
            <line x1={sx + tl * 0.8} y1={sy - tl * 0.45} x2={sx} y2={sy} stroke="#ffe3b0" strokeWidth={8} strokeLinecap="round" />
            <circle cx={sx} cy={sy} r={12} fill="#fff" />
          </g>
          <g transform="translate(700 1520) rotate(-60)">
            <rect x={0} y={-24} width={230} height={48} rx={12} fill="#cfd3de" stroke={OUT} strokeWidth={6} />
            <rect x={230} y={-34} width={40} height={68} rx={10} fill="#6a738a" stroke={OUT} strokeWidth={6} />
          </g>
          <line x1={700} y1={1520} x2={650} y2={1650} stroke={OUT} strokeWidth={10} />
          <line x1={700} y1={1520} x2={760} y2={1650} stroke={OUT} strokeWidth={10} />
          <line x1={700} y1={1520} x2={700} y2={1650} stroke={OUT} strokeWidth={10} />
          <Person x={520} y={1640} s={0.95} coat glasses hair="#7a4a2a" armR={110} armL={20} mouth="smile" look={1} />
          <Person x={880} y={1650} s={0.8} shirt="#c4613b" armR={20} armL={20} mouth="smile" look={-1} flip />
        </NightHill>
      </Cam>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 330,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 120,
          color: '#fff',
          letterSpacing: 2,
          opacity: eo(t, 124.1, 0.8),
          transform: `translateY(${(1 - eo(t, 124.1, 0.8)) * 30}px)`,
          textShadow: '0 0 30px rgba(124,207,255,0.9), 0 6px 14px rgba(0,0,0,0.6)',
        }}
      >
        <span style={{color: '#ffc85a'}}>Semesta</span>Kita
      </div>
      <AbsoluteFill style={{background: '#000', opacity: out}} />
    </>
  );
};

/* ═══════════════════════════ ROOT ═══════════════════════════ */
export const Asteroid: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <TCtx.Provider value={t}>
      <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
        {/* ───── visual ───── */}
        <Scene a={0} b={10.3} fade={0}><SceneHook /></Scene>
        <Scene a={10.3} b={14.4}><SceneOrbit /></Scene>
        <Scene a={14.4} b={19.7}><SceneEntry /></Scene>
        <Scene a={19.7} b={22.9}><SceneSmallBurn /></Scene>
        <Scene a={22.9} b={25.2}><SceneMeteor /></Scene>
        <Scene a={25.2} b={28.6}><SceneMeteorit /></Scene>
        <Scene a={28.6} b={33.6}><SceneBigEntry /></Scene>
        <Scene a={33.6} b={41.5} fade={0.05}><SceneImpact /></Scene>
        <Scene a={41.5} b={44.5}><SceneTsunami /></Scene>
        <Scene a={44.5} b={56.8}><SceneNotebook /></Scene>
        <Scene a={56.8} b={61.4}><SceneCalendar /></Scene>
        <Scene a={61.4} b={66.1} fade={0.12}><SceneStrike /></Scene>
        <Scene a={66.1} b={70.0} fade={0.15}><SceneCrater /></Scene>
        <Scene a={70.0} b={78.2}><SceneDarken /></Scene>
        <Scene a={78.2} b={80.2}><SceneChain /></Scene>
        <Scene a={80.2} b={85.8}><ScenePercent /></Scene>
        <Scene a={85.8} b={89.0}><SceneLab /></Scene>
        <Scene a={89.0} b={91.8}><SceneDate /></Scene>
        <Scene a={91.8} b={98.2}><SceneDart /></Scene>
        <Scene a={98.2} b={100.8}><SceneOrbit2 /></Scene>
        <Scene a={100.8} b={103.4}><SceneKinetic /></Scene>
        <Scene a={103.4} b={107.6}><SceneNotEasy /></Scene>
        <Scene a={107.6} b={118.5}><SceneRadar /></Scene>
        <Scene a={118.5} b={122.6}><SceneGauge /></Scene>
        <Scene a={122.6} b={TOTAL_SECONDS + 1} fade={0.25}><SceneOutro /></Scene>
        <Vignette />
        <Caption />

        {/* ───── audio (voiceover + efek suara) ───── */}
        <Audio src={staticFile('audio.mp3')} />
      </AbsoluteFill>
    </TCtx.Provider>
  );
};

export default Asteroid;
