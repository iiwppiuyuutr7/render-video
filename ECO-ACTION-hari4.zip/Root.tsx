import React from 'react';
import {Composition} from 'remotion';
import {EcoActionDay4, ECO4_TOTAL_SECONDS} from './EcoActionDay4';

const FPS = 60;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EcoActionDay4"
    component={EcoActionDay4}
    durationInFrames={Math.round(ECO4_TOTAL_SECONDS * FPS)}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
