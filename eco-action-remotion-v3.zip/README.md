# ECO-ACTION 4 DAYS (Remotion)

Taruh `Root.tsx` dan `EcoAction.tsx` di folder `src/`, isi folder `public/` ke `public/` project Remotion kamu.

    npm i @remotion/google-fonts
    npx remotion studio
    npx remotion render EcoAction out/eco-action.mp4

- 1920x1080, 30 fps, 67 detik (2010 frame)
- Semua 8 klip dipakai sekali, utuh, kecepatan asli. Audio klip dimatikan.
- Backsound: backsound.mp3 (Strawberry Guy - Mrs Magic, dipotong 67 dtk), otomatis mengecil saat SFX bunyi (ducking, atur di array DUCK). SFX: whoosh, transition, click.
- Atur urutan/durasi klip di array SHOTS (EcoAction.tsx), penanda scene di objek S.
