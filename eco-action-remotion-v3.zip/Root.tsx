import React from 'react';
import {Composition} from 'remotion';
import {EcoAction, TOTAL_FRAMES, FPS} from './EcoAction';

export const RemotionRoot: React.FC = () => (
  <Composition id="EcoAction" component={EcoAction} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1920} height={1080} />
);
