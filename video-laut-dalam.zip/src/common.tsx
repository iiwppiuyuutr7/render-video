import React from "react";
import {AbsoluteFill, Easing, Sequence, interpolate, random, useCurrentFrame} from "remotion";
import {C, FPS, HEIGHT, SceneContext, WIDTH, prog, sec, useT} from "./config";
import {FONT} from "./fonts";

const OVERLAP = 0.35;

const SceneFade: React.FC<{fade: boolean; children: React.ReactNode}> = ({fade, children}) => {
  const frame = useCurrentFrame();
  const opacity = fade
    ? interpolate(frame, [0, sec(OVERLAP)], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      })
    : 1;
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

// Scene mulai OVERLAP detik lebih awal dan masuk dengan crossfade di atas scene sebelumnya.
export const Scene: React.FC<{
  name: string;
  start: number;
  end: number;
  children: React.ReactNode;
}> = ({name, start, end, children}) => {
  const from = Math.max(0, start - OVERLAP);
  return (
    <Sequence name={name} from={sec(from)} durationInFrames={sec(end) - sec(from)}>
      <SceneContext.Provider value={{offset: from}}>
        <SceneFade fade={start > 0}>{children}</SceneFade>
      </SceneContext.Provider>
    </Sequence>
  );
};

// Partikel kecil yang melayang pelan (deterministik).
export const Particles: React.FC<{
  count?: number;
  seed?: string;
  color?: string;
  speed?: number;
  dir?: 1 | -1;
  opacity?: number;
  maxR?: number;
  sway?: number;
}> = ({count = 60, seed = "p", color = "#bfe9ff", speed = 30, dir = 1, opacity = 0.5, maxR = 4, sway = 18}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const items: React.ReactNode[] = [];
  for (let i = 0; i < count; i++) {
    const rx = random(`${seed}-x-${i}`);
    const ry = random(`${seed}-y-${i}`);
    const rs = random(`${seed}-s-${i}`);
    const rr = random(`${seed}-r-${i}`);
    const rp = random(`${seed}-p-${i}`);
    const sp = speed * (0.4 + rs);
    const y = (((ry * HEIGHT + dir * sp * t) % HEIGHT) + HEIGHT) % HEIGHT;
    const x = rx * WIDTH + Math.sin(t * 0.7 + rp * 6.28) * sway;
    const r = 1 + rr * maxR;
    items.push(<circle key={i} cx={x} cy={y} r={r} fill={color} opacity={opacity * (0.35 + 0.65 * rr)} />);
  }
  return (
    <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
      {items}
    </svg>
  );
};

// Cahaya lembut dari lingkaran transparan berlapis.
export const Glow: React.FC<{x: number; y: number; r: number; color: string; intensity?: number}> = ({
  x,
  y,
  r,
  color,
  intensity = 1,
}) => {
  const layers = [1, 0.8, 0.62, 0.46, 0.32, 0.2, 0.1];
  return (
    <g>
      {layers.map((k, i) => (
        <circle key={i} cx={x} cy={y} r={r * k} fill={color} opacity={Math.min(1, intensity * 0.075 * (i + 1))} />
      ))}
    </g>
  );
};

export const Watermark: React.FC = () => {
  const t = useT();
  const o = prog(t, 0.4, 1.2);
  return (
    <div
      style={{
        position: "absolute",
        left: 52,
        bottom: 110,
        display: "flex",
        alignItems: "center",
        gap: 14,
        fontFamily: FONT,
        fontWeight: 600,
        fontSize: 40,
        color: "#ffffff",
        opacity: 0.88 * o,
        textShadow: "0 2px 14px rgba(0,0,0,0.65)",
        letterSpacing: 0.5,
      }}
    >
      <div
        style={{
          width: 14,
          height: 14,
          borderRadius: 7,
          background: C.cyan,
          boxShadow: `0 0 16px ${C.cyan}`,
        }}
      />
      @semestakita
    </div>
  );
};

// Teks umum: posisi absolut, rata tengah.
export const Txt: React.FC<{
  y: number;
  size: number;
  children: React.ReactNode;
  color?: string;
  weight?: 400 | 600 | 700 | 800;
  opacity?: number;
  spacing?: number;
  x?: number;
  width?: number;
  scale?: number;
  dy?: number;
  align?: "center" | "left" | "right";
  lineHeight?: number;
}> = ({
  y,
  size,
  children,
  color = C.white,
  weight = 700,
  opacity = 1,
  spacing = 0,
  x = 0,
  width = WIDTH,
  scale = 1,
  dy = 0,
  align = "center",
  lineHeight = 1.15,
}) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width,
      textAlign: align,
      fontFamily: FONT,
      fontSize: size,
      fontWeight: weight,
      color,
      opacity,
      letterSpacing: spacing,
      lineHeight,
      transform: `translateY(${dy}px) scale(${scale})`,
      textShadow: "0 3px 20px rgba(0,0,0,0.45)",
    }}
  >
    {children}
  </div>
);

export const popIn = (t: number, a: number, d = 0.6): number => prog(t, a, a + d, Easing.out(Easing.back(1.6)));
