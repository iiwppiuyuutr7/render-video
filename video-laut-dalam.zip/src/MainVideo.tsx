import React from "react";
import {AbsoluteFill, Audio, staticFile} from "remotion";
import {C, T} from "./config";
import {Scene, Watermark} from "./common";
import {Scene1} from "./Scene1";
import {Scene2} from "./Scene2";
import {Scene3} from "./Scene3";
import {Scene4} from "./Scene4";
import {Scene5} from "./Scene5";
import {Scene6} from "./Scene6";
import {Scene7} from "./Scene7";

export const MainVideo: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.space}}>
    {/* Narasi (sudah dipercepat ke 90 detik, lihat public/narasi.mp3) */}
    <Audio src={staticFile("narasi.mp3")} />

    <Scene name="1 Pembuka" start={T.s1[0]} end={T.s1[1]}>
      <Scene1 />
    </Scene>
    <Scene name="2 Lima zona" start={T.s2[0]} end={T.s2[1]}>
      <Scene2 />
    </Scene>
    <Scene name="3 Tekanan" start={T.s3[0]} end={T.s3[1]}>
      <Scene3 />
    </Scene>
    <Scene name="4 Bioluminesensi" start={T.s4[0]} end={T.s4[1]}>
      <Scene4 />
    </Scene>
    <Scene name="5 Makanan" start={T.s5[0]} end={T.s5[1]}>
      <Scene5 />
    </Scene>
    <Scene name="6 Challenger Deep" start={T.s6[0]} end={T.s6[1]}>
      <Scene6 />
    </Scene>
    <Scene name="7 Penutup" start={T.s7[0]} end={T.s7[1]}>
      <Scene7 />
    </Scene>

    <Watermark />
  </AbsoluteFill>
);
