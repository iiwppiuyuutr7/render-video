import React from "react";
import {
  AbsoluteFill,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const C = {
  ink: "#03111d",
  deep: "#061d2c",
  blue: "#0b526c",
  cyan: "#65d9e8",
  pale: "#d9f7fa",
  gold: "#f2c879",
};

const clamp = { extrapolateLeft: "clamp" as const, extrapolateRight: "clamp" as const };

const captions: Record<number, string[]> = {
  0: [
    "Di bawah permukaan samudra, ada dunia yang nyaris tak tersentuh.",
    "Semakin dalam kita turun, semakin gelap dan semakin besar tekanannya.",
    "Tujuan kita: Challenger Deep, titik terdalam lautan yang diketahui.",
  ],
  1: [
    "Challenger Deep berada di Palung Mariana, Samudra Pasifik bagian barat.",
    "Kedalamannya diperkirakan sekitar 10.935 meter di bawah permukaan laut.",
    "Angka ini berasal dari pengukuran ilmiah dan memiliki sedikit ketidakpastian.",
  ],
  2: [
    "Di kedalaman ini, tekanan air mencapai kira-kira 1.100 kali tekanan atmosfer.",
    "Cahaya Matahari tidak mampu menembus hingga dasar.",
    "Suhu air sangat dingin, sementara lingkungan tetap penuh tantangan.",
  ],
  3: [
    "Namun, dasar laut terdalam bukanlah tempat yang sepenuhnya kosong.",
    "Peneliti menemukan amphipoda, teripang laut dalam, dan mikroorganisme.",
    "Banyak makhluk bertahan dengan memanfaatkan sisa bahan organik yang turun dari atas.",
  ],
  4: [
    "Ikan pun punya batas kedalaman.",
    "Rekor pengamatan ikan hidup terdalam adalah seekor snailfish pada 8.336 meter.",
    "Rekor itu tercatat di Palung Izu-Ogasawara, bukan di titik terdalam Palung Mariana.",
  ],
  5: [
    "Untuk menjelajah, ilmuwan menggunakan wahana selam, robot, dan perangkat perekam khusus.",
    "Sebagian besar dasar laut masih belum dipetakan dengan resolusi tinggi.",
    "Di sana, masih banyak pertanyaan yang menunggu jawaban.",
  ],
};

const subtitles = [
  [0, 150, 300],
  [0, 150, 300],
  [0, 150, 300],
  [0, 150, 300],
  [0, 150, 300],
  [0, 150, 300],
];

function TextLine({ children, size = 42, color = "white", weight = 700, style = {} }: any) {
  return (
    <div style={{
      fontFamily: "Arial, Helvetica, sans-serif",
      fontSize: size,
      color,
      fontWeight: weight,
      letterSpacing: "-0.025em",
      lineHeight: 1.08,
      textShadow: "0 3px 24px rgba(0,0,0,.55)",
      ...style,
    }}>{children}</div>
  );
}

function Particles({ frame, count = 34 }: { frame: number; count?: number }) {
  return <svg width="100%" height="100%" viewBox="0 0 1080 1920" style={{ position: "absolute", inset: 0, opacity: 0.48 }}>
    {Array.from({ length: count }, (_, i) => {
      const x = (i * 173 + 67) % 1080;
      const baseY = (i * 257 + 120) % 1920;
      const y = (baseY - frame * (0.35 + (i % 5) * 0.13) + 1920) % 1920;
      const r = 1.5 + (i % 4) * 1.15;
      return <circle key={i} cx={x} cy={y} r={r} fill="#b6eff4" opacity={0.24 + (i % 5) * 0.1} />;
    })}
  </svg>;
}

function DeepBackground({ frame, tint = 0 }: { frame: number; tint?: number }) {
  const glow = interpolate(frame, [0, 180, 360], [0.7, 0.32, 0.12], clamp);
  return <>
    <AbsoluteFill style={{
      background: `radial-gradient(ellipse at ${50 + Math.sin(frame / 90) * 8}% ${18 + tint * 5}%, rgba(21,105,130,${glow}) 0%, rgba(5,35,53,.92) 36%, #020811 100%)`,
    }} />
    <div style={{
      position: "absolute", top: -100, left: "18%", width: "64%", height: "70%",
      background: "linear-gradient(180deg, rgba(103,220,235,.15), transparent 80%)",
      filter: "blur(42px)", transform: `translateY(${frame * 0.18}px)`,
    }} />
    <Particles frame={frame} />
    <div style={{
      position: "absolute", inset: 0,
      background: "linear-gradient(180deg, rgba(1,8,16,.08) 0%, transparent 45%, rgba(0,4,10,.78) 100%)",
    }} />
  </>;
}

function DepthHUD({ depth, label = "KEDALAMAN" }: { depth: string; label?: string }) {
  return <div style={{
    position: "absolute", top: 92, left: 72, display: "flex", flexDirection: "column", gap: 8,
    borderLeft: `3px solid ${C.cyan}`, paddingLeft: 20,
  }}>
    <div style={{ color: C.cyan, font: "600 20px Arial", letterSpacing: "0.22em" }}>{label}</div>
    <div style={{ color: "white", font: "700 34px Arial", letterSpacing: "0.04em" }}>{depth}</div>
  </div>;
}

function Submarine({ frame, scale = 1 }: { frame: number; scale?: number }) {
  const bob = Math.sin(frame / 19) * 10;
  return <div style={{
    position: "absolute", left: "50%", top: "43%",
    width: 430 * scale, height: 210 * scale,
    transform: `translate(-50%, calc(-50% + ${bob}px))`,
    filter: "drop-shadow(0 20px 34px rgba(0,0,0,.6))",
  }}>
    <svg viewBox="0 0 430 210" width="100%" height="100%">
      <defs>
        <linearGradient id="hull" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stopColor="#d8e7e7"/><stop offset=".5" stopColor="#738d98"/><stop offset="1" stopColor="#263e4b"/>
        </linearGradient>
        <radialGradient id="lamp"><stop stopColor="#f5f3ce" stopOpacity=".9"/><stop offset="1" stopColor="#9ce9ef" stopOpacity="0"/></radialGradient>
      </defs>
      <path d="M45 91 Q72 45 155 42 L316 52 Q366 62 386 104 Q365 145 310 151 L105 153 Q55 144 45 112Z" fill="url(#hull)" stroke="#d9f4f4" strokeWidth="4"/>
      <path d="M164 48 L190 14 L260 17 L286 54Z" fill="#526e79" stroke="#b8d3d7" strokeWidth="4"/>
      <rect x="205" y="23" width="42" height="27" rx="10" fill="#102e3c" stroke="#b6dfe2" strokeWidth="3"/>
      <circle cx="130" cy="96" r="21" fill="#0b3144" stroke="#d6eeee" strokeWidth="5"/>
      <circle cx="130" cy="96" r="11" fill="#5bc9d9" opacity=".55"/>
      <circle cx="290" cy="100" r="17" fill="#0b3144" stroke="#d6eeee" strokeWidth="5"/>
      <path d="M73 122 L20 149 L91 148Z" fill="#425e6a"/>
      <circle cx="381" cy="112" r="13" fill="#d8f6dc"/>
      <path d="M381 112 L430 89 L430 150Z" fill="url(#lamp)" opacity=".8"/>
      <path d="M380 112 L430 89 L430 150Z" fill="#a8e9f0" opacity=".16"/>
      <path d="M175 155 L178 184 M251 155 L254 183" stroke="#a8c3ca" strokeWidth="9"/>
    </svg>
  </div>;
}

function Fish({ frame, x = 0, y = 0, scale = 1 }: { frame: number; x?: number; y?: number; scale?: number }) {
  const drift = Math.sin(frame / 27) * 24;
  return <div style={{ position: "absolute", left: `calc(50% + ${x + drift}px)`, top: `calc(45% + ${y}px)`, width: 250 * scale, transform: "translate(-50%,-50%)" }}>
    <svg viewBox="0 0 300 150" width="100%">
      <path d="M45 75 Q80 20 180 42 Q225 52 247 75 Q225 105 180 112 Q80 130 45 75Z" fill="#a6bdc1" stroke="#e1f4f2" strokeWidth="3"/>
      <path d="M48 75 L5 35 L15 75 L5 115Z" fill="#819fa7" stroke="#d7e8e8" strokeWidth="3"/>
      <path d="M120 43 Q145 10 170 40" fill="#799aa4"/>
      <circle cx="218" cy="69" r="7" fill="#0a1a22"/>
      <path d="M100 92 Q128 112 160 103" fill="none" stroke="#577982" strokeWidth="3"/>
    </svg>
  </div>;
}

function Creature({ frame, type = "amphi" }: { frame: number; type?: string }) {
  const rotate = Math.sin(frame / 22) * 7;
  if (type === "cucumber") return <div style={{ position: "absolute", left: "50%", top: "53%", width: 390, transform: `translate(-50%,-50%) rotate(${rotate}deg)` }}>
    <svg viewBox="0 0 390 180" width="100%">
      <path d="M35 92 Q55 20 165 34 Q310 20 355 85 Q330 150 160 145 Q55 158 35 92Z" fill="#a7b68a" stroke="#d8e2b8" strokeWidth="4"/>
      {Array.from({length: 13},(_,i)=><path key={i} d={`M${65+i*21} 48 q-8 24 0 48`} stroke="#718d75" strokeWidth="4" opacity=".7"/>)}
      {Array.from({length: 9},(_,i)=><path key={i} d={`M${80+i*26} 140 l${-12+(i%3)*8} 23`} stroke="#c2cda2" strokeWidth="5" strokeLinecap="round"/>)}
    </svg>
  </div>;
  return <div style={{ position: "absolute", left: "50%", top: "52%", width: 300, transform: `translate(-50%,-50%) rotate(${rotate}deg)` }}>
    <svg viewBox="0 0 300 170" width="100%">
      <path d="M40 84 Q55 25 180 42 Q260 50 266 84 Q250 128 170 130 Q65 145 40 84Z" fill="#d29c78" stroke="#f0d1b1" strokeWidth="4"/>
      <path d="M45 84 L8 48 L16 85 L8 122Z" fill="#b77f64"/>
      {Array.from({length: 8},(_,i)=><path key={i} d={`M${70+i*20} 47 q-14 28 0 65`} stroke="#805b4e" strokeWidth="4" opacity=".8"/>)}
      <circle cx="234" cy="72" r="6" fill="#18252a"/>
      <path d="M260 87 l25 12" stroke="#e8c3a2" strokeWidth="5"/>
    </svg>
  </div>;
}

function SceneTitle({ kicker, title, detail }: { kicker: string; title: string; detail?: string }) {
  return <div style={{ position: "absolute", left: 72, right: 72, top: 290 }}>
    <div style={{ color: C.cyan, font: "700 20px Arial", letterSpacing: ".25em", marginBottom: 24 }}>{kicker}</div>
    <TextLine size={68}>{title}</TextLine>
    {detail && <TextLine size={28} color="#c3e5e9" weight={500} style={{ marginTop: 24, lineHeight: 1.35 }}>{detail}</TextLine>}
  </div>;
}

function Subtitle({ scene, frame }: { scene: number; frame: number }) {
  const idx = frame < 150 ? 0 : frame < 300 ? 1 : 2;
  const text = captions[scene]?.[idx] ?? "";
  const fadeIn = interpolate(frame % 150, [0, 12, 138, 150], [0, 1, 1, 0], clamp);
  return <div style={{
    position: "absolute", bottom: 145, left: 58, right: 58, textAlign: "center",
    opacity: fadeIn, padding: "20px 24px",
    background: "rgba(0,8,15,.48)", border: "1px solid rgba(151,226,234,.22)",
    borderRadius: 14, backdropFilter: "blur(8px)",
  }}>
    <div style={{ color: "white", font: "600 29px Arial, Helvetica, sans-serif", lineHeight: 1.28, textShadow: "0 2px 12px #000" }}>{text}</div>
  </div>;
}

function SceneContent({ scene, frame }: { scene: number; frame: number }) {
  if (scene === 0) return <>
    <SceneTitle kicker="DOKUMENTER SAINS • LAUT DALAM" title="APA YANG ADA DI DASAR LAUT TERDALAM BUMI?" detail="Perjalanan menuju tempat paling dalam di planet kita." />
    <div style={{ position: "absolute", top: 890, left: 0, right: 0, height: 550, opacity: .8 }}>
      <div style={{ position: "absolute", left: "10%", right: "10%", bottom: 20, height: 2, background: "rgba(135,223,230,.35)" }} />
      <Submarine frame={frame} scale={1.05}/>
      <div style={{ position: "absolute", top: 300, left: "50%", width: 500, height: 500, transform: "translateX(-50%)", background: "radial-gradient(ellipse, rgba(106,226,235,.2), transparent 65%)" }} />
    </div>
    <div style={{ position: "absolute", bottom: 360, left: 72, color: C.cyan, font: "600 20px Arial", letterSpacing: ".2em" }}>MENYELAM MENUJU KEDALAMAN</div>
  </>;
  if (scene === 1) return <>
    <DepthHUD depth="10.935 M" />
    <SceneTitle kicker="TITIK TERDALAM LAUTAN" title="CHALLENGER DEEP" detail="Palung Mariana • Samudra Pasifik bagian barat" />
    <div style={{ position: "absolute", top: 760, left: 0, right: 0, height: 730 }}>
      <svg viewBox="0 0 1080 730" width="100%" height="100%">
        <defs><linearGradient id="cliff" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#174c61"/><stop offset="1" stopColor="#020811"/></linearGradient></defs>
        <path d="M0 0 L230 0 L340 250 L430 480 L505 610 L575 610 L660 480 L760 250 L850 0 L1080 0 L1080 730 L0 730Z" fill="url(#cliff)" opacity=".9"/>
        <path d="M0 0 L230 0 L340 250 L430 480 L505 610 L575 610 L660 480 L760 250 L850 0" fill="none" stroke="#7bcbd2" strokeWidth="3" opacity=".25"/>
        <path d="M1080 0 L850 0 L760 250 L660 480 L575 610" fill="none" stroke="#7bcbd2" strokeWidth="3" opacity=".25"/>
        <path d="M0 700 Q270 660 505 650 Q540 655 575 650 Q820 660 1080 700 L1080 730 L0 730Z" fill="#101c23"/>
      </svg>
      <Submarine frame={frame} scale={.62}/>
    </div>
    <div style={{ position: "absolute", bottom: 390, left: 72, right: 72, display: "flex", justifyContent: "space-between" }}>
      <div><TextLine size={24} color={C.cyan}>KEDALAMAN TERUKUR</TextLine><TextLine size={48}>10.935 meter</TextLine></div>
      <div style={{ textAlign: "right" }}><TextLine size={22} color="#a8cdd3" weight={500}>PERKIRAAN ILMIAH</TextLine><TextLine size={24} color="#a8cdd3" weight={500}>± 6 meter</TextLine></div>
    </div>
  </>;
  if (scene === 2) return <>
    <DepthHUD depth="≈ 1.100 ATM" label="TEKANAN AIR" />
    <SceneTitle kicker="LINGKUNGAN EKSTREM" title="GELAP. DINGIN. TERTEKAN." detail="Tekanan air meningkat seiring bertambahnya kedalaman." />
    <div style={{ position: "absolute", top: 820, left: 0, right: 0, height: 620 }}>
      {Array.from({length: 8},(_,i)=><div key={i} style={{
        position:"absolute", left: `${5+i*13}%`, top: `${(i%3)*70+80}px`,
        width: 90+i*13, height: 90+i*13, borderRadius:"50%",
        border:"2px solid rgba(117,218,231,.28)", transform:`scale(${1+Math.sin(frame/18+i)*.06})`,
        boxShadow:"0 0 40px rgba(63,182,202,.08)",
      }}/>)}
      <div style={{ position:"absolute", left:"50%", top:"52%", transform:"translate(-50%,-50%)", textAlign:"center" }}>
        <TextLine size={112} color={C.cyan}>1.100×</TextLine>
        <TextLine size={25} color="#d3e8eb" weight={500}>TEKANAN DI PERMUKAAN</TextLine>
      </div>
    </div>
    <div style={{ position:"absolute", bottom:390, left:72, right:72, display:"flex", justifyContent:"space-between" }}>
      <div><TextLine size={22} color={C.cyan}>CAHAYA</TextLine><TextLine size={28}>Tidak ada sinar Matahari</TextLine></div>
      <div style={{textAlign:"right"}}><TextLine size={22} color={C.cyan}>SUHU</TextLine><TextLine size={28}>Sangat dingin</TextLine></div>
    </div>
  </>;
  if (scene === 3) return <>
    <DepthHUD depth="ZONA HADAL" label="LEBIH DARI 6.000 M" />
    <SceneTitle kicker="KEHIDUPAN DI KEGELAPAN" title="TERNYATA, ADA KEHIDUPAN." detail="Ekosistemnya berbeda, tetapi bukan berarti kosong." />
    <Creature frame={frame} type="amphi" />
    <div style={{ position:"absolute", top:1110, left:0, right:0, height:240 }}>
      <Creature frame={frame+30} type="cucumber"/>
    </div>
    <div style={{ position:"absolute", bottom:385, left:72, right:72, display:"flex", gap:18 }}>
      {["AMPHIPODA","TERIPANG","MIKROORGANISME"].map((t,i)=><div key={t} style={{flex:1, borderTop:`2px solid ${C.cyan}`, paddingTop:14, color:"#d8f3f5", font:"700 18px Arial", letterSpacing:".08em", textAlign:"center"}}>{t}</div>)}
    </div>
  </>;
  if (scene === 4) return <>
    <DepthHUD depth="8.336 M" label="REKOR PENGAMATAN IKAN" />
    <SceneTitle kicker="BATAS KEHIDUPAN IKAN" title="IKAN PUNYA BATAS." detail="Snailfish tercatat sebagai ikan terdalam yang pernah diamati hidup." />
    <Fish frame={frame} scale={1}/>
    <div style={{ position:"absolute", top:1130, left:72, right:72, textAlign:"center" }}>
      <TextLine size={76} color={C.cyan}>8.336 METER</TextLine>
      <TextLine size={24} color="#c8e4e8" weight={500} style={{marginTop:14}}>Palung Izu-Ogasawara, dekat Jepang</TextLine>
      <TextLine size={21} color="#a8c4ca" weight={500} style={{marginTop:22}}>Bukan Challenger Deep</TextLine>
    </div>
  </>;
  return <>
    <SceneTitle kicker="MENJELAJAHI YANG BELUM DIKETAHUI" title="MASIH BANYAK YANG TERSEMBUNYI." detail="Robot bawah laut membantu ilmuwan mengamati lingkungan ekstrem ini." />
    <Submarine frame={frame} scale={.95}/>
    <div style={{ position:"absolute", top:1110, left:72, right:72 }}>
      <div style={{height:2, background:"rgba(119,220,231,.4)", marginBottom:20}}/>
      <TextLine size={30} color={C.cyan}>LAUTAN BELUM SEPENUHNYA TERPETAKAN</TextLine>
      <TextLine size={23} color="#c8e4e8" weight={500} style={{marginTop:15, lineHeight:1.35}}>Peta resolusi tinggi baru mencakup sebagian dasar laut. Setiap ekspedisi membuka petunjuk baru.</TextLine>
    </div>
    <div style={{position:"absolute", bottom:245, left:0, right:0, textAlign:"center"}}>
      <TextLine size={66}>RUANG NALAR</TextLine>
      <div style={{width:180, height:3, background:C.cyan, margin:"24px auto"}}/>
      <TextLine size={26} color={C.cyan} weight={500}>Pengetahuan membuka cakrawala</TextLine>
    </div>
  </>;
}

export const Edukasi: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sceneFrames = 450;
  const scene = Math.min(5, Math.floor(frame / sceneFrames));
  const localFrame = frame - scene * sceneFrames;
  const sceneOpacity = interpolate(localFrame, [0, 18, 340, 360], [0, 1, 1, 0], clamp);
  const progress = interpolate(frame, [0, 2700], [0, 100], clamp);
  return <AbsoluteFill style={{ backgroundColor: C.ink, overflow: "hidden" }}>
    <AbsoluteFill style={{ opacity: sceneOpacity }}>
      <DeepBackground frame={frame} tint={scene}/>
      <SceneContent scene={scene} frame={localFrame}/>
      {scene < 6 && <Subtitle scene={scene} frame={localFrame}/>}
    </AbsoluteFill>
    <div style={{position:"absolute", top:44, left:72, right:72, display:"flex", justifyContent:"space-between", alignItems:"center"}}>
      <div style={{color:"rgba(208,242,245,.7)", font:"700 17px Arial", letterSpacing:".2em"}}>RUANG NALAR</div>
      <div style={{color:"rgba(208,242,245,.55)", font:"600 15px Arial", letterSpacing:".14em"}}>OCEAN • EXPLORATION</div>
    </div>
    <div style={{position:"absolute", bottom:0, left:0, height:5, width:`${progress}%`, background:C.cyan, boxShadow:"0 0 18px rgba(101,217,232,.7)"}}/>
  </AbsoluteFill>;
};
