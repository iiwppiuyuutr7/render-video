# Ruang Nalar — Dasar Laut Terdalam

## Isi
- `Edukasi.tsx`: komposisi video animasi vertikal, termasuk subtitle Bahasa Indonesia.
- `Root.tsx`: registrasi komposisi Remotion 1080×1920, 60 FPS, 36 detik.

## Catatan teknis
Komposisi ini sengaja tidak menyertakan voice-over maupun musik, sesuai permintaan. Visual dibuat dengan SVG dan animasi berbasis frame sehingga tidak membutuhkan footage atau aset eksternal. Hasilnya adalah animasi dokumenter bergaya sinematik, bukan kumpulan gambar statis.

## Menjalankan
Salin kedua file ke proyek Remotion yang sudah memiliki dependensi `remotion` dan `react`.
Pastikan entry point proyek memanggil `registerRoot(RemotionRoot)` dari `Root.tsx` (sesuaikan `src/index.ts` sesuai struktur proyek).

Contoh perintah render:
`npx remotion render src/index.ts RuangNalar-DasarLautTerdalam out/ruang-nalar.mp4`

## Akurasi ilmiah
- Challenger Deep berada di Palung Mariana dan kedalamannya sekitar 10.935 m. Estimasi pengukuran ilmiah NOAA menyertakan ketidakpastian ±6 m.
- Zona hadal umumnya merujuk pada kedalaman lebih dari 6.000 m.
- Rekor pengamatan ikan hidup terdalam yang dikonfirmasi adalah snailfish pada 8.336 m di Palung Izu-Ogasawara, bukan di Challenger Deep.
- Kehidupan hadal yang diketahui mencakup amphipoda, teripang laut dalam, dan mikroorganisme. Sumber makanan dapat berasal dari bahan organik yang turun dari lapisan atas.

## Sumber ilmiah
1. NOAA Ocean Service — How deep is the ocean?
   https://oceanservice.noaa.gov/facts/oceandepth.html
2. NOAA repository — Revised depth of the Challenger Deep (10,935 m ± 6 m).
   https://repository.library.noaa.gov/view/noaa/33477
3. NOAA Ocean Exploration — What is the deepest-living fish?
   https://oceanexplorer.noaa.gov/ocean-fact/what-is-the-deepest-living-fish/
4. Natural History Museum — Deepest-ever fish filmed at 8,336 metres.
   https://www.nhm.ac.uk/discover/news/2023/april/deepest-ever-fish-filmed-depth-8336-metres.html

## Batasan
Visual makhluk dan kapal selam adalah ilustrasi animasi, bukan rekaman spesimen asli atau dokumentasi ekspedisi tertentu. Tidak ada klaim bahwa ilustrasi tersebut merupakan footage autentik.
