import React from "react";
import { Composition } from "remotion";
import { Edukasi } from "./Edukasi";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="RuangNalar-DasarLautTerdalam"
      component={Edukasi}
      durationInFrames={2700}
      fps={60}
      width={1080}
      height={1920}
    />
  );
};
