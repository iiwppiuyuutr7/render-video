import React from 'react';
import {Composition} from 'remotion';
import {Fosil} from './Fosil';

// 105 detik x 60 fps = 6300 frame, 1080x1920 (9:16)
export const RemotionRoot: React.FC = () => (
  <Composition id="Fosil" component={Fosil} durationInFrames={6300} fps={60} width={1080} height={1920} />
);
