// @ts-nocheck
import React, {useLayoutEffect, useRef} from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

/**
 * Video 3D "Bagaimana Ilmuwan Tahu Usia Fosil" - 1080x1920, 60 fps, 6300 frame.
 * 3D WebGL asli (engine sendiri, tanpa library tambahan) dalam satu file.
 * Semua dihitung dari nomor frame, jadi aman dirender Remotion.
 * Audio: public/audio.mp3 (narasi + SFX + musik, sudah dimix).
 */
function createEngine(outc) {
  const ENGINE = {};
'use strict';
/* Mesin 3D WebGL minimal (tanpa library). Dipakai untuk render video lewat Chromium. */
const CW = window.OUT_W || 1080, CH = window.OUT_H || 1920;
const glc = document.createElement('canvas'); glc.width = CW; glc.height = CH;
const gl = glc.getContext('webgl', {antialias: true, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: true, powerPreference: 'high-performance'});
outc.width = CW; outc.height = CH;
const ctx = outc.getContext('2d');
const SC = CH / 1920; // skala UI relatif ke desain 1080x1920

/* ---------- util ---------- */
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const lerp = (a, b, k) => a + (b - a) * k;
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const eio = (t) => (t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const eout = (t) => 1 - Math.pow(1 - clamp(t, 0, 1), 3);
const ein = (t) => Math.pow(clamp(t, 0, 1), 3);
const eoutB = (t) => { t = clamp(t, 0, 1); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const ramp = (t, a, b) => clamp((t - a) / (b - a), 0, 1);
const win = (t, a, b, f = .3) => clamp((t - a) / f, 0, 1) * clamp((b - t) / f, 0, 1);
function hash(n) { n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n = Math.imul(n ^ (n >>> 16), 0x45d9f3b); n ^= n >>> 16; return (n >>> 0) / 4294967296; }
const R = (i, s = 0) => hash((i * 7919 + s * 104729) | 0);
function noise2(x, y, s = 0) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const a = R(xi * 73856093 ^ yi * 19349663, s), b = R((xi + 1) * 73856093 ^ yi * 19349663, s), c = R(xi * 73856093 ^ (yi + 1) * 19349663, s), d = R((xi + 1) * 73856093 ^ (yi + 1) * 19349663, s);
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}
const fbm = (x, y, s = 0) => noise2(x, y, s) * .55 + noise2(x * 2.1, y * 2.1, s + 1) * .28 + noise2(x * 4.3, y * 4.3, s + 2) * .17;
const hexc = (h) => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
const mixc = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const scl = (a, k) => [a[0] * k, a[1] * k, a[2] * k];

/* ---------- vektor & matriks ---------- */
const vadd = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const vsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const vmul = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
const vdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const vcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const vlen = (a) => Math.hypot(a[0], a[1], a[2]);
const vnorm = (a) => { const l = vlen(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
const vlerp = (a, b, k) => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
const ident = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
function mmul(a, b) { const o = new Float32Array(16); for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + r] * b[c * 4 + k]; o[c * 4 + r] = s; } return o; }
const mT = (x, y, z) => { const m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; };
const mS = (x, y = x, z = x) => { const m = ident(); m[0] = x; m[5] = y; m[10] = z; return m; };
const mRx = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; };
const mRy = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; };
const mRz = (a) => { const m = ident(), c = Math.cos(a), s = Math.sin(a); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; };
function mPersp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), m = new Float32Array(16); m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m; }
function mLook(e, t, up) { const z = vnorm(vsub(e, t)), x = vnorm(vcross(up, z)), y = vcross(z, x); const m = ident(); m[0] = x[0]; m[4] = x[1]; m[8] = x[2]; m[1] = y[0]; m[5] = y[1]; m[9] = y[2]; m[2] = z[0]; m[6] = z[1]; m[10] = z[2]; m[12] = -vdot(x, e); m[13] = -vdot(y, e); m[14] = -vdot(z, e); return m; }
function mApply(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; }
function mApplyN(m, n) { return vnorm([m[0] * n[0] + m[4] * n[1] + m[8] * n[2], m[1] * n[0] + m[5] * n[1] + m[9] * n[2], m[2] * n[0] + m[6] * n[1] + m[10] * n[2]]); }
function normalMat(m) { // inverse transpose 3x3
  const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
  const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
  const det = a * A + b * B + c * C || 1;
  return new Float32Array([A / det, B / det, C / det, -(b * i - c * h) / det, (a * i - c * g) / det, -(a * h - b * g) / det, (b * f - c * e) / det, -(a * f - c * d) / det, (a * e - b * d) / det]);
}
const TRS = (p, r = [0, 0, 0], s = [1, 1, 1]) => mmul(mT(p[0], p[1], p[2]), mmul(mRy(r[1]), mmul(mRx(r[0]), mmul(mRz(r[2]), mS(s[0], s[1], s[2])))));

/* ---------- mesh builder ---------- */
class B {
  constructor() { this.p = []; this.n = []; this.c = []; this.m = ident(); this.st = []; }
  push() { this.st.push(this.m); return this; }
  pop() { this.m = this.st.pop(); return this; }
  T(x, y, z) { this.m = mmul(this.m, mT(x, y, z)); return this; }
  S(x, y, z) { this.m = mmul(this.m, mS(x, y === undefined ? x : y, z === undefined ? x : z)); return this; }
  Rx(a) { this.m = mmul(this.m, mRx(a)); return this; }
  Ry(a) { this.m = mmul(this.m, mRy(a)); return this; }
  Rz(a) { this.m = mmul(this.m, mRz(a)); return this; }
  v(p, n, c) { const q = mApply(this.m, p), nn = mApplyN(this.m, n); this.p.push(q[0], q[1], q[2]); this.n.push(nn[0], nn[1], nn[2]); this.c.push(c[0], c[1], c[2]); }
  tri(a, b, c, ca, cb = ca, cc = ca, n) { n = n || vnorm(vcross(vsub(b, a), vsub(c, a))); this.v(a, n, ca); this.v(b, n, cb); this.v(c, n, cc); }
  quad(a, b, c, d, ca, cb = ca, cc = ca, cd = ca) { const n = vnorm(vcross(vsub(b, a), vsub(d, a))); this.tri(a, b, c, ca, cb, cc, n); this.tri(a, c, d, ca, cc, cd, n); }
  build() { return mkMesh(this.p, this.n, this.c); }
}
function mkMesh(p, n, c) {
  const mk = (arr) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.STATIC_DRAW); return b; };
  return {bp: mk(p), bn: mk(n), bc: mk(c), count: p.length / 3};
}
function box(b, x, y, z, sx, sy, sz, col, jit = 0, seed = 0) {
  const hx = sx / 2, hy = sy / 2, hz = sz / 2;
  const P = [[x - hx, y - hy, z - hz], [x + hx, y - hy, z - hz], [x + hx, y + hy, z - hz], [x - hx, y + hy, z - hz], [x - hx, y - hy, z + hz], [x + hx, y - hy, z + hz], [x + hx, y + hy, z + hz], [x - hx, y + hy, z + hz]];
  const F = [[4, 5, 6, 7], [1, 0, 3, 2], [5, 1, 2, 6], [0, 4, 7, 3], [7, 6, 2, 3], [0, 1, 5, 4]];
  F.forEach((f, i) => { const k = 1 + (R(i + seed * 13, seed) - .5) * jit; const cc = scl(col, k); b.quad(P[f[0]], P[f[1]], P[f[2]], P[f[3]], cc); });
}
function cyl(b, p0, p1, r0, r1, seg, col, caps = true, col1) {
  const ax = vsub(p1, p0), L = vlen(ax); if (L < 1e-6) return;
  const a = vnorm(ax); const t = Math.abs(a[1]) < .9 ? [0, 1, 0] : [1, 0, 0];
  const u = vnorm(vcross(a, t)), v = vcross(a, u); col1 = col1 || col;
  const dir = (i) => vadd(vmul(u, Math.cos(i / seg * 6.2832)), vmul(v, Math.sin(i / seg * 6.2832)));
  const sl = (r0 - r1) / L;
  for (let i = 0; i < seg; i++) {
    const d0 = dir(i), d1 = dir(i + 1);
    const a0 = vadd(p0, vmul(d0, r0)), a1 = vadd(p0, vmul(d1, r0)), b0 = vadd(p1, vmul(d0, r1)), b1 = vadd(p1, vmul(d1, r1));
    const n0 = vnorm(vadd(d0, vmul(a, sl))), n1 = vnorm(vadd(d1, vmul(a, sl)));
    b.v(a0, n0, col); b.v(a1, n1, col); b.v(b1, n1, col1);
    b.v(a0, n0, col); b.v(b1, n1, col1); b.v(b0, n0, col1);
    if (caps) {
      if (r1 > 0) { b.v(p1, a, col1); b.v(b0, a, col1); b.v(b1, a, col1); }
      if (r0 > 0) { const na = vmul(a, -1); b.v(p0, na, col); b.v(a1, na, col); b.v(a0, na, col); }
    }
  }
}
function sphere(b, c, r, col, lat = 10, lon = 14, sy = 1) {
  for (let i = 0; i < lat; i++) {
    const t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
    for (let j = 0; j < lon; j++) {
      const p0 = 6.2832 * j / lon, p1 = 6.2832 * (j + 1) / lon;
      const P = (t, p) => [Math.sin(t) * Math.cos(p), Math.cos(t), Math.sin(t) * Math.sin(p)];
      const A = P(t0, p0), Bq = P(t0, p1), C = P(t1, p1), D = P(t1, p0);
      const pt = (n) => [c[0] + n[0] * r, c[1] + n[1] * r * sy, c[2] + n[2] * r];
      b.v(pt(A), A, col); b.v(pt(D), D, col); b.v(pt(C), C, col);
      b.v(pt(A), A, col); b.v(pt(C), C, col); b.v(pt(Bq), Bq, col);
    }
  }
}
function torus(b, R0, r0, segs, sides, col) {
  const P = (i, j) => { const u = 6.2832 * i / segs, v = 6.2832 * j / sides; const cx = Math.cos(u) * R0, cy = Math.sin(u) * R0; const nx = Math.cos(u) * Math.cos(v), ny = Math.sin(u) * Math.cos(v), nz = Math.sin(v); return [[cx + nx * r0, cy + ny * r0, nz * r0], [nx, ny, nz]]; };
  for (let i = 0; i < segs; i++) for (let j = 0; j < sides; j++) {
    const a = P(i, j), c = P(i + 1, j), d = P(i + 1, j + 1), e = P(i, j + 1);
    b.v(a[0], a[1], col); b.v(c[0], c[1], col); b.v(d[0], d[1], col); b.v(a[0], a[1], col); b.v(d[0], d[1], col); b.v(e[0], e[1], col);
  }
}
// permukaan grid dengan warna per-vertex bergoyang (tekstur batu murah)
function grid(b, o, u, v, nu, nv, col, jit, seed, flip) {
  const n = vnorm(vcross(u, v)); const nn = flip ? vmul(n, -1) : n;
  const P = (i, j) => vadd(o, vadd(vmul(u, i / nu), vmul(v, j / nv)));
  const C = (i, j) => scl(col, 1 + (fbm(i * .55 + seed, j * .9 + seed * 3, seed) - .5) * jit * 2 + (R(i * 131 + j * 17 + seed, seed) - .5) * jit * .5);
  for (let i = 0; i < nu; i++) for (let j = 0; j < nv; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), d = P(i, j + 1);
    const ca = C(i, j), cb = C(i + 1, j), cc = C(i + 1, j + 1), cd = C(i, j + 1);
    if (!flip) { b.v(a, nn, ca); b.v(bb, nn, cb); b.v(c, nn, cc); b.v(a, nn, ca); b.v(c, nn, cc); b.v(d, nn, cd); }
    else { b.v(a, nn, ca); b.v(c, nn, cc); b.v(bb, nn, cb); b.v(a, nn, ca); b.v(d, nn, cd); b.v(c, nn, cc); }
  }
}
function hfield(b, x0, z0, w, d, nx, nz, fh, fc) {
  const H_ = (i, j) => fh(x0 + w * i / nx, z0 + d * j / nz);
  const P = (i, j) => [x0 + w * i / nx, H_(i, j), z0 + d * j / nz];
  const N = (i, j) => { const e = .5; const hx = fh(x0 + w * i / nx + e, z0 + d * j / nz) - fh(x0 + w * i / nx - e, z0 + d * j / nz); const hz = fh(x0 + w * i / nx, z0 + d * j / nz + e) - fh(x0 + w * i / nx, z0 + d * j / nz - e); return vnorm([-hx / (2 * e), 1, -hz / (2 * e)]); };
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const a = P(i, j), bb = P(i + 1, j), c = P(i + 1, j + 1), dd = P(i, j + 1);
    const na = N(i, j), nb = N(i + 1, j), nc = N(i + 1, j + 1), nd = N(i, j + 1);
    b.v(a, na, fc(a)); b.v(c, nc, fc(c)); b.v(bb, nb, fc(bb)); b.v(a, na, fc(a)); b.v(dd, nd, fc(dd)); b.v(c, nc, fc(c));
  }
}

/* ---------- shader ---------- */
function prog(vs, fs) {
  const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
  const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const inf = gl.getActiveUniform(p, i); u[inf.name] = gl.getUniformLocation(p, inf.name); }
  return {p, u};
}
const MESH = prog(`
attribute vec3 aP; attribute vec3 aN; attribute vec3 aC;
uniform mat4 uVP; uniform mat4 uM; uniform mat3 uNM;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
void main(){ vec4 w=uM*vec4(aP,1.0); vW=w.xyz; vN=normalize(uNM*aN); vC=aC; gl_Position=uVP*w; }`, `
precision highp float;
varying vec3 vN; varying vec3 vC; varying vec3 vW;
uniform vec3 uLD; uniform vec3 uLC; uniform vec3 uAT; uniform vec3 uAB; uniform vec3 uCam; uniform vec3 uFog; uniform float uFD;
uniform vec3 uTint; uniform float uEm; uniform float uAl; uniform float uSp; uniform float uRim; uniform vec3 uRC; uniform vec3 uL2D; uniform vec3 uL2C; uniform float uClip;
void main(){
  if(uClip>-900.0 && vW.y>uClip) discard;
  vec3 n=normalize(vN); vec3 v=normalize(uCam-vW);
  float d=max(dot(n,-uLD),0.0); float d2=max(dot(n,-uL2D),0.0);
  vec3 hemi=mix(uAB,uAT,n.y*0.5+0.5);
  vec3 base=vC*uTint;
  vec3 h=normalize(v-uLD); float s=pow(max(dot(n,h),0.0),28.0)*uSp;
  float rim=pow(1.0-max(dot(n,v),0.0),3.0)*uRim;
  vec3 col=base*(hemi+uLC*d+uL2C*d2)+uLC*s+uRC*rim+base*uEm;
  float dist=length(uCam-vW); float f=1.0-exp(-dist*uFD*0.12-dist*dist*uFD*0.004);
  col=mix(col,uFog,clamp(f,0.0,1.0));
  gl_FragColor=vec4(col,uAl);
}`);
const PART = prog(`
attribute vec3 aP; attribute vec2 aU; attribute vec4 aC; attribute float aS;
uniform mat4 uVP; varying vec2 vU; varying vec4 vC; varying float vS;
void main(){ vU=aU; vC=aC; vS=aS; gl_Position=uVP*vec4(aP,1.0); }`, `
precision highp float;
varying vec2 vU; varying vec4 vC; varying float vS;
void main(){
  float a;
  if(vS<0.5){ float r=length(vU); a=smoothstep(1.0,0.0,r); a=a*a*(3.0-2.0*a); }
  else if(vS<1.5){ float r=length(vU); a=smoothstep(1.0,0.78,r)*smoothstep(0.0,0.15,r+0.0); a=min(1.0,a)*(1.0-0.45*smoothstep(0.5,1.0,r)); }
  else { a=smoothstep(1.0,0.0,abs(vU.x)); a=a*a; a*=smoothstep(1.0,0.85,abs(vU.y)); }
  gl_FragColor=vec4(vC.rgb*vC.a*a, vC.a*a);
}`);
function attr(p, name, buf, size) { const l = gl.getAttribLocation(p, name); if (l < 0) return; gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0); }

/* ---------- scene state ---------- */
const LT = {ld: vnorm([-.4, -.8, -.45]), lc: [1, .95, .85], at: [.35, .38, .45], ab: [.12, .1, .1], fog: [.03, .03, .05], fd: .02, rc: [.2, .3, .5], l2d: [.5, -.2, .6], l2c: [0, 0, 0], clip: -1000};
const CAM = {eye: [0, 3, 10], tgt: [0, 1, 0], fov: 50, roll: 0, up: [0, 1, 0]};
let VP = ident(), VIEW = ident(), PRJ = ident(), CR = [1, 0, 0], CU = [0, 1, 0], CF = [0, 0, -1];
function setCam() {
  const e = CAM.eye, t = CAM.tgt;
  let up = CAM.up; if (CAM.roll) { const f = vnorm(vsub(t, e)); const r = vnorm(vcross(f, [0, 1, 0])); up = vadd(vmul([0, 1, 0], Math.cos(CAM.roll)), vmul(r, Math.sin(CAM.roll))); }
  VIEW = mLook(e, t, up); PRJ = mPersp(CAM.fov * Math.PI / 180, CW / CH, .1, 600); VP = mmul(PRJ, VIEW);
  CF = vnorm(vsub(t, e)); CR = vnorm(vcross(CF, up)); CU = vcross(CR, CF);
}
function useMesh() { gl.useProgram(MESH.p); const u = MESH.u; gl.uniformMatrix4fv(u.uVP, false, VP); gl.uniform3fv(u.uLD, LT.ld); gl.uniform3fv(u.uLC, LT.lc); gl.uniform3fv(u.uAT, LT.at); gl.uniform3fv(u.uAB, LT.ab); gl.uniform3fv(u.uCam, CAM.eye); gl.uniform3fv(u.uFog, LT.fog); gl.uniform1f(u.uFD, LT.fd); gl.uniform3fv(u.uRC, LT.rc); gl.uniform3fv(u.uL2D, LT.l2d); gl.uniform3fv(u.uL2C, LT.l2c); }
function draw(mesh, M, o = {}) {
  const u = MESH.u; if (!mesh || !mesh.count) return;
  gl.uniformMatrix4fv(u.uM, false, M || ident()); gl.uniformMatrix3fv(u.uNM, false, normalMat(M || ident()));
  gl.uniform3fv(u.uTint, o.tint || [1, 1, 1]); gl.uniform1f(u.uEm, o.em || 0); gl.uniform1f(u.uAl, o.al === undefined ? 1 : o.al); gl.uniform1f(u.uSp, o.sp === undefined ? .15 : o.sp); gl.uniform1f(u.uRim, o.rim === undefined ? .25 : o.rim);
  gl.uniform1f(u.uClip, o.clip === undefined ? LT.clip : o.clip);
  attr(MESH.p, 'aP', mesh.bp, 3); attr(MESH.p, 'aN', mesh.bn, 3); attr(MESH.p, 'aC', mesh.bc, 3);
  if (o.al !== undefined && o.al < 1) { gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(o.dw === true); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
  gl.drawArrays(gl.TRIANGLES, 0, mesh.count);
}
/* partikel / billboard */
const PB = {add: [], alp: []};
function pt(list, p, size, col, a = 1, shape = 0) { // lingkaran billboard
  const r = vmul(CR, size), u = vmul(CU, size);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(vsub(p, r), u), Bq = vsub(vadd(p, r), u), C_ = vadd(vadd(p, r), u), D = vadd(vsub(p, r), u);
  list.push([A, -1, -1, c, shape], [Bq, 1, -1, c, shape], [C_, 1, 1, c, shape], [A, -1, -1, c, shape], [C_, 1, 1, c, shape], [D, -1, 1, c, shape]);
}
function beam(list, p0, p1, w, col, a = 1) {
  const d = vsub(p1, p0), mid = vmul(vadd(p0, p1), .5); const toC = vsub(CAM.eye, mid); let s = vcross(d, toC); s = vnorm(s); s = vmul(s, w);
  const c = [col[0], col[1], col[2], a];
  const A = vsub(p0, s), Bq = vadd(p0, s), C_ = vadd(p1, s), D = vsub(p1, s);
  list.push([A, -1, -1, c, 2], [Bq, 1, -1, c, 2], [C_, 1, 1, c, 2], [A, -1, -1, c, 2], [C_, 1, 1, c, 2], [D, -1, 1, c, 2]);
}
const pbuf = {p: gl.createBuffer(), u: gl.createBuffer(), c: gl.createBuffer(), s: gl.createBuffer()};
function flushList(list, additive) {
  if (!list.length) return;
  const P = new Float32Array(list.length * 3), U = new Float32Array(list.length * 2), Cc = new Float32Array(list.length * 4), S = new Float32Array(list.length);
  list.forEach((v, i) => { P[i * 3] = v[0][0]; P[i * 3 + 1] = v[0][1]; P[i * 3 + 2] = v[0][2]; U[i * 2] = v[1]; U[i * 2 + 1] = v[2]; Cc.set(v[3], i * 4); S[i] = v[4]; });
  gl.useProgram(PART.p); gl.uniformMatrix4fv(PART.u.uVP, false, VP);
  const up = (b, d) => { gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, d, gl.DYNAMIC_DRAW); };
  up(pbuf.p, P); attr(PART.p, 'aP', pbuf.p, 3); up(pbuf.u, U); attr(PART.p, 'aU', pbuf.u, 2); up(pbuf.c, Cc); attr(PART.p, 'aC', pbuf.c, 4); up(pbuf.s, S); attr(PART.p, 'aS', pbuf.s, 1);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
  gl.drawArrays(gl.TRIANGLES, 0, list.length); gl.depthMask(true);
  list.length = 0;
}
function flushParticles() { flushList(PB.alp, false); flushList(PB.add, true); }
function beginFrame() { gl.viewport(0, 0, CW, CH); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.disable(gl.CULL_FACE); setCam(); useMesh(); }
function proj(p) { // dunia -> layar (px output)
  const c = mApply(VIEW, p); const w = -c[2]; if (w < .05) return {x: 0, y: 0, z: w, vis: false, s: 0};
  const t = 1 / Math.tan(CAM.fov * Math.PI / 360);
  const x = (c[0] * t / (CW / CH)) / w, y = (c[1] * t) / w;
  return {x: (x * .5 + .5) * CW, y: (1 - (y * .5 + .5)) * CH, z: w, vis: Math.abs(x) < 1.3 && Math.abs(y) < 1.3, s: (CH / 2) * t / w};
}

'use strict';
/* Model prosedural: rangka T-rex, strata, gunung berapi, bumi, kristal, amonit */
const BONE = hexc('#eadfc3'), BONE_D = hexc('#cdbf9c'), DARK = hexc('#201812');
function crPt(P, u) { // Catmull-Rom 2D
  const n = P.length - 1; u = clamp(u, 0, n - 1e-6); const i = Math.floor(u), f = u - i;
  const p0 = P[Math.max(0, i - 1)], p1 = P[i], p2 = P[i + 1], p3 = P[Math.min(n, i + 2)];
  const f2 = f * f, f3 = f2 * f;
  return [0, 1].map((k) => .5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * f + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * f2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * f3));
}
function buildTRex(col = BONE) {
  const b = new B(); const j = (k, s) => scl(col, 1 + (R(s, 3) - .5) * .16 * k);
  const SP = [[-7.6, 1.5], [-5.9, 2.05], [-4.3, 2.65], [-2.7, 3.25], [-1.3, 3.65], [.1, 3.75], [1.5, 3.8], [2.8, 4.15], [3.8, 4.7], [4.6, 5.2], [5.15, 5.35]];
  const NV = 56; const pts2 = [];
  for (let i = 0; i < NV; i++) {
    const u = (i / (NV - 1)) * (SP.length - 1); const p = crPt(SP, u), q = crPt(SP, Math.min(u + .05, SP.length - 1.001)); const ang = Math.atan2(q[1] - p[1], q[0] - p[0]);
    const k = i / (NV - 1); // 0 ekor ... 1 leher
    const sz = k < .5 ? lerp(.13, .42, k / .5) : k < .78 ? .42 : lerp(.42, .3, (k - .78) / .22);
    pts2.push({p, ang, sz, k});
    b.push(); b.T(p[0], p[1], 0); b.Rz(ang); box(b, 0, 0, 0, sz * 1.15, sz * .95, sz * .95, j(1, i)); b.pop();
    // prosesus neural
    const nh = (k < .5 ? lerp(.15, .55, k / .5) : k < .78 ? .55 : .3);
    b.push(); b.T(p[0], p[1], 0); b.Rz(ang); box(b, 0, sz * .5 + nh / 2, 0, sz * .22, nh, sz * .16, j(1, i + 100)); b.pop();
    if (k > .1 && k < .8) { b.push(); b.T(p[0], p[1], 0); b.Rz(ang); box(b, 0, 0, 0, sz * .2, sz * .18, sz * 1.5, j(1, i + 200)); b.pop(); }
  }
  // tulang rusuk
  for (let r = 0; r < 13; r++) {
    const u = lerp(.48, .83, r / 12) * (SP.length - 1), p = crPt(SP, u); const sizeF = Math.sin(Math.PI * (.12 + .8 * r / 12));
    for (const s of [-1, 1]) {
      let prev = null; const Rz = (.55 + .55 * sizeF) * 1.05, Ry = 1.0 + .65 * sizeF;
      for (let t = 0; t <= 9; t++) {
        const th = .12 + t / 9 * 2.55; const cur = [p[0] + t * .012, p[1] - .15 - Ry * (1 - Math.cos(th)) * .55, s * Rz * Math.sin(th)];
        if (prev) cyl(b, prev, cur, .06 * (1 - t / 14), .055 * (1 - (t + 1) / 14), 5, j(1, r * 30 + t), false);
        prev = cur;
      }
    }
  }
  // panggul + kaki
  for (const s of [-1, 1]) {
    box(b, -1.2, 3.75, s * .5, 1.7, .5, .22, j(1, 301)); box(b, -.5, 3.55, s * .5, .9, .4, .2, j(1, 302));
    cyl(b, [-.6, 3.3, s * .5], [.25, 2.3, s * .52], .12, .08, 6, j(1, 303)); cyl(b, [-1.4, 3.3, s * .5], [-2.2, 2.5, s * .5], .1, .06, 6, j(1, 304));
    const hip = [-1.0, 3.35, s * .72], knee = [.45, 2.0, s * .8], ank = [-.55, .6, s * .74], mt = [.15, .18, s * .74];
    cyl(b, hip, knee, .22, .16, 8, j(1, 305)); sphere(b, knee, .2, j(1, 306), 6, 8); cyl(b, knee, ank, .16, .1, 8, j(1, 307)); sphere(b, ank, .14, j(1, 308), 6, 8); cyl(b, ank, mt, .1, .09, 7, j(1, 309));
    for (let t = -1; t <= 1; t++) { const tip = [1.15, .08, s * .74 + t * .26]; cyl(b, [.15, .16, s * .74 + t * .09], tip, .08, .06, 6, j(1, 310 + t)); cyl(b, tip, [1.4, .06, tip[2]], .06, 0, 6, DARK.map((x) => x * 1.6)); }
    cyl(b, [2.35, 3.55, s * .5], [2.95, 2.75, s * .52], .1, .07, 6, j(1, 320)); cyl(b, [2.95, 2.75, s * .52], [3.35, 2.45, s * .5], .07, .05, 6, j(1, 321)); cyl(b, [3.35, 2.45, s * .5], [3.55, 2.25, s * .5], .05, 0, 5, j(1, 322));
  }
  // tengkorak
  b.push(); b.T(5.7, 5.35, 0); b.Rz(-.1);
  box(b, 0, .05, 0, 1.4, 1.0, .82, j(1, 400)); box(b, 1.25, -.05, 0, 1.5, .6, .6, j(1, 401)); box(b, 2.15, -.12, 0, .6, .45, .5, j(1, 402));
  box(b, .05, -.55, 0, 1.25, .1, .78, BONE_D); box(b, .1, .15, 0, .26, .26, .86, DARK); box(b, 2.4, .02, 0, .1, .12, .52, DARK);
  box(b, -.2, .4, 0, .8, .18, .66, j(1, 403));
  for (const s of [-1, 1]) { box(b, .35, -.05, s * .41, .5, .7, .06, BONE_D); box(b, 1.2, .15, s * .3, 1.4, .08, .06, BONE_D); }
  b.pop();
  b.push(); b.T(6.1, 4.95, 0); b.Rz(.06 - .12);
  box(b, .9, 0, 0, 2.4, .28, .5, j(1, 410)); box(b, 2.0, .05, 0, .5, .24, .42, j(1, 411));
  b.pop();
  for (let t = 0; t < 9; t++) for (const s of [-1, 1]) {
    const x = 6.5 + t * .2; const y = 5.0; cyl(b, [x, y, s * .26], [x + .03, y - .26 - (t % 3) * .03, s * .26], .05, 0, 5, hexc('#f5efdc'));
    cyl(b, [x - .15, 4.95, s * .2], [x - .12, 4.95 + .22, s * .2], .045, 0, 5, hexc('#f5efdc'));
  }
  return b.build();
}
function buildLayer(w, d, h, col, seed, topLumps = false) {
  const b = new B(); const c = hexc(col);
  const nu = Math.max(8, Math.round(w * 4)), nv = Math.max(3, Math.round(h * 5));
  grid(b, [-w / 2, 0, d / 2], [w, 0, 0], [0, h, 0], nu, nv, c, .2, seed); // depan
  grid(b, [-w / 2, 0, -d / 2], [w, 0, 0], [0, h, 0], nu, nv, scl(c, .8), .2, seed + 1, true);
  grid(b, [w / 2, 0, d / 2], [0, 0, -d], [0, h, 0], 10, nv, scl(c, .78), .2, seed + 2);
  grid(b, [-w / 2, 0, -d / 2], [0, 0, d], [0, h, 0], 10, nv, scl(c, .78), .2, seed + 3);
  grid(b, [-w / 2, h, d / 2], [w, 0, 0], [0, 0, -d], nu, 10, scl(c, 1.12), .25, seed + 4);
  // pita warna tipis (lamina sedimen)
  for (let k = 1; k < Math.round(h * 4); k++) { const y = h * k / Math.round(h * 4) + (R(k, seed) - .5) * .03; box(b, 0, y, d / 2 + .006, w, .018 + R(k + 9, seed) * .02, .012, scl(c, .7 + R(k, seed + 5) * .5)); }
  return b.build();
}
function buildVolcano() {
  const b = new B();
  const fh = (x, z) => { const r = Math.hypot(x, z); let h = 7.2 * Math.exp(-r * r / 14) + 1.2 * Math.exp(-r * r / 60) * .6; h -= 1.55 * Math.exp(-r * r / .7); h += (fbm(x * .5 + 7, z * .5 + 3, 4) - .5) * 1.2 * Math.min(1, r / 3); return Math.max(h, -.1); };
  const fc = (p) => { const r = Math.hypot(p[0], p[2]); const th = Math.atan2(p[2], p[0]); let c = mixc(hexc('#3b302b'), hexc('#6b5a4c'), clamp(p[1] / 6, 0, 1) * .8 + fbm(p[0] * .6, p[2] * .6, 8) * .4); c = mixc(c, hexc('#8b7a60'), clamp(1 - p[1] / 2, 0, 1) * .6);
    for (let k = 0; k < 5; k++) { const a = k * 1.2566 + .4 + Math.sin(r * 1.3 + k) * .08; const dth = Math.abs(((th - a + Math.PI * 3) % 6.2832) - Math.PI); if (dth < .1 && r < 6.2 && r > .5) c = mixc(c, hexc('#ff7a1a'), 1 - dth / .1); }
    if (r < 1.4) c = mixc(c, hexc('#ff9a2a'), clamp(1.4 - r, 0, 1)); return c; };
  hfield(b, -16, -16, 32, 32, 64, 64, fh, fc);
  return {mesh: b.build(), fh};
}
function buildEarth(r = 1) {
  const b = new B(); const lat = 30, lon = 48;
  const cf = (lt, ln) => { const x = Math.cos(lt) * Math.cos(ln), y = Math.sin(lt), z = Math.cos(lt) * Math.sin(ln); const n = fbm(x * 2.2 + 5, z * 2.2 + y * 2, 12); const polar = Math.abs(y) > .86; if (polar) return hexc('#eaf2f8'); return n > .52 ? mixc(hexc('#3f8f4a'), hexc('#b89a5a'), clamp((n - .52) * 4, 0, 1)) : mixc(hexc('#123f8a'), hexc('#1f6fc4'), n * 1.4); };
  for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) {
    const t0 = -Math.PI / 2 + Math.PI * i / lat, t1 = -Math.PI / 2 + Math.PI * (i + 1) / lat, p0 = 6.2832 * j / lon, p1 = 6.2832 * (j + 1) / lon;
    const P = (t, p) => [Math.cos(t) * Math.cos(p), Math.sin(t), Math.cos(t) * Math.sin(p)];
    const A = P(t0, p0), Bq = P(t0, p1), C_ = P(t1, p1), D = P(t1, p0);
    const q = (n) => vmul(n, r); const cA = cf(t0, p0), cB = cf(t0, p1), cC = cf(t1, p1), cD = cf(t1, p0);
    b.v(q(A), A, cA); b.v(q(Bq), Bq, cB); b.v(q(C_), C_, cC); b.v(q(A), A, cA); b.v(q(C_), C_, cC); b.v(q(D), D, cD);
  }
  return b.build();
}
function buildCrystal() {
  const b = new B(); const c = hexc('#ffb347'), c2 = hexc('#ffd68a');
  cyl(b, [0, -1, 0], [0, 1, 0], .5, .5, 6, c, false); cyl(b, [0, 1, 0], [0, 1.7, 0], .5, 0, 6, c2, false); cyl(b, [0, -1, 0], [0, -1.6, 0], .5, 0, 6, c2, false);
  return b.build();
}
function buildAmmonite() {
  const b = new B(); const col = hexc('#d9c08a');
  let prev = null;
  for (let i = 0; i <= 60; i++) { const t = i / 60 * 3.2 * Math.PI * 2 * .5; const rr = .06 * Math.exp(.18 * t); const p = [Math.cos(t) * rr * 3, Math.sin(t) * rr * 3, 0]; const sz = rr * 1.1; if (prev) cyl(b, prev.p, p, prev.s, sz, 7, scl(col, .85 + .3 * ((i % 4) / 4))); prev = {p, s: sz}; }
  return b.build();
}
function buildLayerIcon() { const b = new B(); const cs = ['#7a5a3c', '#b08a58', '#c9a56a', '#8c8f7a']; cs.forEach((c, i) => box(b, 0, i * .42, 0, 2, .38, 1.3, hexc(c))); return b.build(); }
function buildPlinth() { const b = new B(); box(b, 0, -.4, 0, 12, .8, 6.5, hexc('#2a2420')); box(b, 0, .02, 0, 11.4, .08, 5.9, hexc('#3a322b')); return b.build(); }
function buildGround(w, d, c1, c2, y = 0, seed = 1) { const b = new B(); hfield(b, -w / 2, -d / 2, w, d, 48, 48, (x, z) => y + (fbm(x * .22, z * .22, seed) - .5) * 1.2, (p) => mixc(hexc(c1), hexc(c2), fbm(p[0] * .3, p[2] * .3, seed + 2))); return b.build(); }

const WORDS=[{"w": "Tidak", "a": 0.05, "e": 0.309, "b": null}, {"w": "ada", "a": 0.309, "e": 0.568, "b": null}, {"w": "manusia", "a": 0.568, "e": 1.085, "b": null}, {"w": "yang", "a": 1.085, "e": 1.215, "b": null}, {"w": "melihat", "a": 1.215, "e": 1.603, "b": null}, {"w": "dinosaurus", "a": 1.603, "e": 2.121, "b": null}, {"w": "hidup.", "a": 2.121, "e": 2.38, "b": "strong"}, {"w": "Lalu", "a": 3.043, "e": 3.354, "b": null}, {"w": "bagaimana", "a": 3.354, "e": 3.976, "b": null}, {"w": "ilmuwan", "a": 3.976, "e": 4.443, "b": null}, {"w": "tahu", "a": 4.443, "e": 4.754, "b": null}, {"w": "usia", "a": 4.754, "e": 5.22, "b": null}, {"w": "fosil", "a": 5.22, "e": 5.531, "b": null}, {"w": "jutaan", "a": 5.531, "e": 5.998, "b": null}, {"w": "tahun?", "a": 5.998, "e": 6.309, "b": "strong"}, {"w": "Jawabannya", "a": 6.876, "e": 7.666, "b": null}, {"w": "ada", "a": 7.666, "e": 8.061, "b": null}, {"w": "di", "a": 8.061, "e": 8.259, "b": null}, {"w": "lapisan", "a": 8.259, "e": 8.851, "b": null}, {"w": "tanah.", "a": 8.851, "e": 9.247, "b": "strong"}, {"w": "Fosil", "a": 9.725, "e": 10.101, "b": null}, {"w": "terkubur", "a": 10.101, "e": 10.664, "b": null}, {"w": "di", "a": 10.664, "e": 10.852, "b": null}, {"w": "batuan", "a": 10.852, "e": 11.415, "b": null}, {"w": "sedimen", "a": 11.415, "e": 11.979, "b": null}, {"w": "yang", "a": 11.979, "e": 12.167, "b": null}, {"w": "menumpuk", "a": 12.167, "e": 12.73, "b": null}, {"w": "lapis", "a": 12.73, "e": 13.106, "b": null}, {"w": "demi", "a": 13.106, "e": 13.482, "b": null}, {"w": "lapis.", "a": 13.482, "e": 13.857, "b": "strong"}, {"w": "Lapisan", "a": 14.252, "e": 14.725, "b": null}, {"w": "paling", "a": 14.725, "e": 15.04, "b": null}, {"w": "bawah", "a": 15.04, "e": 15.355, "b": null}, {"w": "terbentuk", "a": 15.355, "e": 15.829, "b": null}, {"w": "lebih", "a": 15.829, "e": 16.144, "b": null}, {"w": "dulu,", "a": 16.144, "e": 16.46, "b": "weak"}, {"w": "jadi", "a": 16.772, "e": 17.072, "b": null}, {"w": "lebih", "a": 17.072, "e": 17.372, "b": null}, {"w": "tua", "a": 17.372, "e": 17.672, "b": null}, {"w": "dari", "a": 17.672, "e": 17.972, "b": null}, {"w": "lapisan", "a": 17.972, "e": 18.423, "b": null}, {"w": "di", "a": 18.423, "e": 18.573, "b": null}, {"w": "atasnya.", "a": 18.573, "e": 19.023, "b": "strong"}, {"w": "Itu", "a": 19.497, "e": 19.875, "b": null}, {"w": "prinsip", "a": 19.875, "e": 20.254, "b": null}, {"w": "superposisi.", "a": 20.254, "e": 21.2, "b": "strong"}, {"w": "Tapi", "a": 21.652, "e": 21.959, "b": null}, {"w": "cara", "a": 21.959, "e": 22.266, "b": null}, {"w": "ini", "a": 22.266, "e": 22.574, "b": null}, {"w": "hanya", "a": 22.574, "e": 22.881, "b": null}, {"w": "memberi", "a": 22.881, "e": 23.342, "b": null}, {"w": "urutan,", "a": 23.342, "e": 23.803, "b": "weak"}, {"w": "bukan", "a": 23.957, "e": 24.317, "b": null}, {"w": "angka", "a": 24.317, "e": 24.677, "b": null}, {"w": "pasti.", "a": 24.677, "e": 25.037, "b": "strong"}, {"w": "Untuk", "a": 25.477, "e": 25.813, "b": null}, {"w": "mendapatkan", "a": 25.813, "e": 26.484, "b": null}, {"w": "angka,", "a": 26.484, "e": 26.82, "b": "weak"}, {"w": "ilmuwan", "a": 27.109, "e": 27.572, "b": null}, {"w": "memakai", "a": 27.572, "e": 28.035, "b": null}, {"w": "penanggalan", "a": 28.035, "e": 28.652, "b": null}, {"w": "radiometrik.", "a": 28.652, "e": 29.424, "b": "strong"}, {"w": "Atom", "a": 29.774, "e": 30.112, "b": null}, {"w": "radioaktif", "a": 30.112, "e": 30.957, "b": null}, {"w": "meluruh", "a": 30.957, "e": 31.464, "b": null}, {"w": "menjadi", "a": 31.464, "e": 31.971, "b": null}, {"w": "unsur", "a": 31.971, "e": 32.309, "b": null}, {"w": "lain", "a": 32.309, "e": 32.478, "b": null}, {"w": "dengan", "a": 32.478, "e": 32.816, "b": null}, {"w": "laju", "a": 32.816, "e": 33.154, "b": null}, {"w": "yang", "a": 33.154, "e": 33.323, "b": null}, {"w": "bisa", "a": 33.323, "e": 33.661, "b": null}, {"w": "diukur.", "a": 33.661, "e": 34.168, "b": "strong"}, {"w": "Waktu", "a": 34.549, "e": 34.892, "b": null}, {"w": "hingga", "a": 34.892, "e": 35.235, "b": null}, {"w": "setengahnya", "a": 35.235, "e": 35.92, "b": null}, {"w": "meluruh", "a": 35.92, "e": 36.435, "b": null}, {"w": "disebut", "a": 36.435, "e": 36.949, "b": null}, {"w": "waktu", "a": 36.949, "e": 37.292, "b": null}, {"w": "paruh.", "a": 37.292, "e": 37.635, "b": "strong"}, {"w": "Uranium-238,", "a": 38.0, "e": 39.316, "b": "weak"}, {"w": "misalnya,", "a": 39.316, "e": 40.303, "b": "weak"}, {"w": "sekitar", "a": 40.546, "e": 41.335, "b": null}, {"w": "4,47", "a": 41.335, "e": 42.124, "b": null}, {"w": "miliar", "a": 42.124, "e": 42.913, "b": null}, {"w": "tahun.", "a": 42.913, "e": 43.439, "b": "strong"}, {"w": "Dengan", "a": 43.822, "e": 44.152, "b": null}, {"w": "membandingkan", "a": 44.152, "e": 44.812, "b": null}, {"w": "atom", "a": 44.812, "e": 45.143, "b": null}, {"w": "induk", "a": 45.143, "e": 45.473, "b": null}, {"w": "dan", "a": 45.473, "e": 45.638, "b": null}, {"w": "hasil", "a": 45.638, "e": 45.968, "b": null}, {"w": "peluruhannya,", "a": 45.968, "e": 46.793, "b": "weak"}, {"w": "usia", "a": 47.125, "e": 47.579, "b": null}, {"w": "mineral", "a": 47.579, "e": 48.033, "b": null}, {"w": "bisa", "a": 48.033, "e": 48.335, "b": null}, {"w": "dihitung.", "a": 48.335, "e": 48.789, "b": "strong"}, {"w": "Kenapa", "a": 49.227, "e": 49.909, "b": null}, {"w": "bukan", "a": 49.909, "e": 50.364, "b": null}, {"w": "karbon-14?", "a": 50.364, "e": 50.819, "b": "strong"}, {"w": "Waktu", "a": 51.192, "e": 51.559, "b": null}, {"w": "paruhnya", "a": 51.559, "e": 52.11, "b": null}, {"w": "hanya", "a": 52.11, "e": 52.477, "b": null}, {"w": "5.730", "a": 52.477, "e": 54.129, "b": null}, {"w": "tahun,", "a": 54.129, "e": 54.497, "b": "weak"}, {"w": "dan", "a": 54.785, "e": 54.808, "b": null}, {"w": "efektif", "a": 54.808, "e": 54.878, "b": null}, {"w": "sampai", "a": 54.878, "e": 54.925, "b": null}, {"w": "sekitar", "a": 54.925, "e": 54.995, "b": null}, {"w": "50.000", "a": 54.995, "e": 55.136, "b": null}, {"w": "tahun.", "a": 55.136, "e": 55.183, "b": "strong"}, {"w": "Sedangkan", "a": 55.314, "e": 55.594, "b": null}, {"w": "dinosaurus", "a": 55.594, "e": 55.967, "b": null}, {"w": "hidup", "a": 55.967, "e": 56.153, "b": null}, {"w": "puluhan", "a": 56.153, "e": 56.433, "b": null}, {"w": "hingga", "a": 56.433, "e": 56.62, "b": null}, {"w": "ratusan", "a": 56.62, "e": 56.9, "b": null}, {"w": "juta", "a": 56.9, "e": 57.086, "b": null}, {"w": "tahun", "a": 57.086, "e": 57.273, "b": null}, {"w": "lalu.", "a": 57.273, "e": 57.46, "b": "strong"}, {"w": "Solusinya", "a": 57.837, "e": 59.536, "b": null}, {"w": "abu", "a": 59.536, "e": 60.385, "b": null}, {"w": "vulkanik.", "a": 60.385, "e": 61.66, "b": "strong"}, {"w": "Mineral", "a": 62.075, "e": 62.647, "b": null}, {"w": "dari", "a": 62.647, "e": 63.028, "b": null}, {"w": "letusan", "a": 63.028, "e": 63.6, "b": null}, {"w": "gunung", "a": 63.6, "e": 63.981, "b": null}, {"w": "berapi", "a": 63.981, "e": 64.553, "b": null}, {"w": "bisa", "a": 64.553, "e": 64.934, "b": null}, {"w": "diuji", "a": 64.934, "e": 65.506, "b": null}, {"w": "dengan", "a": 65.506, "e": 65.887, "b": null}, {"w": "metode", "a": 65.887, "e": 66.459, "b": null}, {"w": "kalium-argon", "a": 66.459, "e": 67.412, "b": null}, {"w": "atau", "a": 67.412, "e": 67.793, "b": null}, {"w": "argon-argon.", "a": 67.793, "e": 68.555, "b": "strong"}, {"w": "Jika", "a": 68.687, "e": 68.822, "b": null}, {"w": "abu", "a": 68.822, "e": 68.957, "b": null}, {"w": "di", "a": 68.957, "e": 69.024, "b": null}, {"w": "bawah", "a": 69.024, "e": 69.159, "b": null}, {"w": "fosil", "a": 69.159, "e": 69.294, "b": null}, {"w": "berusia", "a": 69.294, "e": 69.564, "b": null}, {"w": "100", "a": 69.564, "e": 69.699, "b": null}, {"w": "juta", "a": 69.699, "e": 69.834, "b": null}, {"w": "tahun,", "a": 69.834, "e": 69.968, "b": "weak"}, {"w": "dan", "a": 70.334, "e": 70.539, "b": null}, {"w": "abu", "a": 70.539, "e": 70.949, "b": null}, {"w": "di", "a": 70.949, "e": 71.154, "b": null}, {"w": "atasnya", "a": 71.154, "e": 71.769, "b": null}, {"w": "95", "a": 71.769, "e": 72.589, "b": null}, {"w": "juta", "a": 72.589, "e": 72.999, "b": null}, {"w": "tahun,", "a": 72.999, "e": 73.409, "b": "weak"}, {"w": "fosil", "a": 73.619, "e": 73.926, "b": null}, {"w": "itu", "a": 73.926, "e": 74.232, "b": null}, {"w": "berasal", "a": 74.232, "e": 74.691, "b": null}, {"w": "dari", "a": 74.691, "e": 74.997, "b": null}, {"w": "rentang", "a": 74.997, "e": 75.303, "b": null}, {"w": "antara", "a": 75.303, "e": 75.762, "b": null}, {"w": "keduanya.", "a": 75.762, "e": 76.375, "b": "strong"}, {"w": "Hasilnya", "a": 76.732, "e": 77.277, "b": null}, {"w": "memang", "a": 77.277, "e": 77.64, "b": null}, {"w": "punya", "a": 77.64, "e": 78.004, "b": null}, {"w": "rentang", "a": 78.004, "e": 78.367, "b": null}, {"w": "ketidakpastian.", "a": 78.367, "e": 79.457, "b": "strong"}, {"w": "Karena", "a": 79.863, "e": 80.301, "b": null}, {"w": "itu", "a": 80.301, "e": 80.593, "b": null}, {"w": "ilmuwan", "a": 80.593, "e": 81.031, "b": null}, {"w": "menggabungkan", "a": 81.031, "e": 81.615, "b": null}, {"w": "banyak", "a": 81.615, "e": 81.907, "b": null}, {"w": "bukti:", "a": 81.907, "e": 82.199, "b": "weak"}, {"w": "posisi", "a": 82.627, "e": 83.978, "b": null}, {"w": "lapisan,", "a": 83.978, "e": 85.328, "b": "weak"}, {"w": "hasil", "a": 85.754, "e": 86.047, "b": null}, {"w": "radiometrik,", "a": 86.047, "e": 86.781, "b": "weak"}, {"w": "mineral,", "a": 87.023, "e": 88.115, "b": "weak"}, {"w": "dan", "a": 88.324, "e": 88.576, "b": null}, {"w": "fosil", "a": 88.576, "e": 89.081, "b": null}, {"w": "lain", "a": 89.081, "e": 89.333, "b": null}, {"w": "di", "a": 89.333, "e": 89.586, "b": null}, {"w": "sekitarnya.", "a": 89.586, "e": 90.595, "b": "strong"}, {"w": "Jika", "a": 90.986, "e": 91.284, "b": null}, {"w": "semuanya", "a": 91.284, "e": 91.879, "b": null}, {"w": "cocok,", "a": 91.879, "e": 92.177, "b": "weak"}, {"w": "perkiraannya", "a": 92.37, "e": 93.199, "b": null}, {"w": "makin", "a": 93.199, "e": 93.531, "b": null}, {"w": "kuat.", "a": 93.531, "e": 93.862, "b": "strong"}, {"w": "Jadi,", "a": 94.278, "e": 94.803, "b": "weak"}, {"w": "usia", "a": 94.965, "e": 95.509, "b": null}, {"w": "fosil", "a": 95.509, "e": 95.872, "b": null}, {"w": "bukan", "a": 95.872, "e": 96.235, "b": null}, {"w": "tebakan.", "a": 96.235, "e": 96.779, "b": "strong"}, {"w": "Itu", "a": 97.243, "e": 97.587, "b": null}, {"w": "rekonstruksi", "a": 97.587, "e": 98.277, "b": null}, {"w": "sejarah", "a": 98.277, "e": 98.794, "b": null}, {"w": "Bumi", "a": 98.794, "e": 99.139, "b": null}, {"w": "dari", "a": 99.139, "e": 99.484, "b": null}, {"w": "bukti", "a": 99.484, "e": 99.829, "b": null}, {"w": "yang", "a": 99.829, "e": 100.001, "b": null}, {"w": "saling", "a": 100.001, "e": 100.346, "b": null}, {"w": "mendukung.", "a": 100.346, "e": 100.863, "b": "strong"}];const NARR_DUR=101.06775;

/* Scenes: Bagaimana ilmuwan tahu usia fosil — 1080x1920, semua dihitung deterministik dari T */
(function () {
const OFF = .6, DUR = 105;
const S = {s2: 6.88, s3: 25.48, s4: 49.23, s5: 57.84, s6: 76.73, s7: 94.28, end: 101.07};
const EV = []; const E = (t, ty, v = 1) => EV.push([+t.toFixed(3), ty, v]); window.EV = EV; window.DUR = DUR; window.OFF = OFF;
let n = 0, BG = ['#000', '#000'], HUD = () => {}; const SHK = [];
const shake = (t, a, d) => SHK.push([t, a, d]);
const norm = (s) => s.toLowerCase().replace(/[^a-z0-9\-\.]/g, '').replace(/\.$/, '');
function W(w, k = 0) { let c = 0; for (const t of WORDS) if (norm(t.w) === w) { if (c++ === k) return t.a; } return 0; }
const SPH = (() => { const b = new B(); sphere(b, [0, 0, 0], 1, [1, 1, 1], 10, 14); return b.build(); })();
const UBOX = (() => { const b = new B(); box(b, 0, 0, 0, 1, 1, 1, [1, 1, 1]); return b.build(); })();
const RING = (() => { const b = new B(); torus(b, 1, .035, 56, 6, [1, 1, 1]); return b.build(); })();
const RING2 = (() => { const b = new B(); torus(b, 1, .02, 48, 5, [1, 1, 1]); return b.build(); })();
const M = {trex: buildTRex(), plinth: buildPlinth(), ground: buildGround(90, 90, '#2a2420', '#3a2f26'), ground2: buildGround(90, 90, '#181513', '#26211c', 0, 5),
  crystal: buildCrystal(), earth: buildEarth(1), volc: buildVolcano().mesh, amm: buildAmmonite(), lico: buildLayerIcon()};
function sh(t, a, d) { return t; }
const VIG = (() => { const c = document.createElement('canvas'); c.width = 270; c.height = 480; const x = c.getContext('2d'); const g = x.createRadialGradient(135, 230, 90, 135, 240, 330); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.62)'); x.fillStyle = g; x.fillRect(0, 0, 270, 480); return c; })();

/* ---------- util kamera / cahaya ---------- */
function camShake() { let o = [0, 0, 0]; for (const [t0, a, d] of SHK) { const t = n - t0; if (t >= 0 && t < d) { const k = Math.pow(1 - t / d, 2) * a; o = [o[0] + Math.sin(n * 83 + t0) * k, o[1] + Math.cos(n * 97 + t0) * k, o[2] + Math.sin(n * 71) * k * .5]; } } return o; }
function cam(eye, tgt, fov = 50, roll = 0) { const s = camShake(); CAM.eye = vadd(eye, s); CAM.tgt = vadd(tgt, vmul(s, .5)); CAM.fov = fov; CAM.roll = roll; }
function light(o) { Object.assign(LT, {ld: vnorm([-.4, -.8, -.45]), lc: [1, .95, .85], at: [.35, .38, .45], ab: [.12, .1, .1], l2d: [.5, -.2, .6], l2c: [0, 0, 0], clip: -1000, rc: [.2, .3, .5], fd: .02, fog: [.03, .03, .05]}, o); }
function puff(p0, t, nn, spd, size, col, life, seed, grav = 6, a0 = .55, list = PB.alp) {
  if (t < 0 || t > life) return; const k = t / life;
  for (let i = 0; i < nn; i++) {
    const a = R(i, seed) * 6.283, s = spd * (.35 + R(i, seed + 2) * .65), up = .35 + R(i, seed + 1) * .8;
    const p = [p0[0] + Math.cos(a) * s * t * (1 - k * .35), p0[1] + up * s * t - grav * t * t * .5 * (list === PB.add ? 1 : .15), p0[2] + Math.sin(a) * s * t * (1 - k * .35)];
    pt(list, p, size * (.5 + k * 1.1) * (.6 + R(i, seed + 3) * .8), col, a0 * (1 - k) * (1 - k * .3), 0);
  }
}
const kfv = (t, kf) => { if (t <= kf[0][0]) return kf[0][1]; for (let i = 1; i < kf.length; i++) if (t <= kf[i][0]) return lerp(kf[i - 1][1], kf[i][1], sstep(kf[i - 1][0], kf[i][0], t)); return kf[kf.length - 1][1]; };
const P2 = (p) => { const q = proj(p); q.x /= SC; q.y /= SC; q.s /= SC; return q; };

/* ---------- util 2D ---------- */
const FONT = 'Inter, "Arial Black", Arial, "DejaVu Sans", sans-serif';
function txt(s, x, y, size, col, o = {}) {
  ctx.save(); ctx.translate(x, y); if (o.rot) ctx.rotate(o.rot); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, o.scy || sc);
  ctx.globalAlpha = o.al === undefined ? 1 : o.al; ctx.font = `${o.w || 900} ${size}px ${FONT}`; ctx.textAlign = o.align || 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
  const lines = String(s).split('\n'); const lh = size * 1.08; const y0 = -(lines.length - 1) * lh / 2;
  lines.forEach((ln, li) => {
    const yy = y0 + li * lh;
    if (o.depth) { ctx.fillStyle = o.dcol || '#6b3f00'; for (let i = o.depth; i > 0; i--) ctx.fillText(ln, i * .55, yy + i * .9); }
    if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = o.gb || 36; }
    if (o.stroke) { ctx.lineWidth = o.sw || 12; ctx.strokeStyle = o.stroke; ctx.strokeText(ln, 0, yy); }
    ctx.fillStyle = col; ctx.fillText(ln, 0, yy); ctx.shadowBlur = 0;
  });
  ctx.restore();
}
function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
function chip(s, x, y, size, bg, fg, o = {}) {
  ctx.save(); ctx.translate(x, y); const sc = o.sc === undefined ? 1 : o.sc; ctx.scale(sc, sc); if (o.rot) ctx.rotate(o.rot); ctx.globalAlpha = o.al === undefined ? 1 : o.al;
  ctx.font = `900 ${size}px ${FONT}`; const w = ctx.measureText(s).width + size * 1.1, h = size * 1.55;
  if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = 30; } ctx.fillStyle = bg; rr(-w / 2, -h / 2, w, h, h / 2); ctx.fill(); ctx.shadowBlur = 0;
  if (o.border) { ctx.lineWidth = 5; ctx.strokeStyle = o.border; ctx.stroke(); }
  ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s, 0, size * .04); ctx.restore();
}
function glowDot(x, y, r, col, a) { const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(${col},${a})`); g.addColorStop(1, `rgba(${col},0)`); ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); }
const popK = (t, d = .38) => ({sc: eoutB(clamp(t / d, 0, 1)), al: clamp(t / .1, 0, 1)});
function title(s, t0, t1, y, size, col, o = {}) {
  if (n < t0 || n > t1) return; const t = n - t0, out = clamp((t1 - n) / .25, 0, 1); const p = popK(t);
  txt(s, o.x || 540, y + (1 - out) * -30, size, col, Object.assign({sc: p.sc * (.94 + .06 * out), al: p.al * out, stroke: '#000', sw: size * .16, glow: o.glow || 'rgba(0,0,0,.6)', gb: 24}, o));
}
function fmt(v) { return String(Math.round(v)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function lab(text, pos, hgt, col, o = {}) { const q = P2(pos); if (!q.vis || q.z < 2) return; const size = clamp(hgt * q.s, 8, 400); if (size < 14) return; txt(text, q.x, q.y, size, col, Object.assign({stroke: '#000', sw: size * .14}, o)); }
const stars = []; for (let i = 0; i < 240; i++) { const a = R(i, 3) * 6.283, b = Math.acos(R(i, 4) * 2 - 1); stars.push([Math.sin(b) * Math.cos(a) * 90, Math.cos(b) * 90, Math.sin(b) * Math.sin(a) * 90, .08 + R(i, 5) * .22, R(i, 6)]); }
function starfield(al = 1) { stars.forEach((s) => { const p = vadd(CAM.eye, [s[0], s[1], s[2]]); pt(PB.add, p, s[3] * 1.6, [.8, .88, 1], al * (.4 + .6 * Math.sin(n * (1 + s[4] * 3) + s[4] * 9) ** 2), 0); }); }
function motes(cnt, spread, hgt, spd, size, col, a) { for (let i = 0; i < cnt; i++) { const x = (R(i, 11) - .5) * spread, z = (R(i, 12) - .5) * spread, y = ((R(i, 13) * hgt + n * spd * (.3 + R(i, 14))) % hgt); pt(PB.add, [x + Math.sin(n * .7 + i) * .4, y, z], size * (.5 + R(i, 15)), col, a * (.3 + .7 * R(i, 16)), 0); } }

/* ================= SFX timeline (narration time) ================= */
E(-.55, 'riser', 1); E(.04, 'impact', 1.1); E(3.0, 'impact', 1.2); E(2.4, 'riser', .8); E(3.0, 'shimmer', .8);
[S.s2, S.s3, S.s4, S.s5, S.s6, S.s7].forEach((b) => { E(b - .22, 'whoosh', 1); E(b, 'impact', .9); });

/* ================= SCENE 1: hook ================= */
function sc1() {
  BG = ['#2c2016', '#080605']; light({fog: hexc('#0b0907'), fd: .028, lc: [1, .9, .75], at: [.3, .3, .35], ab: [.1, .08, .07], l2d: [.7, -.2, .5], l2c: [.08, .16, .3]});
  const u = clamp((n + .6) / 7.5, 0, 1), a = .55 + u * 1.9, r = lerp(15, 24, eio(u)), h = lerp(3.5, 8, eio(u));
  const crane = sstep(2.9, 4.2, n); cam([Math.cos(a) * r, h + crane * 3, Math.sin(a) * r], [-.4, 3.2 + u * .8, 0], lerp(40, 52, u));
  beginFrame();
  draw(M.ground, mT(0, -.8, 0)); draw(M.plinth, ident()); draw(M.trex, mT(-.4, 0, 0), {sp: .3, em: .05 + .1 * sstep(2.8, 3.2, n) * (1 - sstep(3.2, 5, n))});
  for (let k = 0; k < 6; k++) beam(PB.add, [-10 + k * 4, 17, -4 + (k % 2) * 6], [-12 + k * 4, 0, -1 + (k % 2) * 3], 1.5, [1, .82, .5], .045 + .02 * Math.sin(n * 1.7 + k));
  motes(80, 40, 14, .35, .07, [1, .9, .7], .6);
  flushParticles();
  HUD = () => {
    const c = clamp(n / 2.8, 0, 1), val = 100000000 * eout(c);
    const rev = n >= S.s2 - 1.2 ? 0 : 1;
    if (n < 3.0) {
      title('TIDAK ADA MANUSIA\nYANG MELIHATNYA HIDUP', -.5, 2.9, 300, 76, '#ffffff');
      const p = popK(n - .1);
      txt(fmt(val), 540, 590, 150, '#ffd24a', {sc: p.sc, al: p.al, stroke: '#2a1700', sw: 26, glow: 'rgba(255,170,0,.8)', gb: 50, depth: 10});
      txt('TAHUN LALU', 540, 705, 62, '#ffffff', {al: p.al * clamp((n - .6) / .3, 0, 1), stroke: '#000', sw: 12});
    } else {
      const t = n - 3.0, p = popK(t, .45), sk = Math.exp(-t * 6) * Math.sin(t * 60) * 10 * (1);
      txt('?', 540 + sk, 560, 520, '#ff4a3d', {sc: p.sc, al: p.al, stroke: '#2a0300', sw: 40, glow: 'rgba(255,60,40,.8)', gb: 70, depth: 22, dcol: '#5a0d08'});
      title('LALU, BAGAIMANA\nILMUWAN TAHU USIANYA?', 3.15, 6.7, 960, 70, '#ffffff');
      if (n > 5.4) txt(fmt(100000000), 540, 1110, 90, '#ffd24a', {al: clamp((n - 5.4) / .4, 0, 1) * clamp((6.8 - n) / .3, 0, 1), stroke: '#2a1700', sw: 16, glow: 'rgba(255,170,0,.7)'});
    }
  };
}

/* ================= SCENE 2: strata ================= */
const C2 = ['#5a4331', '#7d5f40', '#a98558', '#8f806a', '#bf9c62', '#6f6054'];
const LY2 = C2.map((c, i) => buildLayer(10, 6, 1.5, c, i * 3 + 1));
const DROP2 = [7.3, 8.6, 9.9, 11.2, 12.5, 13.8];
DROP2.forEach((t, i) => { E(t + .45, 'thud', .9 + i * .02); });
E(9.9, 'shimmer', .6); E(14.25, 'ding', .7); E(19.5, 'impact', 1.2); E(19.5, 'shimmer', .9);
[21.9, 22.4, 22.9, 23.4, 23.9].forEach((t, i) => E(t, 'pop', .8)); E(23.96, 'zap', .9);
DROP2.forEach((t) => shake(t + .45, .22, .35));
function sc2() {
  BG = ['#1e2733', '#07090d']; light({fog: hexc('#0a0d12'), fd: .012, lc: [1, .93, .8], at: [.4, .42, .5], ab: [.1, .09, .09], l2d: [.6, -.1, .5], l2c: [.12, .18, .3]});
  const u = ramp(n, S.s2, S.s3), a = lerp(1.35, 1.95, eio(u)), r = 25 + 3 * Math.sin(u * 3), h = lerp(30, 6.5, eout(ramp(n, S.s2, 9.6)));
  cam([Math.cos(a) * r, h, Math.sin(a) * r], [0, lerp(.5, 4.3, eout(ramp(n, S.s2, 9.6))), 0], 50);
  beginFrame();
  draw(M.ground2, mT(0, -.1, 0));
  const gap = .38 * sstep(21.8, 22.6, n) * (1 - sstep(24.7, 25.3, n)), pulse = .22 + .2 * Math.sin(n * 7);
  for (let k = 0; k < 6; k++) {
    const tk = DROP2[k]; if (n < tk) continue; const q = (n - tk) / .45; let yo = 0, sy = 1;
    if (q < 1) yo = 16 * (1 - ein(q)); else { const w = n - tk - .45; sy = 1 - .1 * Math.exp(-w * 9) * Math.cos(w * 28); }
    const hl = (k === 0 && n > 14.25 && n < 19.6) ? pulse : 0;
    draw(LY2[k], mmul(mT(0, k * (1.5 + gap) + yo, 0), mS(1, sy, 1)), {em: hl, tint: hl ? [1.25, 1.1, .9] : [1, 1, 1]});
    if (q >= 1) puff([k % 2 ? 5 : -5, k * 1.5 + .2, 3.2], n - tk - .45, 10, 3.4, .6, [.75, .68, .58], 1.3, 40 + k, 3, .5);
    if (q >= 1) puff([k % 2 ? -5 : 5, k * 1.5 + .2, 3.2], n - tk - .45, 8, 3, .55, [.7, .63, .53], 1.2, 70 + k, 3, .45);
  }
  if (n > DROP2[3] + .45) {
    const g2 = 2 * gap, ge = 1 + clamp((n - 10) / 1, 0, 1);
    const pul = 1.1 + .25 * Math.sin(n * 6) * (n > 9.9 && n < 14.2 ? 1 : 0);
    if (n > DROP2[2] + .45) { draw(M.trex, TRS([-1.6, 3 + gap * 2 + .1, 3.02], [0, 0, 0], [.28, .28, .06]), {sp: .25, em: n < 14.2 ? .12 + .12 * Math.sin(n * 6) : .05}); }
    if (n > DROP2[4] + .45) draw(M.amm, TRS([2.2, 6 + gap * 4 + .78, 3.02], [0, 0, 0], [1.05, 1.05, .12]), {sp: .2, em: .06});
    pt(PB.add, [-1.6, 3.9 + gap * 2, 3.3], 3.4 * pul, [1, .8, .35], .22 * (n > 9.9 && n < 14.4 ? 1 : 0), 0);
  }
  motes(50, 24, 12, .15, .06, [.9, .85, .75], .5);
  flushParticles();
  const front = (k, x = 5.1) => P2([x, k * (1.5 + gap) + .75, 3.05]);
  HUD = () => {
    title('RAHASIANYA ADA DI\nLAPISAN TANAH', 7.0, 9.6, 300, 74, '#ffffff');
    title('BATUAN SEDIMEN\nMENUMPUK BERLAPIS', 9.9, 13.9, 300, 70, '#ffe1a0');
    if (n > 14.25 && n < 19.3) {
      const t = n - 14.25; const q0 = P2([0, .75, 3.1]), q1 = P2([0, 5 * 1.5 + .75, 3.1]);
      chip('TERTUA', q0.x, q0.y, 52, '#ff5a3c', '#fff', Object.assign({glow: 'rgba(255,90,60,.9)'}, {sc: eoutB(t / .4), al: clamp(t / .2, 0, 1)}));
      chip('TERMUDA', q1.x, q1.y, 52, '#3cc4ff', '#00131c', {glow: 'rgba(60,196,255,.9)', sc: eoutB((t - .5) / .4), al: clamp((t - .5) / .2, 0, 1)});
      const ax = 90, y0 = Math.min(q0.y, q1.y), y1 = Math.max(q0.y, q1.y);
      ctx.save(); ctx.globalAlpha = clamp((t - .9) / .3, 0, 1); ctx.strokeStyle = '#fff'; ctx.lineWidth = 9; ctx.setLineDash([22, 16]); ctx.lineDashOffset = -n * 40; ctx.beginPath(); ctx.moveTo(ax, y1 - 70); ctx.lineTo(ax, y0 + 90); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(ax, y0 + 40); ctx.lineTo(ax - 28, y0 + 100); ctx.lineTo(ax + 28, y0 + 100); ctx.fill(); ctx.restore();
      txt('BAWAH = LEBIH TUA', 540, 300, 70, '#ffffff', {stroke: '#000', sw: 14, sc: popK(t - 1.0).sc, al: popK(t - 1.0).al * clamp((19.3 - n) / .25, 0, 1)});
    }
    if (n > 19.5 && n < 21.8) { const t = n - 19.5, p = popK(t, .5); txt('SUPERPOSISI', 540, 330, 118, '#ffd24a', {sc: p.sc * (1 + .02 * Math.sin(t * 8)), al: p.al * clamp((21.8 - n) / .25, 0, 1), stroke: '#2a1700', sw: 22, depth: 18, glow: 'rgba(255,190,40,.8)', gb: 44, rot: -.03}); }
    if (n > 21.9 && n < 25.4) {
      const fo = clamp((25.4 - n) / .3, 0, 1);
      title('HANYA URUTAN', 21.9, 23.9, 300, 80, '#ffffff'); title('BUKAN ANGKA PASTI', 23.96, 25.35, 300, 74, '#ff6a5a');
      for (let k = 0; k < 6; k++) { const t = n - (21.9 + (5 - k) * .5 + .0); if (t < 0) continue; const q = front(k, -4.3), p = popK(t, .3); const nm = String(6 - k);
        ctx.save(); ctx.globalAlpha = fo * p.al; ctx.translate(q.x, q.y); ctx.scale(p.sc, p.sc); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(0, 0, 36, 0, 6.283); ctx.fill(); ctx.fillStyle = '#111'; ctx.font = `900 46px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(nm, 0, 3); ctx.restore();
        if (n > 23.96) chip('?? TAHUN', q.x + 190, q.y, 34, '#ff4a3d', '#fff', {al: fo * clamp((n - 23.96 - (5 - k) * .08) / .2, 0, 1), sc: 1}); }
    }
  };
}

/* ================= SCENE 3: radiometrik ================= */
const NA = 125, ATOMS = []; { const perm = [...Array(NA).keys()].sort((a, b) => R(a, 91) - R(b, 91));
  for (let i = 0; i < NA; i++) { const x = i % 5, y = Math.floor(i / 5) % 5, z = Math.floor(i / 25); const r = (perm[i] + R(i, 92)) / NA; let td = 29.77 - 8.23 * Math.log2(1 - r); td = Math.max(30.2, td);
    ATOMS.push({p: [(x - 2) * 1.4, (y - 2) * 1.4, (z - 2) * 1.4], td: td < 49.2 ? td : Infinity}); } }
ATOMS.forEach((a, i) => { if (isFinite(a.td)) E(a.td, i % 3 ? 'tick' : 'zap', .5 + R(i, 3) * .3); });
const Dfun = (t) => t < 29.77 ? 0 : 1 - Math.pow(2, -(t - 29.77) / 8.23);
E(28.65, 'ding', .8); E(28.4, 'riser', .7); E(38.0, 'ding', 1); E(38.0, 'impact', .8); E(43.82, 'whoosh', .6); E(46.2, 'ding', .6); E(25.7, 'impact', 1);
function sc3() {
  if (n < S.s3 + 4.3) {
    BG = ['#251540', '#04030a']; light({fog: hexc('#08051a'), fd: .02, lc: [1, .85, .6], at: [.3, .3, .5], ab: [.1, .08, .15], l2d: [.6, -.1, .5], l2c: [.15, .1, .4]});
    const u = ramp(n, 28.4, 29.77), r = lerp(9, .6, ein(u)), a = n * .5;
    cam([Math.cos(a) * r, 1.6 * (1 - u), Math.sin(a) * r], [0, 0, 0], 50 + 25 * u);
    beginFrame();
    draw(M.crystal, mmul(mT(0, Math.sin(n * 1.5) * .15, 0), mmul(mRy(n * 1.1), mS(2.4))), {em: .35 + .1 * Math.sin(n * 5), sp: .6, rim: .6, tint: [1.1, 1, .95]});
    for (let k = 0; k < 8; k++) { const ang = n * .8 + k * .785; beam(PB.add, [0, 0, 0], [Math.cos(ang) * 11, Math.sin(ang * 1.3) * 5, Math.sin(ang) * 11], .9, [1, .78, .35], .12); }
    pt(PB.add, [0, 0, 0], 7 + Math.sin(n * 3), [1, .7, .3], .3, 0);
    for (let i = 0; i < 70; i++) { const a2 = R(i, 5) * 6.283, rr2 = 2.5 + R(i, 6) * 5; pt(PB.add, [Math.cos(a2 + n * .4) * rr2, (R(i, 7) - .5) * 6 + Math.sin(n + i) * .3, Math.sin(a2 + n * .4) * rr2], .09 + R(i, 8) * .08, [1, .85, .55], .8 * (.4 + .6 * Math.sin(n * 3 + i) ** 2), 0); }
    flushParticles();
    HUD = () => {
      title('BUTUH ANGKA?', 25.7, 28.3, 330, 96, '#ffffff', {glow: 'rgba(255,200,100,.7)'});
      if (n > 28.4) { const p = popK(n - 28.4, .5); txt('PENANGGALAN\nRADIOMETRIK', 540, 340, 100, '#ffd24a', {sc: p.sc, al: p.al * clamp((29.7 - n) / .1, 0, 1), stroke: '#2a1700', sw: 20, depth: 14, glow: 'rgba(255,190,40,.8)', gb: 44}); }
    };
    return;
  }
  BG = ['#0b1230', '#02030a']; light({fog: hexc('#050818'), fd: .012, lc: [.9, .9, 1], at: [.3, .35, .55], ab: [.08, .08, .15], l2d: [.6, -.2, .4], l2c: [.25, .25, .5], rc: [.3, .4, .9]});
  const t = n - 29.77, a = n * .24 + .5, r = lerp(25, 20, ramp(n, 29.77, 49)); cam([Math.cos(a) * r, 2.5 + Math.sin(n * .5) * 1.4, Math.sin(a) * r], [0, .4, 0], 48);
  beginFrame();
  const D = Dfun(n);
  ATOMS.forEach((at, i) => {
    const age = n - at.td, dec = age >= 0, jx = Math.sin(n * 9 + i) * .02;
    const p = [at.p[0] + jx, at.p[1] + Math.cos(n * 8 + i * 2) * .02, at.p[2]];
    if (!dec) { draw(SPH, TRS(p, [0, 0, 0], [.46, .46, .46]), {tint: [1, .22, .18], em: .45 + .12 * Math.sin(n * 6 + i), sp: .5, rim: .5}); pt(PB.add, p, .9, [1, .2, .1], .14, 0); }
    else {
      const pop = 1 + .8 * Math.exp(-age * 7), s2 = .36 * pop; draw(SPH, TRS(p, [0, 0, 0], [s2, s2, s2]), {tint: [.28, .6, 1], em: .3 + .6 * Math.exp(-age * 5), sp: .6, rim: .5});
      if (age < .45) { const k = age / .45; pt(PB.add, p, 1 + k * 3, [1, .95, .8], .85 * (1 - k) ** 2, 0); const d = vnorm([R(i, 1) - .5, R(i, 2) - .5, R(i, 3) - .5]); beam(PB.add, vadd(p, vmul(d, .5)), vadd(p, vmul(d, .5 + k * 3.2)), .12, [1, .8, .3], .9 * (1 - k)); }
    }
  });
  flushParticles();
  const par = 1 - D;
  HUD = () => {
    if (n < 34.5) { title('ATOM RADIOAKTIF', 29.9, 32, 330, 82, '#ff7a6a'); title('MELURUH → UNSUR LAIN', 32.1, 34.5, 330, 74, '#7cc4ff'); }
    if (n >= 34.5) {
      const t2 = n - 34.5, y = 270;
      txt('WAKTU PARUH', 540, y, 84, '#ffffff', {stroke: '#000', sw: 16, sc: popK(t2).sc, al: popK(t2).al, glow: 'rgba(120,180,255,.7)'});
      // bar induk/anak
      const bx = 140, bw = 800, by = 395, bh = 56; ctx.save(); ctx.globalAlpha = clamp(t2 / .3, 0, 1);
      ctx.fillStyle = 'rgba(0,0,0,.55)'; rr(bx - 8, by - 8, bw + 16, bh + 16, 22); ctx.fill();
      ctx.fillStyle = '#ff4a3c'; rr(bx, by, Math.max(2, bw * par), bh, 16); ctx.fill(); ctx.fillStyle = '#3c9bff'; rr(bx + bw * par, by, bw * (1 - par), bh, 16); ctx.fill();
      ctx.restore();
      txt(Math.round(par * 100) + '% INDUK', bx + 10, by + bh + 52, 44, '#ff7a6a', {align: 'left', stroke: '#000', sw: 9, al: clamp(t2 / .3, 0, 1)});
      txt(Math.round(D * 100) + '% ANAK', bx + bw - 10, by + bh + 52, 44, '#7cc4ff', {align: 'right', stroke: '#000', sw: 9, al: clamp(t2 / .3, 0, 1)});
      if (n > 38 && n < 40.6) { const tt = n - 38, p = popK(tt, .4); txt('½', 540, 640, 330, '#ffd24a', {sc: p.sc, al: p.al * clamp((40.6 - n) / .3, 0, 1), stroke: '#2a1700', sw: 26, depth: 16, glow: 'rgba(255,200,60,.9)', gb: 60}); }
    }
    if (n > 38 && n < 43.8) { const tt = n - 38; txt('URANIUM-238  →  TIMBAL-206', 540, 1050, 48, '#ffffff', {stroke: '#000', sw: 10, al: popK(tt, .4).al * clamp((43.6 - n) / .25, 0, 1), sc: popK(tt).sc});
      if (n > 39.6) { const v = 4.47 * eout(ramp(n, 39.6, 41.6)); txt(v.toFixed(2).replace('.', ',') + ' MILIAR', 540, 1170, 110, '#ffd24a', {stroke: '#2a1700', sw: 20, depth: 10, glow: 'rgba(255,190,40,.8)', al: clamp((43.6 - n) / .25, 0, 1), sc: popK(n - 39.6).sc}); txt('TAHUN', 540, 1255, 56, '#fff', {stroke: '#000', sw: 12, al: clamp((43.6 - n) / .25, 0, 1) * clamp((n - 40.6) / .2, 0, 1)}); } }
    if (n >= 43.82) { const tt = n - 43.82, p = popK(tt, .4), fo = clamp((49.1 - n) / .2, 0, 1); const ratio = D / Math.max(.01, par);
      txt('BANDINGKAN\nINDUK vs ANAK', 540, 1030, 70, '#ffffff', {stroke: '#000', sw: 14, sc: p.sc, al: p.al * fo});
      if (n > 46.2) { const q = popK(n - 46.2, .4); chip('USIA = DIHITUNG ✓', 540, 1190, 56, '#2bd47a', '#00220f', {glow: 'rgba(40,220,120,.8)', sc: q.sc, al: q.al * fo}); }
      txt('RASIO ANAK : INDUK = ' + ratio.toFixed(1).replace('.', ','), 540, 1300 - (n > 46.2 ? 0 : 0), 42, '#cfe3ff', {stroke: '#000', sw: 9, al: .85 * fo * clamp(tt / .6, 0, 1)});
    }
  };
}

/* ================= SCENE 4: karbon-14 & terowongan waktu ================= */
const WALLZ = -48, RN = 66; const WALLM = (() => { const b = new B(); box(b, 0, 0, 0, 18, 18, .8, [1, .25, .2], .2, 3); return b.build(); })();
E(49.9, 'zap', 1); E(49.91, 'impact', 1); E(51.19, 'whoosh', 1); E(52.48, 'pop', .9); E(54.99, 'ding', .9); E(55.35, 'impact', 1.6); E(55.35, 'shatter', 1.2); E(55.3, 'riser', 1); E(55.4, 'whoosh', 1.3);
shake(55.35, .9, .8);
function sc4() {
  if (n < S.s4 + 1.96) {
    BG = ['#10223a', '#03060c']; light({fog: hexc('#050a14'), fd: .02, lc: [.9, .95, 1], at: [.3, .4, .5], ab: [.08, .1, .12], l2d: [.6, -.2, .4], l2c: [.1, .3, .4]});
    const a = n * .6, r = lerp(24, 17, eout(ramp(n, S.s4, 50.4))); cam([Math.cos(a) * r, 2.4, Math.sin(a) * r], [0, 0, 0], 48);
    beginFrame();
    const cm = mRy(n * .8);
    for (let i = 0; i < 14; i++) { const d = vnorm([R(i, 1) - .5, R(i, 2) - .5, R(i, 3) - .5]); const p = vmul(d, .55 + R(i, 4) * .35); draw(SPH, TRS(p, [0, 0, 0], [.52, .52, .52]), {tint: i < 6 ? [.4, .4, .45] : [.55, .55, .6], em: .15, sp: .5}); }
    draw(SPH, TRS([0, 0, 0], [0, 0, 0], [.4, .4, .4]), {tint: [1, .3, .2], em: .7});
    for (let k = 0; k < 3; k++) { draw(RING2, mmul(mRy(k * 1.05 + n * .3), mmul(mRx(k * .9 + 1), mS(3.4 + k * .6))), {tint: [.4, .8, 1], em: .8}); const ang = n * (2 + k) + k * 2; const rp = vadd([0, 0, 0], mApply(mmul(mRy(k * 1.05 + n * .3), mRx(k * .9 + 1)), [Math.cos(ang) * (3.4 + k * .6), Math.sin(ang) * (3.4 + k * .6), 0])); draw(SPH, TRS(rp, [0, 0, 0], [.2, .2, .2]), {tint: [.5, .9, 1], em: .9}); pt(PB.add, rp, .8, [.4, .8, 1], .5, 0); }
    pt(PB.add, [0, 0, 0], 8, [.3, .7, 1], .16, 0);
    flushParticles();
    HUD = () => {
      title('KENAPA BUKAN\nKARBON-14?', S.s4 + .05, S.s4 + 1.96, 300, 84, '#ffffff', {glow: 'rgba(80,180,255,.8)'});
      txt('C-14', 540, 1010, 190, '#7cc4ff', {stroke: '#001a2e', sw: 28, depth: 14, dcol: '#06324f', glow: 'rgba(80,180,255,.9)', gb: 50, sc: popK(n - S.s4 - .1, .5).sc, al: clamp((51.1 - n) / .1, 0, 1)});
      if (n > 49.9) txt('✕', 540, 1010, 360, '#ff3a2e', {sc: eoutB((n - 49.9) / .3), al: clamp((n - 49.9) / .08, 0, 1) * clamp((51.1 - n) / .1, 0, 1), stroke: '#2a0300', sw: 24, glow: 'rgba(255,60,40,.9)'});
    };
    return;
  }
  BG = ['#05101f', '#010206']; light({fog: [.01, .02, .04], fd: .028, lc: [.8, .9, 1], at: [.4, .5, .7], ab: [.15, .2, .3], l2d: [0, 0, -1], l2c: [.2, .3, .5]});
  const u1 = clamp((n - 51.19) / 4.12, 0, 1); let cz = 6 - 50 * Math.pow(u1, 1.25); let fov = 55;
  if (n >= 55.31) { const u2 = clamp((n - 55.31) / 2.53, 0, 1); cz = -44 - 172 * (1 - Math.pow(1 - u2, 2.2)); fov = lerp(55, 95, Math.sin(u2 * Math.PI * .5) * (1 - u2 * .3)); }
  cam([Math.sin(n * .7) * .35, Math.cos(n * .9) * .25, cz], [0, 0, cz - 20], fov);
  beginFrame();
  for (let i = 0; i < RN; i++) { const z = -i * 4; if (z > cz + 6 || z < cz - 190) continue; const k = i <= 12 ? i / 12 : 1; const col = i <= 12 ? mixc([.1, 1, .9], [.3, 1, .4], k) : mixc([1, .5, .2], [.7, .2, 1], clamp((i - 12) / 40, 0, 1)); draw(RING, mmul(mT(0, 0, z), mmul(mRz(i * .3 + n * .2 * (i % 2 ? 1 : -1)), mS(5.6))), {tint: col, em: 1.2, sp: 0, rim: 0}); }
  if (n < 55.35) draw(WALLM, mT(0, 0, WALLZ), {tint: [1, .35, .3], em: .5 + .2 * Math.sin(n * 8), sp: .3});
  else { const t = n - 55.35; for (let i = 0; i < 70; i++) { const a = R(i, 1) * 6.283, s = 8 + R(i, 2) * 24; const p = [Math.cos(a) * s * t * (.3 + R(i, 3) * .7) * 1.2, Math.sin(a) * s * t * .9, WALLZ - t * (R(i, 4) * 30 - 8) - 3]; draw(UBOX, TRS(p, [t * 3 + i, t * 4, i], [.8 + R(i, 5), .8 + R(i, 6), .3]), {tint: [1, .4, .3], em: .6 * (1 - t / 1.6), al: 1}); if (t > 1.6) break; } pt(PB.add, [0, 0, WALLZ - 2 - t * 3], 14 * Math.exp(-t * 4), [1, .6, .3], .9 * Math.exp(-t * 4), 0); }
  for (let i = 0; i < 60; i++) { const a = R(i, 21) * 6.283, rr2 = 1 + R(i, 22) * 4.5, z0 = -((R(i, 23) * 220 + n * 4) % 220) + 6 + Math.min(0, cz) * 0; pt(PB.add, [Math.cos(a) * rr2, Math.sin(a) * rr2, cz - ((R(i, 23) * 90 + n * 20) % 90) + 5], .06, [.7, 1, 1], .5, 0); }
  flushParticles();
  HUD = () => {
    if (n < 51.19 + 4.1) {
      if (n < 52.4) title('BAYANGKAN\nGARIS WAKTU', 51.25, 52.4, 300, 74, '#ffffff', {glow: 'rgba(80,220,255,.8)'});
      else if (n < 55.3) { const t = n - 52.48, p = popK(t, .4); txt('5.730 TAHUN', 540, 290, 100, '#4dffd0', {sc: p.sc, al: p.al, stroke: '#00241a', sw: 20, depth: 12, dcol: '#05503c', glow: 'rgba(60,255,200,.8)'}); txt('WAKTU PARUH C-14', 540, 385, 48, '#fff', {stroke: '#000', sw: 10, al: p.al}); }
    }
    lab('50.000 TAHUN', [0, 0, WALLZ + .6], 2.6, '#ffffff', {glow: 'rgba(255,60,40,.9)', al: n < 55.35 ? 1 : 0, depth: 8, dcol: '#5a0d08'});
    if (n > 54.5 && n < 55.35) chip('BATAS C-14 ⚠', 540, 1050, 56, '#ff3a2e', '#fff', {glow: 'rgba(255,60,40,.9)', sc: popK(n - 54.5).sc, al: popK(n - 54.5).al});
    if (n >= 55.35) {
      const t = n - 55.35; const wp = clamp(1 - t / 1.2, 0, 1);
      ctx.save(); ctx.globalAlpha = .55 * Math.min(1, t / .1) * (1 - ramp(n, 57.2, 57.8)); ctx.strokeStyle = '#bff'; ctx.lineWidth = 3; for (let i = 0; i < 46; i++) { const a = R(i, 40) * 6.283, r0 = 120 + R(i, 41) * 200, r1 = r0 + 160 + R(i, 42) * 700; ctx.beginPath(); ctx.moveTo(540 + Math.cos(a) * r0, 900 + Math.sin(a) * r0 * 1.6); ctx.lineTo(540 + Math.cos(a) * r1, 900 + Math.sin(a) * r1 * 1.6); ctx.stroke(); } ctx.restore();
      if (n > 55.59) { const p = popK(n - 55.59, .35); txt('PULUHAN – RATUSAN\nJUTA TAHUN', 540, 300, 84, '#ffd24a', {sc: p.sc, al: p.al * clamp((57.8 - n) / .2, 0, 1), stroke: '#2a1700', sw: 18, depth: 10, glow: 'rgba(255,190,40,.8)'}); }
      lab('100.000.000\nTAHUN', [0, 0, -226], 2.2, '#ffd24a', {al: ramp(n, 56.8, 57.4) * clamp((57.8 - n) / .2, 0, 1)});
    }
  };
}

/* ================= SCENE 5: abu vulkanik ================= */
E(58.7, 'rumble', 1.1); E(58.75, 'impact', 1.3); E(59.45, 'shimmer', .6); E(62.08, 'whoosh', .7);
E(66.46, 'ding', .9); E(67.79, 'ding', .9); E(66.4, 'zap', .6); E(68.85, 'thud', 1); E(69.95, 'thud', 1); E(70.9, 'thud', 1); E(69.56, 'pop', .8); E(71.77, 'pop', .8); E(75.3, 'ding', 1.1); E(75.3, 'impact', .9); E(75.3, 'shimmer', 1);
shake(58.7, .55, 1.6); shake(68.85 + .45, .2, .3); shake(69.95 + .45, .2, .3); shake(70.9 + .45, .2, .3);
const C5 = ['#c8c2b6', '#a2794a', '#b9b3a8'], H5 = [1.4, 2.6, 1.4];
const LY5 = C5.map((c, i) => buildLayer(9, 5, H5[i], c, 40 + i)), DR5 = [68.7, 69.8, 70.75], Y5 = [0, 1.4, 4.0];
function sc5() {
  if (n < 62.08) {
    BG = ['#3a2417', '#0c0706']; const cr = [0, 6.8, 0]; light({fog: hexc('#150d09'), fd: .014, lc: [1, .8, .6], at: [.35, .3, .35], ab: [.12, .08, .06], l2d: [0, -.5, -.8], l2c: [.7, .25, .05]});
    const t = n - S.s5, a = .9 + t * .1, r = 24 - 3 * eout(t / 4); cam([Math.cos(a) * r, 3 + t * .5, Math.sin(a) * r], [0, 9 + t * .6, 0], 52);
    beginFrame(); draw(M.volc, mT(0, 0, 0), {sp: .1, em: .02});
    const E0 = 58.7;
    for (let i = 0; i < 150; i++) { const t0 = E0 + R(i, 1) * 2.6, ag = n - t0; if (ag < 0 || ag > 4.5) continue; const kk = ag / 4.5; const a2 = R(i, 2) * 6.283, sp2 = 1 + R(i, 3) * 3.5; const p = [Math.cos(a2) * sp2 * ag * (1 + ag * .35) * .8, 6.8 + ag * (9 + R(i, 4) * 6) * (1 - kk * .35), Math.sin(a2) * sp2 * ag * (1 + ag * .35) * .8]; pt(PB.alp, p, 1.1 + ag * 1.1, mixc([.22, .19, .17], [.5, .46, .42], kk), .55 * (1 - kk) , 0); }
    for (let i = 0; i < 90; i++) { const t0 = E0 + R(i, 7) * 2.4, ag = n - t0; if (ag < 0 || ag > 2.8) continue; const a2 = R(i, 8) * 6.283, v = 3 + R(i, 9) * 5; const p = [Math.cos(a2) * v * ag * .6, 6.8 + (11 + R(i, 10) * 8) * ag - 7 * ag * ag, Math.sin(a2) * v * ag * .6]; pt(PB.add, p, .22 + R(i, 11) * .2, [1, .55 + R(i, 12) * .3, .15], 1 - ag / 2.8, 0); }
    pt(PB.add, [0, 7, 0], 5 + Math.sin(n * 9) * .6, [1, .45, .1], .55 * ramp(n, 58.6, 59.1), 0);
    flushParticles();
    HUD = () => { title('ABU VULKANIK', 59.3, 62.0, 330, 104, '#ffd24a', {glow: 'rgba(255,120,30,.9)', depth: 12, dcol: '#5a1d00', stroke: '#2a0f00'}); title('BUMI MENYIMPAN ARSIPNYA', 57.95, 59.2, 330, 64, '#fff'); };
    return;
  }
  if (n < S.s6 - 8.04) {
    BG = ['#07202a', '#010608']; light({fog: hexc('#03111a'), fd: .02, lc: [.9, 1, 1], at: [.3, .45, .5], ab: [.06, .1, .12], l2d: [.5, -.2, .5], l2c: [.1, .5, .6], rc: [.3, .8, 1]});
    const a = n * .35, r = 15 - 1.5 * Math.sin(ramp(n, 62, 68.7) * 3); cam([Math.cos(a) * r, 1.2 + Math.sin(n * .6), Math.sin(a) * r], [0, 0, 0], 50);
    beginFrame();
    draw(M.crystal, mmul(mRy(n * .9), mS(1.9)), {em: .3, sp: .8, rim: .7, tint: [.8, 1, 1.1]});
    for (let i = 0; i < 9; i++) { const ang = n * .5 + i * .698, rr2 = 4.2 + (i % 3) * .6; draw(M.crystal, mmul(mT(Math.cos(ang) * rr2, Math.sin(n + i) * 1.2, Math.sin(ang) * rr2), mmul(mRy(n * 1.3 + i), mmul(mRz(i), mS(.62)))), {em: .15, sp: .6, rim: .5, tint: [.7, 1, 1]}); }
    const sy = Math.sin(n * 2.2) * 2.8; beam(PB.add, [-8, sy, 1], [8, sy, 1], .09, [.4, 1, 1], .95); beam(PB.add, [-8, sy, 1], [8, sy, 1], .5, [.2, .8, 1], .2); pt(PB.add, [0, sy, 1], 3, [.4, 1, 1], .35, 0);
    pt(PB.add, [0, 0, 0], 8, [.2, .7, 1], .12, 0); motes(60, 14, 8, .2, .06, [.5, 1, 1], .7);
    flushParticles();
    HUD = () => {
      title('MINERAL DARI LETUSAN', 62.15, 64.3, 300, 70, '#ffffff', {glow: 'rgba(80,255,255,.7)'});
      title('BISA DIUJI\nDENGAN METODE…', 64.4, 66.4, 300, 70, '#bff');
      if (n > 66.46) { const p = popK(n - 66.46, .4); chip('KALIUM-ARGON  (K–Ar)', 540, 280, 52, '#00b8d9', '#001419', {glow: 'rgba(0,220,255,.9)', sc: p.sc, al: p.al * clamp((68.65 - n) / .2, 0, 1)}); }
      if (n > 67.79) { const p = popK(n - 67.79, .4); chip('ARGON-ARGON  (Ar–Ar)', 540, 400, 52, '#7a5cff', '#fff', {glow: 'rgba(140,100,255,.9)', sc: p.sc, al: p.al * clamp((68.65 - n) / .2, 0, 1)}); }
    };
    return;
  }
  BG = ['#2a2018', '#09070a']; light({fog: hexc('#0c0907'), fd: .012, lc: [1, .93, .8], at: [.4, .42, .5], ab: [.1, .09, .09], l2d: [.6, -.1, .5], l2c: [.15, .12, .1]});
  const u = ramp(n, 68.7, S.s6), a = lerp(1.35, 1.95, eio(u)); cam([Math.cos(a) * 18, 5.5 + 1.5 * Math.sin(u * 3), Math.sin(a) * 18], [0, 3.0, 0], 50);
  beginFrame(); draw(M.ground2, mT(0, -.1, 0));
  for (let k = 0; k < 3; k++) {
    if (n < DR5[k]) continue; const q = (n - DR5[k]) / .45; let yo = 0, sy = 1; if (q < 1) yo = 14 * (1 - ein(q)); else { const w = n - DR5[k] - .45; sy = 1 - .1 * Math.exp(-w * 9) * Math.cos(w * 28); }
    const hl = ((k === 0 && n > 69.4 && n < 71) || (k === 2 && n > 71.6 && n < 73.2) || (k === 1 && n > 73.4 && n < 75.3)) ? .25 + .2 * Math.sin(n * 8) : 0;
    draw(LY5[k], mmul(mT(0, Y5[k] + yo, 0), mS(1, sy, 1)), {em: hl, tint: k === 1 && hl ? [1.2, 1.1, .9] : [1, 1, 1]});
    if (q >= 1) { puff([-4.4, Y5[k] + .2, 2.8], n - DR5[k] - .45, 12, 3.4, .6, [.8, .78, .72], 1.4, 55 + k, 3, .55); puff([4.4, Y5[k] + .2, 2.8], n - DR5[k] - .45, 12, 3.4, .6, [.8, .78, .72], 1.4, 85 + k, 3, .55); }
  }
  if (n > DR5[1] + .5) { draw(M.trex, TRS([-.5, Y5[1] + .22, 2.52], [0, 0, 0], [.3, .3, .06]), {sp: .25, em: .1}); }
  for (let i = 0; i < 70; i++) pt(PB.alp, [(R(i, 31) - .5) * 24, 14 - ((R(i, 32) * 14 + n * (.8 + R(i, 33))) % 14), (R(i, 34) - .3) * 12], .09 + R(i, 35) * .1, [.75, .72, .66], .45, 0);
  flushParticles();
  HUD = () => {
    title('BANDINGKAN LAPISAN', 68.75, 69.5, 300, 70, '#fff');
    if (n > 69.56) { const q = P2([0, .7, 2.6]), p = popK(n - 69.56, .4); chip('ABU BAWAH: 100 JUTA TAHUN', 540, 1130, 44, '#b9b3a8', '#111', {sc: p.sc, al: p.al * clamp((75.2 - n) / .3, 0, 1) + 0 * q.x, glow: 'rgba(255,255,255,.4)'}); }
    if (n > 71.77) { const p = popK(n - 71.77, .4); chip('ABU ATAS: 95 JUTA TAHUN', 540, 440, 44, '#b9b3a8', '#111', {sc: p.sc, al: p.al * clamp((75.2 - n) / .3, 0, 1), glow: 'rgba(255,255,255,.4)'}); }
    if (n > 73.4 && n < 75.3) { const q = P2([0, Y5[1] + 1.3, 3]); txt('FOSIL = ?', 540, q.y, 92, '#ffd24a', {stroke: '#2a1700', sw: 18, sc: popK(n - 73.4).sc, al: popK(n - 73.4).al * clamp((75.3 - n) / .15, 0, 1), glow: 'rgba(255,190,40,.9)'}); }
    if (n >= 75.3) { const t = n - 75.3, p = popK(t, .5); const q0 = P2([5.2, Y5[0] + .1, 2.5]), q1 = P2([5.2, Y5[2] + H5[2] - .1, 2.5]);
      ctx.save(); ctx.globalAlpha = p.al; ctx.strokeStyle = '#ffd24a'; ctx.lineWidth = 10; ctx.shadowColor = 'rgba(255,200,60,.9)'; ctx.shadowBlur = 24; const bx = Math.min(1010, q0.x + 70); ctx.beginPath(); ctx.moveTo(bx - 40, q1.y); ctx.lineTo(bx, q1.y); ctx.lineTo(bx, q0.y); ctx.lineTo(bx - 40, q0.y); ctx.stroke(); ctx.restore();
      txt('FOSIL BERUMUR\n95–100 JUTA TAHUN', 540, 300, 84, '#ffd24a', {sc: p.sc, al: p.al * clamp((S.s6 - .1 - n) / .1, 0, 1), stroke: '#2a1700', sw: 18, depth: 10, glow: 'rgba(255,190,40,.9)'}); }
  };
}

/* ================= SCENE 6: ketidakpastian + banyak bukti ================= */
const ICONT = [82.63, 86.05, 87.02, 89.08], ICONL = ['POSISI LAPISAN', 'RADIOMETRIK', 'MINERAL', 'FOSIL LAIN'];
ICONT.forEach((t) => E(t, 'pop', 1)); E(76.73, 'zap', .8); E(79.86, 'whoosh', .8); E(90.99, 'riser', 1); E(92.0, 'ding', 1.1); E(92.0, 'shimmer', 1);
[83.4, 86.6, 87.6, 89.7].forEach((t) => E(t, 'tick', .6));
const BANDKF = [[76.7, 0], [77.7, 7], [82.4, 7], [83.4, 5.2], [85.8, 5.2], [86.6, 3.8], [87.0, 3.8], [87.6, 2.9], [88.9, 2.9], [89.7, 2.0], [90.9, 2.0], [92.8, .5]];
const ATOMICON = (() => { const b = new B(); sphere(b, [0, 0, 0], .55, [1, .3, .25]); return b.build(); })();
function sc6() {
  BG = ['#10183a', '#030510']; light({fog: hexc('#060a20'), fd: .012, lc: [1, .95, .9], at: [.35, .38, .55], ab: [.1, .1, .16], l2d: [.6, -.1, .5], l2c: [.2, .22, .5], rc: [.4, .5, 1]});
  const a = 1.5708 + .3 * Math.sin(n * .35); cam([Math.cos(a) * 21, 3.4, Math.sin(a) * 21], [0, 2.4, 0], 50);
  beginFrame();
  const BY = 7.4;
  draw(UBOX, TRS([0, BY, 0], [0, 0, 0], [12.4, .2, .5]), {tint: [.55, .6, .75], em: .15});
  for (let k = -6; k <= 6; k++) draw(UBOX, TRS([k, BY + .25, 0], [0, 0, 0], [.07, .32, .3]), {tint: [.8, .85, 1], em: .2});
  const bw = kfv(n, BANDKF) + .0001; draw(UBOX, TRS([0, BY, 0], [0, 0, 0], [bw, 1.6, .8]), {tint: [.2, .8, 1], em: .9, al: .32 + .1 * Math.sin(n * 5), dw: false});
  const mk = ramp(n, 76.8, 77.4); draw(SPH, TRS([Math.sin(n * 1.3) * Math.min(bw, 6) * .1 * (1 - ramp(n, 90.5, 92.5)), BY, 0], [0, 0, 0], [.5 * mk, .5 * mk, .5 * mk]), {tint: [1, .85, .3], em: .9});
  pt(PB.add, [0, BY, 0], 2.5 * mk, [1, .85, .3], .3, 0);
  const CY = 2.2, conv = sstep(90.99, 92.0, n), core = .8 + .15 * Math.sin(n * 6) + conv * .8;
  if (n > 79.86) { draw(SPH, TRS([0, CY, 0], [0, 0, 0], [core, core, core]), {tint: [1, .95, .75], em: 1.1, al: clamp((n - 79.86) / .6, 0, 1)}); pt(PB.add, [0, CY, 0], 4 + conv * 6, [1, .85, .5], .3 + conv * .35, 0); }
  const cnt = ICONT.filter((t) => n >= t).length;
  ICONT.forEach((t, i) => {
    if (n < t - .9) return; const k = eoutB(ramp(n, t - .9, t + .1)), ang = n * (.55 + conv * 1.2) + i * 1.5708, rad = lerp(5.4, 3.4, conv); const pos = [Math.cos(ang) * rad, CY + Math.sin(ang * 2 + i) * .5, Math.sin(ang) * rad * .85];
    const fp = vlerp([Math.cos(ang) * 30, CY + 15, 25], pos, k); const s2 = k;
    const m = [mRy(n * 1.2), mRy(n * 1.5), mRy(n * 1.0), mRz(n * .8)][i];
    if (i === 0) draw(M.lico, mmul(mT(fp[0], fp[1] - .6, fp[2]), mmul(mRy(n * 1.2), mS(1.4 * s2))), {em: .2});
    if (i === 1) { draw(ATOMICON, mmul(mT(fp[0], fp[1], fp[2]), mS(1.5 * s2)), {em: .5}); for (let q = 0; q < 2; q++) draw(RING2, mmul(mT(fp[0], fp[1], fp[2]), mmul(mRy(n * 1.5 + q * 1.5), mmul(mRx(q * 1.1 + .5), mS(2.3 * s2)))), {tint: [.5, .9, 1], em: .9}); }
    if (i === 2) draw(M.crystal, mmul(mT(fp[0], fp[1], fp[2]), mmul(mRy(n * 1.3), mS(1.3 * s2))), {em: .35, sp: .6});
    if (i === 3) draw(M.amm, mmul(mT(fp[0], fp[1], fp[2]), mmul(mRy(n * .8), mS(1.9 * s2))), {em: .15});
    pt(PB.add, fp, 2.2 * s2, [.6, .8, 1], .22, 0);
    if (n > t && n < t + .5) pt(PB.add, fp, 5 * (n - t) * 2, [1, 1, 1], .8 * (1 - (n - t) / .5), 0);
    if (conv > 0) beam(PB.add, fp, [0, CY, 0], .12 + conv * .1, [1, .9, .6], .7 * conv * (.7 + .3 * Math.sin(n * 10 + i)));
    ICONP[i] = fp;
  });
  flushParticles();
  const bq = P2([0, BY, 0]);
  HUD = () => {
    const p = popK(n - 76.8, .4);
    txt('± RENTANG\nKETIDAKPASTIAN', 540, 255, 66, '#9fe7ff', {sc: p.sc, al: p.al, stroke: '#00141c', sw: 14, glow: 'rgba(60,200,255,.8)'});
    if (n < 79.86) title('HASIL PENGUKURAN\nTIDAK 100% PASTI', 77.6, 79.8, 700, 62, '#fff');
    if (n >= 79.86 && n < 82.4) title('GABUNGKAN\nBANYAK BUKTI', 79.9, 82.4, 520, 80, '#ffd24a');
    ICONT.forEach((t, i) => { if (n < t || !ICONP[i]) return; const q = P2(vadd(ICONP[i], [0, -1.45, 0])); const pp = popK(n - t, .35); chip(ICONL[i], clamp(q.x, 190, 890), q.y, 38, '#ffffff', '#101830', {sc: pp.sc, al: pp.al * (1 - conv * .6), glow: 'rgba(120,180,255,.7)'}); });
    if (n > 90.99) { const t = n - 90.99, pp = popK(t, .5); const fill = eout(clamp(t / 1.9, 0, 1)); title('SEMUA COCOK =\nSEMAKIN KUAT', 91.0, 94.28, 520, 76, '#fff');
      ctx.save(); ctx.globalAlpha = pp.al * clamp((94.2 - n) / .2, 0, 1); ctx.fillStyle = 'rgba(0,0,0,.55)'; rr(140, 1290, 800, 52, 26); ctx.fill(); const g = ctx.createLinearGradient(140, 0, 940, 0); g.addColorStop(0, '#2bd47a'); g.addColorStop(1, '#b6ff5a'); ctx.fillStyle = g; rr(144, 1294, 792 * fill, 44, 22); ctx.fill(); ctx.restore();
      txt('KEYAKINAN ' + Math.round(fill * 100) + '%', 540, 1262, 40, '#c9ffd9', {stroke: '#00220f', sw: 8, al: pp.al * clamp((94.2 - n) / .2, 0, 1)}); }
  };
}
const ICONP = [];

/* ================= SCENE 7: kesimpulan + end card ================= */
E(96.1, 'stamp', 1.4); E(96.1, 'impact', 1.3); shake(96.12, .7, .7); E(97.24, 'shimmer', 1); E(97.24, 'riser', .6); E(101.07, 'ding', 1); E(101.2, 'shimmer', .9);
function sc7() {
  BG = ['#0a1330', '#010208']; light({ld: vnorm([-.7, -.2, -.6]), fog: [.01, .015, .04], fd: .003, lc: [1.1, 1.05, .95], at: [.12, .16, .3], ab: [.03, .04, .08], l2d: [.9, .2, .3], l2c: [.05, .12, .35], rc: [.3, .6, 1]});
  const u = ramp(n, S.s7, 100), r = lerp(11, 17, eout(u)); const a = 1.3 + n * .09; cam([Math.cos(a) * r, 1 + u * 1.5, Math.sin(a) * r], [0, 0, 0], 48);
  beginFrame(); starfield(1);
  draw(M.earth, mmul(mRz(.4), mmul(mRy(n * .35), mS(3))), {sp: .5, rim: 1.0, tint: [1, 1, 1]});
  draw(M.earth, mmul(mRz(.4), mmul(mRy(n * .35), mS(3.12))), {tint: [.3, .55, 1], em: .35, al: .13, rim: 1.4});
  pt(PB.add, [0, 0, 0], 8.2, [.3, .55, 1], .12, 0);
  const t1 = ramp(n, 97.24, 98.3);
  if (t1 > 0) for (let i = 0; i < 4; i++) { const ang = n * .7 + i * 1.5708, rad = 5.6, pos = [Math.cos(ang) * rad * (.3 + .7 * t1), Math.sin(ang * 1.5) * .8, Math.sin(ang) * rad * (.3 + .7 * t1)], s2 = eoutB(t1);
    if (i === 0) draw(M.lico, mmul(mT(pos[0], pos[1] - .5, pos[2]), mmul(mRy(n), mS(.6 * s2))), {em: .25});
    if (i === 1) draw(ATOMICON, mmul(mT(pos[0], pos[1], pos[2]), mS(.7 * s2)), {em: .5});
    if (i === 2) draw(M.crystal, mmul(mT(pos[0], pos[1], pos[2]), mmul(mRy(n * 1.3), mS(.55 * s2))), {em: .35});
    if (i === 3) draw(M.amm, mmul(mT(pos[0], pos[1], pos[2]), mmul(mRy(n * .8), mS(.9 * s2))), {em: .15});
    pt(PB.add, pos, 1.4 * s2, [.7, .85, 1], .25, 0); }
  flushParticles();
  HUD = () => {
    const tS = n - 96.1; if (n > 94.4 && n < 96.1) title('USIA FOSIL BUKAN…', 94.4, 96.1, 330, 76, '#fff');
    if (tS >= 0 && n < S.end - .2) { const p = popK(tS, .22), k = 1 + Math.exp(-tS * 9) * .8; ctx.save(); ctx.translate(540, 360); ctx.rotate(-.1); ctx.scale(p.sc * k, p.sc * k); ctx.globalAlpha = p.al;
      ctx.lineWidth = 14; ctx.strokeStyle = '#ff3a2e'; ctx.shadowColor = 'rgba(255,50,30,.9)'; ctx.shadowBlur = 40; rr(-440, -125, 880, 250, 28); ctx.stroke(); ctx.shadowBlur = 0; ctx.restore();
      txt('BUKAN\nTEBAKAN', 540, 360, 112, '#ff4a3d', {rot: -.1, sc: p.sc * k, al: p.al, stroke: '#2a0300', sw: 20, glow: 'rgba(255,60,40,.9)', gb: 40}); }
    if (n > 97.24 && n < S.end) { const p = popK(n - 97.24, .45); txt('REKONSTRUKSI\nSEJARAH BUMI', 540, 1080, 82, '#ffd24a', {sc: p.sc, al: p.al * clamp((S.end - n) / .3, 0, 1), stroke: '#2a1700', sw: 18, depth: 10, glow: 'rgba(255,190,40,.8)'});
      if (n > 99.0) { const q = popK(n - 99.0, .4); txt('dari bukti yang saling mendukung', 540, 1210, 40, '#e6f0ff', {al: q.al * clamp((S.end - n) / .3, 0, 1), stroke: '#000', sw: 8, w: 700}); } }
    if (n >= S.end) { const t = n - S.end, p = popK(t, .5); ctx.save(); ctx.globalAlpha = clamp(t / .35, 0, .72); ctx.fillStyle = '#02040d'; ctx.fillRect(0, 0, 1080, 1920); ctx.restore();
      txt('SEMESTA', 540, 640, 150, '#ffffff', {sc: p.sc, al: p.al, stroke: '#001', sw: 24, glow: 'rgba(100,170,255,.9)', gb: 60}); txt('KITA', 540, 780, 170, '#ffd24a', {sc: popK(t - .12, .5).sc, al: popK(t - .12, .5).al, stroke: '#2a1700', sw: 26, depth: 14, glow: 'rgba(255,190,40,.8)', gb: 50});
      txt('IKUTI UNTUK SAINS\nYANG ASYIK & JELAS', 540, 960, 54, '#e6f0ff', {al: clamp((t - .5) / .4, 0, 1), stroke: '#000', sw: 10, w: 800});
      chip('KIRIM KE TEMAN YANG MASIH BINGUNG 👇', 540, 1130, 36, '#ffd24a', '#241400', {al: clamp((t - .9) / .4, 0, 1), sc: 1 + .03 * Math.sin(t * 6), glow: 'rgba(255,190,40,.7)'});
      txt('Sumber: NIST • Smithsonian • AMNH • USGS • Australian Museum', 540, 1300, 28, '#9fb0cc', {al: clamp((t - 1.2) / .5, 0, 1), w: 600}); }
  };
}

/* ================= caption ================= */
const CHUNKS = (() => { const out = []; let cur = []; const flush = () => { if (cur.length) out.push(cur); cur = []; };
  WORDS.forEach((w, i) => { const len = cur.reduce((a, c) => a + c.w.length + 1, 0); if (cur.length && (len + w.w.length > 20 || cur.length >= 3)) flush(); cur.push(w); if (w.b) flush(); }); flush();
  return out.map((c, i) => ({ws: c, a: c[0].a, e: (out[i + 1] ? Math.min(out[i + 1][0].a, c[c.length - 1].e + .35) : c[c.length - 1].e + .3)})); })();
function captions() {
  if (n >= S.end - .2) return; const ch = CHUNKS.find((c) => n >= c.a - .02 && n < c.e); if (!ch) return;
  const size = 68, y = 1405; ctx.save(); ctx.font = `900 ${size}px ${FONT}`; const sp = size * .42; const ws = ch.ws.map((w) => ctx.measureText(w.w.toUpperCase().replace(/[,\.\?:]+$/, '')).width); const tot = ws.reduce((a, b) => a + b, 0) + sp * (ws.length - 1); let x = 540 - tot / 2; ctx.restore();
  const pop = clamp((n - ch.a) / .12, 0, 1);
  ch.ws.forEach((w, i) => { const act = n >= w.a - .02 && n < w.e + .04 || (i === ch.ws.length - 1 && n >= w.a); const past = n >= w.e; const age = n - w.a; const s2 = act ? 1 + .1 * Math.exp(-Math.max(0, age) * 9) + .02 : 1;
    txt(w.w.toUpperCase().replace(/[,\.\?:]+$/, ''), x + ws[i] / 2, y - (act ? 6 : 0) + (1 - pop) * 24, size, act ? '#ffd24a' : '#ffffff', {sc: s2, al: clamp(pop * 1.4, 0, 1), stroke: '#000', sw: 16, glow: act ? 'rgba(255,190,40,.55)' : undefined, gb: 28}); x += ws[i] + sp; });
}
function watermark() {
  ctx.save(); ctx.globalAlpha = .82; const x = 1038, y = 1858; ctx.font = `900 40px ${FONT}`; const w = ctx.measureText('SemestaKita').width;
  ctx.shadowColor = 'rgba(0,0,0,.8)'; ctx.shadowBlur = 12; const g = ctx.createRadialGradient(x - w - 38, y - 6, 2, x - w - 30, y, 24); g.addColorStop(0, '#9ad0ff'); g.addColorStop(.6, '#2d6fd6'); g.addColorStop(1, '#0c2a6a'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x - w - 28, y, 21, 0, 6.283); ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,.8)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x - w - 28, y, 21, 7, -.5, 0, 6.283); ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle'; ctx.fillText('Semesta', x - ctx.measureText('Kita').width, y); ctx.fillStyle = '#ffd24a'; ctx.fillText('Kita', x, y); ctx.restore();
}
function transitions() {
  [S.s2, S.s3, S.s4, S.s5, S.s6, S.s7].forEach((b) => { const t = n - b; if (t > -.1 && t < .35) { const a = t < 0 ? (1 + t / .1) * .5 : Math.pow(1 - t / .35, 2); ctx.save(); ctx.globalAlpha = clamp(a, 0, 1) * .9; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 1080, 1920); ctx.restore(); } });
}

ENGINE.renderFrame = function (T) {
  n = T - OFF; const fn = n < S.s2 ? sc1 : n < S.s3 ? sc2 : n < S.s4 ? sc3 : n < S.s5 ? sc4 : n < S.s6 ? sc5 : n < S.s7 ? sc6 : sc7;
  fn();
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = 1; const g = ctx.createLinearGradient(0, 0, 0, CH); g.addColorStop(0, BG[0]); g.addColorStop(1, BG[1]); ctx.fillStyle = g; ctx.fillRect(0, 0, CW, CH);
  ctx.drawImage(glc, 0, 0); ctx.drawImage(VIG, 0, 0, CW, CH);
  ctx.save(); ctx.scale(SC, SC); HUD(); transitions(); captions(); watermark();
  ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(0, 0, 1080, 10); const gr = ctx.createLinearGradient(0, 0, 1080, 0); gr.addColorStop(0, '#ffd24a'); gr.addColorStop(1, '#ff7a3c'); ctx.fillStyle = gr; ctx.fillRect(0, 0, 1080 * clamp(T / DUR, 0, 1), 10);
  ctx.restore();
};
ENGINE.grab = () => outc.toDataURL('image/jpeg', .92);
})();

  return ENGINE;
}

export const Fosil: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<any>(null);

  useLayoutEffect(() => {
    if (!engineRef.current) engineRef.current = createEngine(canvasRef.current!);
    engineRef.current.renderFrame(frame / fps);
  }, [frame, fps]);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <canvas ref={canvasRef} style={{width: 1080, height: 1920, display: 'block'}} />
      <Audio src={staticFile('audio.mp3')} />
    </AbsoluteFill>
  );
};
