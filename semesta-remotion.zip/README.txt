Taruh Semesta.tsx & Root.tsx di src/ (ganti Root.tsx lama), folder public/ digabung ke public/ proyekmu.
Butuh: remotion, @remotion/google-fonts (sama seperti contoh sebelumnya).
Preview : npx remotion studio   (composition id: Semesta)
Render  : npx remotion render Semesta out/semesta.mp4
Durasi 8874 frame (147,9 dtk) @60fps 1080x1920 - mengikuti panjang narasi (147,4 dtk).
Atur efek suara di array SFX (bagian bawah Semesta.tsx); volume global: SFX_VOL.
