import React from 'react';
import {Composition} from 'remotion';
import {Semesta, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Semesta';

export const RemotionRoot: React.FC = () => (
  <Composition id="Semesta" component={Semesta} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
