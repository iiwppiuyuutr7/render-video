/**
 * "Sebenarnya, Bagaimana Semua Ini Terbentuk?" - dari Big Bang sampai kehidupan pertama
 * 1080x1920 (9:16) · 60 fps · ±147,9 detik (8874 frame)
 * Audio: public/narration.mp3 (voiceover) + public/sfx/*.wav (efek suara, diatur di bagian SFX paling bawah)
 * Semua waktu di file ini dalam DETIK pada audio narasi.
 */
import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Sequence,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;

export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_SECONDS = 147.9;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SECONDS * FPS);

const OUT = '#2a1a2c';
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;

/* ───────────────── timestamp kata [kata, mulai, selesai] ─────────────────
 * Hasil alignment narasi (public/narration.mp3). Kalau ada kata yang terasa
 * meleset, cukup ubah angka mulai/selesainya di sini - semua visual & caption
 * mengikuti lewat W('kata', urutanKe).
 */
const WORDS: Array<[string, number, number]> = [
  ["Segala", 0.00, 0.44],
  ["sesuatu", 0.44, 1.01],
  ["di", 1.01, 1.21],
  ["sekitar", 1.21, 1.65],
  ["kita,", 1.65, 1.97],
  ["dari", 2.19, 2.64],
  ["batu,", 2.64, 3.10],
  ["air,", 3.25, 3.60],
  ["sampai", 3.60, 4.08],
  ["tubuh", 4.08, 4.44],
  ["kita", 4.44, 4.79],
  ["sendiri,", 4.79, 5.27],
  ["punya", 5.62, 5.98],
  ["asal-usul", 5.98, 6.61],
  ["yang", 6.61, 6.82],
  ["sangat", 6.82, 7.18],
  ["panjang.", 7.30, 7.76],
  ["Jadi,", 8.22, 8.66],
  ["bagaimana", 8.85, 9.39],
  ["semua", 9.39, 9.73],
  ["ini", 9.73, 9.98],
  ["terbentuk?", 9.98, 10.33],
  ["Ceritanya", 11.09, 11.76],
  ["dimulai", 11.76, 12.43],
  ["sekitar", 12.57, 13.02],
  ["13,8", 13.02, 13.76],
  ["miliar", 13.76, 14.21],
  ["tahun", 14.21, 14.54],
  ["lalu.", 14.54, 14.86],
  ["Menurut", 15.29, 15.76],
  ["teori", 15.76, 16.23],
  ["Big", 16.23, 16.44],
  ["Bang,", 16.44, 16.65],
  ["alam", 16.98, 17.32],
  ["semesta", 17.32, 17.78],
  ["berawal", 17.78, 18.24],
  ["dari", 18.24, 18.58],
  ["kondisi", 18.58, 19.04],
  ["yang", 19.04, 19.25],
  ["sangat", 19.25, 19.58],
  ["panas", 19.58, 19.92],
  ["dan", 19.92, 20.12],
  ["padat,", 20.12, 20.46],
  ["lalu", 20.97, 21.42],
  ["ruang", 21.63, 21.93],
  ["itu", 21.93, 22.23],
  ["sendiri", 22.23, 22.65],
  ["memuai.", 22.65, 23.18],
  ["Big", 23.60, 23.83],
  ["Bang", 23.83, 24.06],
  ["bukan", 24.06, 24.43],
  ["ledakan", 24.43, 24.95],
  ["di", 24.95, 25.18],
  ["ruang", 25.18, 25.55],
  ["kosong.", 25.55, 25.92],
  ["Sejak", 26.32, 26.66],
  ["saat", 26.66, 27.01],
  ["itu,", 27.01, 27.35],
  ["alam", 27.59, 27.89],
  ["semesta", 27.89, 28.30],
  ["terus", 28.44, 28.82],
  ["mengembang", 28.82, 29.35],
  ["dan", 29.35, 29.58],
  ["mendingin.", 29.58, 30.11],
  ["Dalam", 30.48, 30.78],
  ["beberapa", 30.78, 31.31],
  ["menit", 31.31, 31.61],
  ["pertama,", 31.61, 32.03],
  ["proton", 32.30, 32.64],
  ["dan", 32.64, 32.85],
  ["neutron", 32.85, 33.32],
  ["bergabung", 33.32, 33.80],
  ["membentuk", 33.80, 34.27],
  ["inti", 34.40, 34.79],
  ["hidrogen,", 34.79, 35.32],
  ["helium,", 35.61, 36.11],
  ["dan", 36.26, 36.47],
  ["sedikit", 36.47, 36.95],
  ["litium.", 36.95, 37.43],
  ["Sekitar", 37.77, 38.29],
  ["380", 38.29, 39.15],
  ["ribu", 39.15, 39.52],
  ["tahun", 39.52, 39.90],
  ["kemudian,", 39.90, 40.56],
  ["suhunya", 40.86, 41.36],
  ["cukup", 41.36, 41.73],
  ["rendah", 41.73, 42.09],
  ["sehingga", 42.31, 42.80],
  ["inti", 42.80, 43.16],
  ["atom", 43.16, 43.52],
  ["menangkap", 43.52, 44.01],
  ["elektron,", 44.01, 44.51],
  ["dan", 44.84, 45.06],
  ["atom", 45.06, 45.42],
  ["pertama", 45.42, 45.91],
  ["pun", 45.91, 46.13],
  ["terbentuk.", 46.13, 46.62],
  ["Lalu", 47.12, 47.52],
  ["gravitasi", 47.52, 48.21],
  ["mulai", 48.21, 48.76],
  ["bekerja.", 48.76, 49.31],
  ["Wilayah", 49.68, 50.11],
  ["yang", 50.11, 50.31],
  ["lebih", 50.31, 50.62],
  ["padat", 50.62, 50.93],
  ["menarik", 50.93, 51.37],
  ["materi", 51.37, 51.80],
  ["di", 51.80, 52.00],
  ["sekitarnya.", 52.00, 52.55],
  ["Awan", 52.89, 53.28],
  ["gas", 53.28, 53.52],
  ["semakin", 53.52, 54.07],
  ["padat", 54.07, 54.46],
  ["dan", 54.46, 54.70],
  ["panas,", 54.70, 55.09],
  ["sampai", 55.27, 55.74],
  ["fusi", 55.74, 56.08],
  ["nuklir", 56.08, 56.42],
  ["menyala", 56.42, 56.90],
  ["di", 56.90, 57.11],
  ["pusatnya.", 57.11, 57.58],
  ["Lahirlah", 57.92, 58.54],
  ["bintang", 58.54, 58.98],
  ["pertama.", 58.98, 59.60],
  ["Di", 60.01, 60.23],
  ["dalam", 60.23, 60.59],
  ["bintang,", 60.59, 60.95],
  ["terbentuk", 61.12, 61.64],
  ["unsur", 61.64, 62.02],
  ["seperti", 62.02, 62.53],
  ["karbon,", 62.53, 62.91],
  ["oksigen,", 63.13, 63.71],
  ["dan", 63.71, 63.96],
  ["besi.", 63.96, 64.38],
  ["Saat", 64.79, 65.18],
  ["bintang", 65.18, 65.57],
  ["mati,", 65.57, 65.96],
  ["ledakan", 66.17, 66.65],
  ["supernova", 66.65, 67.27],
  ["menyebarkan", 67.27, 67.89],
  ["unsur-unsur", 67.89, 68.51],
  ["itu", 68.51, 68.86],
  ["ke", 68.86, 69.08],
  ["angkasa.", 69.08, 69.56],
  ["Unsur", 69.88, 70.23],
  ["yang", 70.23, 70.45],
  ["sangat", 70.45, 70.80],
  ["berat", 70.80, 71.15],
  ["bahkan", 71.32, 71.67],
  ["bisa", 71.67, 72.02],
  ["terbentuk", 72.02, 72.50],
  ["dari", 72.50, 72.85],
  ["tabrakan", 72.85, 73.33],
  ["bintang", 73.33, 73.68],
  ["neutron.", 73.68, 74.16],
  ["Artinya,", 74.49, 75.12],
  ["banyak", 75.30, 75.64],
  ["unsur", 75.64, 75.98],
  ["penyusun", 75.98, 76.44],
  ["tubuh", 76.44, 76.78],
  ["kita", 76.78, 77.12],
  ["pernah", 77.25, 77.61],
  ["terbentuk", 77.61, 78.10],
  ["di", 78.10, 78.32],
  ["dalam", 78.32, 78.67],
  ["bintang.", 78.67, 79.03],
  ["Seiring", 79.42, 79.98],
  ["waktu,", 80.11, 80.39],
  ["gravitasi", 80.58, 81.33],
  ["mengumpulkan", 81.33, 82.08],
  ["bintang,", 82.08, 82.51],
  ["gas,", 82.67, 82.93],
  ["dan", 82.93, 83.19],
  ["debu", 83.19, 83.61],
  ["menjadi", 83.61, 84.19],
  ["galaksi,", 84.19, 84.77],
  ["termasuk", 85.11, 85.67],
  ["Bima", 85.67, 86.08],
  ["Sakti,", 86.20, 86.34],
  ["tempat", 86.74, 87.01],
  ["Tata", 87.14, 87.48],
  ["Surya", 87.48, 87.82],
  ["kita", 87.82, 88.16],
  ["berada.", 88.16, 88.63],
  ["Sekitar", 88.99, 89.50],
  ["4,6", 89.50, 90.20],
  ["miliar", 90.20, 90.71],
  ["tahun", 90.71, 91.07],
  ["lalu,", 91.07, 91.44],
  ["sebuah", 91.61, 92.08],
  ["awan", 92.08, 92.43],
  ["besar", 92.43, 92.77],
  ["gas", 92.77, 92.98],
  ["dan", 92.98, 93.19],
  ["debu", 93.19, 93.53],
  ["runtuh", 93.53, 93.88],
  ["oleh", 93.88, 94.22],
  ["gravitasinya", 94.22, 94.96],
  ["sendiri.", 94.96, 95.43],
  ["Sebagian", 95.79, 96.35],
  ["besar", 96.35, 96.66],
  ["materi", 96.66, 97.09],
  ["berkumpul", 97.09, 97.53],
  ["di", 97.53, 97.72],
  ["tengah", 97.72, 98.04],
  ["dan", 98.04, 98.23],
  ["menjadi", 98.23, 98.66],
  ["Matahari.", 98.66, 99.22],
  ["Sisanya", 99.61, 100.18],
  ["membentuk", 100.18, 100.74],
  ["piringan", 100.86, 101.31],
  ["berputar,", 101.31, 101.76],
  ["tempat", 102.09, 102.43],
  ["debu", 102.43, 102.78],
  ["dan", 102.78, 102.99],
  ["batuan", 102.99, 103.46],
  ["saling", 103.46, 103.80],
  ["bertabrakan", 103.80, 104.41],
  ["hingga", 104.41, 104.75],
  ["menjadi", 104.75, 105.23],
  ["planet,", 105.23, 105.57],
  ["termasuk", 105.93, 106.39],
  ["Bumi.", 106.39, 106.72],
  ["Bumi", 107.09, 107.55],
  ["muda", 107.55, 108.01],
  ["sangat", 108.01, 108.48],
  ["panas.", 108.48, 108.94],
  ["Besi", 109.19, 109.53],
  ["bergerak", 109.53, 109.99],
  ["ke", 109.99, 110.20],
  ["dalam,", 110.20, 110.54],
  ["sementara", 110.76, 111.30],
  ["material", 111.30, 111.84],
  ["yang", 111.84, 112.02],
  ["lebih", 112.02, 112.33],
  ["ringan", 112.33, 112.63],
  ["membentuk", 112.63, 113.05],
  ["bagian", 113.05, 113.48],
  ["luar,", 113.48, 113.78],
  ["sehingga", 114.15, 114.57],
  ["terbentuklah", 114.57, 115.11],
  ["inti,", 115.11, 115.42],
  ["mantel,", 115.60, 116.09],
  ["dan", 116.38, 116.81],
  ["kerak.", 116.81, 117.51],
  ["Lalu", 117.90, 118.34],
  ["permukaannya", 118.46, 119.22],
  ["mendingin,", 119.22, 119.71],
  ["dan", 119.94, 120.19],
  ["atmosfer", 120.19, 120.75],
  ["serta", 120.75, 121.16],
  ["lautan", 121.16, 121.73],
  ["berkembang.", 121.73, 122.29],
  ["Di", 122.63, 122.86],
  ["Bumi", 122.86, 123.24],
  ["purba,", 123.24, 123.61],
  ["kehidupan", 123.83, 124.40],
  ["pertama", 124.40, 124.84],
  ["kemungkinan", 124.84, 125.40],
  ["muncul", 125.40, 125.72],
  ["dari", 125.72, 126.04],
  ["proses", 126.04, 126.36],
  ["kimia", 126.36, 126.81],
  ["alami,", 126.81, 127.25],
  ["yang", 127.50, 127.66],
  ["disebut", 127.66, 128.01],
  ["abiogenesis.", 128.24, 129.29],
  ["Bukti", 129.57, 129.90],
  ["menunjukkan", 129.90, 130.48],
  ["kehidupan", 130.48, 131.07],
  ["sudah", 131.07, 131.40],
  ["ada", 131.40, 131.73],
  ["setidaknya", 131.73, 132.31],
  ["sekitar", 132.31, 132.77],
  ["3,5", 132.91, 133.58],
  ["miliar", 133.58, 134.06],
  ["tahun", 134.06, 134.41],
  ["lalu.", 134.41, 134.76],
  ["Tapi", 135.15, 135.53],
  ["bagaimana", 135.53, 136.35],
  ["persisnya,", 136.35, 136.88],
  ["masih", 137.09, 137.36],
  ["belum", 137.36, 137.64],
  ["diketahui.", 137.64, 138.23],
  ["Dan", 138.63, 138.83],
  ["masih", 138.83, 139.15],
  ["ada", 139.15, 139.47],
  ["satu", 139.47, 139.79],
  ["pertanyaan", 139.79, 140.36],
  ["besar", 140.36, 140.68],
  ["yang", 140.68, 140.88],
  ["belum", 140.88, 141.20],
  ["terjawab:", 141.20, 141.65],
  ["mengapa", 142.01, 142.47],
  ["alam", 142.47, 142.80],
  ["semesta", 142.80, 143.25],
  ["bisa", 143.25, 143.58],
  ["ada", 143.58, 143.91],
  ["sejak", 143.91, 144.24],
  ["awal,", 144.24, 144.57],
  ["dan", 144.92, 145.15],
  ["apa", 145.15, 145.51],
  ["yang", 145.51, 145.74],
  ["terjadi", 145.74, 146.25],
  ["sebelum", 146.25, 146.76],
  ["Big", 146.76, 146.98],
  ["Bang?", 146.98, 147.21],
];

/* ───────────────────────── util ───────────────────────── */
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const easeIn = Easing.in(Easing.cubic);
const easeInOut = Easing.inOut(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9áéíóúñ-]/g, '');
/** waktu mulai kata ke-`nth` (mulai dari 0) yang cocok dengan `text` */
const W = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, s] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return s;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};
/* ───────────────────────── konteks waktu ───────────────────────── */
const TCtx = createContext(0); // detik-audio absolut
const LCtx = createContext(0); // detik sejak scene mulai
const useT = () => useContext(TCtx);
const useLT = () => useContext(LCtx);

const Scene: React.FC<{a: number; b: number; fade?: number; children?: React.ReactNode}> = ({
  a,
  b,
  fade = 0.2,
  children,
}) => {
  const t = useT();
  if (t < a || t >= b + fade + 0.05) return null;
  const lt = t - a;
  return (
    <LCtx.Provider value={lt}>
      <AbsoluteFill style={{opacity: fade > 0 ? clamp(lt / fade) : 1, overflow: 'hidden'}}>
        {children}
      </AbsoluteFill>
    </LCtx.Provider>
  );
};

type Shake = {a: number; d: number; amp: number};
const Cam: React.FC<{
  z0?: number;
  z1?: number;
  dur?: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  r0?: number;
  r1?: number;
  shakes?: Shake[];
  children?: React.ReactNode;
}> = ({z0 = 1, z1 = 1, dur = 5, x0 = 0, x1 = 0, y0 = 0, y1 = 0, r0 = 0, r1 = 0, shakes = [], children}) => {
  const lt = useLT();
  const t = useT();
  const p = easeInOut(prog(lt, 0, dur));
  let sx = 0;
  let sy = 0;
  for (const s of shakes) {
    const q = prog(t, s.a, s.d);
    if (q > 0 && q < 1) {
      const k = (1 - q) * s.amp;
      sx += Math.sin(t * 93) * k;
      sy += Math.cos(t * 71) * k;
    }
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${lerp(x0, x1, p) + sx}px,${lerp(y0, y1, p) + sy}px) scale(${lerp(z0, z1, p)}) rotate(${lerp(r0, r1, p)}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── SVG dasar ───────────────────────── */
const Defs = () => (
  <defs>
    <radialGradient id="glowYellow">
      <stop offset="0" stopColor="#fff6b0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ffc93a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff9a2e" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowCyan">
      <stop offset="0" stopColor="#e8ffff" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#6fe6ff" stopOpacity="0.55" />
      <stop offset="1" stopColor="#2fb4ff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowWhite">
      <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowBlue">
      <stop offset="0.72" stopColor="#7ccfff" stopOpacity="0.6" />
      <stop offset="1" stopColor="#7ccfff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowGreen">
      <stop offset="0" stopColor="#b8ffd0" stopOpacity="0.9" />
      <stop offset="1" stopColor="#4cff9a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowRed">
      <stop offset="0" stopColor="#ffd0c0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ff5a3a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff2a1a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="earthShade" cx="0.35" cy="0.3" r="0.9">
      <stop offset="0.5" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#000" stopOpacity="0.5" />
    </radialGradient>
    <linearGradient id="seaGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#3aa6e6" />
      <stop offset="0.45" stopColor="#1668b0" />
      <stop offset="1" stopColor="#0a2a5c" />
    </linearGradient>
    <linearGradient id="deepGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#0f4a86" />
      <stop offset="0.5" stopColor="#082a58" />
      <stop offset="1" stopColor="#030d24" />
    </linearGradient>
    <linearGradient id="sandGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#e8c98a" />
      <stop offset="1" stopColor="#b88f55" />
    </linearGradient>
    <linearGradient id="sandDeep" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#5b5b7a" />
      <stop offset="1" stopColor="#2c2c48" />
    </linearGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#fff" stopOpacity="0.3" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </linearGradient>
  </defs>
);

const S: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    width={WIDTH}
    height={HEIGHT}
    style={{position: 'absolute', left: 0, top: 0}}
  >
    <Defs />
    {children}
  </svg>
);

/* ───────────────────────── background ───────────────────────── */
const Stars: React.FC<{n?: number}> = ({n = 70}) => {
  const t = useT();
  return (
    <S>
      {Array.from({length: n}).map((_, i) => {
        const x = random(`sx${i}`) * WIDTH;
        const y = (random(`sy${i}`) * HEIGHT + t * (4 + random(`sv${i}`) * 8)) % HEIGHT;
        const r = 1.5 + random(`sr${i}`) * 3;
        const o = 0.45 + 0.55 * Math.abs(Math.sin(t * (0.8 + random(`sf${i}`) * 2) + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#fff" opacity={o} />;
      })}
    </S>
  );
};

const SpaceBG: React.FC = () => (
  <>
    <AbsoluteFill style={{background: 'radial-gradient(120% 80% at 50% 30%, #1f2570 0%, #0d123f 55%, #04061a 100%)'}} />
    <Stars />
  </>
);

const Vignette = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
    }}
  />
);

/* ───────────────────────── objek umum ───────────────────────── */
const Check: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#3ddc84'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill={color} stroke={OUT} strokeWidth={7} />
    <path d="M-22,2 L-6,20 L26,-18" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
  </g>
);

const Cross: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill="#ff4b4b" stroke={OUT} strokeWidth={7} />
    <path d="M-20,-20 L20,20 M20,-20 L-20,20" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" />
  </g>
);

const Person: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  shirt?: string;
  pants?: string;
  hair?: string;
  glasses?: boolean;
  armL?: number;
  armR?: number;
  mouth?: 'smile' | 'o' | 'flat';
  look?: number;
}> = ({x, y, s = 1, flip = false, shirt = '#4a7bb5', pants = '#2b2f55', hair = '#4a2f22', glasses = false, armL = 15, armR = 15, mouth = 'smile', look = 0}) => {
  const arm = (ang: number, side: number) => {
    const sx = side * 36;
    const sy = -172;
    const a = (ang * side * Math.PI) / 180;
    const L = 88;
    const ex = sx + Math.sin(a) * L;
    const ey = sy + Math.cos(a) * L;
    return (
      <g>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={OUT} strokeWidth={31} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={shirt} strokeWidth={20} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={13} fill="#f7efe4" stroke={OUT} strokeWidth={4} />
      </g>
    );
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={60} ry={10} fill="#000" opacity={0.2} />
      <rect x={-29} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <rect x={6} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <ellipse cx={-20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      <ellipse cx={20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      {arm(armL, -1)}
      <rect x={-42} y={-195} width={84} height={112} rx={28} fill={shirt} stroke={OUT} strokeWidth={6} />
      {arm(armR, 1)}
      <circle cx={look * 5} cy={-248} r={50} fill="#f7efe4" stroke={OUT} strokeWidth={6} />
      <path
        d={`M${-50 + look * 5},-252 A50,50 0 0 1 ${50 + look * 5},-252 Q${look * 5},-292 ${-50 + look * 5},-252Z`}
        fill={hair}
        stroke={OUT}
        strokeWidth={4}
      />
      <circle cx={-17 + look * 6} cy={-250} r={6} fill={OUT} />
      <circle cx={17 + look * 6} cy={-250} r={6} fill={OUT} />
      {glasses && (
        <g fill="none" stroke={OUT} strokeWidth={4}>
          <circle cx={-17 + look * 6} cy={-250} r={14} />
          <circle cx={17 + look * 6} cy={-250} r={14} />
          <line x1={-3 + look * 6} y1={-250} x2={3 + look * 6} y2={-250} />
        </g>
      )}
      {mouth === 'smile' && <path d={`M${-14 + look * 5},-226 Q${look * 5},-212 ${14 + look * 5},-226`} fill="none" stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
      {mouth === 'o' && <ellipse cx={look * 5} cy={-222} rx={8} ry={10} fill={OUT} />}
      {mouth === 'flat' && <line x1={-12 + look * 5} y1={-222} x2={12 + look * 5} y2={-222} stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
    </g>
  );
};

/* ───────────────────────── efek ───────────────────────── */
const Sparks: React.FC<{
  x: number;
  y: number;
  t0: number;
  n?: number;
  speed?: number;
  life?: number;
  g?: number;
  color?: string;
  size?: number;
  seed?: string;
}> = ({x, y, t0, n = 30, speed = 500, life = 1.2, g = 600, color = '#ffc85a', size = 7, seed = 'sp'}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0 || age > life) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const v = (0.3 + random(`${seed}v${i}`) * 0.7) * speed;
        const px = x + Math.cos(a) * v * age;
        const py = y + Math.sin(a) * v * age + 0.5 * g * age * age;
        const o = 1 - age / life;
        return <circle key={i} cx={px} cy={py} r={size * (0.5 + random(`${seed}r${i}`)) * o} fill={color} opacity={o} />;
      })}
    </g>
  );
};

const Ring: React.FC<{x: number; y: number; t0: number; max?: number; dur?: number; color?: string; w?: number}> = ({x, y, t0, max = 300, dur = 0.9, color = '#fff', w = 12}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (p <= 0 || p >= 1) return null;
  return <circle cx={x} cy={y} r={max * easeOut(p)} fill="none" stroke={color} strokeWidth={w * (1 - p)} opacity={1 - p * 0.7} />;
};

const Flash: React.FC<{t0: number; dur?: number; color?: string}> = ({t0, dur = 0.5, color = '#fff'}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (t < t0 || p >= 1) return null;
  return <AbsoluteFill style={{background: color, opacity: 0.85 * (1 - easeOut(p))}} />;
};

/* ───────────────────────── UI: label, caption ───────────────────────── */
const Pill: React.FC<{
  x: number;
  y: number;
  text: string;
  at: number;
  color?: string;
  size?: number;
  rot?: number;
  sub?: string;
  until?: number;
  bg?: string;
}> = ({x, y, text, at, color = '#ffb84d', size = 54, rot = 0, sub, until, bg = 'rgba(18,12,30,0.88)'}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const outP = until !== undefined ? 1 - prog(t, until - 0.2, 0.2) : 1;
  const p = pop(t, at, 0.4) * (outP > 0 ? outP : 0);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`,
        background: bg,
        border: `5px solid ${color}`,
        color: '#fff',
        padding: sub ? '12px 38px' : '14px 36px',
        borderRadius: sub ? 44 : 999,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: 2,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {text}
      {sub && <div style={{fontSize: size * 0.52, fontWeight: 600, opacity: 0.85, letterSpacing: 1}}>{sub}</div>}
    </div>
  );
};

/** catatan tulisan tangan */
const Note: React.FC<{x: number; y: number; text: string; at: number; color?: string; size?: number; rot?: number; until?: number}> = ({
  x,
  y,
  text,
  at,
  color = '#ffe27a',
  size = 62,
  rot = -4,
  until,
}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const p = eo(t, at, 0.35);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${0.8 + 0.2 * p})`,
        opacity: p,
        fontFamily: HAND,
        fontWeight: 700,
        fontSize: size,
        color,
        whiteSpace: 'nowrap',
        textShadow: '0 4px 10px rgba(0,0,0,0.55)',
      }}
    >
      {text}
    </div>
  );
};

const Caption: React.FC = () => {
  const t = useT();
  let idx = -1;
  for (let i = 0; i < WORDS.length; i++) {
    if (WORDS[i][1] <= t) idx = i;
    else break;
  }
  if (idx < 0) return null;
  const [w, s, e] = WORDS[idx];
  if (t > e + 0.28) return null;
  const sc = 0.82 + 0.18 * backOut(prog(t, s, 0.16));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '46%',
        textAlign: 'center',
        transform: `translateY(-50%) scale(${sc})`,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 92,
        color: '#fff',
        letterSpacing: -1,
        WebkitTextStroke: '12px rgba(22,12,34,0.9)',
        paintOrder: 'stroke fill',
        textShadow: '0 6px 14px rgba(0,0,0,0.55)',
        padding: '0 40px',
      }}
    >
      {w}
    </div>
  );
};


/* ───────────────────────── helper khusus video ini ───────────────────────── */
const hex = (s: string) => [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];
const mix = (a: string, b: string, p: number) => {
  const A = hex(a);
  const B = hex(b);
  const q = clamp(p);
  return `rgb(${Math.round(lerp(A[0], B[0], q))},${Math.round(lerp(A[1], B[1], q))},${Math.round(lerp(A[2], B[2], q))})`;
};

const ROCK_PTS = [92, 84, 97, 88, 79, 94, 86, 98, 82, 90, 96, 83, 93, 87]
  .map((r, i) => {
    const a = (i / 14) * Math.PI * 2;
    return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
  })
  .join(' ');

const Rock: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <polygon points={ROCK_PTS} fill="#8d7b78" stroke={OUT} strokeWidth={5.5 / s} strokeLinejoin="round" />
    <path d="M-70,-45 Q-30,-85 20,-80 Q-20,-60 -70,-45Z" fill="#b3a29d" opacity={0.8} />
    <ellipse cx={-30} cy={-14} rx={20} ry={15} fill="#6c5c5b" stroke={OUT} strokeWidth={3.5 / s} />
    <ellipse cx={35} cy={30} rx={26} ry={18} fill="#6c5c5b" stroke={OUT} strokeWidth={3.5 / s} />
  </g>
);

const Drop: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M0,-110 C46,-40 74,-6 74,36 A74,74 0 0 1 -74,36 C-74,-6 -46,-40 0,-110Z" fill="#4aa8ff" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
    <path d="M-34,10 C-40,36 -30,58 -10,66" fill="none" stroke="#fff" strokeOpacity={0.7} strokeWidth={9} strokeLinecap="round" />
  </g>
);

const StarBody: React.FC<{x: number; y: number; r: number; t: number; color?: string; core?: string; rays?: boolean; glow?: number}> = ({
  x,
  y,
  r,
  t,
  color = '#ffcf4a',
  core = '#ffe27a',
  rays = true,
  glow = 1,
}) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r={r * 2.4} fill="url(#glowYellow)" opacity={glow} />
    {rays && (
      <g transform={`rotate(${t * 12})`}>
        {Array.from({length: 12}).map((_, i) => (
          <rect key={i} x={-r * 0.09} y={-r * 1.45} width={r * 0.18} height={r * 0.4} rx={r * 0.09} fill="#ffd45a" transform={`rotate(${i * 30})`} />
        ))}
      </g>
    )}
    <circle r={r} fill={color} stroke={OUT} strokeWidth={6} />
    <circle r={r * 0.7} fill={core} />
  </g>
);

/** kisi ruang yang memuai */
const Lattice: React.FC<{cx: number; cy: number; k: number; o: number; color?: string}> = ({cx, cy, k, o, color = '#fff'}) => {
  if (o <= 0) return null;
  const sp = 110 * k;
  const n = Math.ceil(1300 / sp);
  const items: React.ReactNode[] = [];
  for (let i = -n; i <= n; i++) {
    const x = cx + i * sp;
    const y = cy + i * sp;
    if (x > -20 && x < WIDTH + 20) items.push(<line key={`v${i}`} x1={x} y1={0} x2={x} y2={HEIGHT} stroke={color} strokeOpacity={0.22 * o} strokeWidth={3} />);
    if (y > -20 && y < HEIGHT + 20) items.push(<line key={`h${i}`} x1={0} y1={y} x2={WIDTH} y2={y} stroke={color} strokeOpacity={0.22 * o} strokeWidth={3} />);
  }
  for (let i = -n; i <= n; i++) {
    for (let j = -n; j <= n; j++) {
      const x = cx + i * sp;
      const y = cy + j * sp;
      if (x > 0 && x < WIDTH && y > 0 && y < HEIGHT && (i + j) % 2 === 0) items.push(<circle key={`d${i}_${j}`} cx={x} cy={y} r={7} fill={color} opacity={0.75 * o} />);
    }
  }
  return <g>{items}</g>;
};

const Thermo: React.FC<{x: number; y: number; level: number; color: string}> = ({x, y, level, color}) => (
  <g transform={`translate(${x} ${y})`}>
    <rect x={-30} y={-260} width={60} height={420} rx={30} fill="#f4f0e6" stroke={OUT} strokeWidth={8} />
    <circle cx={0} cy={170} r={56} fill="#f4f0e6" stroke={OUT} strokeWidth={8} />
    <rect x={-30} y={-260} width={60} height={420} rx={30} fill="none" stroke={OUT} strokeWidth={8} />
    <rect x={-14} y={160 - 400 * level} width={28} height={400 * level + 10} rx={10} fill={color} />
    <circle cx={0} cy={170} r={40} fill={color} />
  </g>
);

/** awan gas yang runtuh ke pusat */
const GasCloud: React.FC<{
  cx: number;
  cy: number;
  n?: number;
  c0: string;
  c1: string;
  tc: number;
  dc: number;
  spin?: number;
  maxR?: number;
  seed: string;
  opacity?: number;
  sk?: number;
}> = ({cx, cy, n = 40, c0, c1, tc, dc, spin = 0, maxR = 520, seed, opacity = 0.4, sk = 1}) => {
  const t = useT();
  const p = easeInOut(prog(t, tc, dc));
  return (
    <g opacity={opacity > 0 ? 1 : 0}>
      {Array.from({length: n}).map((_, i) => {
        const R0 = 120 + random(`${seed}r${i}`) * (maxR - 120);
        const R = lerp(R0, R0 * 0.14, p);
        const th = random(`${seed}t${i}`) * Math.PI * 2 + t * 0.06 + spin * p * 4;
        const size = lerp(60 + random(`${seed}s${i}`) * 70, 34 + random(`${seed}s${i}`) * 26, p) * sk;
        return <circle key={i} cx={cx + Math.cos(th) * R} cy={cy + Math.sin(th) * R * 0.95} r={size} fill={mix(c0, c1, p)} opacity={opacity} />;
      })}
    </g>
  );
};

const Nucleon: React.FC<{x: number; y: number; proton: boolean; s?: number}> = ({x, y, proton, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={34} fill={proton ? '#ff5a5a' : '#8f9bb8'} stroke={OUT} strokeWidth={6} />
    <circle cx={-10} cy={-12} r={9} fill="#fff" opacity={0.6} />
    {proton && <path d="M-9,0 H9 M0,-9 V9" stroke="#fff" strokeWidth={6} strokeLinecap="round" />}
  </g>
);

const Atom: React.FC<{x: number; y: number; s?: number; t: number; np: number; nn: number; e: number; amp?: number}> = ({x, y, s = 1, t, np, nn, e, amp = 1}) => {
  const balls: Array<[number, number, boolean]> = [];
  const total = np + nn;
  for (let i = 0; i < total; i++) {
    const a = (i / Math.max(total, 1)) * Math.PI * 2 + 0.6;
    const r = total === 1 ? 0 : total <= 4 ? 22 : 40;
    balls.push([Math.cos(a) * r, Math.sin(a) * r, i % 2 === 0 ? i / 2 < np : i < np]);
  }
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {[130, 190].slice(0, e > 1 ? 2 : 1).map((r, i) => (
        <ellipse key={i} cx={0} cy={0} rx={r} ry={r * 0.9} fill="none" stroke="#fff" strokeOpacity={0.35 * amp} strokeWidth={4} strokeDasharray="10 12" transform={`rotate(${i * 60})`} />
      ))}
      {balls.map(([bx, by, pr], i) => (
        <Nucleon key={i} x={bx} y={by} proton={pr} s={total <= 4 ? 0.75 : 0.62} />
      ))}
      {Array.from({length: e}).map((_, i) => {
        const r = [130, 190][i % 2];
        const a = t * (3 - i) + i * 3;
        return (
          <g key={i} opacity={amp} transform={`rotate(${i * 60})`}>
            <circle cx={Math.cos(a) * r} cy={Math.sin(a) * r * 0.9} r={20} fill="#ffe27a" stroke={OUT} strokeWidth={5} />
            <path d={`M${Math.cos(a) * r - 8},${Math.sin(a) * r * 0.9} h16`} stroke={OUT} strokeWidth={5} strokeLinecap="round" />
          </g>
        );
      })}
    </g>
  );
};

const ElementChip: React.FC<{x: number; y: number; sym: string; num: number; name: string; color: string; at: number}> = ({x, y, sym, num, name, color, at}) => {
  const t = useT();
  if (t < at) return null;
  const p = pop(t, at, 0.5);
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      <rect x={-85} y={-95} width={170} height={190} rx={24} fill={color} stroke={OUT} strokeWidth={8} />
      <text x={-62} y={-52} fontFamily={FONT} fontWeight={800} fontSize={34} fill="#fff" stroke={OUT} strokeWidth={7} paintOrder="stroke">
        {num}
      </text>
      <text x={0} y={26} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={92} fill="#fff" stroke={OUT} strokeWidth={12} paintOrder="stroke">
        {sym}
      </text>
      <text x={0} y={72} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={30} fill="#fff" stroke={OUT} strokeWidth={7} paintOrder="stroke">
        {name}
      </text>
    </g>
  );
};

/** galaksi spiral (stars bergerak dari acak menuju bentuk spiral) */
const GALAXY_N = 520;
const galaxyStar = (i: number) => {
  const arm = i % 2;
  const r = 30 + Math.pow(random(`gr${i}`), 0.8) * 420;
  const th = arm * Math.PI + r * 0.0125 + (random(`gj${i}`) - 0.5) * 0.7;
  return {r, th, size: 3.5 + random(`gs${i}`) * 6, col: ['#fff', '#bfe0ff', '#ffd9f2', '#ffe9a8'][i % 4]};
};

const Galaxy: React.FC<{cx: number; cy: number; p: number; rot: number; tilt?: number}> = ({cx, cy, p, rot, tilt = 0.78}) => (
  <g>
    <circle cx={cx} cy={cy} r={190} fill="url(#glowYellow)" opacity={0.9 * p} />
    {Array.from({length: GALAXY_N}).map((_, i) => {
      const g = galaxyStar(i);
      const sx = cx + (random(`gx${i}`) - 0.5) * 1500;
      const sy = cy + (random(`gy${i}`) - 0.5) * 1800;
      const fx = cx + Math.cos(g.th + rot) * g.r;
      const fy = cy + Math.sin(g.th + rot) * g.r * tilt;
      return <circle key={i} cx={lerp(sx, fx, p)} cy={lerp(sy, fy, p)} r={g.size} fill={g.col} opacity={0.9} />;
    })}
  </g>
);

const Cell: React.FC<{x: number; y: number; s?: number; t: number}> = ({x, y, s = 1, t}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={150} fill="url(#glowGreen)" opacity={0.55} />
    <ellipse rx={92 + Math.sin(t * 3) * 4} ry={78 + Math.cos(t * 3) * 4} fill="#8ff0b0" stroke={OUT} strokeWidth={8} />
    <ellipse rx={64} ry={52} fill="#c9ffd8" opacity={0.7} />
    <circle cx={-14} cy={-6} r={20} fill="#3ab87a" stroke={OUT} strokeWidth={5} />
    {[[30, 20], [-34, 28], [24, -26]].map(([cx, cy], i) => (
      <circle key={i} cx={cx} cy={cy} r={8} fill="#fff" opacity={0.8} />
    ))}
    <path d="M60,40 q36,10 56,-12" fill="none" stroke="#3ab87a" strokeWidth={7} strokeLinecap="round" />
  </g>
);

/* ═══════════════════════════ SCENES ═══════════════════════════ */

/* 1 ─ hook (0 – 11.09) */
const SceneHook = () => {
  const t = useT();
  const tB = W('batu');
  const tA = W('air');
  const tT = W('tubuh', 0);
  const tJ = W('Jadi');
  const titleO = Math.min(eo(t, 0.15, 0.6), 1 - prog(t, tJ + 0.3, 0.6));
  const bob = (k: number) => Math.sin(t * 2 + k) * 10;
  const fade = 1 - 0.85 * eo(t, tJ, 0.6);
  const q = pop(t, W('bagaimana', 0), 0.6);
  return (
    <>
      <SpaceBG />
      <S>
        <g opacity={fade}>
          <g transform={`translate(0 ${bob(0)})`}>
            <g transform={`translate(230 1300) scale(${pop(t, tB, 0.45)})`}>
              <circle r={170} fill="url(#glowWhite)" opacity={0.18} />
              <Rock x={0} y={0} s={1.2} rot={Math.sin(t) * 8} />
            </g>
          </g>
          <g transform={`translate(0 ${bob(2)})`}>
            <g transform={`translate(540 1300) scale(${pop(t, tA, 0.45)})`}>
              <circle r={170} fill="url(#glowBlue)" opacity={0.5} />
              <Drop x={0} y={0} s={1.2} />
            </g>
          </g>
          <g transform={`translate(0 ${bob(4)})`}>
            <g transform={`translate(850 1470) scale(${pop(t, tT, 0.45)})`}>
              <Person x={0} y={0} s={1.0} shirt="#e38b3d" mouth="smile" />
            </g>
          </g>
        </g>
        {t >= W('bagaimana', 0) && (
          <g transform={`translate(540 1330) scale(${q})`}>
            <circle r={230} fill="url(#glowYellow)" opacity={0.5} />
          </g>
        )}
      </S>
      <Pill x={230} y={1070} text="BATU" at={tB} color="#c9bcb8" size={46} until={tJ} />
      <Pill x={540} y={1070} text="AIR" at={tA} color="#7ccfff" size={46} until={tJ} />
      <Pill x={850} y={1070} text="TUBUH KITA" at={tT} color="#ffb06a" size={46} until={tJ} />
      <Note x={540} y={1330} text="?" at={W('bagaimana', 0)} size={340} color="#ffe27a" rot={5} />
      <div
        style={{
          position: 'absolute',
          top: 150,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: titleO,
          transform: `translateY(${(1 - titleO) * -30}px)`,
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          textShadow: '0 6px 18px rgba(0,0,0,0.6)',
        }}
      >
        <div style={{fontSize: 50, letterSpacing: 8, color: '#ffd45a'}}>SEBENARNYA,</div>
        <div style={{fontSize: 96, marginTop: 8}}>BAGAIMANA</div>
        <div style={{fontSize: 74, color: '#8ff0ff'}}>SEMUA INI TERBENTUK?</div>
      </div>
    </>
  );
};

/* 2 ─ 13,8 miliar tahun lalu (11.09 – 15.29) */
const SceneAgo = () => {
  const lt = useLT();
  const t138 = W('13,8');
  const spin = lt * lt * 40;
  return (
    <>
      <SpaceBG />
      <Cam z0={1.06} z1={1} dur={4.2}>
        <S>
          {[0, 1, 2].map((i) => {
            const p = (lt * 0.7 + i / 3) % 1;
            return <circle key={i} cx={540} cy={1180} r={260 + (1 - p) * 360} fill="none" stroke="#8ff0ff" strokeWidth={8} opacity={p * 0.6} />;
          })}
          <g transform="translate(540 1180)">
            <circle r={250} fill="#fffaf0" stroke={OUT} strokeWidth={10} />
            {Array.from({length: 12}).map((_, i) => (
              <line key={i} x1={0} y1={-212} x2={0} y2={-188} stroke={OUT} strokeWidth={8} strokeLinecap="round" transform={`rotate(${i * 30})`} />
            ))}
            <line x1={0} y1={0} x2={0} y2={-170} stroke={OUT} strokeWidth={10} strokeLinecap="round" transform={`rotate(${-spin * 3})`} />
            <line x1={0} y1={0} x2={0} y2={-110} stroke="#a3261c" strokeWidth={14} strokeLinecap="round" transform={`rotate(${-spin * 0.4})`} />
            <circle r={14} fill={OUT} />
          </g>
          <path d="M360,880 A190,190 0 0 1 720,880" fill="none" stroke="#ffd45a" strokeWidth={14} strokeLinecap="round" />
          <path d="M360,880 l10,-34 M360,880 l36,12" stroke="#ffd45a" strokeWidth={14} strokeLinecap="round" fill="none" />
        </S>
      </Cam>
      <Pill x={540} y={600} text="13,8 MILIAR" sub="TAHUN LALU" at={t138} color="#ffd45a" size={80} />
    </>
  );
};

/* 3 ─ Big Bang: panas, padat, memuai (15.29 – 23.60) */
const SceneBang = () => {
  const t = useT();
  const tAlam = W('alam', 0);
  const tPad = W('padat', 0);
  const tLalu = W('lalu', 1);
  const tRuang = W('ruang', 0);
  const grow = eo(t, 15.5, 1.4);
  const hot = t >= tAlam;
  const r = hot ? 64 + Math.sin(t * 12) * 5 : lerp(5, 28, grow);
  const exp = eo(t, tLalu, 2.6);
  const k = lerp(0.7, 1.9, exp);
  const ballO = 1 - 0.65 * exp;
  const pulse = 0.7 + 0.3 * Math.sin(t * 10);
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(90% 60% at 50% 55%, ${mix('#3a1230', '#5b1f3a', exp)} 0%, #12061f 70%, #07030f 100%)`}} />
      <Stars n={50} />
      <S>
        <Lattice cx={540} cy={1150} k={k} o={exp} color="#8ff0ff" />
        <g opacity={ballO}>
          <circle cx={540} cy={1150} r={r * (hot ? 5 : 3)} fill="url(#glowYellow)" opacity={0.9 * pulse} />
          {hot && <circle cx={540} cy={1150} r={r * 3} fill="url(#glowRed)" opacity={0.55} />}
          <circle cx={540} cy={1150} r={r} fill="#fff7c8" stroke={hot ? '#ff7a2e' : '#ffd45a'} strokeWidth={hot ? 10 : 5} />
          {hot &&
            [0, 1].map((i) => {
              const p = (t * 1.2 + i / 2) % 1;
              return <circle key={i} cx={540} cy={1150} r={r + p * 220} fill="none" stroke="#ff9a2e" strokeWidth={10 * (1 - p)} opacity={1 - p} />;
            })}
        </g>
        {hot && <Thermo x={930} y={1180} level={0.95} color="#ff4b3a" />}
        {t >= tLalu && <Ring x={540} y={1150} t0={tLalu} max={600} color="#8ff0ff" w={14} />}
      </S>
      <Pill x={540} y={600} text="TEORI BIG BANG" at={W('teori')} until={tAlam} color="#ffd45a" size={62} />
      <Pill x={540} y={600} text="SANGAT PANAS" at={W('sangat', 1)} until={tPad} color="#ff7a4a" size={62} />
      <Pill x={540} y={600} text="DAN PADAT" at={tPad} until={tLalu} color="#ffb84d" size={62} />
      <Pill x={540} y={600} text="RUANG MEMUAI" at={tRuang} color="#8ff0ff" size={68} />
    </>
  );
};

/* 4 ─ bukan ledakan biasa · mengembang & mendingin (23.60 – 30.48) */
const SceneNotBlast = () => {
  const t = useT();
  const lt = useLT();
  const tBu = W('bukan', 0);
  const tLed = W('ledakan', 0);
  const tSej = W('Sejak');
  const cool = eo(t, tSej, 3.6);
  const burst = pop(t, 23.7, 0.45) * (1 - eo(t, tSej - 0.1, 0.5));
  const star: string[] = [];
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    const rr = i % 2 === 0 ? 300 : 170;
    star.push(`${(Math.cos(a) * rr).toFixed(1)},${(Math.sin(a) * rr).toFixed(1)}`);
  }
  const k = lerp(1.0, 1.9, eo(t, tSej, 4));
  return (
    <>
      <AbsoluteFill style={{background: mix('#4a1630', '#0b1840', cool)}} />
      <Stars n={50} />
      <S>
        <Lattice cx={540} cy={1150} k={k} o={eo(t, tSej, 0.8)} color="#8ff0ff" />
        {burst > 0.01 && (
          <g transform={`translate(540 1150) scale(${burst}) rotate(${lt * 8})`}>
            <polygon points={star.join(' ')} fill="#ff9a2e" stroke={OUT} strokeWidth={10} strokeLinejoin="round" />
            <circle r={150} fill="#ffe27a" stroke={OUT} strokeWidth={8} />
          </g>
        )}
        {t >= tLed && burst > 0.01 && <Cross x={540} y={1150} s={pop(t, tLed, 0.45) * 3.2} />}
        {t >= tSej && <Thermo x={930} y={1180} level={lerp(0.95, 0.12, cool)} color={mix('#ff4b3a', '#3a8bff', cool)} />}
        {/* galaksi kecil bergerak menjauh */}
        {t >= tSej + 0.4 &&
          [0, 1, 2, 3, 4, 5].map((i) => {
            const a = (i / 6) * Math.PI * 2 + 0.4;
            const d = 120 + 260 * eo(t, tSej + 0.4, 3.5);
            return <circle key={i} cx={540 + Math.cos(a) * d * 1.3} cy={1150 + Math.sin(a) * d * 1.1} r={14} fill="#ffe27a" stroke={OUT} strokeWidth={4} />;
          })}
      </S>
      <Pill x={540} y={600} text="BUKAN LEDAKAN BIASA" at={tBu} until={tSej} color="#ff6a5a" size={54} />
      <Note x={540} y={1530} text="di ruang kosong?" at={W('ruang', 1)} until={tSej} size={80} color="#fff" rot={-3} />
      <Pill x={540} y={600} text="TERUS MENGEMBANG" at={W('mengembang')} until={W('mendingin', 0)} color="#8ff0ff" size={58} />
      <Pill x={540} y={600} text="DAN MENDINGIN" at={W('mendingin', 0)} color="#7ccfff" size={58} />
    </>
  );
};

/* 5 ─ proton & neutron → inti ringan (30.48 – 37.77) */
const NUC_TARGETS: Array<[number, number, boolean]> = [
  [200, 1250, true], // H
  [514, 1220, true], [566, 1220, false], [514, 1272, false], [566, 1272, true], // He (2p 2n)
  [850, 1190, true], [902, 1190, false], [824, 1240, true], [876, 1240, false], [928, 1240, true], [850, 1290, false], [902, 1290, false], // Li
];

const SceneNuclei = () => {
  const t = useT();
  const tPro = W('proton');
  const tNeu = W('neutron', 0);
  const tBerg = W('bergabung');
  const tH = W('hidrogen');
  const tHe = W('helium');
  const tLi = W('litium');
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(100% 70% at 50% 45%, #2a2a78 0%, #12123f 60%, #070720 100%)'}} />
      <Stars n={40} />
      <S>
        {/* partikel bebas */}
        {Array.from({length: 14}).map((_, i) => {
          const x = 140 + random(`fx${i}`) * 800 + Math.sin(t * 1.4 + i) * 40;
          const y = 980 + random(`fy${i}`) * 600 + Math.cos(t * 1.2 + i) * 40;
          const o = 1 - eo(t, tBerg, 0.9);
          if (o <= 0.01 || t < 30.7) return null;
          return <Nucleon key={i} x={x} y={y} proton={i % 2 === 0} s={0.8 * pop(t, 30.7 + i * 0.05, 0.4)} />;
        })}
        {/* nukleon yang bergabung */}
        {NUC_TARGETS.map(([tx, ty, pr], i) => {
          const sx = 140 + random(`nx${i}`) * 800;
          const sy = 980 + random(`ny${i}`) * 600;
          const p = easeInOut(prog(t, tBerg + i * 0.05, 1.3));
          const wig = (1 - p) * 30;
          if (t < tPro) return null;
          return <Nucleon key={i} x={lerp(sx, tx, p) + Math.sin(t * 3 + i) * wig} y={lerp(sy, ty, p) + Math.cos(t * 2.4 + i) * wig} proton={pr} s={0.95 * pop(t, tPro + (pr ? 0 : 0.1), 0.4)} />;
        })}
        {t >= tH && <Ring x={200} y={1250} t0={tH} max={150} color="#ff8a8a" />}
        {t >= tHe && <Ring x={540} y={1246} t0={tHe} max={170} color="#ffd45a" />}
        {t >= tLi && <Ring x={870} y={1250} t0={tLi - 0.5} max={190} color="#8ff0ff" />}
      </S>
      <Pill x={540} y={600} text="BEBERAPA MENIT" sub="PERTAMA" at={W('beberapa')} until={tPro} color="#ffd45a" size={62} />
      <Note x={250} y={700} text="proton" at={tPro} until={tBerg} size={84} color="#ff8a8a" rot={-6} />
      <Note x={800} y={700} text="neutron" at={tNeu} until={tBerg} size={84} color="#c9d4f0" rot={5} />
      <Pill x={540} y={600} text="INTI ATOM RINGAN" at={tBerg + 0.4} color="#8ff0ff" size={58} until={tH + 0.6} />
      <Pill x={200} y={1440} text="HIDROGEN" at={tH} color="#ff8a8a" size={38} />
      <Pill x={540} y={1440} text="HELIUM" at={tHe} color="#ffd45a" size={38} />
      <Pill x={870} y={1440} text="LITIUM" at={tLi} color="#8ff0ff" size={38} />
    </>
  );
};

/* 6 ─ 380 ribu tahun: atom pertama (37.77 – 47.12) */
const SceneAtom = () => {
  const t = useT();
  const t380 = W('380');
  const tSuhu = W('suhunya');
  const tSeh = W('sehingga', 0);
  const tMeng = W('menangkap');
  const tAtom = W('atom', 1);
  const tTerb = W('terbentuk', 1);
  const cool = eo(t, tSuhu, 1.4);
  const cap = eo(t, tMeng, 1.1);
  const amp = prog(t, tMeng + 0.5, 0.8);
  return (
    <>
      <AbsoluteFill style={{background: `radial-gradient(100% 70% at 50% 50%, ${mix('#5a2a6a', '#1c3a8a', cool)} 0%, #0d1040 65%, #05061a 100%)`}} />
      <Stars n={50} />
      <S>
        <g transform="translate(540 1200)">
          {/* inti helium */}
          <Atom x={0} y={0} s={1.7} t={t} np={2} nn={2} e={0} amp={0} />
        </g>
        {/* elektron bebas masuk ke orbit */}
        {[0, 1].map((i) => {
          const r = [130, 190][i] * 1.1;
          const a = t * (3 - i) + i * 3;
          const fx = 540 + Math.cos(a) * r;
          const fy = 1200 + Math.sin(a) * r * 0.9;
          const sx = 540 + (i === 0 ? -460 : 470) + Math.sin(t * 2 + i) * 40;
          const sy = 900 + i * 650 + Math.cos(t * 1.7 + i) * 50;
          const vis = t >= tSuhu;
          if (!vis) return null;
          return (
            <g key={i}>
              <circle cx={lerp(sx, fx, cap)} cy={lerp(sy, fy, cap)} r={22} fill="#ffe27a" stroke={OUT} strokeWidth={5} />
              <path d={`M${lerp(sx, fx, cap) - 9},${lerp(sy, fy, cap)} h18`} stroke={OUT} strokeWidth={5} strokeLinecap="round" />
            </g>
          );
        })}
        {amp > 0 &&
          [143, 209].map((r, i) => (
            <ellipse key={i} cx={540} cy={1200} rx={r} ry={r * 0.9} fill="none" stroke="#fff" strokeOpacity={0.4 * amp} strokeWidth={4} strokeDasharray="10 12" transform={`rotate(${i * 60} 540 1200)`} />
          ))}
        <circle cx={540} cy={1200} r={90} fill="url(#glowCyan)" opacity={0.4 * amp} />
        {t >= tAtom && <Ring x={540} y={1200} t0={tTerb - 0.1} max={420} color="#8ff0ff" w={14} />}
        {t >= tTerb && <Check x={880} y={1020} s={pop(t, tTerb, 0.45)} />}
        {t >= tSuhu && <Thermo x={160} y={1180} level={lerp(0.9, 0.2, cool)} color={mix('#ff4b3a', '#3a8bff', cool)} />}
      </S>
      <Pill x={540} y={600} text="380.000 TAHUN" sub="KEMUDIAN" at={t380} until={tSuhu} color="#ffd45a" size={66} />
      <Pill x={540} y={600} text="SUHU TURUN" at={tSuhu} until={tSeh} color="#7ccfff" size={64} />
      <Pill x={540} y={600} text="INTI MENANGKAP ELEKTRON" at={tSeh} until={tAtom} color="#ffe27a" size={46} />
      <Pill x={540} y={600} text="ATOM PERTAMA" at={tAtom} color="#6fe6a0" size={68} />
    </>
  );
};

/* 7 ─ gravitasi → bintang pertama (47.12 – 60.01) */
const SceneStar = () => {
  const t = useT();
  const tGr = W('gravitasi', 0);
  const tWil = W('Wilayah');
  const tAwan = W('Awan');
  const tFusi = W('fusi');
  const tNyala = W('menyala');
  const tLahir = W('Lahirlah');
  const gasO = 0.42 * (1 - eo(t, tNyala + 0.3, 1.5));
  const heat = eo(t, tAwan, 2.6);
  const star = pop(t, tLahir, 0.6);
  return (
    <>
      <SpaceBG />
      <Cam z0={1.0} z1={1.06} dur={12.9} shakes={[{a: tNyala, d: 0.7, amp: 10}]}>
        <S>
          <GasCloud cx={540} cy={1150} n={44} c0="#8a6bff" c1="#ff8a3a" tc={tWil} dc={tNyala - tWil} seed="g1" opacity={gasO} maxR={560} sk={0.7} />
          {/* panah gravitasi */}
          {t >= tGr && t < tAwan &&
            Array.from({length: 8}).map((_, i) => {
              const a = (i / 8) * Math.PI * 2;
              const p = (t * 0.8 + i / 8) % 1;
              const R = lerp(520, 330, p);
              const x = 540 + Math.cos(a) * R;
              const y = 1150 + Math.sin(a) * R;
              return <path key={i} d="M0,-20 L36,0 L0,20Z" fill="#ffe27a" stroke={OUT} strokeWidth={4} transform={`translate(${x} ${y}) rotate(${(a * 180) / Math.PI + 180})`} opacity={eo(t, tGr, 0.4)} />;
            })}
          {/* wilayah lebih padat */}
          {t >= W('lebih', 0) && t < tAwan && <circle cx={540} cy={1150} r={260} fill="none" stroke="#ffe27a" strokeWidth={6} strokeDasharray="16 14" opacity={0.9} />}
          {t >= tAwan && t < tNyala && <circle cx={540} cy={1150} r={lerp(120, 40, heat)} fill={mix('#ffb06a', '#fff7c8', heat)} opacity={0.5 + 0.4 * heat} />}
          {t >= tNyala && t < tLahir + 0.5 && <circle cx={540} cy={1150} r={lerp(30, 130, prog(t, tNyala, 1.5))} fill="url(#glowYellow)" />}
          {t >= tNyala && <Ring x={540} y={1150} t0={tNyala} max={520} color="#fff7b0" w={16} />}
          {t >= tNyala && <Sparks x={540} y={1150} t0={tNyala} n={40} speed={600} life={1.4} g={0} color="#ffe27a" size={9} seed="ign" />}
          {t >= tLahir && (
            <g transform={`translate(540 1150) scale(${star})`}>
              <StarBody x={0} y={0} r={130} t={t} />
            </g>
          )}
        </S>
      </Cam>
      <Flash t0={tNyala} dur={0.5} color="#fff4c8" />
      <Pill x={540} y={600} text="GRAVITASI" sub="MULAI BEKERJA" at={tGr} until={tWil} color="#ffd45a" size={66} />
      <Pill x={540} y={600} text="WILAYAH LEBIH PADAT" at={tWil} until={tAwan} color="#ffe27a" size={50} />
      <Pill x={540} y={600} text="SEMAKIN PADAT & PANAS" at={tAwan} until={tFusi} color="#ff9a4a" size={50} />
      <Pill x={540} y={600} text="FUSI NUKLIR MENYALA" at={tFusi} until={tLahir} color="#fff7b0" size={52} />
      <Pill x={540} y={600} text="BINTANG PERTAMA" at={W('bintang', 0)} color="#ffd45a" size={66} />
    </>
  );
};

/* 8 ─ di dalam bintang → supernova → tabrakan bintang neutron (60.01 – 74.49) */
const SceneForge = () => {
  const t = useT();
  const tDalam = W('dalam', 1);
  const tUnsur = W('terbentuk', 2);
  const tK = W('karbon');
  const tO = W('oksigen');
  const tFe = W('besi');
  const tMati = W('mati');
  const tLed = W('ledakan', 1);
  const tSN = W('supernova');
  const tUn2 = W('Unsur', 1);
  const tTab = W('tabrakan');
  const tCol = tTab + 0.5;
  const inStar = t < tLed;
  const swell = eo(t, tMati - 0.2, tLed - tMati + 0.2);
  const rStar = lerp(300, 380, swell);
  const exploded = t >= tLed;
  const ex = eo(t, tLed, 2.2);
  const nsPhase = t >= tUn2 - 0.3;
  const orbit = easeIn(prog(t, tUn2 + 0.2, tCol - tUn2 - 0.2));
  const oR = lerp(300, 0, orbit);
  const ang = (t - tUn2) * (2 + orbit * 16);
  return (
    <>
      <SpaceBG />
      <Cam z0={1.0} z1={1.05} dur={14.5} shakes={[{a: tLed, d: 1.0, amp: 18}, {a: tCol, d: 0.8, amp: 16}]}>
        <S>
          {inStar && (
            <g transform="translate(540 1150)">
              <circle r={rStar * 1.9} fill="url(#glowYellow)" opacity={0.7} />
              <circle r={rStar} fill={mix('#ff8a3a', '#ff4b2a', swell)} stroke={OUT} strokeWidth={9} />
              <circle r={rStar * 0.7} fill={mix('#ffcf4a', '#ff8a3a', swell)} />
              <circle r={rStar * 0.38} fill="#fff7c8" />
              {Array.from({length: 10}).map((_, i) => {
                const a = (i / 10) * Math.PI * 2 + t * 0.4;
                return <circle key={i} cx={Math.cos(a) * rStar * 0.55} cy={Math.sin(a) * rStar * 0.55} r={14} fill="#fff" opacity={0.35} />;
              })}
            </g>
          )}
          {/* chip unsur */}
          {t < tMati + 0.2 && (
            <>
              <ElementChip x={250} y={640} sym="C" num={6} name="Karbon" color="#4a4f78" at={tK} />
              <ElementChip x={540} y={560} sym="O" num={8} name="Oksigen" color="#e0524b" at={tO} />
              <ElementChip x={830} y={640} sym="Fe" num={26} name="Besi" color="#6d7a9a" at={tFe} />
            </>
          )}
          {/* supernova */}
          {exploded && !nsPhase && (
            <g transform="translate(540 1150)">
              <circle r={lerp(40, 520, ex)} fill="url(#glowRed)" opacity={1 - ex * 0.7} />
              <circle r={lerp(20, 480, ex)} fill="none" stroke="#fff" strokeWidth={22 * (1 - ex)} opacity={1 - ex} />
              {Array.from({length: 54}).map((_, i) => {
                const a = random(`sa${i}`) * Math.PI * 2;
                const v = 200 + random(`sv${i}`) * 700;
                const d = v * ex * 1.1;
                const col = ['#6a6ff0', '#ff5a5a', '#aab2c8', '#ffd45a'][i % 4];
                return <circle key={i} cx={Math.cos(a) * d} cy={Math.sin(a) * d} r={9 + random(`sr${i}`) * 9} fill={col} stroke={OUT} strokeWidth={3} opacity={1 - ex * 0.5} />;
              })}
            </g>
          )}
          {/* bintang neutron */}
          {nsPhase && t < tCol && (
            <g transform="translate(540 1150)">
              {[0, 1].map((i) => {
                const a = ang + i * Math.PI;
                return (
                  <g key={i} transform={`translate(${Math.cos(a) * oR} ${Math.sin(a) * oR * 0.6})`}>
                    <circle r={110} fill="url(#glowCyan)" opacity={0.8} />
                    <circle r={46} fill="#e8fbff" stroke={OUT} strokeWidth={7} />
                  </g>
                );
              })}
            </g>
          )}
          {t >= tCol && (
            <g transform="translate(540 1150)">
              <circle r={lerp(60, 560, eo(t, tCol, 1.2))} fill="url(#glowYellow)" opacity={1 - eo(t, tCol, 1.6)} />
              <Ring x={0} y={0} t0={tCol} max={560} color="#fff" w={20} />
            </g>
          )}
          {t >= tCol && <Sparks x={540} y={1150} t0={tCol} n={60} speed={700} life={1.6} g={0} color="#ffe27a" size={10} seed="col" />}
        </S>
      </Cam>
      <Flash t0={tLed} dur={0.6} color="#ffd9b0" />
      <Flash t0={tCol} dur={0.7} color="#ffffff" />
      <Pill x={540} y={330} text="DI DALAM BINTANG" at={tDalam} until={tUnsur} color="#ffd45a" size={56} />
      <Pill x={540} y={330} text="UNSUR BARU TERBENTUK" at={tUnsur} until={tMati} color="#8ff0ff" size={52} />
      <Pill x={540} y={600} text="BINTANG MATI" at={tMati} until={tSN} color="#ff7a4a" size={60} />
      <Pill x={540} y={600} text="SUPERNOVA" at={tSN} until={tUn2} color="#ffb84d" size={76} />
      <Pill x={540} y={330} text="UNSUR SANGAT BERAT" at={tUn2} until={tTab} color="#8ff0ff" size={56} />
      <Pill x={540} y={600} text="TABRAKAN" sub="BINTANG NEUTRON" at={tTab} color="#ffffff" size={66} />
    </>
  );
};

/* 9 ─ tubuh kita dari bintang (74.49 – 79.42) */
const SceneBody = () => {
  const t = useT();
  const tBan = W('banyak');
  const tTub = W('tubuh', 1);
  const tBin = W('bintang', 4);
  const glow = 0.5 + 0.5 * Math.sin(t * 6);
  return (
    <>
      <SpaceBG />
      <S>
        <StarBody x={540} y={560} r={110} t={t} />
        {/* partikel unsur mengalir ke tubuh */}
        {Array.from({length: 26}).map((_, i) => {
          const p = (t * 0.55 + i / 26) % 1;
          const sx = 540 + Math.sin(i * 2.1) * 40;
          const ex = 540 + Math.sin(i * 1.3) * 50;
          const x = lerp(sx, ex, p) + Math.sin(p * 10 + i) * 60 * (1 - p);
          const y = lerp(660, 1500, easeInOut(p));
          const col = ['#6a6ff0', '#ff5a5a', '#aab2c8', '#ffd45a'][i % 4];
          return <circle key={i} cx={x} cy={y} r={11} fill={col} stroke={OUT} strokeWidth={3} opacity={Math.sin(p * Math.PI)} />;
        })}
        <Person x={540} y={1760} s={1.7} shirt="#e38b3d" armL={14} armR={14} mouth="smile" />
        <g transform="translate(540 1530)">
          <circle r={110} fill="url(#glowYellow)" opacity={0.6 + 0.3 * glow} />
          <path d="M0,-50 L14,-14 L52,-14 L22,10 L34,48 L0,26 L-34,48 L-22,10 L-52,-14 L-14,-14Z" fill="#ffe27a" stroke={OUT} strokeWidth={5} strokeLinejoin="round" transform={`scale(${pop(t, tTub, 0.5)})`} />
        </g>
      </S>
      <Pill x={540} y={330} text="BANYAK UNSUR" at={tBan} until={tTub} color="#8ff0ff" size={58} />
      <Pill x={540} y={330} text="PENYUSUN TUBUH KITA" at={tTub} until={tBin - 0.2} color="#ffb06a" size={50} />
      <Pill x={540} y={330} text="PERNAH DI DALAM BINTANG" at={tBin - 0.2} color="#ffd45a" size={46} />
    </>
  );
};

/* 10 ─ galaksi, Bima Sakti, Tata Surya (79.42 – 88.99) */
const SceneGalaxy = () => {
  const t = useT();
  const tGr = W('gravitasi', 1);
  const tGal = W('galaksi');
  const tBima = W('Bima');
  const tTata = W('Tata');
  const tKita = W('kita', 3);
  const p = easeInOut(prog(t, tGr, 3.3));
  const rot = t * 0.07;
  const CX = 540;
  const CY = 1150;
  const mr = 260;
  const mth = 2.2 + mr * 0.0125 + rot;
  const mx = CX + Math.cos(mth) * mr;
  const my = CY + Math.sin(mth) * mr * 0.78;
  return (
    <>
      <SpaceBG />
      <Cam z0={1.0} z1={t > tBima ? 1.25 : 1.05} dur={9.5}>
        <S>
          <Galaxy cx={CX} cy={CY} p={p} rot={rot} />
          {t >= tTata && (
            <g transform={`translate(${mx} ${my})`}>
              <circle r={70} fill="url(#glowYellow)" opacity={0.8 + 0.2 * Math.sin(t * 8)} />
              <circle r={14} fill="#fff7b0" stroke={OUT} strokeWidth={4} transform={`scale(${pop(t, tTata, 0.5)})`} />
              <Ring x={0} y={0} t0={tTata} max={150} color="#ffd45a" />
            </g>
          )}
        </S>
      </Cam>
      <Pill x={540} y={600} text="GRAVITASI" sub="MENGUMPULKAN BINTANG, GAS, DEBU" at={tGr} until={tGal} color="#ffd45a" size={60} />
      <Pill x={540} y={600} text="GALAKSI" at={tGal} until={tBima} color="#c7b0ff" size={72} />
      <Pill x={540} y={600} text="BIMA SAKTI" at={tBima} color="#8ff0ff" size={72} />
      <Pill x={540} y={1640} text="TATA SURYA" at={tTata} color="#ffd45a" size={54} />
      <Note x={540} y={1470} text="kita di sini" at={tKita} size={76} color="#fff" rot={-3} />
    </>
  );
};

/* 11 ─ awan runtuh jadi Matahari (88.99 – 99.61) */
const SceneNebula = () => {
  const t = useT();
  const t46 = W('4,6');
  const tAwan = W('awan', 1);
  const tRun = W('runtuh');
  const tSeb = W('Sebagian');
  const tMat = W('Matahari');
  const core = eo(t, tSeb, 2.6);
  const sun = pop(t, tMat, 0.6);
  return (
    <>
      <SpaceBG />
      <Cam z0={1.0} z1={1.07} dur={10.6} shakes={[{a: tMat, d: 0.6, amp: 10}]}>
        <S>
          <GasCloud cx={540} cy={1150} n={52} c0="#9a6bff" c1="#ffb06a" tc={tRun - 0.4} dc={tMat - tRun} spin={0.6} seed="neb" opacity={0.34 * (1 - 0.7 * eo(t, tMat, 1))} maxR={600} sk={0.65} />
          {t >= tSeb && t < tMat && <circle cx={540} cy={1150} r={lerp(20, 120, core)} fill="url(#glowYellow)" />}
          {t >= tMat && (
            <g transform={`translate(540 1150) scale(${sun})`}>
              <StarBody x={0} y={0} r={150} t={t} />
            </g>
          )}
          {t >= tMat && <Ring x={540} y={1150} t0={tMat} max={560} color="#fff7b0" w={16} />}
        </S>
      </Cam>
      <Flash t0={tMat} dur={0.5} color="#fff4c8" />
      <Pill x={540} y={600} text="4,6 MILIAR" sub="TAHUN LALU" at={t46} until={tAwan} color="#ffd45a" size={72} />
      <Pill x={540} y={600} text="AWAN GAS & DEBU" at={tAwan} until={tRun} color="#c7b0ff" size={56} />
      <Pill x={540} y={600} text="RUNTUH OLEH GRAVITASI" at={tRun} until={tSeb} color="#ffb84d" size={50} />
      <Pill x={540} y={600} text="BERKUMPUL DI TENGAH" at={tSeb} until={tMat} color="#ffe27a" size={52} />
      <Pill x={540} y={600} text="MATAHARI" at={tMat} color="#ffd45a" size={76} />
    </>
  );
};

/* 12 ─ piringan → planet (99.61 – 107.09) */
const PLANETS: Array<{rx: number; sp: number; r: number; c: string; a0: number; name: string}> = [
  {rx: 170, sp: 1.5, r: 24, c: '#c9a46a', a0: 0.5, name: ''},
  {rx: 270, sp: 1.0, r: 34, c: '#e8b66a', a0: 2.2, name: ''},
  {rx: 380, sp: 0.7, r: 40, c: '#3a8bff', a0: 4.0, name: 'BUMI'},
  {rx: 470, sp: 0.5, r: 32, c: '#e0644b', a0: 5.4, name: ''},
];

const SceneDisk = () => {
  const t = useT();
  const tPir = W('piringan');
  const tBat = W('batuan');
  const tTab = W('bertabrakan');
  const tPla = W('planet');
  const tBumi = W('Bumi', 0);
  const grow = eo(t, tTab, tPla - tTab + 0.3);
  const CX = 540;
  const CY = 1100;
  return (
    <>
      <SpaceBG />
      <S>
        <ellipse cx={CX} cy={CY} rx={520} ry={190} fill="url(#glowYellow)" opacity={0.12 * eo(t, tPir - 0.3, 0.6)} />
        {[170, 270, 380, 470].map((rx, i) => (
          <ellipse key={i} cx={CX} cy={CY} rx={rx} ry={rx * 0.36} fill="none" stroke="#fff" strokeOpacity={0.25 * eo(t, tPir, 0.6)} strokeWidth={3} strokeDasharray="8 12" />
        ))}
        {/* debu & batuan */}
        {Array.from({length: 90}).map((_, i) => {
          const rx = 150 + random(`dk${i}`) * 340;
          const a = random(`da${i}`) * Math.PI * 2 + t * (1.6 - rx * 0.0022) * (0.6 + random(`dv${i}`) * 0.5);
          const o = eo(t, 99.9, 0.5) * (1 - grow);
          return <circle key={i} cx={CX + Math.cos(a) * rx} cy={CY + Math.sin(a) * rx * 0.36} r={3 + random(`ds${i}`) * 5} fill={i % 3 === 0 ? '#a89592' : '#d9c9a8'} opacity={o} />;
        })}
        {t >= tBat && t < tPla + 0.3 && <Sparks x={CX - 190} y={CY + 60} t0={tTab} n={14} speed={200} life={0.8} g={0} color="#ffd45a" size={8} seed="c1" />}
        {t >= tBat && t < tPla + 0.3 && <Sparks x={CX + 260} y={CY - 40} t0={tTab + 0.3} n={14} speed={200} life={0.8} g={0} color="#ffd45a" size={8} seed="c2" />}
        <StarBody x={CX} y={CY} r={70} t={t} />
        {t >= tTab &&
          PLANETS.map((p, i) => {
            const a = p.a0 + t * p.sp * 0.5;
            const sc = grow * pop(t, tPla + i * 0.1, 0.5);
            return (
              <g key={i} transform={`translate(${CX + Math.cos(a) * p.rx} ${CY + Math.sin(a) * p.rx * 0.36}) scale(${clamp(sc, 0, 1.2)})`}>
                {p.name && <circle r={p.r * 2.4} fill="url(#glowBlue)" opacity={0.8} />}
                <circle r={p.r} fill={p.c} stroke={OUT} strokeWidth={5} />
                {p.name && <path d="M-20,-8 C-10,-26 8,-22 12,-8 C16,6 -6,14 -18,10Z" fill="#62b85c" />}
              </g>
            );
          })}
        {t >= tBumi && <Ring x={CX + Math.cos(PLANETS[2].a0 + t * 0.35) * 380} y={CY + Math.sin(PLANETS[2].a0 + t * 0.35) * 380 * 0.36} t0={tBumi} max={140} color="#7ccfff" />}
      </S>
      <Pill x={540} y={560} text="PIRINGAN BERPUTAR" at={tPir} until={W('tempat', 1)} color="#ffd45a" size={56} />
      <Pill x={540} y={560} text="DEBU & BATUAN" at={W('tempat', 1)} until={tTab} color="#d9c9a8" size={56} />
      <Pill x={540} y={560} text="SALING BERTABRAKAN" at={tTab} until={tPla} color="#ff9a4a" size={54} />
      <Pill x={540} y={560} text="JADI PLANET" at={tPla} until={tBumi} color="#8ff0ff" size={60} />
      <Pill x={540} y={560} text="TERMASUK BUMI" at={tBumi} color="#7ccfff" size={60} />
    </>
  );
};

/* 13 ─ Bumi muda: inti, mantel, kerak (107.09 – 117.90) */
const SceneEarth = () => {
  const t = useT();
  const tPan = W('sangat', 3);
  const tBesi = W('Besi', 1);
  const tRing = W('ringan');
  const tTerb = W('terbentuklah');
  const tInti = W('inti', 2);
  const tMan = W('mantel');
  const tKer = W('kerak');
  const mv = eo(t, tTerb - 0.3, 0.9);
  const CX = lerp(540, 380, mv);
  const CY = 1100;
  const R = lerp(340, 290, mv);
  const sink = eo(t, tBesi, 2.2);
  const core = lerp(0, 140, sink);
  const mantle = eo(t, tRing, 2.0);
  const crust = pop(t, tKer - 0.1, 0.5);
  return (
    <>
      <SpaceBG />
      <Cam z0={1.0} z1={1.05} dur={10.8} shakes={[{a: tBesi, d: 0.5, amp: 6}]}>
        <S>
          <circle cx={CX} cy={CY} r={R * 1.5} fill="url(#glowRed)" opacity={0.55 * (1 - 0.5 * mantle)} />
          <circle cx={CX} cy={CY} r={R} fill={mix('#ff6a2a', '#ff8a3a', mantle)} stroke={OUT} strokeWidth={10} />
          {/* retakan lava (fase awal) */}
          {t < tTerb &&
            [0, 1, 2, 3, 4, 5].map((i) => {
              const a = (i / 6) * Math.PI * 2 + 0.4;
              const x1 = CX + Math.cos(a) * 60;
              const y1 = CY + Math.sin(a) * 60;
              const x2 = CX + Math.cos(a + 0.2) * (R - 30);
              const y2 = CY + Math.sin(a + 0.2) * (R - 30);
              return <path key={i} d={`M${x1},${y1} L${(x1 + x2) / 2 + 20},${(y1 + y2) / 2 - 20} L${x2},${y2}`} fill="none" stroke="#ffe27a" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" opacity={0.7 * (1 - sink * 0.6)} />;
            })}
          {/* partikel besi menuju pusat */}
          {t >= tBesi &&
            Array.from({length: 38}).map((_, i) => {
              const a = random(`fa${i}`) * Math.PI * 2;
              const r0 = 80 + random(`fr${i}`) * (R - 100);
              const p = easeIn(prog(t, tBesi + random(`ft${i}`) * 0.8, 1.4));
              const r1 = lerp(r0, random(`fe${i}`) * 80, p);
              return <circle key={i} cx={CX + Math.cos(a) * r1} cy={CY + Math.sin(a) * r1} r={11} fill="#6d7a9a" stroke={OUT} strokeWidth={3} opacity={1 - 0.8 * (p > 0.99 ? 1 : 0)} />;
            })}
          {/* partikel ringan menuju luar */}
          {t >= tRing &&
            Array.from({length: 30}).map((_, i) => {
              const a = random(`la${i}`) * Math.PI * 2;
              const p = easeOut(prog(t, tRing + random(`lt${i}`) * 0.8, 1.4));
              const r1 = lerp(120 + random(`lr${i}`) * 100, R - 30, p);
              return <circle key={i} cx={CX + Math.cos(a) * r1} cy={CY + Math.sin(a) * r1} r={10} fill="#ffd9a0" stroke={OUT} strokeWidth={3} opacity={1 - p * 0.9} />;
            })}
          {/* lapisan */}
          {t >= tBesi && <circle cx={CX} cy={CY} r={core} fill="#ffe27a" stroke={OUT} strokeWidth={7} />}
          {t >= tTerb && <circle cx={CX} cy={CY} r={R - 40} fill="none" stroke={OUT} strokeWidth={6} />}
          {t >= tTerb && <circle cx={CX} cy={CY} r={R - 40} fill="#ff8a3a" opacity={0.0} />}
          {t >= tTerb && <circle cx={CX} cy={CY} r={R - 40} fill="none" stroke="#ffb06a" strokeWidth={3} strokeDasharray="6 10" />}
          {t >= tKer - 0.1 && <circle cx={CX} cy={CY} r={R - 20 * crust} fill="none" stroke="#8a5a3a" strokeWidth={36 * crust} />}
          {t >= tInti && <line x1={690} y1={1000} x2={CX + core * 0.4} y2={CY - 10} stroke="#ffe27a" strokeWidth={6} strokeLinecap="round" strokeDasharray="4 12" />}
          {t >= tMan && <line x1={690} y1={1150} x2={CX + (R - 40 + core) / 2} y2={CY + 20} stroke="#ffb06a" strokeWidth={6} strokeLinecap="round" strokeDasharray="4 12" />}
          {t >= tKer && <line x1={690} y1={1300} x2={CX + R * 0.78} y2={CY + R * 0.62} stroke="#d9b08a" strokeWidth={6} strokeLinecap="round" strokeDasharray="4 12" />}
        </S>
      </Cam>
      <Pill x={540} y={440} text="BUMI MUDA" sub="SANGAT PANAS" at={tPan - 0.5} until={tBesi} color="#ff7a4a" size={64} />
      <Pill x={540} y={440} text="BESI KE DALAM" at={tBesi} until={tRing} color="#aab2c8" size={62} />
      <Pill x={540} y={440} text="MATERIAL RINGAN" sub="KE BAGIAN LUAR" at={tRing} until={tTerb} color="#ffd9a0" size={58} />
      <Note x={850} y={1000} text="inti" at={tInti} size={92} color="#ffe27a" rot={-4} />
      <Note x={850} y={1150} text="mantel" at={tMan} size={92} color="#ffb06a" rot={3} />
      <Note x={850} y={1300} text="kerak" at={tKer} size={92} color="#d9b08a" rot={-3} />
    </>
  );
};

/* 14 ─ mendingin: atmosfer & lautan (117.90 – 122.63) */
const SceneOcean = () => {
  const t = useT();
  const tMen = W('mendingin', 1);
  const tAtm = W('atmosfer');
  const tLaut = W('lautan');
  const cool = eo(t, tMen - 0.6, 1.6);
  const atm = eo(t, tAtm, 1.0);
  const sea = eo(t, tLaut, 1.4);
  const CX = 540;
  const CY = 1100;
  const R = 340;
  return (
    <>
      <SpaceBG />
      <S>
        <circle cx={CX} cy={CY} r={R * 1.5} fill="url(#glowRed)" opacity={0.5 * (1 - cool)} />
        <circle cx={CX} cy={CY} r={R * 1.35} fill="url(#glowBlue)" opacity={atm} />
        <clipPath id="oceanclip">
          <circle cx={CX} cy={CY} r={R} />
        </clipPath>
        <circle cx={CX} cy={CY} r={R} fill={mix('#ff6a2a', '#6b5a4a', cool)} stroke={OUT} strokeWidth={10} />
        <g clipPath="url(#oceanclip)" opacity={sea}>
          {[[-120, -60, 170], [140, 70, 190], [-60, 170, 130], [150, -150, 120], [-190, 100, 110]].map(([dx, dy, rr], i) => (
            <circle key={i} cx={CX + dx} cy={CY + dy} r={(rr as number) * sea} fill="#2f7fd6" opacity={0.95} />
          ))}
          <circle cx={CX} cy={CY} r={R} fill="url(#earthShade)" />
        </g>
        {/* awan */}
        {[[-250, -220], [260, -140], [-200, 260]].map(([dx, dy], i) => (
          <g key={i} transform={`translate(${CX + dx + Math.sin(t * 0.6 + i) * 18} ${CY + dy})`} opacity={atm}>
            <ellipse rx={80} ry={28} fill="#fff" stroke={OUT} strokeWidth={5} />
            <ellipse cx={-28} cy={-18} rx={40} ry={26} fill="#fff" stroke={OUT} strokeWidth={5} />
          </g>
        ))}
        <circle cx={CX} cy={CY} r={R} fill="none" stroke={OUT} strokeWidth={10} />
        {t >= tLaut && <Ring x={CX} y={CY} t0={tLaut} max={520} color="#7ccfff" w={14} />}
      </S>
      <Pill x={540} y={480} text="PERMUKAAN MENDINGIN" at={W('permukaannya')} until={tAtm} color="#7ccfff" size={50} />
      <Pill x={540} y={480} text="ATMOSFER" at={tAtm} until={tLaut} color="#8ff0ff" size={68} />
      <Pill x={540} y={480} text="LAUTAN" at={tLaut} color="#4aa8ff" size={76} />
    </>
  );
};

/* 15 ─ Bumi purba: kimia alami → abiogenesis (122.63 – 129.57) */
const Molecule: React.FC<{x: number; y: number; s?: number; hue: number}> = ({x, y, s = 1, hue}) => {
  const cols = ['#ff7a8a', '#7ccfff', '#ffd45a', '#8ff0b0'];
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <line x1={-26} y1={10} x2={0} y2={-18} stroke={OUT} strokeWidth={12} strokeLinecap="round" />
      <line x1={0} y1={-18} x2={28} y2={12} stroke={OUT} strokeWidth={12} strokeLinecap="round" />
      <line x1={-26} y1={10} x2={0} y2={-18} stroke="#fff" strokeWidth={5} strokeLinecap="round" />
      <line x1={0} y1={-18} x2={28} y2={12} stroke="#fff" strokeWidth={5} strokeLinecap="round" />
      <circle cx={-26} cy={10} r={14} fill={cols[hue % 4]} stroke={OUT} strokeWidth={5} />
      <circle cx={0} cy={-18} r={16} fill={cols[(hue + 1) % 4]} stroke={OUT} strokeWidth={5} />
      <circle cx={28} cy={12} r={13} fill={cols[(hue + 2) % 4]} stroke={OUT} strokeWidth={5} />
    </g>
  );
};

const SceneLife = () => {
  const t = useT();
  const tPur = W('Bumi', 2);
  const tProses = W('proses');
  const tAbio = W('abiogenesis');
  const flashes = [125.0, 126.7];
  const bolt = flashes.some((f) => t > f && t < f + 0.25);
  const join = eo(t, tProses, 2.2);
  const cell = pop(t, tAbio, 0.6);
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#3a1d3a 0%,#8a3a3a 38%,#e08a4a 62%)'}} />
      <S>
        {/* gunung api */}
        <path d="M-40,1150 L180,740 L260,740 L480,1150Z" fill="#3a2a30" stroke={OUT} strokeWidth={8} strokeLinejoin="round" />
        <path d="M170,740 L270,740 L250,700 L190,700Z" fill="#ff7a2a" stroke={OUT} strokeWidth={6} />
        <circle cx={220} cy={640} r={110 + Math.sin(t * 5) * 8} fill="url(#glowYellow)" opacity={0.65} />
        {[0, 1, 2].map((i) => {
          const p = (t * 0.4 + i / 3) % 1;
          return <circle key={i} cx={220 + Math.sin(t + i) * 40} cy={700 - p * 360} r={34 + p * 70} fill="#5a4a50" opacity={0.7 * (1 - p)} />;
        })}
        {bolt && <path d="M760,0 L690,330 L760,320 L640,700 L720,690 L620,980" fill="none" stroke="#fff7b0" strokeWidth={16} strokeLinejoin="round" strokeLinecap="round" />}
        {/* laut purba */}
        <rect x={0} y={1200} width={WIDTH} height={720} fill="#1d5a5a" />
        <path d={`M-40,1200 ${Array.from({length: 57}).map((_, i) => `L${-40 + i * 20},${(1200 + Math.sin(i * 0.5 + t * 2) * 9).toFixed(1)}`).join(' ')} L1120,1920 L-40,1920Z`} fill="#2a7a72" stroke={OUT} strokeWidth={6} />
        {/* molekul */}
        {Array.from({length: 9}).map((_, i) => {
          const sx = 120 + random(`mx${i}`) * 840;
          const sy = 1400 + random(`my${i}`) * 400;
          const tx = 540 + (i - 4) * 22;
          const ty = 1560 + Math.sin(i) * 26;
          const p = join;
          const x = lerp(sx, tx, p) + Math.sin(t * 2 + i) * 20 * (1 - p);
          const y = lerp(sy, ty, p) + Math.cos(t * 1.6 + i) * 20 * (1 - p);
          if (t < tPur + 0.4) return null;
          if (t >= tAbio) return null;
          return <Molecule key={i} x={x} y={y} s={0.9 * pop(t, tPur + 0.4 + i * 0.08, 0.4)} hue={i} />;
        })}
        {t >= tAbio && <Cell x={540} y={1560} s={cell * 1.3} t={t} />}
        {t >= tAbio && <Ring x={540} y={1560} t0={tAbio} max={360} color="#8ff0b0" w={14} />}
      </S>
      <Flash t0={flashes[0]} dur={0.3} color="#fff7d0" />
      <Flash t0={flashes[1]} dur={0.3} color="#fff7d0" />
      <Pill x={540} y={330} text="BUMI PURBA" at={tPur} until={tProses} color="#ffb06a" size={64} />
      <Pill x={540} y={330} text="PROSES KIMIA ALAMI" at={tProses} until={tAbio} color="#8ff0b0" size={56} />
      <Pill x={540} y={330} text="ABIOGENESIS" at={tAbio} color="#6fe6a0" size={72} />
    </>
  );
};

/* 16 ─ bukti kehidupan 3,5 miliar tahun lalu (129.57 – 135.15) */
const SceneEvidence = () => {
  const t = useT();
  const tBuk = W('Bukti');
  const t35 = W('3,5');
  const lens = eo(t, tBuk + 0.2, 0.6);
  const lx = 540 + Math.sin(t * 1.3) * 90;
  const ly = 1180 + Math.cos(t * 1.1) * 40;
  const layers = ['#8a6a4a', '#a98260', '#7a5a3a', '#b8946a', '#6a4a30'];
  return (
    <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,#2a1d3a 0%,#1a1228 100%)'}} />
      <S>
        <g transform="rotate(-2 540 1180)">
          {layers.map((c, i) => (
            <rect key={i} x={110} y={820 + i * 100} width={860} height={104} fill={c} stroke={OUT} strokeWidth={6} />
          ))}
          {[0, 1, 2, 3, 4, 5, 6].map((i) => (
            <ellipse key={i} cx={200 + i * 120} cy={900 + (i % 3) * 120} rx={26} ry={16} fill="#d9c9a8" stroke={OUT} strokeWidth={4} opacity={0.9} />
          ))}
        </g>
        <clipPath id="lensclip">
          <circle cx={lx} cy={ly} r={190} />
        </clipPath>
        <g opacity={lens}>
          <circle cx={lx} cy={ly} r={190} fill="#fff7e8" opacity={0.9} />
          <g clipPath="url(#lensclip)">
            <rect x={lx - 200} y={ly - 200} width={400} height={400} fill="#6a4a30" />
            <Cell x={lx - 20} y={ly + 10} s={0.9} t={t} />
            <ellipse cx={lx + 90} cy={ly - 90} rx={36} ry={26} fill="#8ff0b0" stroke={OUT} strokeWidth={5} />
          </g>
          <circle cx={lx} cy={ly} r={190} fill="none" stroke={OUT} strokeWidth={18} />
          <circle cx={lx} cy={ly} r={190} fill="none" stroke="#f2c14e" strokeWidth={10} />
          <line x1={lx + 134} y1={ly + 134} x2={lx + 280} y2={ly + 280} stroke={OUT} strokeWidth={46} strokeLinecap="round" />
          <line x1={lx + 134} y1={ly + 134} x2={lx + 280} y2={ly + 280} stroke="#c94b3b" strokeWidth={28} strokeLinecap="round" />
        </g>
      </S>
      <Pill x={540} y={540} text="BUKTI KEHIDUPAN PURBA" at={tBuk} until={t35} color="#ffb06a" size={50} />
      <Pill x={540} y={540} text="3,5 MILIAR" sub="TAHUN LALU" at={t35} color="#ffd45a" size={80} />
    </>
  );
};

/* 17 ─ masih belum diketahui (135.15 – 138.63) */
const SceneUnknown = () => {
  const t = useT();
  const tTap = W('Tapi');
  const tMas = W('masih', 0);
  return (
    <>
      <SpaceBG />
      <S>
        <Cell x={540} y={1150} s={1.6} t={t} />
        {[[200, 880, 160, -10], [880, 920, 190, 12], [300, 1500, 140, 8], [820, 1480, 170, -8]].map(([x, y, sz, rot], i) => {
          const p = pop(t, tTap + 0.2 + i * 0.25, 0.5);
          return (
            <text key={i} x={x} y={y + Math.sin(t * 2 + i) * 12} textAnchor="middle" fontFamily={HAND} fontWeight={700} fontSize={(sz as number) * p} fill="#ffe27a" stroke={OUT} strokeWidth={10} paintOrder="stroke" transform={`rotate(${rot} ${x} ${y})`}>
              ?
            </text>
          );
        })}
      </S>
      <Pill x={540} y={600} text="BAGAIMANA PERSISNYA?" at={tTap} until={tMas} color="#ffd45a" size={54} />
      <Pill x={540} y={600} text="BELUM DIKETAHUI" at={tMas} color="#ff9a8a" size={64} />
    </>
  );
};

/* 18 ─ pertanyaan besar (138.63 – akhir) */
const SceneFinal = () => {
  const t = useT();
  const lt = useLT();
  const tDan = W('Dan', 13);
  const tMeng = W('mengapa');
  const tApa = W('apa');
  const tSeb = W('sebelum');
  const q = pop(t, tDan + 0.2, 0.7);
  const line = eo(t, tApa, 1.8);
  return (
    <>
      <AbsoluteFill style={{background: 'radial-gradient(100% 70% at 50% 50%, #1a1050 0%, #0a0626 60%, #03020f 100%)'}} />
      <Stars n={80} />
      <Cam z0={1.0} z1={1.08} dur={9.5}>
        <S>
          <circle cx={540} cy={1210} r={320 + Math.sin(lt * 2) * 14} fill="url(#glowYellow)" opacity={0.18 * q} />
          {/* garis waktu: sebelum Big Bang */}
          {t >= tApa && (
            <g>
              <line x1={540} y1={1560} x2={540 + 420 * line} y2={1560} stroke="#8ff0ff" strokeWidth={10} strokeLinecap="round" />
              <line x1={540} y1={1560} x2={540 - 420 * line} y2={1560} stroke="#fff" strokeOpacity={0.5} strokeWidth={10} strokeLinecap="round" strokeDasharray="6 20" />
              <circle cx={540} cy={1560} r={26} fill="#fff7c8" stroke="#ff7a2e" strokeWidth={8} />
              <circle cx={540} cy={1560} r={80} fill="url(#glowYellow)" opacity={0.7} />
            </g>
          )}
        </S>
      </Cam>
      <Note x={540} y={1210} text="?" at={tDan + 0.2} size={470 * Math.min(1, q)} color="#ffe27a" rot={4} />
      <Pill x={540} y={440} text="SATU PERTANYAAN BESAR" at={W('pertanyaan')} until={tMeng} color="#ffd45a" size={52} />
      <Pill x={540} y={440} text="MENGAPA ADA?" at={tMeng} until={tApa} color="#8ff0ff" size={74} />
      <Pill x={540} y={1670} text="BIG BANG" at={tSeb + 0.3} color="#ffb84d" size={46} />
      <Pill x={250} y={1470} text="SEBELUMNYA?" at={tSeb + 0.5} color="#c7b0ff" size={46} />
      <Pill x={540} y={440} text="APA SEBELUM BIG BANG?" at={tApa} color="#c7b0ff" size={52} />
    </>
  );
};

/* ═══════════════════════════ SFX ═══════════════════════════
 * [waktu (detik), nama file di public/sfx, volume 0..1]
 * Cukup edit / hapus baris untuk mengatur efek suara.
 */
const SFX_VOL = 1; // pengali volume semua efek
const SFX: Array<[number, string, number]> = [
  [W('batu'), 'pop', 0.35],
  [W('air'), 'pop', 0.35],
  [W('tubuh', 0), 'pop', 0.35],
  [W('bagaimana', 0), 'riser', 0.22],
  [10.9, 'whoosh', 0.28],
  [W('13,8'), 'ding', 0.3],
  [15.15, 'whoosh', 0.28],
  [W('Big', 0), 'pop', 0.35],
  [W('alam', 0), 'thud', 0.4],
  [W('padat', 0) + 0.2, 'riser', 0.25],
  [W('lalu', 1), 'whoosh', 0.32],
  [23.5, 'whoosh', 0.28],
  [W('ledakan', 0), 'error', 0.3],
  [W('Sejak'), 'whoosh', 0.25],
  [W('mendingin', 0), 'ding', 0.28],
  [30.35, 'whoosh', 0.28],
  [W('proton'), 'pop', 0.35],
  [W('neutron', 0), 'pop', 0.35],
  [W('hidrogen'), 'pop', 0.35],
  [W('helium'), 'pop', 0.35],
  [W('litium'), 'pop', 0.35],
  [37.65, 'whoosh', 0.28],
  [W('380'), 'ding', 0.3],
  [W('menangkap'), 'blips', 0.28],
  [W('terbentuk', 1), 'chime', 0.32],
  [47.0, 'whoosh', 0.28],
  [W('Awan') + 1.5, 'riser', 0.28],
  [W('menyala'), 'zap', 0.4],
  [W('Lahirlah'), 'chime', 0.34],
  [59.9, 'whoosh', 0.28],
  [W('karbon'), 'pop', 0.35],
  [W('oksigen'), 'pop', 0.35],
  [W('besi'), 'pop', 0.35],
  [W('mati') + 0.1, 'riser', 0.25],
  [W('ledakan', 1), 'thud', 0.5],
  [W('supernova'), 'whoosh', 0.3],
  [W('Unsur', 1) + 0.5, 'riser', 0.25],
  [W('tabrakan') + 0.5, 'thud', 0.5],
  [74.4, 'whoosh', 0.28],
  [W('tubuh', 1), 'ding', 0.3],
  [79.3, 'whoosh', 0.28],
  [W('Bima'), 'ding', 0.3],
  [W('Tata'), 'pop', 0.35],
  [88.85, 'whoosh', 0.28],
  [W('runtuh') + 0.6, 'riser', 0.25],
  [W('Matahari'), 'chime', 0.36],
  [99.5, 'whoosh', 0.28],
  [W('bertabrakan'), 'spark', 0.4],
  [W('planet'), 'pop', 0.35],
  [W('Bumi', 0), 'ding', 0.3],
  [107.0, 'whoosh', 0.28],
  [W('Besi', 1), 'thud', 0.38],
  [W('inti', 2), 'pop', 0.35],
  [W('mantel'), 'pop', 0.35],
  [W('kerak'), 'pop', 0.35],
  [117.8, 'whoosh', 0.28],
  [W('lautan'), 'splash', 0.32],
  [122.5, 'whoosh', 0.28],
  [125.0, 'spark', 0.3],
  [126.7, 'spark', 0.3],
  [W('abiogenesis'), 'chime', 0.34],
  [129.45, 'whoosh', 0.28],
  [W('3,5'), 'ding', 0.3],
  [W('diketahui'), 'sonar', 0.3],
  [138.5, 'whoosh', 0.28],
  [W('mengapa'), 'sonar', 0.28],
  [W('apa'), 'riser', 0.25],
  [W('sebelum') + 0.3, 'thud', 0.35],
];

/* ═══════════════════════════ ROOT ═══════════════════════════ */
export const Semesta: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const endFade = interpolate(t, [TOTAL_SECONDS - 0.7, TOTAL_SECONDS], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <TCtx.Provider value={t}>
      <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
        {/* ───── visual ───── */}
        <Scene a={0} b={W('Ceritanya')} fade={0}><SceneHook /></Scene>
        <Scene a={W('Ceritanya')} b={W('Menurut')}><SceneAgo /></Scene>
        <Scene a={W('Menurut')} b={W('Big', 1)}><SceneBang /></Scene>
        <Scene a={W('Big', 1)} b={W('Dalam')}><SceneNotBlast /></Scene>
        <Scene a={W('Dalam')} b={W('Sekitar', 2)}><SceneNuclei /></Scene>
        <Scene a={W('Sekitar', 2)} b={W('Lalu', 2)}><SceneAtom /></Scene>
        <Scene a={W('Lalu', 2)} b={W('Di', 4)}><SceneStar /></Scene>
        <Scene a={W('Di', 4)} b={W('Artinya')}><SceneForge /></Scene>
        <Scene a={W('Artinya')} b={W('Seiring')}><SceneBody /></Scene>
        <Scene a={W('Seiring')} b={W('Sekitar', 3)}><SceneGalaxy /></Scene>
        <Scene a={W('Sekitar', 3)} b={W('Sisanya')}><SceneNebula /></Scene>
        <Scene a={W('Sisanya')} b={W('Bumi', 1)}><SceneDisk /></Scene>
        <Scene a={W('Bumi', 1)} b={W('Lalu', 4)}><SceneEarth /></Scene>
        <Scene a={W('Lalu', 4)} b={W('Di', 7)}><SceneOcean /></Scene>
        <Scene a={W('Di', 7)} b={W('Bukti')}><SceneLife /></Scene>
        <Scene a={W('Bukti')} b={W('Tapi')}><SceneEvidence /></Scene>
        <Scene a={W('Tapi')} b={W('Dan', 13)}><SceneUnknown /></Scene>
        <Scene a={W('Dan', 13)} b={TOTAL_SECONDS + 1} fade={0.25}><SceneFinal /></Scene>
        <Vignette />
        <Caption />
        <AbsoluteFill style={{background: '#000', opacity: endFade, pointerEvents: 'none'}} />

        {/* ───── audio: narasi ───── */}
        <Audio src={staticFile('narration.mp3')} />

        {/* ───── audio: efek suara ───── */}
        {SFX.map(([at, name, vol], i) => (
          <Sequence key={i} from={Math.max(0, Math.round(at * FPS))} durationInFrames={Math.round(2.6 * FPS)}>
            <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol * SFX_VOL} />
          </Sequence>
        ))}
      </AbsoluteFill>
    </TCtx.Provider>
  );
};

export default Semesta;
