import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/*
  APA YANG TERJADI JIKA KITA MENGGALI TEMBUS KE SISI LAIN BUMI?  (3D voxel)
  90,5 detik, vertikal 1080x1920, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  Dunia 3D voxel murni SVG (mesin render kecil dengan rotasi kamera), tanpa WebGL.
  Waktu kalimat ada di SENT (sinkron dengan voice.mp3 asli, tanpa dipercepat); batas scene ada di SCT.
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;
const DUR = 90.5;
const WM_BOTTOM = 270; // jarak watermark dari bawah (naikkan/turunkan di sini)

const C = {
  orange: '#ff7a1a',
  amber: '#ffb020',
  cyan: '#5ad1ff',
  bone: '#f4e8cf',
  ink: '#5a3d22',
  red: '#ff4d4d',
  green: '#6ee7a0',
};

// batas scene (detik)
const SCT = [0, 7.7, 27.4, 36.0, 40.9, 48.8, 54.6, 62.0, 67.1, 79.4];
const CHAPTERS = ['PEMBUKA', 'MENEMBUS 4 LAPISAN', 'SUHU EKSTREM', 'TEKANAN', 'GRAVITASI NOL', 'MELUNCUR', 'VAKUM', 'WAKTU TEMPUH', 'KOLA SUPERDEEP', 'KESIMPULAN'];

const SENT: {a: number; b: number; t: string}[] = [
  {a: 0.00, b: 0.73, t: "Bayangkan kamu"},
  {a: 1.01, b: 3.35, t: "menggali terowongan lurus menembus Bumi,"},
  {a: 3.78, b: 5.72, t: "lalu muncul di sisi yang berlawanan."},
  {a: 6.21, b: 7.22, t: "Apa yang akan terjadi?"},
  {a: 7.81, b: 8.32, t: "Pertama,"},
  {a: 8.61, b: 10.08, t: "kamu melewati kerak Bumi,"},
  {a: 10.38, b: 13.71, t: "lapisan terluar setebal 5 sampai 70 kilometer."},
  {a: 14.16, b: 15.02, t: "Lalu mantel,"},
  {a: 15.30, b: 19.13, t: "batuan yang membentang hingga kedalaman 2.900 kilometer."},
  {a: 19.61, b: 21.11, t: "Setelah itu inti luar,"},
  {a: 21.43, b: 23.21, t: "lautan besi dan nikel cair."},
  {a: 23.65, b: 24.16, t: "Terakhir"},
  {a: 24.39, b: 25.06, t: "inti dalam,"},
  {a: 25.35, b: 26.94, t: "besi padat di pusat Bumi."},
  {a: 27.39, b: 29.35, t: "Makin dalam, makin ekstrem."},
  {a: 29.72, b: 34.08, t: "Suhu inti diperkirakan mencapai 5.000 sampai 6.000 derajat Celsius,"},
  {a: 34.31, b: 35.66, t: "setara permukaan Matahari."},
  {a: 36.04, b: 40.53, t: "Tekanannya sekitar 3,6 juta kali tekanan atmosfer di permukaan laut."},
  {a: 41.02, b: 43.17, t: "Tapi di pusat Bumi, ada hal aneh:"},
  {a: 43.56, b: 45.27, t: "gravitasi bersihnya nol,"},
  {a: 45.64, b: 48.49, t: "karena tarikan dari segala arah saling menyeimbangkan."},
  {a: 48.94, b: 51.26, t: "Meski begitu, kamu tidak berhenti di sana,"},
  {a: 51.64, b: 54.37, t: "kamu terus meluncur karena sudah punya kecepatan."},
  {a: 54.73, b: 57.47, t: "Jika terowongan tanpa udara dan tanpa gesekan,"},
  {a: 57.77, b: 59.48, t: "kecepatanmu paling tinggi di pusat,"},
  {a: 59.85, b: 61.79, t: "lalu melambat menuju sisi seberang."},
  {a: 62.13, b: 64.96, t: "Perjalanannya diperkirakan sekitar 38 menit,"},
  {a: 65.32, b: 66.86, t: "menurut perhitungan teoretis."},
  {a: 67.22, b: 68.30, t: "Sebagai perbandingan,"},
  {a: 68.56, b: 70.34, t: "lubang terdalam buatan manusia,"},
  {a: 70.64, b: 72.59, t: "Kola Superdeep Borehole di Rusia,"},
  {a: 72.83, b: 75.37, t: "baru sekitar 12,2 kilometer,"},
  {a: 75.72, b: 79.15, t: "belum sampai 0,2 persen perjalanan menuju pusat Bumi."},
  {a: 79.48, b: 81.93, t: "Jadi, ini masih eksperimen pikiran."},
  {a: 82.25, b: 86.20, t: "Suhu dan tekanan ekstrem membuatnya mustahil dengan teknologi sekarang."},
];

const CAPS = (() => {
  const out: {a: number; b: number; text: string}[] = [];
  for (const n of SENT) {
    const w = n.t.split(' ');
    const parts = Math.ceil(w.length / 8);
    const size = Math.ceil(w.length / parts);
    const pieces: string[] = [];
    for (let i = 0; i < w.length; i += size) pieces.push(w.slice(i, i + size).join(' '));
    const total = pieces.reduce((a, p) => a + p.length, 0);
    let cur = n.a;
    for (const p of pieces) {
      const d = ((n.b - n.a) * p.length) / total;
      out.push({a: cur, b: cur + d + 0.12, text: p});
      cur += d;
    }
  }
  return out;
})();

/* ---------- util ---------- */

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ramp = (
  t: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (x: number) => number = Easing.inOut(Easing.cubic),
) => interpolate(t, [a, b], [from, to], {...cl, easing});
const outC = Easing.out(Easing.cubic);
const lin = Easing.linear;
const win = (t: number, a: number, b: number, f = 0.4) => ramp(t, a, a + f, 0, 1, lin) * ramp(t, b - f, b, 1, 0, lin);
const rad = (d: number) => (d * Math.PI) / 180;
// pop dengan overshoot
const pop = (t: number, a: number, d = 0.5) => {
  const p = Math.min(1, Math.max(0, (t - a) / d));
  const c1 = 1.70158;
  return p <= 0 ? 0 : 1 + (c1 + 1) * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2);
};

const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const shade = (h: string, k: number) => `rgb(${hex(h).map((v) => Math.max(0, Math.min(255, Math.round(v * k)))).join(',')})`;

const mulberry32 = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};


/* ---------- teks ---------- */

const Title: React.FC<{
  t: number;
  lines: string[];
  start: number;
  end: number;
  y: number;
  size: number;
  color?: string;
  step?: number;
}> = ({t, lines, start, end, y, size, color = '#fff', step = 0.1}) => {
  if (t < start - 0.1 || t > end + 0.1) return null;
  const outA = ramp(t, end - 0.45, end, 1, 0, lin);
  let idx = 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: 40,
        right: 40,
        top: y,
        textAlign: 'center',
        opacity: outA,
        fontFamily: cond,
        fontWeight: 700,
        fontSize: size,
        lineHeight: 0.98,
        letterSpacing: '0.02em',
        color,
        textShadow: '0 0 36px rgba(255,122,26,0.38), 0 4px 30px rgba(0,0,0,0.8)',
      }}
    >
      {lines.map((ln, li) => (
        <div key={li} style={{display: 'flex', justifyContent: 'center', gap: size * 0.22}}>
          {ln.split(' ').map((w, wi) => {
            const i = idx++;
            const p = ramp(t, start + i * step, start + i * step + 0.45, 0, 1, outC);
            return (
              <span key={wi} style={{display: 'inline-block', opacity: p, transform: `translateY(${(1 - p) * 38}px) scale(${0.96 + 0.04 * p})`}}>
                {w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

const Caption: React.FC<{t: number}> = ({t}) => {
  const c = CAPS.find((x) => t >= x.a && t < x.b);
  if (!c) return null;
  const o = ramp(t, c.a, c.a + 0.16, 0, 1, lin) * ramp(t, c.b - 0.1, c.b, 1, 0, lin);
  return (
    <div
      style={{
        position: 'absolute',
        left: 90,
        right: 90,
        top: 1330,
        height: 230,
        display: 'flex',
        justifyContent: 'center',
        textAlign: 'center',
        opacity: o,
        transform: `translateY(${(1 - o) * 12}px)`,
        fontFamily: sans,
        fontWeight: 700,
        fontSize: 56,
        lineHeight: 1.22,
        color: '#fff',
        textShadow: '0 3px 22px rgba(0,0,0,0.95), 0 0 6px rgba(0,0,0,0.9)',
      }}
    >
      <span>{c.text}</span>
    </div>
  );
};



/* ================= mesin voxel 3D (SVG) ================= */

type Cam = {yaw: number; pitch: number; zoom: number; cx: number; cy: number; tx: number; ty: number; tz: number};
// x,y,z = pojok minimum; w,d,h = ukuran; e = emisif (tidak digelapkan); o = opacity; b = bias urutan gambar
type Bx = {x: number; y: number; z: number; w: number; d: number; h: number; c: string; e?: boolean; o?: number; b?: number};

const mk = (yaw: number, pitch: number, zoom: number, tx: number, ty: number, tz: number, cy = 820): Cam => ({yaw, pitch, zoom, cx: 540, cy, tx, ty, tz});

const proj = (c: Cam, x: number, y: number, z: number): [number, number, number] => {
  const cs = Math.cos(c.yaw);
  const sn = Math.sin(c.yaw);
  const sp = Math.sin(c.pitch);
  const cp = Math.cos(c.pitch);
  const dx = x - c.tx;
  const dy = y - c.ty;
  const dz = z - c.tz;
  const x1 = dx * cs - dy * sn;
  const y1 = dx * sn + dy * cs;
  return [c.cx + c.zoom * x1, c.cy + c.zoom * (y1 * sp - dz * cp), y1 * cp + dz * sp];
};

const rgb = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mul = (h: string, k: number) => {
  const v = rgb(h);
  return `rgb(${v.map((n) => Math.max(0, Math.min(255, Math.round(n * k)))).join(',')})`;
};
const LIGHT = (() => {
  const v = [0.55, -0.5, 0.9];
  const l = Math.hypot(v[0], v[1], v[2]);
  return v.map((a) => a / l);
})();

const FACES: {n: [number, number, number]; v: number[][]}[] = [
  {n: [0, 0, 1], v: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]]},
  {n: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]]},
  {n: [-1, 0, 0], v: [[0, 1, 0], [0, 0, 0], [0, 0, 1], [0, 1, 1]]},
  {n: [0, 1, 0], v: [[1, 1, 0], [0, 1, 0], [0, 1, 1], [1, 1, 1]]},
  {n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]]},
];

const Voxels: React.FC<{boxes: Bx[]; cam: Cam; edge?: number}> = ({boxes, cam, edge = 0.3}) => {
  const sn = Math.sin(cam.yaw);
  const cs = Math.cos(cam.yaw);
  const items: {d: number; pts: string; f: string; o: number}[] = [];
  for (const b of boxes) {
    if (b.o === 0 || b.h <= 0.001) continue;
    const d0 = proj(cam, b.x + b.w / 2, b.y + b.d / 2, b.z + b.h / 2)[2] + (b.b || 0);
    for (let fi = 0; fi < 5; fi++) {
      const f = FACES[fi];
      if (fi > 0 && f.n[0] * sn + f.n[1] * cs <= 0) continue;
      const dot = f.n[0] * LIGHT[0] + f.n[1] * LIGHT[1] + f.n[2] * LIGHT[2];
      const k = fi === 0 ? 1.08 : 0.5 + 0.5 * Math.max(0, dot) + 0.12;
      const pts = f.v
        .map((v) => {
          const p = proj(cam, b.x + v[0] * b.w, b.y + v[1] * b.d, b.z + v[2] * b.h);
          return p[0].toFixed(1) + ',' + p[1].toFixed(1);
        })
        .join(' ');
      items.push({d: d0 + (fi === 0 ? 0.0004 : 0), pts, f: b.e ? mul(b.c, fi === 0 ? 1.1 : 0.92) : mul(b.c, k), o: b.o === undefined ? 1 : b.o});
    }
  }
  items.sort((a, b) => a.d - b.d);
  return (
    <g stroke="rgba(0,0,0,0.28)" strokeWidth={edge} strokeLinejoin="round">
      {items.map((it, i) => (
        <polygon key={i} points={it.pts} fill={it.f} opacity={it.o} />
      ))}
    </g>
  );
};

const Shadow: React.FC<{cam: Cam; x: number; y: number; rx: number; ry: number; o?: number}> = ({cam, x, y, rx, ry, o = 0.35}) => {
  const p = proj(cam, x, y, 0);
  return <ellipse cx={p[0]} cy={p[1] + 40} rx={rx * cam.zoom} ry={ry * cam.zoom * 0.5} fill="#000" opacity={o} />;
};

const Label: React.FC<{cam: Cam; x: number; y: number; z: number; text: string; size?: number; color?: string; o?: number; dy?: number}> = ({cam, x, y, z, text, size = 40, color = '#fff', o = 1, dy = 0}) => {
  const p = proj(cam, x, y, z);
  return (
    <text x={p[0]} y={p[1] + dy} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
      {text}
    </text>
  );
};

const T2: React.FC<{x: number; y: number; text: string; size?: number; color?: string; o?: number; anchor?: 'start' | 'middle' | 'end'}> = ({x, y, text, size = 40, color = '#fff', o = 1, anchor = 'middle'}) => (
  <text x={x} y={y} textAnchor={anchor} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.05em" fill={color} opacity={o} stroke="#000" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round">
    {text}
  </text>
);
/* ---------- maskot Fosi + meme ---------- */

type Mood = 'confused' | 'brow' | 'tired';

const Fosi: React.FC<{x: number; y: number; s?: number; mood: Mood; t: number}> = ({x, y, s = 1, mood, t}) => {
  const bob = Math.sin(t * 9) * 4;
  const body = '#f2dcae';
  const pup = mood === 'confused' ? [[-30, -18], [46, -28]] : mood === 'brow' ? [[-26, -20], [26, -20]] : [[-36, -8], [34, -8]];
  return (
    <g transform={`translate(${x},${y + bob}) scale(${s}) rotate(${mood === 'confused' ? Math.sin(t * 5) * 3 : 0})`}>
      <ellipse cx={0} cy={96} rx={92} ry={12} fill="#000" opacity={0.35} />
      <ellipse cx={-104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(25 -104 20)" />
      <ellipse cx={104} cy={20} rx={22} ry={34} fill={body} stroke={C.ink} strokeWidth={7} transform="rotate(-25 104 20)" />
      <ellipse cx={0} cy={0} rx={100} ry={90} fill={body} stroke={C.ink} strokeWidth={7} />
      <path d="M -78 30 Q 0 56 78 30" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      <path d="M -62 56 Q 0 78 62 56" fill="none" stroke="#d3b57c" strokeWidth={6} strokeLinecap="round" />
      {[-38, 38].map((ex, i) => (
        <g key={i}>
          <circle cx={ex} cy={-22} r={30} fill="#fff" stroke={C.ink} strokeWidth={5} />
          <circle cx={ex + pup[i][0] * 0.35 + (i ? 0 : 0)} cy={-22 + pup[i][1] * 0.35} r={11} fill="#2a1a0e" />
          {mood === 'tired' && <path d={`M ${ex - 30} -22 A 30 30 0 0 1 ${ex + 30} -22 Z`} fill={body} stroke={C.ink} strokeWidth={5} />}
        </g>
      ))}
      {mood === 'confused' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -66 L -16 -56" />
          <path d="M 66 -76 L 16 -62" />
        </g>
      )}
      {mood === 'brow' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -62 -50 L -14 -52" />
          <path d="M 14 -78 Q 40 -90 64 -70" />
        </g>
      )}
      {mood === 'tired' && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M -66 -62 L -14 -52" />
          <path d="M 66 -62 L 14 -52" />
        </g>
      )}
      {mood === 'confused' && <path d="M -34 46 q 17 -16 34 0 t 34 0" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'brow' && <path d="M -24 48 L 24 48" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' && <path d="M -32 58 Q 0 30 32 58" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />}
      {mood === 'tired' &&
        [0, 1].map((k) => {
          const p = (t * 1.3 + k * 0.5) % 1;
          return <path key={k} d="M 0 -12 Q 12 8 0 16 Q -12 8 0 -12 Z" transform={`translate(${96 + k * 20},${-60 + p * 90})`} fill={C.cyan} opacity={1 - p} />;
        })}
      {mood === 'confused' &&
        [[-130, -110, 0], [140, -90, 1.3], [-40, -150, 2.4]].map(([qx, qy, ph], i) => (
          <text key={i} x={qx} y={qy + Math.sin(t * 4 + ph) * 8} fontFamily={cond} fontWeight={700} fontSize={84} fill={C.amber} stroke="#000" strokeWidth={8} paintOrder="stroke" textAnchor="middle">
            ?
          </text>
        ))}
    </g>
  );
};

const MemeText: React.FC<{lines: string[]; y: number; size: number; t: number; a: number}> = ({lines, y, size, t, a}) => {
  const p = pop(t, a + 0.05, 0.45);
  const sh = t - a < 0.5 ? Math.sin(t * 60) * 5 * (1 - (t - a) / 0.5) : 0;
  return (
    <g transform={`translate(${CX + sh},${y}) scale(${Math.max(0.01, p)})`}>
      {lines.map((ln, i) => (
        <text key={i} x={0} y={i * size * 0.98} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill="#fff" stroke="#000" strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke" letterSpacing="0.02em">
          {ln}
        </text>
      ))}
    </g>
  );
};

const Meme: React.FC<{t: number; a: number; b: number; mood: Mood; lines: string[]; ty: number; size?: number; fx?: number; fy?: number; fs?: number}> = ({
  t,
  a,
  b,
  mood,
  lines,
  ty,
  size = 112,
  fx = CX,
  fy = 1110,
  fs = 1.15,
}) => {
  if (t < a - 0.05 || t > b + 0.05) return null;
  const o = win(t, a, b, 0.25);
  const flash = ramp(t, a, a + 0.12, 0.55, 0, lin);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: '#000', opacity: 0.5 * o}} />
      <svg width={W} height={H} style={{position: 'absolute', inset: 0, opacity: o}}>
        <g transform={`translate(${fx},${fy}) scale(${Math.max(0.01, pop(t, a, 0.5))}) translate(${-fx},${-fy})`}>
          <Fosi x={fx} y={fy} s={fs} mood={mood} t={t} />
        </g>
        <MemeText lines={lines} y={ty} size={size} t={t} a={a} />
      </svg>
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
    </AbsoluteFill>
  );
};

/* ================= latar ================= */

const hexMix = (a: string, b: string, k: number) => {
  const A = rgb(a);
  const B = rgb(b);
  const kk = Math.max(0, Math.min(1, k));
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * kk).toString(16).padStart(2, '0')).join('');
};
const fmt = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const lerpN = (a: number, b: number, k: number) => a + (b - a) * k;
const seg = (t: number, a: number, b: number) => Math.min(1, Math.max(0, (t - a) / (b - a)));

const BGK: [number, string, string][] = [
  [0, '#0b1030', '#1d3a7a'],
  [7.7, '#140a08', '#3a2010'],
  [14.16, '#1a0804', '#5a1e0a'],
  [19.61, '#2a1204', '#7a3a08'],
  [23.65, '#2e1c05', '#8a5a0c'],
  [27.4, '#1c0606', '#7a1a0a'],
  [36.0, '#07091c', '#16206a'],
  [40.9, '#05050f', '#171040'],
  [48.8, '#06061a', '#0d1c52'],
  [54.6, '#05050f', '#1a1240'],
  [62.0, '#04101a', '#0a3050'],
  [67.1, '#0c1226', '#223a6a'],
  [79.4, '#120a1c', '#40200f'],
];
const DUST = (() => {
  const r = mulberry32(5);
  return Array.from({length: 60}, () => ({x: r() * W, y: r() * H, s: r() * 2.4 + 0.8, o: r() * 0.35 + 0.1, v: 8 + r() * 24, p: r() * 6.28}));
})();

const Bg: React.FC<{t: number}> = ({t}) => {
  let i = 0;
  BGK.forEach((k, j) => {
    if (t >= k[0]) i = j;
  });
  const p = i > 0 ? ramp(t, BGK[i][0], BGK[i][0] + 0.8, 0, 1, lin) : 1;
  const prev = BGK[Math.max(0, i - 1)];
  const top = hexMix(prev[1], BGK[i][1], p);
  const bot = hexMix(prev[2], BGK[i][2], p);
  return (
    <AbsoluteFill>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <defs>
          <linearGradient id="bgg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={top} />
            <stop offset="0.7" stopColor={bot} />
            <stop offset="1" stopColor={top} />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill="url(#bgg)" />
        {DUST.map((d, k) => (
          <circle key={k} cx={(d.x + Math.sin(t * 0.3 + d.p) * 20) % W} cy={(((d.y - t * d.v) % H) + H) % H} r={d.s} fill="#ffd9a0" opacity={d.o * (0.6 + 0.4 * Math.sin(t * 1.5 + d.p))} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};

const Stage: React.FC<{a: number; b: number; t: number; children: React.ReactNode}> = ({a, b, t, children}) => {
  if (t < a - 0.4 || t > b + 0.4) return null;
  const o = ramp(t, a - 0.35, a + 0.25, 0, 1, lin) * ramp(t, b - 0.25, b + 0.35, 1, 0, lin);
  return (
    <AbsoluteFill style={{opacity: o}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        {children}
      </svg>
    </AbsoluteFill>
  );
};

const rnd = (() => {
  const r = mulberry32(123);
  return Array.from({length: 400}, () => r());
})();
const R = (i: number) => rnd[i % 400];

// buang kotak di luar layar (hemat render)
const cull = (cam: Cam, bs: Bx[], m = 1.5) =>
  bs.filter((b) => {
    const p = proj(cam, b.x + b.w / 2, b.y + b.d / 2, b.z + b.h / 2);
    const mm = cam.zoom * m + Math.max(b.w, b.h) * cam.zoom;
    return p[0] > -mm && p[0] < W + mm && p[1] > -mm && p[1] < H + mm;
  });

// label kapsul di layar
const Tag: React.FC<{t: number; a: number; b?: number; x: number; y: number; text: string; size?: number; bg?: string; fg?: string}> = ({t, a, b = 999, x, y, text, size = 46, bg = 'rgba(10,10,20,0.78)', fg = '#fff'}) => {
  if (t < a || t > b + 0.3) return null;
  const p = pop(t, a, 0.45) * (1 - seg(t, b, b + 0.25));
  const w = text.length * size * 0.5 + 70;
  return (
    <g transform={`translate(${x},${y}) scale(${Math.max(0.001, p)})`}>
      <rect x={-w / 2} y={-size * 0.95} width={w} height={size * 1.7} rx={size * 0.85} fill={bg} stroke={fg} strokeWidth={3} />
      <text textAnchor="middle" y={size * 0.28} fontFamily={cond} fontWeight={700} fontSize={size} letterSpacing="0.06em" fill={fg}>
        {text}
      </text>
    </g>
  );
};

/* ================= bumi irisan 3D ================= */

const hsh = (i: number, j: number) => {
  const x = Math.sin(i * 127.1 + j * 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const CELLS = (() => {
  const a: {i: number; j: number; r: number; h: number}[] = [];
  for (let i = -14; i < 14; i++)
    for (let j = -14; j < 14; j++) {
      const r = Math.hypot(i + 0.5, j + 0.5);
      if (r <= 14) a.push({i, j, r, h: hsh(i, j)});
    }
  return a;
})();
const vary = (c: string, h: number, k = 0.16) => hexMix(c, '#000000', h * k);

const earthCells = (o: {t: number; dig?: number; heat?: number; sun?: boolean; tunnel?: boolean}): Bx[] => {
  const {t, dig = 1, heat = 0, sun = false, tunnel = true} = o;
  const bs: Bx[] = [];
  for (const c of CELLS) {
    let col: string;
    let e = false;
    const zc = c.j + 0.5;
    const inTun = tunnel && !sun && (c.i === -1 || c.i === 0) && zc >= 14 - 28 * dig;
    if (sun) {
      col = c.r < 9 ? hexMix('#fff3a0', '#ffb020', c.r / 9) : hexMix('#ffb020', '#f26a0f', (c.r - 9) / 5);
      col = vary(col, c.h, 0.12);
      e = true;
    } else if (inTun) {
      col = hexMix('#1a0d10', '#5a2010', heat * (0.5 + 0.5 * Math.sin(t * 6 + c.j)));
    } else if (c.r >= 13) {
      col = vary(c.h < 0.4 ? '#4aa35a' : c.h < 0.8 ? '#2f6fb5' : '#8a6a3b', c.h, 0.15);
    } else if (c.r >= 7) {
      col = vary(hexMix('#a63a12', '#f08a2e', (13 - c.r) / 6), c.h, 0.2);
      if (heat > 0) col = hexMix(col, '#ffd28a', heat * (c.r < 9 ? 0.3 : 0.12));
    } else if (c.r >= 2.7) {
      col = vary(hexMix('#ffb020', '#ffd45a', (7 - c.r) / 4.3), c.h, 0.12);
      e = heat > 0.3;
    } else {
      col = hexMix('#fff4b0', '#ffffff', 0.5 + 0.5 * Math.sin(t * 3 + c.h * 6));
      e = true;
    }
    bs.push({x: c.i, y: 0, z: c.j, w: 1, d: 3, h: 1, c: col, e});
  }
  return bs;
};

// orang voxel (sz = skala tinggi, untuk efek remuk)
const person = (x: number, y: number, z: number, s: number, t: number, o: {pose?: number; sz?: number; rot?: number} = {}): Bx[] => {
  const {pose = 0, sz = 1} = o;
  const sw = Math.sin(t * 11) * 0.35 * pose;
  const B = 6;
  const hh = (v: number) => v * s * sz;
  return [
    {x: x - 0.32 * s, y: y - 0.2 * s, z, w: 0.26 * s, d: 0.4 * s, h: hh(0.7), c: '#2b4fa8', b: B},
    {x: x + 0.06 * s, y: y - 0.2 * s, z, w: 0.26 * s, d: 0.4 * s, h: hh(0.7), c: '#2b4fa8', b: B},
    {x: x - 0.36 * s, y: y - 0.25 * s, z: z + hh(0.7), w: 0.72 * s, d: 0.5 * s, h: hh(0.8), c: '#ff7a1a', b: B},
    {x: x - 0.64 * s, y: y - 0.2 * s, z: z + hh(0.7 + 0.1 + sw * 0.5), w: 0.26 * s, d: 0.4 * s, h: hh(0.7), c: '#f2dcae', b: B},
    {x: x + 0.38 * s, y: y - 0.2 * s, z: z + hh(0.7 + 0.1 - sw * 0.5), w: 0.26 * s, d: 0.4 * s, h: hh(0.7), c: '#f2dcae', b: B},
    {x: x - 0.28 * s, y: y - 0.28 * s, z: z + hh(1.5), w: 0.56 * s, d: 0.56 * s, h: hh(0.56), c: '#f2dcae', b: B},
    {x: x - 0.3 * s, y: y - 0.3 * s, z: z + hh(1.95), w: 0.6 * s, d: 0.6 * s, h: hh(0.2), c: '#ffb020', b: B + 1},
    {x: x - 0.12 * s, y: y - 0.3 * s, z: z + hh(1.68), w: 0.1 * s, d: 0.04 * s, h: hh(0.1), c: '#2a1a0e', b: B + 1},
    {x: x + 0.06 * s, y: y - 0.3 * s, z: z + hh(1.68), w: 0.1 * s, d: 0.04 * s, h: hh(0.1), c: '#2a1a0e', b: B + 1},
  ];
};

const Glow: React.FC<{cam: Cam; r: number; color: string; o: number; z?: number}> = ({cam, r, color, o, z = 0}) => {
  const p = proj(cam, 0, 1.5, z);
  return (
    <g>
      <circle cx={p[0]} cy={p[1]} r={r * cam.zoom * 1.28} fill={color} opacity={o * 0.1} />
      <circle cx={p[0]} cy={p[1]} r={r * cam.zoom * 1.14} fill={color} opacity={o * 0.14} />
    </g>
  );
};

const DepthMeter: React.FC<{z: number; o: number}> = ({z, o}) => {
  const y0 = 400;
  const y1 = 1200;
  const f = Math.min(1, Math.max(0, (14 - z) / 14));
  const bounds = [0, 1 / 14, 7 / 14, 11.3 / 14, 1];
  const cols = ['#4aa35a', '#d8541a', '#ffb020', '#fff4b0'];
  return (
    <g opacity={o}>
      {cols.map((c, i) => (
        <rect key={i} x={58} y={y0 + bounds[i] * (y1 - y0)} width={26} height={(bounds[i + 1] - bounds[i]) * (y1 - y0)} fill={c} stroke="#000" strokeOpacity={0.4} />
      ))}
      <circle cx={71} cy={y0 + f * (y1 - y0)} r={20} fill="#fff" stroke="#000" strokeWidth={4} />
      <circle cx={71} cy={y0 + f * (y1 - y0)} r={9} fill={C.orange} />
      <T2 x={71} y={y0 - 22} text="0 KM" size={28} />
      <T2 x={71} y={y1 + 46} text="6.371" size={28} />
    </g>
  );
};

const zOfDescent = (t: number) => {
  const K: [number, number][] = [[7.7, 15.2], [8.6, 14.0], [13.7, 13.0], [14.2, 13.0], [19.2, 7.0], [19.6, 7.0], [23.3, 2.7], [23.7, 2.7], [27.0, 0.0], [27.4, 0.0]];
  if (t <= K[0][0]) return K[0][1];
  for (let i = 1; i < K.length; i++) {
    if (t <= K[i][0]) {
      const k = seg(t, K[i - 1][0], K[i][0]);
      const e = k * k * (3 - 2 * k) * 0.5 + k * 0.5;
      return lerpN(K[i - 1][1], K[i][1], e);
    }
  }
  return 0;
};

const shake = (t: number, t0: number, amp = 0.35, d = 0.5) => {
  const k = t - t0;
  if (k < 0 || k > d) return [0, 0];
  const f = 1 - k / d;
  return [Math.sin(k * 90) * amp * f, Math.cos(k * 77) * amp * f];
};

/* ================= scene A: pembuka ================= */

const SceneA: React.FC<{t: number}> = ({t}) => {
  const dig = ramp(t, 1.0, 3.35, 0, 1, lin);
  const cam = mk(ramp(t, 0, 7.7, -0.65, 0.2, lin), ramp(t, 0, 4, 0.12, 0.42), ramp(t, 0, 3.6, 46, 29, outC), 0, 1.5, ramp(t, 0, 3.6, 7, 0, outC), 900);
  const bs = earthCells({t, dig});
  const zd = 14 - 28 * dig;
  // bor
  if (dig > 0 && dig < 1) {
    bs.push({x: -0.6, y: 0.7, z: zd + 0.3, w: 1.2, d: 1.6, h: 2.6, c: '#9aa3ad', b: 7});
    bs.push({x: -0.5, y: 0.8, z: zd - 0.8, w: 1.0, d: 1.4, h: 1.1, c: '#ffcc33', b: 7, e: true});
    for (let k = 0; k < 12; k++) {
      const ph = (t * 3 + k * 0.17) % 1;
      bs.push({x: (R(k) - 0.5) * 3.2, y: 0.4 + R(k + 9) * 2, z: zd - 0.5 + ph * 2.5, w: 0.3, d: 0.3, h: 0.3, c: '#ffb020', e: true, o: 1 - ph, b: 8});
    }
  }
  // orang muncul di sisi lain
  const q = pop(t, 3.8, 0.5);
  if (q > 0) bs.push(...person(0, 1.5, -15.4 + Math.sin(t * 8) * 0.15, 1.5 * q, t, {pose: 1}));
  const start = pop(t, 0.5, 0.5);
  const qm = pop(t, 6.25, 0.55);
  const top = proj(cam, 0, 1.5, 7);
  return (
    <g>
      <Glow cam={cam} r={14} color="#5ad1ff" o={1} />
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      <Label cam={cam} x={0} y={1.5} z={16.2} text="MULAI DARI SINI" size={42} color={C.amber} o={pop(t, 1.9, 0.5) * (1 - seg(t, 3.0, 3.4))} />
      <Label cam={cam} x={0} y={1.5} z={-18.2} text="MUNCUL DI SINI" size={46} color={C.green} o={q} />
      <g transform={`translate(${top[0] + 10},${top[1] + 80}) scale(${qm}) rotate(${Math.sin(t * 5) * 6})`}>
        <T2 x={0} y={0} text="?" size={360} color={C.amber} />
      </g>
    </g>
  );
};

/* ================= scene B: menembus 4 lapisan ================= */

const LAYER_T: [number, number][] = [[14.16, 0], [19.61, 0], [23.65, 0]];
const SceneB: React.FC<{t: number}> = ({t}) => {
  const z = zOfDescent(t);
  const [sx, sz] = [14.16, 19.61, 23.65, 8.6].map((b) => shake(t, b, 0.4, 0.55)).reduce((a, b) => [a[0] + b[0], a[1] + b[1]], [0, 0]);
  const spd = Math.abs(zOfDescent(t + 0.05) - zOfDescent(t - 0.05)) / 0.1;
  const cam = mk(ramp(t, 7.7, 27.4, -0.3, 0.3, lin), 0.3, 74, 0 + sx, 1.5, z - 3.5 + sz, 960);
  const bs = earthCells({t, heat: seg(t, 19, 27) * 0.5});
  bs.push(...person(0, 1.5, z - 1.0, 1.5, t, {pose: 1}));
  // garis kecepatan
  for (let k = 0; k < 26; k++) {
    const zz = z - 14 + ((k * 2.3 + t * (4 + spd * 2.5)) % 28);
    bs.push({x: (R(k) < 0.5 ? -1 : 1) * (1.6 + R(k + 30) * 3.6), y: 0.3 + R(k + 60) * 2.4, z: zz, w: 0.14, d: 0.14, h: 1.1 + spd * 0.5, c: '#ffffff', e: true, o: 0.45, b: 8});
  }
  const flashes = [14.16, 19.61, 23.65].map((b) => Math.max(0, 0.65 - (t - b) * 3.2) * (t >= b ? 1 : 0));
  const fl = Math.max(...flashes, 0);
  const tag = (a: number, b: number, text: string, col: string) => <Tag t={t} a={a} b={b} x={CX} y={1215} text={text} size={50} bg={col} />;
  return (
    <g>
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      <DepthMeter z={z} o={ramp(t, 8.0, 8.6, 0, 1, lin)} />
      {tag(10.38, 14.1, 'TEBAL 5–70 KM', 'rgba(74,163,90,0.92)')}
      {tag(15.3, 19.5, 'SAMPAI ±2.900 KM', 'rgba(200,80,20,0.92)')}
      {tag(21.43, 23.6, 'BESI + NIKEL CAIR', 'rgba(220,150,20,0.92)')}
      {tag(25.35, 27.3, 'BESI PADAT', 'rgba(200,160,30,0.92)')}
      <rect width={W} height={H} fill="#fff" opacity={fl} />
    </g>
  );
};

/* ================= scene C: suhu ================= */

const SceneC: React.FC<{t: number}> = ({t}) => {
  const heat = ramp(t, 27.4, 29.5, 0.3, 1, lin);
  const [sx, sz] = shake(t, 27.4, 0.6, 1.2);
  const zoom = ramp(t, 27.4, 29.6, 62, 26, outC);
  const cam = mk(-0.25 + Math.sin(t * 0.6) * 0.1, 0.4, zoom, sx, 1.5, ramp(t, 27.4, 29.6, 0, -1, outC) + sz, 860);
  const bs = earthCells({t, heat});
  const sunCam: Cam = {...cam, cx: 840, cy: 560, zoom: 11, tx: 0, ty: 1.5, tz: 0, yaw: cam.yaw, pitch: cam.pitch};
  const sunP = pop(t, 34.3, 0.55);
  const fill = ramp(t, 29.72, 34.0, 0, 1, Easing.inOut(Easing.quad));
  const temp = lerpN(0, 6000, fill);
  const embers: React.ReactNode[] = [];
  for (let k = 0; k < 34; k++) {
    const ph = (t * (0.35 + R(k) * 0.3) + R(k + 3)) % 1;
    embers.push(<circle key={k} cx={200 + R(k + 7) * 700 + Math.sin(t * 2 + k) * 20} cy={1180 - ph * 900} r={3 + R(k + 11) * 5} fill={k % 3 ? C.orange : C.amber} opacity={(1 - ph) * 0.8 * ramp(t, 28.5, 30, 0, 1, lin)} />);
  }
  return (
    <g>
      <Glow cam={cam} r={14} color="#ff4d1a" o={heat} />
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      {embers}
      {/* termometer */}
      <g opacity={ramp(t, 29.6, 30.2, 0, 1, lin)}>
        <rect x={64} y={420} width={44} height={720} rx={22} fill="rgba(0,0,0,0.55)" stroke="#fff" strokeWidth={4} />
        <rect x={72} y={1132 - 700 * fill} width={28} height={700 * fill + 8} rx={14} fill={hexMix('#ffb020', '#ff2a1a', fill)} />
        <circle cx={86} cy={1170} r={46} fill={hexMix('#ffb020', '#ff2a1a', fill)} stroke="#fff" strokeWidth={4} />
      </g>
      <g transform={`translate(${CX},1235)`} opacity={ramp(t, 29.7, 30.1, 0, 1, lin)}>
        <T2 x={0} y={0} text={`${fmt(temp)} °C`} size={118} color={hexMix('#ffd45a', '#ff4d1a', fill)} />
      </g>
      {sunP > 0 && (
        <g>
          <g transform={`translate(840,560) scale(${sunP}) translate(-840,-560)`}>
            <Voxels boxes={earthCells({t, sun: true, tunnel: false})} cam={sunCam} />
          </g>
          <Tag t={t} a={34.5} x={840} y={760} text="MATAHARI ±5.500 °C" size={38} bg="rgba(255,122,26,0.95)" />
        </g>
      )}
    </g>
  );
};

/* ================= scene P: tekanan ================= */

const SceneP: React.FC<{t: number}> = ({t}) => {
  const p = ramp(t, 36.6, 39.7, 0, 1, Easing.in(Easing.cubic));
  const sz = 1 - 0.8 * p;
  const [sx, sz2] = shake(t, 39.7, 0.5, 0.6);
  const cam = mk(0.45, 0.28, 60, sx, 1.5, 3.6 + sz2, 790);
  const hPerson = 2.0 * 2.2 * sz;
  const plateZ = 0.1 + hPerson + 0.3;
  const bs: Bx[] = [];
  bs.push({x: -6, y: -2.5, z: -1.2, w: 12, d: 6.5, h: 1.2, c: '#4b5563'});
  bs.push({x: -6, y: -2.5, z: plateZ + 6 * (1 - p) * 0 , w: 12, d: 6.5, h: 1.4, c: '#6b7280', b: 3});
  // kolom pendorong
  bs.push({x: -1.2, y: -0.4, z: plateZ + 1.4, w: 2.4, d: 2.4, h: 14, c: '#9ca3af', b: 3});
  bs.push(...person(0, 0.7, 0.1, 2.2, t, {pose: 1 - p, sz}));
  // percikan saat remuk
  for (let k = 0; k < 14; k++) {
    const ph = seg(t, 38.6 + k * 0.05, 39.4 + k * 0.05);
    if (ph > 0 && ph < 1) bs.push({x: (R(k) - 0.5) * 6, y: 0.5, z: 0.5 + ph * 3 * R(k + 4), w: 0.25, d: 0.25, h: 0.25, c: '#ffb020', e: true, o: 1 - ph, b: 8});
  }
  const cnt = lerpN(0, 3.6, ramp(t, 36.4, 39.5, 0, 1, lin));
  return (
    <g>
      <Voxels boxes={bs} cam={cam} />
      <g transform={`translate(${CX},1190)`}>
        <T2 x={0} y={0} text={`${cnt.toFixed(1).replace('.', ',')} JUTA ×`} size={124} color={hexMix('#ffffff', '#ff6a3a', p)} />
        <T2 x={0} y={64} text="TEKANAN ATMOSFER" size={52} color={C.cyan} />
      </g>
      {/* panah tekan */}
      {[-1, 1].map((d) => (
        <g key={d} transform={`translate(${CX + d * 330},${760 - 90 * Math.sin(t * 8)})`} opacity={ramp(t, 36.4, 37, 0, 1, lin)}>
          <path d="M 0 -80 L 0 40 M -40 0 L 0 50 L 40 0" stroke={C.red} strokeWidth={14} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      ))}
    </g>
  );
};

/* ================= scene G: gravitasi nol ================= */

const arrow = (cx: number, cz: number, ang: number, len: number, pulse: number): Bx[] => {
  const bs: Bx[] = [];
  const dx = Math.cos(ang);
  const dz = Math.sin(ang);
  const n = 5;
  for (let k = 0; k < n; k++) {
    const d = len * (0.2 + k * 0.17) + pulse;
    bs.push({x: cx + dx * d - 0.15, y: 1.35, z: cz + dz * d - 0.15, w: 0.3, d: 0.3, h: 0.3, c: '#ff4d4d', e: true, o: 0.95, b: 5});
  }
  const d = len * 0.2 + pulse;
  bs.push({x: cx + dx * d - 0.35, y: 1.15, z: cz + dz * d - 0.35, w: 0.7, d: 0.7, h: 0.7, c: '#ff4d4d', e: true, b: 5});
  return bs;
};

const SceneG: React.FC<{t: number}> = ({t}) => {
  const cam = mk(ramp(t, 40.9, 48.8, -0.5, 0.5, lin), 0.3, ramp(t, 40.9, 43.5, 40, 62, outC), 0, 1.5, 0, 900);
  const bs = earthCells({t, heat: 0.3});
  const pulse = Math.sin(t * 5) * 0.25;
  const showArr = ramp(t, 45.5, 46.0, 0, 1, lin) * (1 - seg(t, 48.6, 48.8));
  const showA2 = ramp(t, 41.8, 42.4, 0, 1, lin);
  const bob = Math.sin(t * 1.7) * 0.35;
  const bs2: Bx[] = [...person(0, 1.5, -1.2 + bob, 1.4, t, {pose: 0.2})];
  // serpihan melayang
  for (let k = 0; k < 18; k++) {
    const a = t * (0.2 + R(k) * 0.25) + R(k + 3) * 6.28;
    bs2.push({x: Math.cos(a) * (1.8 + R(k + 7) * 1.4) - 0.2, y: 0.4 + R(k + 9) * 2.2, z: Math.sin(a) * (1.8 + R(k + 7) * 1.4) - 0.2 + bob * 0.5, w: 0.4, d: 0.4, h: 0.4, c: k % 2 ? '#ffd45a' : '#fff4b0', e: true, b: 4});
  }
  if (showArr > 0.01) for (let k = 0; k < 8; k++) bs2.push(...arrow(0, 0, (k / 8) * Math.PI * 2 + Math.PI, -4.2, pulse * -1 - 0.4).map((b) => ({...b, o: showArr})));
  const zero = pop(t, 43.56, 0.6);
  return (
    <g>
      <Glow cam={cam} r={2.8} color="#fff4b0" o={1.6} />
      <Voxels boxes={cull(cam, [...bs, ...bs2])} cam={cam} />
      <g transform={`translate(${CX},1130) scale(${zero})`}>
        <T2 x={0} y={0} text="0" size={400} color={C.green} />
      </g>
      <Tag t={t} a={44.0} x={CX} y={1250} text="GAYA GRAVITASI BERSIH" size={46} bg="rgba(20,120,70,0.92)" />
      <Tag t={t} a={41.4} b={43.4} x={CX} y={1190} text="PUSAT BUMI" size={56} bg="rgba(255,122,26,0.95)" />
      {showA2 < 0 && null}
    </g>
  );
};

/* ================= scene F: terus meluncur ================= */

const SceneF: React.FC<{t: number}> = ({t}) => {
  const zp = -(t - 48.94) * 1.9 - 0.2;
  const [sx, sz] = shake(t, 48.94, 0.4, 0.7);
  const cam = mk(0.1 + Math.sin(t * 0.8) * 0.15, 0.3, 66, sx, 1.5, zp - 1.8 + sz, 960);
  const bs = earthCells({t, heat: 0.4});
  bs.push(...person(0, 1.5, zp - 1.0, 1.5, t, {pose: 1}));
  for (let k = 0; k < 34; k++) {
    const zz = zp - 14 + ((k * 1.7 + t * 14) % 28);
    bs.push({x: (R(k) < 0.5 ? -1 : 1) * (1.4 + R(k + 30) * 3.2), y: 0.2 + R(k + 60) * 2.6, z: zz, w: 0.12, d: 0.12, h: 2.2, c: '#ffffff', e: true, o: 0.5, b: 8});
  }
  return (
    <g>
      <Glow cam={cam} r={14} color="#ffb020" o={1} />
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      <g opacity={ramp(t, 49.2, 49.7, 0, 1, lin)}>
        <path d={`M ${CX} 1080 L ${CX} 1210 M ${CX - 46} 1160 L ${CX} 1218 L ${CX + 46} 1160`} stroke={C.amber} strokeWidth={16} fill="none" strokeLinecap="round" strokeLinejoin="round" transform={`translate(0,${Math.sin(t * 9) * 10})`} />
      </g>
      <Tag t={t} a={49.6} x={CX} y={1010} text="KECEPATAN TERBAWA" size={50} bg="rgba(220,130,10,0.95)" />
    </g>
  );
};

/* ================= scene V: vakum & kecepatan ================= */

const zV = (t: number) => {
  if (t < 54.7) return 13;
  if (t < 57.6) return 13 * Math.cos((Math.PI / 2) * seg(t, 54.7, 57.6));
  return -13 * Math.sin((Math.PI / 2) * seg(t, 57.6, 62.0));
};
const spdV = (t: number) => (t < 54.7 ? 0 : t < 57.6 ? Math.sin((Math.PI / 2) * seg(t, 54.7, 57.6)) : Math.cos((Math.PI / 2) * seg(t, 57.6, 62.0)));

const SceneV: React.FC<{t: number}> = ({t}) => {
  const cam = mk(ramp(t, 54.6, 62, -0.35, 0.35, lin), 0.38, 27, 0, 1.5, 0, 800);
  const bs = earthCells({t, heat: 0.3});
  const z = zV(t);
  bs.push(...person(0, 1.5, z - 0.6, 0.9, t, {pose: 0.6}));
  // udara disedot keluar
  const out = seg(t, 54.9, 56.6);
  for (let k = 0; k < 30; k++) {
    const z0 = -13 + R(k) * 26;
    const zz = z0 + out * (14 - z0 + 3) * (1 + R(k + 5));
    if (zz > 15.5) continue;
    bs.push({x: -0.8 + R(k + 8) * 1.4, y: 0.3 + R(k + 9) * 2.4, z: zz, w: 0.32, d: 0.32, h: 0.32, c: '#bfe9ff', e: true, o: 0.9, b: 4});
  }
  const sp = spdV(t);
  // jejak cahaya
  const tr = z + (zV(t - 0.25) - z);
  const barX = 150;
  const barW = 780;
  return (
    <g>
      <Glow cam={cam} r={14} color="#5ad1ff" o={0.7} />
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      {tr > 99 && null}
      <g opacity={ramp(t, 57.6, 58.2, 0, 1, lin)}>
        <rect x={barX} y={1170} width={barW} height={40} rx={20} fill="rgba(0,0,0,0.55)" stroke="#fff" strokeWidth={4} />
        <rect x={barX + 4} y={1174} width={Math.max(8, (barW - 8) * sp)} height={32} rx={16} fill={hexMix('#5ad1ff', '#ff4d4d', sp)} />
        <T2 x={barX} y={1150} text="KECEPATAN" size={36} anchor="start" />
        <T2 x={barX + barW} y={1150} text={sp > 0.95 ? 'MAKS' : sp < 0.2 ? 'HAMPIR 0' : ''} size={36} color={C.amber} anchor="end" />
      </g>
      <Tag t={t} a={54.8} b={57.5} x={CX} y={1170} text="VAKUM · 0 UDARA · 0 GESEKAN" size={44} bg="rgba(40,90,180,0.92)" />
      <Tag t={t} a={57.8} b={59.6} x={CX} y={1050} text="TERCEPAT DI PUSAT" size={52} bg="rgba(220,60,40,0.95)" />
      <Tag t={t} a={59.9} x={CX} y={1050} text="LALU MELAMBAT" size={52} bg="rgba(40,150,120,0.95)" />
    </g>
  );
};

/* ================= scene M: 38 menit ================= */

const SceneM: React.FC<{t: number}> = ({t}) => {
  const k = seg(t, 62.13, 66.6);
  const z = 13 * Math.cos(Math.PI * k);
  const cam = mk(Math.sin(t * 0.5) * 0.3, 0.38, 28, 0, 1.5, 0, 830);
  const bs = earthCells({t});
  bs.push(...person(0, 1.5, z - 0.6, 0.9, t, {pose: 0.5}));
  // jejak
  for (let i = 0; i < 12; i++) {
    const kk = Math.max(0, k - i * 0.012);
    bs.push({x: -0.3, y: 1.4, z: 13 * Math.cos(Math.PI * kk), w: 0.6, d: 0.2, h: 0.5, c: '#ffffff', e: true, o: 0.5 - i * 0.04, b: 5});
  }
  const min = Math.round(38 * k);
  const done = seg(t, 66.4, 66.8);
  const b = pop(t, 66.5, 0.5);
  const bp = proj(cam, 0, 1.5, -15);
  return (
    <g>
      <Glow cam={cam} r={14} color="#5ad1ff" o={0.7} />
      <Voxels boxes={cull(cam, bs)} cam={cam} />
      <g transform={`translate(${CX},1190)`}>
        <T2 x={0} y={0} text={`${String(min).padStart(2, '0')}:00`} size={170} color={done > 0 ? C.green : '#ffffff'} />
        <T2 x={0} y={64} text="MENIT" size={50} color={C.cyan} />
      </g>
      <g transform={`translate(${bp[0]},${bp[1] + 40}) scale(${b})`}>
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <rect key={i} x={-5} y={-150 - 20 * (1 + Math.sin(t * 20 + i))} width={10} height={50} fill={C.amber} transform={`rotate(${i * 45 - 90 + 45})`} />
        ))}
      </g>
      <Tag t={t} a={65.32} x={CX} y={1010} text="HASIL HITUNGAN TEORETIS" size={44} bg="rgba(90,60,160,0.95)" />
    </g>
  );
};

/* ================= scene K: kola ================= */

const derrick = (x: number, y: number, z: number, s: number): Bx[] => [
  {x: x - 1.2 * s, y: y - 1.2 * s, z, w: 2.4 * s, d: 2.4 * s, h: 0.5 * s, c: '#6b7280'},
  {x: x - 0.9 * s, y: y - 0.9 * s, z: z + 0.5 * s, w: 0.3 * s, d: 0.3 * s, h: 3.6 * s, c: '#ef4444'},
  {x: x + 0.6 * s, y: y - 0.9 * s, z: z + 0.5 * s, w: 0.3 * s, d: 0.3 * s, h: 3.6 * s, c: '#ef4444'},
  {x: x - 0.9 * s, y: y + 0.6 * s, z: z + 0.5 * s, w: 0.3 * s, d: 0.3 * s, h: 3.6 * s, c: '#ef4444'},
  {x: x + 0.6 * s, y: y + 0.6 * s, z: z + 0.5 * s, w: 0.3 * s, d: 0.3 * s, h: 3.6 * s, c: '#ef4444'},
  {x: x - 0.9 * s, y: y - 0.9 * s, z: z + 2.2 * s, w: 1.8 * s, d: 1.8 * s, h: 0.25 * s, c: '#e5e7eb'},
  {x: x - 0.6 * s, y: y - 0.6 * s, z: z + 4.1 * s, w: 1.2 * s, d: 1.2 * s, h: 0.8 * s, c: '#f87171'},
  {x: x - 0.12 * s, y: y - 0.12 * s, z: z + 4.9 * s, w: 0.24 * s, d: 0.24 * s, h: 1.2 * s, c: '#e5e7eb'},
];

const SceneK: React.FC<{t: number}> = ({t}) => {
  const barX = 330;
  const y0 = 540;
  const y1 = 1180;
  const wipe = ramp(t, 67.3, 68.5, 0, 1, outC);
  const bounds = [0, 1 / 14, 7 / 14, 11.3 / 14, 1];
  const cols = ['#4aa35a', '#d8541a', '#ffb020', '#fff4b0'];
  const cam = mk(0.5, 0.3, 46, 0, 0, 0, 900);
  const dp = pop(t, 68.6, 0.6);
  const notch = pop(t, 72.9, 0.4);
  const mag = pop(t, 75.8, 0.55);
  return (
    <g>
      <g opacity={wipe}>
        {cols.map((c, i) => (
          <rect key={i} x={barX} y={y0 + bounds[i] * (y1 - y0) * wipe} width={110} height={(bounds[i + 1] - bounds[i]) * (y1 - y0) * wipe} fill={c} stroke="#000" strokeOpacity={0.5} strokeWidth={3} />
        ))}
        <T2 x={barX + 55} y={y1 + 70} text="PUSAT BUMI" size={36} />
        <T2 x={barX - 16} y={y0 + 10} text="PERMUKAAN" size={30} anchor="end" />
      </g>
      {/* kerangka bor 3D */}
      {dp > 0 && (
        <g transform={`translate(${barX + 55 - 540},${y0 - 40 - 830}) `}>
          <g transform={`translate(540,830) scale(${dp * 0.75}) translate(-540,-830)`}>
            <Voxels boxes={derrick(0, 0, 0, 1)} cam={mk(0.6, 0.35, 46, 0, 0, 0, 830)} />
          </g>
        </g>
      )}
      {/* garis kedalaman 12,2 km */}
      {notch > 0 && (
        <g>
          <rect x={barX + 40} y={y0} width={30} height={Math.max(6, 0.0019 * (y1 - y0) * 3)} fill={C.red} />
          <path d={`M ${barX + 120} ${y0 + 4} L ${barX + 190} ${y0 + 4}`} stroke={C.red} strokeWidth={6} />
        </g>
      )}
      <Tag t={t} a={70.64} x={760} y={480} text="KOLA SUPERDEEP" size={44} bg="rgba(30,60,140,0.95)" />
      <Tag t={t} a={70.9} x={760} y={560} text="BOREHOLE · RUSIA" size={44} bg="rgba(30,60,140,0.95)" />
      <g transform={`translate(760,730) scale(${notch})`}>
        <T2 x={0} y={0} text="12,2 KM" size={140} color={C.red} />
      </g>
      <g transform={`translate(760,840) scale(${pop(t, 73.6, 0.5)})`}>
        <T2 x={0} y={0} text="RADIUS BUMI" size={44} color={C.cyan} />
        <T2 x={0} y={66} text="6.371 KM" size={76} />
      </g>
      {mag > 0 && (
        <g transform={`translate(760,1090) scale(${mag})`}>
          <circle r={110} fill="rgba(0,0,0,0.6)" stroke="#fff" strokeWidth={8} />
          <clipPath id="mc"><circle r={100} /></clipPath>
          <g clipPath="url(#mc)">
            <rect x={-120} y={-120} width={240} height={240} fill="#4aa35a" />
            <rect x={-120} y={-120} width={240} height={22} fill={C.red} />
          </g>
          <T2 x={0} y={160} text="< 0,2%" size={72} color={C.amber} />
        </g>
      )}
    </g>
  );
};

/* ================= scene Z: kesimpulan ================= */

const SceneZ: React.FC<{t: number}> = ({t}) => {
  const bubble = pop(t, 79.6, 0.6);
  const cam = mk(0.3, 0.3, 13, 0, 1.5, 0, 720);
  const bs = earthCells({t, heat: seg(t, 82.2, 84) * 0.8});
  const x1 = pop(t, 83.6, 0.45);
  const shakeX = t > 82.3 ? Math.sin(t * 40) * 3 * seg(t, 82.3, 83) * (1 - seg(t, 85, 86)) : 0;
  return (
    <g>
      <g transform={`translate(${CX + shakeX},720) scale(${bubble}) translate(${-CX},-720)`}>
        <ellipse cx={CX} cy={720} rx={300} ry={270} fill="rgba(255,255,255,0.12)" stroke="#fff" strokeWidth={6} />
        <circle cx={CX - 230} cy={1030} r={22} fill="rgba(255,255,255,0.18)" stroke="#fff" strokeWidth={5} />
        <circle cx={CX - 160} cy={985} r={36} fill="rgba(255,255,255,0.18)" stroke="#fff" strokeWidth={5} />
        <Voxels boxes={bs} cam={{...cam, cx: CX, cy: 720}} />
        <g transform={`translate(${CX},720) scale(${x1})`} opacity={0.95}>
          <path d="M -150 -150 L 150 150 M 150 -150 L -150 150" stroke={C.red} strokeWidth={34} strokeLinecap="round" />
        </g>
      </g>
      <Tag t={t} a={82.6} x={CX - 220} y={1100} text="SUHU EKSTREM" size={46} bg="rgba(220,60,40,0.95)" />
      <Tag t={t} a={83.2} x={CX + 230} y={1180} text="TEKANAN EKSTREM" size={46} bg="rgba(40,90,180,0.95)" />
      <Tag t={t} a={84.4} x={CX} y={1260} text="BELUM BISA DENGAN TEKNOLOGI SEKARANG" size={34} bg="rgba(20,20,30,0.92)" />
    </g>
  );
};

const Hud: React.FC<{t: number}> = ({t}) => {
  let s = 0;
  SCT.forEach((a, i) => {
    if (t >= a) s = i;
  });
  const o = ramp(t, 0.6, 1.4, 0, 1, lin) * ramp(t, 87.0, 87.6, 1, 0, lin);
  return (
    <div style={{position: 'absolute', inset: 0, opacity: o}}>
      <div style={{position: 'absolute', left: 64, right: 64, top: 66, height: 4, background: 'rgba(255,255,255,0.18)', borderRadius: 2}}>
        <div style={{width: `${(t / DUR) * 100}%`, height: 4, background: C.orange, borderRadius: 2, boxShadow: `0 0 12px ${C.orange}`}} />
      </div>
      <div style={{position: 'absolute', left: 64, top: 92, fontFamily: cond, fontWeight: 600, fontSize: 30, letterSpacing: '0.16em', color: 'rgba(255,255,255,0.85)'}}>
        {`${String(s + 1).padStart(2, '0')} / 10  ·  ${CHAPTERS[s]}`}
      </div>
      <div style={{position: 'absolute', left: 64, top: 130, fontFamily: sans, fontWeight: 600, fontSize: 20, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.42)'}}>
        ILUSTRASI ARTISTIK · TIDAK SESUAI SKALA
      </div>
    </div>
  );
};

const Watermark: React.FC<{t: number}> = ({t}) => (
  <div
    style={{
      position: 'absolute',
      right: 52,
      bottom: WM_BOTTOM,
      opacity: ramp(t, 0.2, 0.8, 0, 0.92, lin) * ramp(t, DUR - 0.8, DUR - 0.2, 1, 0, lin),
      fontFamily: cond,
      fontWeight: 700,
      fontSize: 46,
      letterSpacing: '0.06em',
      color: '#fff',
      textShadow: '0 2px 14px rgba(0,0,0,0.95), 0 0 4px rgba(0,0,0,0.9)',
    }}
  >
    Semesta<span style={{color: C.orange}}>Kita</span>
  </div>
);

const EndCard: React.FC<{t: number}> = ({t}) => {
  const e = ramp(t, 87.4, 88.2, 0, 1, outC);
  if (e <= 0) return null;
  return (
    <AbsoluteFill style={{opacity: e, background: 'rgba(0,0,0,0.6)'}}>
      <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
        <text x={CX} y={820 + (1 - e) * 30} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={122} letterSpacing="0.05em" fill="#fff">
          SEMESTA<tspan fill={C.orange}>KITA</tspan>
        </text>
        <rect x={CX - 70} y={860} width={140} height={4} fill={C.orange} />
        <text x={CX} y={960} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={62} letterSpacing="0.05em" fill="rgba(255,255,255,0.92)">
          FOLLOW UNTUK FAKTA
        </text>
        <text x={CX} y={1032} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={62} letterSpacing="0.05em" fill="rgba(255,255,255,0.92)">
          SEMESTA LAINNYA
        </text>
      </svg>
    </AbsoluteFill>
  );
};

export const Bumi: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const fadeIn = ramp(t, 0, 0.25, 1, 0, lin);
  const fadeOut = ramp(t, DUR - 0.5, DUR, 0, 1, lin);
  const TT = (lines: string[], a: number, b: number, size: number, color = '#fff') => <Title t={t} lines={lines} start={a} end={b} y={190} size={size} color={color} />;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Bg t={t} />
      <Stage a={SCT[0]} b={SCT[1]} t={t}><SceneA t={t} /></Stage>
      <Stage a={SCT[1]} b={SCT[2]} t={t}><SceneB t={t} /></Stage>
      <Stage a={SCT[2]} b={SCT[3]} t={t}><SceneC t={t} /></Stage>
      <Stage a={SCT[3]} b={SCT[4]} t={t}><SceneP t={t} /></Stage>
      <Stage a={SCT[4]} b={SCT[5]} t={t}><SceneG t={t} /></Stage>
      <Stage a={SCT[5]} b={SCT[6]} t={t}><SceneF t={t} /></Stage>
      <Stage a={SCT[6]} b={SCT[7]} t={t}><SceneV t={t} /></Stage>
      <Stage a={SCT[7]} b={SCT[8]} t={t}><SceneM t={t} /></Stage>
      <Stage a={SCT[8]} b={SCT[9]} t={t}><SceneK t={t} /></Stage>
      <Stage a={SCT[9]} b={DUR} t={t}><SceneZ t={t} /></Stage>

      {TT(['GALI TERUS KE', 'SISI LAIN BUMI?'], 0.05, 6.1, 100)}
      {TT(['APA YANG', 'AKAN TERJADI?'], 6.2, 7.6, 108, C.amber)}
      {TT(['LAPIS 1:', 'KERAK BUMI'], 7.8, 14.1, 112, C.green)}
      {TT(['LAPIS 2:', 'MANTEL'], 14.2, 19.5, 112, '#ff9a5a')}
      {TT(['LAPIS 3:', 'INTI LUAR'], 19.6, 23.55, 112, C.amber)}
      {TT(['LAPIS 4:', 'INTI DALAM'], 23.65, 27.3, 112, '#fff4b0')}
      {TT(['MAKIN DALAM,', 'MAKIN EKSTREM'], 27.45, 29.65, 100)}
      {TT(['SUHU INTI:', '5.000–6.000 °C'], 29.75, 36.0, 100, C.amber)}
      {TT(['TEKANAN INTI:', '3,6 JUTA × ATMOSFER'], 36.1, 40.8, 84, C.cyan)}
      {TT(['PUSAT BUMI:', 'GRAVITASI NOL'], 41.0, 48.7, 104, C.green)}
      {TT(['TERUS', 'MELUNCUR!'], 48.9, 54.5, 120, C.amber)}
      {TT(['TANPA UDARA,', 'TANPA GESEKAN'], 54.7, 57.6, 100, C.cyan)}
      {TT(['KECEPATAN MAKS', 'DI PUSAT'], 57.7, 59.75, 100, C.red)}
      {TT(['LALU MELAMBAT', 'KE SISI SEBERANG'], 59.8, 61.95, 88)}
      {TT(['PERJALANAN:', '±38 MENIT'], 62.1, 67.0, 108, C.amber)}
      {TT(['BANDINGKAN DENGAN', 'LUBANG TERDALAM'], 67.2, 72.7, 88)}
      {TT(['MANUSIA BARU', 'SAMPAI 12,2 KM'], 72.8, 79.3, 100, C.red)}
      {TT(['MASIH EKSPERIMEN', 'PIKIRAN'], 79.5, 82.2, 96, C.amber)}
      {TT(['SUHU & TEKANAN', 'TERLALU EKSTREM'], 82.3, 87.2, 96, C.red)}

      <Meme t={t} a={21.5} b={23.3} mood="brow" lines={['BESI CAIR?!']} ty={800} />
      <Meme t={t} a={34.4} b={36.0} mood="confused" lines={['SEPANAS', 'MATAHARI?!']} ty={800} />
      <Meme t={t} a={38.9} b={40.7} mood="tired" lines={['REMUK BOS']} ty={800} />
      <Meme t={t} a={43.9} b={45.8} mood="confused" lines={['GRAVITASI', 'NOL?!']} ty={800} />
      <Meme t={t} a={63.5} b={65.3} mood="brow" lines={['CUMA 38', 'MENIT?!']} ty={800} />
      <Meme t={t} a={79.6} b={81.6} mood="tired" lines={['JADI CUMA', 'KHAYALAN?!']} ty={800} />

      <Audio src={staticFile('audio.mp3')} />
      <Caption t={t} />
      <Hud t={t} />
      <EndCard t={t} />
      <Watermark t={t} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: '#000', opacity: Math.max(fadeIn, fadeOut), pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
