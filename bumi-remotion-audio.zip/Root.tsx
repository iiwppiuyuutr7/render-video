import React from 'react';
import {Composition} from 'remotion';
import {Bumi} from './Bumi';

export const RemotionRoot: React.FC = () => (
  <Composition id="Bumi" component={Bumi} durationInFrames={5430} fps={60} width={1080} height={1920} />
);
