/**
 * ECO-ACTION 4 DAYS – Hari Pertama: Audit dan Diagnosa Lingkungan
 * 1920x1080 (16:9) · 30 fps · ±70 detik
 * Aset: public/eco/clips (klip asli, sudah 30fps & tanpa audio), public/eco/sfx, public/eco/music.mp3
 * Semua waktu di file ini dalam FRAME (30 frame = 1 detik).
 * Tanpa narasi / voice-over. Informasi hanya lewat footage + teks di layar.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const WHITE = '#ffffff';
const BEIGE = '#efe5cf';
const GREEN = '#9fcf86';
const DEEP = '#0f2e1c';

const OVERLAP = 15; // durasi dissolve antar klip (0,5 detik)

/* ───────────────────────── urutan klip ─────────────────────────
 * dur = jumlah frame klip (sesuai file di public/eco/clips).
 * Klip diputar berurutan, tiap klip masuk dengan cinematic dissolve.
 */
type Seg = {id: string; src: string; dur: number; zoom: 'in' | 'out'};

const SEGS: Seg[] = [
  {id: 'a', src: 'a-opening', dur: 240, zoom: 'in'},
  {id: 'b', src: 'b-lingkungan', dur: 195, zoom: 'in'},
  {id: 'c', src: 'c-audit-pohon', dur: 270, zoom: 'out'},
  {id: 'd', src: 'd-audit-lahan', dur: 222, zoom: 'in'},
  {id: 'e', src: 'e-analisis', dur: 360, zoom: 'in'},
  {id: 'f', src: 'f-diskusi', dur: 360, zoom: 'out'},
  {id: 'g', src: 'g-perencanaan', dur: 276, zoom: 'in'},
  {id: 'h', src: 'h-closing', dur: 176, zoom: 'out'},
];

const START: Record<string, number> = {};
SEGS.reduce((acc, s, i) => {
  const st = i === 0 ? 0 : acc - OVERLAP;
  START[s.id] = st;
  return st + s.dur;
}, 0);

const LAST = SEGS[SEGS.length - 1];
const END_START = START[LAST.id] + LAST.dur - OVERLAP; // end card mulai saat klip terakhir selesai
const END_DUR = 125;
export const ECO_TOTAL_FRAMES = END_START + END_DUR;

/* ───────────────────────── util ───────────────────────── */
const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const fadeWindow = (f: number, dur: number, fi = 14, fo = 12) =>
  interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], clampOpts);

const rise = (f: number, delay = 0, dist = 18) =>
  interpolate(f, [delay, delay + 16], [dist, 0], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });

const shadow = '0 3px 24px rgba(0,0,0,0.38)';

/* ───────────────────────── klip video ───────────────────────── */
// Color grading ringan: sedikit hangat, saturasi hijau natural, kontras seimbang.
const GRADE = 'saturate(1.12) contrast(1.05) brightness(0.98) sepia(0.10)';

const VideoSeg: React.FC<{seg: Seg; index: number}> = ({seg, index}) => {
  const f = useCurrentFrame();
  const opacity =
    index === 0
      ? interpolate(f, [0, 24], [0, 1], clampOpts)
      : interpolate(f, [0, OVERLAP], [0, 1], clampOpts);
  const scale =
    seg.zoom === 'in'
      ? interpolate(f, [0, seg.dur], [1.0, 1.045], clampOpts)
      : interpolate(f, [0, seg.dur], [1.045, 1.0], clampOpts);
  return (
    <AbsoluteFill style={{opacity}}>
      <OffthreadVideo
        src={staticFile(`eco/clips/${seg.src}.mp4`)}
        volume={0}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${scale})`,
          filter: GRADE,
        }}
      />
    </AbsoluteFill>
  );
};

/* ───────────────────────── teks ───────────────────────── */
const Pill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 28,
      color: WHITE,
      padding: '8px 24px',
      borderRadius: 999,
      border: '2px solid rgba(255,255,255,0.7)',
      background: 'rgba(255,255,255,0.12)',
      textShadow: shadow,
    }}
  >
    {children}
  </div>
);

// Judul bagian di kiri bawah, dengan scrim gradasi halus di bawahnya.
const LowerThird: React.FC<{
  start: number;
  end: number;
  title: string;
  sub: string;
  extra?: string;
}> = ({start, end, title, sub, extra}) => {
  const dur = end - start;
  return (
    <Sequence from={start} durationInFrames={dur}>
      <LowerThirdInner dur={dur} title={title} sub={sub} extra={extra} />
    </Sequence>
  );
};

const LowerThirdInner: React.FC<{dur: number; title: string; sub: string; extra?: string}> = ({
  dur,
  title,
  sub,
  extra,
}) => {
  const f = useCurrentFrame();
  const op = fadeWindow(f, dur);
  const bar = interpolate(f, [0, 20], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: op,
          background:
            'linear-gradient(to top, rgba(6,22,11,0.70) 0%, rgba(6,22,11,0.38) 28%, rgba(6,22,11,0) 52%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 120,
          display: 'flex',
          gap: 30,
          alignItems: 'stretch',
          opacity: op,
        }}
      >
        <div
          style={{
            width: 7,
            borderRadius: 4,
            background: GREEN,
            transform: `scaleY(${bar})`,
            transformOrigin: 'bottom',
          }}
        />
        <div style={{transform: `translateY(${rise(f)}px)`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 68,
              lineHeight: 1.12,
              color: WHITE,
              textShadow: shadow,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 36,
              marginTop: 14,
              color: BEIGE,
              textShadow: shadow,
              transform: `translateY(${rise(f, 6, 12)}px)`,
            }}
          >
            {sub}
          </div>
          {extra ? (
            <div style={{marginTop: 26, display: 'flex'}}>
              <Pill>{extra}</Pill>
            </div>
          ) : null}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Panel teks di tengah layar (opening & closing).
const CenterPanel: React.FC<{start: number; end: number; children: React.ReactNode}> = ({
  start,
  end,
  children,
}) => {
  const dur = end - start;
  return (
    <Sequence from={start} durationInFrames={dur}>
      <CenterInner dur={dur}>{children}</CenterInner>
    </Sequence>
  );
};

const CenterInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, 18, 14),
        transform: `translateY(${rise(f, 0, 22)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const Line: React.FC<{size: number; weight: 600 | 800; color: string; mt?: number; spacing?: number; children: React.ReactNode}> = ({
  size,
  weight,
  color,
  mt = 0,
  spacing = 0,
  children,
}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: weight,
      fontSize: size,
      color,
      marginTop: mt,
      letterSpacing: spacing,
      lineHeight: 1.15,
      textShadow: shadow,
      maxWidth: 1500,
    }}
  >
    {children}
  </div>
);

const Rule: React.FC<{width?: number}> = ({width = 220}) => {
  const f = useCurrentFrame();
  const w = interpolate(f, [8, 34], [0, width], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return <div style={{height: 5, width: w, borderRadius: 3, background: GREEN, marginTop: 30}} />;
};

// Peredup lembut agar teks putih terbaca di atas footage terang.
const Dim: React.FC<{start: number; end: number; strength: number}> = ({start, end, strength}) => {
  const dur = end - start;
  return (
    <Sequence from={start} durationInFrames={dur}>
      <DimInner dur={dur} strength={strength} />
    </Sequence>
  );
};
const DimInner: React.FC<{dur: number; strength: number}> = ({dur, strength}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background: `rgba(8,26,14,${strength})`,
        opacity: interpolate(f, [0, 22, dur - 22, dur], [0, 1, 1, 0], clampOpts),
      }}
    />
  );
};

// Kilau halus saat judul muncul (sinkron dengan efek kamera flash).
const SoftFlash: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const o = interpolate(f, [at, at + 3, at + 14], [0, 0.10, 0], clampOpts);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

/* ───────────────────────── end card ───────────────────────── */
const EndCard: React.FC = () => {
  const f = useCurrentFrame();
  const bg = interpolate(f, [0, OVERLAP + 5], [0, 1], clampOpts);
  const content = interpolate(f, [14, 34, END_DUR - 38, END_DUR - 6], [0, 1, 1, 0], clampOpts);
  return (
    <AbsoluteFill style={{background: DEEP, opacity: bg}}>
      <AbsoluteFill
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          textAlign: 'center',
          opacity: content,
          transform: `translateY(${rise(f, 14, 16)}px)`,
        }}
      >
        <Line size={104} weight={800} color={WHITE} spacing={3}>
          ECO-ACTION 4 DAYS
        </Line>
        <Rule width={200} />
        <Line size={36} weight={600} color={BEIGE} mt={30}>
          Aksi Nyata Pelajar Hijau untuk Sekolah Asri dan Berkelanjutan
        </Line>
        <div style={{display: 'flex', gap: 18, marginTop: 44}}>
          <Pill>Kelas X E7</Pill>
          <Pill>Kelompok 5 — Video Kampanye</Pill>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/* ───────────────────────── audio ───────────────────────── */
const Sfx: React.FC<{file: string; at: number; vol?: number}> = ({file, at, vol = 0.5}) => (
  <Sequence from={Math.max(0, at)}>
    <Audio src={staticFile(`eco/sfx/${file}.mp3`)} volume={vol} />
  </Sequence>
);

// Backsound: naik perlahan di awal, turun halus di akhir.
const musicVolume = (f: number) => {
  const build = interpolate(f, [0, 480, 900], [0.08, 0.28, 0.32], clampOpts);
  const out = interpolate(f, [ECO_TOTAL_FRAMES - 100, ECO_TOTAL_FRAMES], [1, 0], clampOpts);
  return build * out;
};

/* ───────────────────────── komposisi ───────────────────────── */
export const EcoAction: React.FC = () => {
  const S = START;
  const sectionStarts = [S.b, S.c, S.e, S.f, S.g, S.h]; // awal tiap bagian baru (whoosh)
  const titleStarts = [S.b + 20, S.c + 20, S.e + 20, S.f + 20, S.g + 20];

  return (
    <AbsoluteFill style={{backgroundColor: DEEP}}>
      {/* ── video (urut, dissolve) ── */}
      {SEGS.map((seg, i) => (
        <Sequence key={seg.id} from={START[seg.id]} durationInFrames={seg.dur}>
          <VideoSeg seg={seg} index={i} />
        </Sequence>
      ))}

      {/* vignette tipis di seluruh video */}
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(8,24,12,0.34) 100%)',
        }}
      />

      {/* ── 1. OPENING ── */}
      <Dim start={0} end={S.b + 8} strength={0.32} />
      <CenterPanel start={20} end={135}>
        <Line size={128} weight={800} color={WHITE} spacing={4}>
          ECO-ACTION 4 DAYS
        </Line>
        <Rule />
        <Line size={40} weight={600} color={BEIGE} mt={30}>
          Aksi Nyata Pelajar Hijau untuk Sekolah Asri dan Berkelanjutan
        </Line>
      </CenterPanel>
      <CenterPanel start={137} end={S.b + 8}>
        <Line size={58} weight={800} color={WHITE}>
          Kokurikuler Gaya Hidup Berkelanjutan
        </Line>
        <Line size={40} weight={600} color={BEIGE} mt={16}>
          Hari Pertama: Audit dan Diagnosa Lingkungan
        </Line>
        <div style={{display: 'flex', gap: 18, marginTop: 40}}>
          <Pill>Kelas X E7</Pill>
          <Pill>Kelompok 5 — Video Kampanye</Pill>
        </div>
      </CenterPanel>
      <SoftFlash at={18} />

      {/* ── 2. PENGENALAN LINGKUNGAN SEKOLAH ── */}
      <LowerThird
        start={titleStarts[0]}
        end={titleStarts[0] + 120}
        title="Mengenali Lingkungan di Sekitar Kita"
        sub="Setiap Perubahan Dimulai dari Kepedulian"
      />

      {/* ── 3. AUDIT DAN OBSERVASI LINGKUNGAN ── */}
      <LowerThird
        start={titleStarts[1]}
        end={titleStarts[1] + 120}
        title="Audit dan Diagnosa Lingkungan"
        sub="Mengamati, Mengidentifikasi, dan Memahami"
      />

      {/* ── 4. ANALISIS PERMASALAHAN LINGKUNGAN ── */}
      <LowerThird
        start={titleStarts[2]}
        end={titleStarts[2] + 120}
        title="Memahami Permasalahan Lingkungan"
        sub="Menemukan Potensi, Menentukan Prioritas"
      />

      {/* ── 5. DISKUSI DAN BRAINSTORMING ── */}
      <LowerThird
        start={titleStarts[3]}
        end={titleStarts[3] + 120}
        title="Discover & Brainstorm"
        sub="Merancang Solusi untuk Lingkungan yang Lebih Baik"
      />

      {/* ── 6. PERENCANAAN AKSI TAMANISASI ── */}
      <LowerThird
        start={titleStarts[4]}
        end={titleStarts[4] + 120}
        title="Dari Pengamatan Menuju Perencanaan"
        sub="Merancang Aksi Nyata Pelajar Hijau"
        extra="Kelompok 5 — Video Kampanye"
      />

      {/* ── 7. CLOSING ── */}
      <Dim start={S.h + 4} end={END_START + 6} strength={0.42} />
      <CenterPanel start={S.h + 12} end={END_START - 4}>
        <Line size={66} weight={800} color={WHITE}>
          Hari Ini Kita Mengamati dan Merencanakan
        </Line>
        <Line size={66} weight={800} color={BEIGE} mt={14}>
          Besok Kita Mulai Mewujudkan Perubahan
        </Line>
      </CenterPanel>
      <Sequence from={END_START} durationInFrames={END_DUR}>
        <EndCard />
      </Sequence>

      {/* ── AUDIO ── */}
      <Audio src={staticFile('eco/music.mp3')} volume={musicVolume} />

      {/* efek kamera di judul pembuka & kemunculan teks */}
      <Sfx file="flash" at={18} vol={0.4} />
      <Sfx file="pop" at={137} vol={0.45} />

      {/* perpindahan antar bagian */}
      {sectionStarts.map((s) => (
        <Sfx key={`w${s}`} file="whoosh" at={s - 12} vol={0.3} />
      ))}
      {/* perpindahan antar klip dalam satu bagian */}
      <Sfx file="transition" at={S.d} vol={0.35} />

      {/* kemunculan judul bagian */}
      {titleStarts.map((t) => (
        <Sfx key={`c${t}`} file="click" at={t + 3} vol={0.4} />
      ))}

      {/* closing */}
      <Sfx file="pop" at={S.h + 14} vol={0.4} />
      <Sfx file="click" at={S.h + 34} vol={0.4} />
      <Sfx file="transition" at={END_START} vol={0.35} />
      <Sfx file="click" at={END_START + 18} vol={0.35} />
    </AbsoluteFill>
  );
};
