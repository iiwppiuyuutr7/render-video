import React from 'react';
import {Composition} from 'remotion';
import {EcoAction, ECO_TOTAL_FRAMES} from './EcoAction';

export const RemotionRoot: React.FC = () => (
  <Composition id="EcoAction" component={EcoAction} durationInFrames={ECO_TOTAL_FRAMES} fps={30} width={1920} height={1080} />
);
