Gedung - animasi edukasi "Mengapa Gedung Tinggi Bisa Bergoyang Tanpa Mengalami Kerusakan?"
(portrait 9:16, 1080x1920, 60fps, 93.39 detik = sepanjang audio narasi)
File: Gedung.tsx, Root.tsx, public/audio.mp3
Taruh Gedung.tsx & Root.tsx di src/ proyek Remotion (audio di public/).
Render: npx remotion render Gedung out/gedung.mp4
Watermark "@semestakita" di kiri bawah. 10 adegan; waktu mulai tiap adegan ada di konstanta SCENES (Gedung.tsx) - ubah angkanya kalau ingin menggeser adegan.
