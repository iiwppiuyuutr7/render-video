import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';

/* =====================================================================
   GEDUNG – animasi edukasi, 9:16 • 1080x1920 • 60 fps • 93.39 detik
   Watermark @semestakita (kiri bawah). Audio: public/audio.mp3
   ===================================================================== */
export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_SECONDS = 93.39;

// waktu mulai tiap adegan (detik) – selaras dengan jeda narasi
const SCENES = [0, 11.89, 26.52, 34.12, 48.36, 55.32, 69.38, 78.56, 83.24, 87.2, TOTAL_SECONDS];

const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const sm = (p: number) => { const x = clamp(p); return x * x * (3 - 2 * x); };
const prog = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
const ap = (t: number, a: number, d = 0.5) => sm(prog(t, a, a + d));
const rnd = (seed: number) => {
  let a = seed * 9301 + 49297;
  a = Math.imul(a ^ (a >>> 15), 2246822507);
  a = Math.imul(a ^ (a >>> 13), 3266489909);
  return ((a ^ (a >>> 16)) >>> 0) / 4294967296;
};
const TAU = Math.PI * 2;
const swy = (t: number, a: number, f = 0.32, ph = 0) => a * Math.sin(TAU * f * t + ph);

const C = {
  navy: '#0b1d3a', white: '#ffffff', bld: '#27364f', bldD: '#1b2740', lit: '#ffd86b', glass: '#bfe3f5',
  orange: '#ff8a3d', teal: '#2ec4b6', red: '#ef476f', gold: '#ffc83d', green: '#3ddc84', grass: '#2f7d4f', ground: '#1f4d3a',
};
const FONT = "'Poppins','Montserrat','Segoe UI','Helvetica Neue',Arial,sans-serif";
const GROUND = 1560;

// ---------- elemen dasar ----------
const T: React.FC<{x: number; y: number; lines: string[]; size: number; fill?: string; weight?: number; anchor?: 'middle' | 'start'; lh?: number; p?: number; stroke?: string; op?: number}> =
  ({x, y, lines, size, fill = C.white, weight = 800, anchor = 'middle', lh = 1.18, p = 1, stroke = C.navy, op = 1}) => (
    <g opacity={p * op} transform={`translate(0 ${(1 - p) * 24})`}>
      {lines.map((l, i) => (
        <text key={i} x={x} y={y + i * size * lh} fontFamily={FONT} fontWeight={weight} fontSize={size} fill={fill} textAnchor={anchor}
          stroke={stroke} strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke">{l}</text>
      ))}
    </g>
  );

const Pill: React.FC<{x: number; y: number; text: string; size?: number; bg?: string; fg?: string; p?: number; check?: boolean}> =
  ({x, y, text, size = 44, bg = C.orange, fg = C.white, p = 1, check = false}) => {
    const w = text.length * size * 0.6 + size * 1.8 + (check ? size * 1.2 : 0);
    const h = size * 1.7;
    return (
      <g opacity={p} transform={`translate(${x} ${y + (1 - p) * 30}) scale(${lerp(0.9, 1, p)})`}>
        <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={h / 2} fill={bg} stroke={C.navy} strokeWidth={5} />
        {check && <path d={`M${-w / 2 + size * 0.7} 0 l${size * 0.35} ${size * 0.35} l${size * 0.65} ${-size * 0.7}`} fill="none" stroke={fg} strokeWidth={size * 0.2} strokeLinecap="round" strokeLinejoin="round" />}
        <text x={check ? size * 0.55 : 0} y={size * 0.34} fontFamily={FONT} fontWeight={800} fontSize={size} fill={fg} textAnchor="middle">{text}</text>
      </g>
    );
  };

const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; color?: string; w?: number; op?: number}> = ({x1, y1, x2, y2, color = C.white, w = 12, op = 1}) => {
  const a = Math.atan2(y2 - y1, x2 - x1), hs = w * 2.6;
  const bx = x2 - Math.cos(a) * hs * 0.6, by = y2 - Math.sin(a) * hs * 0.6;
  const p1 = [x2 - Math.cos(a - 0.5) * hs, y2 - Math.sin(a - 0.5) * hs], p2 = [x2 - Math.cos(a + 0.5) * hs, y2 - Math.sin(a + 0.5) * hs];
  return (
    <g opacity={op}>
      <line x1={x1} y1={y1} x2={bx} y2={by} stroke={color} strokeWidth={w} strokeLinecap="round" />
      <polygon points={`${x2},${y2} ${p1[0]},${p1[1]} ${p2[0]},${p2[1]}`} fill={color} />
    </g>
  );
};

// ---------- latar ----------
const Background: React.FC<{t: number}> = ({t}) => (
  <g>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#1e5aa8" /><stop offset="0.55" stopColor="#5fa8dc" /><stop offset="1" stopColor="#cfeaf6" />
      </linearGradient>
    </defs>
    <rect width={WIDTH} height={HEIGHT} fill="url(#sky)" />
    <circle cx={880} cy={430} r={90} fill="#fff6c8" opacity={0.9} />
    {[0, 1, 2, 3].map(i => {
      const x = ((t * (14 + i * 6) + i * 400) % 1500) - 250;
      return <g key={i} opacity={0.75}><ellipse cx={x} cy={300 + i * 230} rx={150} ry={46} fill="#fff" /><ellipse cx={x + 90} cy={285 + i * 230} rx={100} ry={44} fill="#fff" /></g>;
    })}
    {Array.from({length: 14}, (_, i) => {
      const w = 80 + rnd(i + 3) * 70, h = 220 + rnd(i + 9) * 380;
      return <rect key={i} x={i * 80 - 20} y={GROUND - h} width={w} height={h} fill="#7c9bbd" opacity={0.55} />;
    })}
    <rect x={0} y={GROUND} width={WIDTH} height={HEIGHT - GROUND} fill={C.ground} />
    <rect x={0} y={GROUND} width={WIDTH} height={16} fill={C.grass} />
  </g>
);

const WindStreaks: React.FC<{t: number; k?: number}> = ({t, k = 1}) => (
  <g opacity={0.4 * k} stroke="#fff" strokeWidth={6} fill="none" strokeLinecap="round">
    {Array.from({length: 10}, (_, i) => {
      const y = 520 + rnd(i + 20) * 900, sp = 260 + rnd(i + 40) * 260;
      const x = ((t * sp + rnd(i + 60) * 1400) % 1500) - 300;
      return <path key={i} d={`M${x} ${y} h160 q40 0 40 -26 q0 -22 -26 -22`} />;
    })}
  </g>
);

// ---------- gedung (melentur: simpangan ~ (tinggi)^2) ----------
const offAt = (i: number, n: number, amp: number) => amp * Math.pow(i / n, 2);

const Building: React.FC<{cx: number; base?: number; w: number; h: number; amp: number; floors?: number; body?: string; ghost?: boolean; stroke?: string; sw?: number; seed?: number; lit?: number; antenna?: boolean}> =
  ({cx, base = GROUND, w, h, amp, floors = 22, body = C.bld, ghost = false, stroke = C.navy, sw = 6, seed = 1, lit = 0.55, antenna = true}) => {
    const n = floors, dy = h / n;
    const L: string[] = [], R: string[] = [];
    for (let i = 0; i <= n; i++) { const y = base - i * dy, o = offAt(i, n, amp); L.push(`${cx - w / 2 + o},${y}`); R.push(`${cx + w / 2 + o},${y}`); }
    const pts = [...L, ...R.reverse()].join(' ');
    const cols = 4, ww = w / cols * 0.5, wh = dy * 0.5;
    return (
      <g>
        <polygon points={pts} fill={ghost ? 'none' : body} stroke={stroke} strokeWidth={sw} strokeDasharray={ghost ? '22 16' : undefined} strokeLinejoin="round" />
        {!ghost && Array.from({length: n}, (_, i) => Array.from({length: cols}, (_, c) => {
          const o = offAt(i + 0.5, n, amp), on = rnd(seed * 131 + i * 7 + c) < lit;
          return <rect key={`${i}-${c}`} x={cx - w / 2 + o + w * (c + 0.5) / cols - ww / 2} y={base - (i + 0.5) * dy - wh / 2} width={ww} height={wh} rx={3} fill={on ? C.lit : C.glass} opacity={on ? 0.95 : 0.55} />;
        }))}
        {antenna && <line x1={cx + amp} y1={base - h} x2={cx + amp * 1.06} y2={base - h - 130} stroke={stroke} strokeWidth={sw + 2} strokeLinecap="round" />}
      </g>
    );
  };

// ---------- ADEGAN ----------
const BX = 540, BW = 250, BH = 950;

const S1: React.FC<{t: number}> = ({t}) => {
  const am = swy(t, 70 * sm(prog(t, 0, 2.5)));
  const tx = BX + am, ty = GROUND - BH - 40;
  return (
    <g>
      <WindStreaks t={t} />
      <T x={540} y={230} lines={['MENGAPA GEDUNG TINGGI', 'BISA BERGOYANG?']} size={66} p={ap(t, 0.3, 0.8)} />
      <Building cx={BX} w={BW} h={BH} amp={am} />
      {t > 5.5 && <g opacity={ap(t, 5.5)}>
        <Arrow x1={tx - 60} y1={ty} x2={tx - 200} y2={ty} color={C.orange} w={12} />
        <Arrow x1={tx + 60} y1={ty} x2={tx + 200} y2={ty} color={C.orange} w={12} />
      </g>}
      <Pill x={540} y={1700} text="Bagian atas bergerak sedikit" size={40} p={ap(t, 6.5)} />
    </g>
  );
};

const S2: React.FC<{t: number}> = ({t}) => {
  const A = 70, am = swy(t, A);
  return (
    <g>
      <g opacity={0.18 * ap(t, 0.3, 1)} stroke="#fff" strokeWidth={2}>
        {Array.from({length: 14}, (_, i) => <line key={'v' + i} x1={i * 80} y1={0} x2={i * 80} y2={GROUND} />)}
        {Array.from({length: 20}, (_, i) => <line key={'h' + i} x1={0} y1={i * 80} x2={WIDTH} y2={i * 80} />)}
      </g>
      <T x={540} y={230} lines={['DIPERHITUNGKAN', 'SEJAK TAHAP DESAIN']} size={62} p={ap(t, 0.3, 0.8)} />
      <g opacity={ap(t, 1.5, 1)}>
        <Building cx={BX} w={BW} h={BH} amp={A} ghost stroke={C.orange} sw={5} floors={22} antenna={false} />
        <Building cx={BX} w={BW} h={BH} amp={-A} ghost stroke={C.orange} sw={5} floors={22} antenna={false} />
      </g>
      <Building cx={BX} w={BW} h={BH} amp={am} />
      <Pill x={540} y={1640} text="Gerak terkendali = selamat" size={40} bg={C.green} fg={C.navy} check p={ap(t, 6.5)} />
      <Pill x={540} y={1760} text="Bergoyang bukan berarti runtuh" size={36} bg={C.teal} p={ap(t, 9)} />
    </g>
  );
};

const S3: React.FC<{t: number}> = ({t}) => {
  const quake = t > 2.4 ? 1 : 0;
  const am = swy(t, 45 * ap(t, 0, 1)) + (quake ? swy(t, 10, 3.2) * ap(t, 2.4, 0.5) : 0);
  const spiral = (r0: number, ph: number) => {
    const pts = []; for (let k = 0; k < 60; k++) { const a = k * 0.35 + ph, r = r0 + k * 3.2; pts.push(`${(k ? 'L' : 'M')}${790 + Math.cos(a) * r} ${760 + Math.sin(a) * r * 0.7}`); }
    return pts.join(' ');
  };
  return (
    <g>
      <T x={540} y={230} lines={['PENYEBAB GEDUNG', 'BERGOYANG']} size={66} p={ap(t, 0.2, 0.7)} />
      <Building cx={BX} w={BW} h={BH} amp={am} />
      {/* angin: panah makin panjang makin tinggi */}
      <g opacity={ap(t, 0.4)}>
        {Array.from({length: 7}, (_, i) => {
          const f = i / 6, y = GROUND - 120 - f * (BH - 160), len = 70 + 230 * f, pulse = Math.sin(t * 5 + i) * 10, xe = BX - BW / 2 - 24 + offAt(f * 22, 22, am);
          return <Arrow key={i} x1={xe - len - pulse} y1={y} x2={xe} y2={y} color="#fff" w={9 + 4 * f} />;
        })}
      </g>
      {quake > 0 && <g opacity={ap(t, 2.4)} stroke={C.orange} strokeWidth={8} fill="none" strokeLinecap="round">
        {[0, 1, 2].map(i => <path key={i} d={`M${100 + i * 20} ${GROUND + 60 + i * 50} l40 -22 l40 44 l40 -44 l40 44 l40 -44 l40 44 l40 -44 l40 44 l40 -44 l40 44 l40 -44 l40 44 l40 -44 l40 22`} transform={`translate(${swy(t, 14, 3, i)} 0)`} />)}
      </g>}
      {t > 4.2 && <g opacity={ap(t, 4.2)} stroke="#fff" strokeWidth={8} fill="none" strokeLinecap="round" strokeDasharray="30 18" strokeDashoffset={-t * 120}>
        <path d={spiral(10, t * 3)} /><path d={spiral(40, t * 3 + 2)} opacity={0.7} />
      </g>}
      <Pill x={250} y={420} text="Angin" size={38} bg={C.teal} p={ap(t, 0.6)} />
      <Pill x={540} y={420} text="Gempa" size={38} bg={C.orange} p={ap(t, 2.6)} />
      <Pill x={830} y={420} text="Pusaran udara" size={34} bg="#6c5ce7" p={ap(t, 4.4)} />
      <Pill x={540} y={1720} text="Makin tinggi, angin makin kuat" size={36} bg={C.red} p={ap(t, 5.5)} />
    </g>
  );
};

const Card: React.FC<{y: number; title: string; sub: string; color: string; p: number; icon: React.ReactNode}> = ({y, title, sub, color, p, icon}) => (
  <g opacity={p} transform={`translate(${(1 - p) * -80} 0)`}>
    <rect x={90} y={y} width={900} height={230} rx={36} fill="#0e1c36" stroke={color} strokeWidth={8} opacity={0.96} />
    <g transform={`translate(230 ${y + 115})`}>{icon}</g>
    <text x={400} y={y + 105} fontFamily={FONT} fontWeight={800} fontSize={52} fill="#fff">{title}</text>
    <text x={400} y={y + 165} fontFamily={FONT} fontWeight={500} fontSize={34} fill="#c9d8ee">{sub}</text>
  </g>
);

const S4: React.FC<{t: number}> = ({t}) => {
  const k = Math.sin(t * 4);
  const spring = (() => { const top = -70, bot = 70 + k * 18; const n = 8; let d = `M0 ${top}`; for (let i = 1; i <= n; i++) d += ` L${i % 2 ? 36 : -36} ${top + (bot - top) * (i / (n + 1))}`; return d + ` L0 ${bot}`; })();
  const sx = t > 8 ? 540 + 360 * Math.exp(-0.55 * (t - 8)) * Math.cos(2.4 * (t - 8)) : 540;
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="#0b1d3a" opacity={0.55} />
      <T x={540} y={190} lines={['3 HAL YANG', 'DISEIMBANGKAN']} size={66} p={ap(t, 0.2, 0.7)} />
      <Card y={330} title="Kekakuan" sub="menahan perubahan bentuk" color={C.teal} p={ap(t, 0.8)} icon={<path d={spring} fill="none" stroke={C.teal} strokeWidth={10} strokeLinejoin="round" />} />
      <Card y={590} title="Massa" sub="memengaruhi respons gerakan" color={C.gold} p={ap(t, 3.2)} icon={<g transform={`translate(0 ${k * 6})`}><path d="M-60 60 L-40 -30 H40 L60 60 Z" fill={C.gold} stroke={C.navy} strokeWidth={5} /><circle cx={0} cy={-42} r={14} fill="none" stroke={C.gold} strokeWidth={8} /></g>} />
      <Card y={850} title="Peredaman" sub="mengurangi getaran" color={C.orange} p={ap(t, 5.6)} icon={<g><rect x={-30} y={-60} width={60} height={70} rx={8} fill="#8795ad" /><rect x={-9} y={-10 + k * 14} width={18} height={70} fill="#d9e2f0" /><rect x={-30} y={50 + k * 14} width={60} height={12} rx={5} fill={C.orange} /></g>} />
      {/* slider keseimbangan */}
      <g opacity={ap(t, 8)}>
        <defs><linearGradient id="bal" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor={C.red} /><stop offset="0.5" stopColor={C.green} /><stop offset="1" stopColor={C.red} /></linearGradient></defs>
        <rect x={120} y={1290} width={840} height={36} rx={18} fill="url(#bal)" stroke={C.navy} strokeWidth={5} />
        <circle cx={sx} cy={1308} r={34} fill="#fff" stroke={C.navy} strokeWidth={8} />
        <T x={120} y={1400} lines={['Terlalu kaku']} size={38} anchor="start" />
        <T x={120} y={1450} lines={['desain tidak efisien']} size={30} anchor="start" weight={600} />
        <T x={960} y={1400} lines={['Terlalu fleksibel']} size={38} anchor="end" />
        <T x={960} y={1450} lines={['gerak berlebihan, tidak nyaman']} size={28} anchor="end" weight={600} />
      </g>
      <Pill x={540} y={1640} text="Seimbang = aman & nyaman" size={42} bg={C.green} fg={C.navy} check p={ap(t, 11)} />
    </g>
  );
};

const S5: React.FC<{t: number}> = ({t}) => {
  const w = 17, amp = 80, am = swy(t, amp, 0.4), n = 22, w2 = 360, h2 = 1000;
  const base = GROUND, top = base - h2;
  const o = (i: number) => offAt(i, n, am);
  const anchorX = BX + o(n - 0.6), anchorY = top + (h2 / n) * 0.5 + 40, L = 190;
  const th = -0.5 * Math.sin(TAU * 0.4 * t - 0.15);
  const bx = anchorX + Math.sin(th) * L, by = anchorY + Math.cos(th) * L;
  const dir = Math.cos(TAU * 0.4 * t) >= 0 ? 1 : -1;
  const pl = [`${BX - w2 / 2 + o(n - 3.4) + 16},${top + (h2 / n) * 3.4}`, `${BX + w2 / 2 + o(n - 3.4) - 16},${top + (h2 / n) * 3.4}`, `${BX + w2 / 2 + o(n - 0.3) - 16},${top + (h2 / n) * 0.3}`, `${BX - w2 / 2 + o(n - 0.3) + 16},${top + (h2 / n) * 0.3}`].join(' ');
  void w;
  return (
    <g>
      <T x={540} y={230} lines={['TUNED MASS DAMPER']} size={64} p={ap(t, 0.2, 0.7)} />
      <Building cx={BX} w={w2} h={h2} amp={am} seed={4} />
      <polygon points={pl} fill="#0c1a33" stroke={C.gold} strokeWidth={5} opacity={ap(t, 0.5, 0.8)} />
      <g opacity={ap(t, 0.8, 0.8)}>
        <rect x={anchorX - 70} y={anchorY - 14} width={140} height={14} rx={5} fill="#8795ad" />
        <line x1={anchorX} y1={anchorY} x2={bx} y2={by} stroke="#d9e2f0" strokeWidth={7} />
        <circle cx={bx} cy={by} r={50} fill={C.gold} stroke={C.navy} strokeWidth={6} />
      </g>
      <g opacity={ap(t, 3)}>
        <T x={900} y={700} lines={['Gedung']} size={36} p={1} />
        <Arrow x1={900 - dir * 60} y1={740} x2={900 + dir * 60} y2={740} color={C.red} w={14} />
        <T x={900} y={850} lines={['Massa']} size={36} />
        <Arrow x1={900 + dir * 60} y1={890} x2={900 - dir * 60} y2={890} color={C.teal} w={14} />
      </g>
      <Pill x={540} y={1700} text="Massa bergerak melawan ayunan" size={36} bg={C.orange} p={ap(t, 4)} />
    </g>
  );
};

const S6: React.FC<{t: number}> = ({t}) => {
  const f = 0.4, am = swy(t, 80, f), cx = 260, base = GROUND;
  const off = (y: number) => am * Math.pow((base - y) / 1000, 2);
  const tiers: React.ReactNode[] = [];
  for (let i = 0; i < 8; i++) {
    const yb = base - 120 - i * 100, yt = yb - 100, b = 230 - 12 * i, tp = b * 1.2;
    tiers.push(<polygon key={i} points={`${cx - b / 2 + off(yb)},${yb} ${cx + b / 2 + off(yb)},${yb} ${cx + tp / 2 + off(yt)},${yt} ${cx - tp / 2 + off(yt)},${yt}`} fill={i % 2 ? '#2f8f83' : '#35a597'} stroke={C.navy} strokeWidth={5} strokeLinejoin="round" />);
  }
  const ys = base - 120 - 5.5 * 100;
  const th = -0.5 * Math.sin(TAU * f * t - 0.15);
  const ccx = 720, ccy = 800, R = 300;
  const ceilX = ccx + 70 * Math.sin(TAU * f * t), ceilY = ccy - 200;
  const bx = ceilX + Math.sin(th) * 230, by = ceilY + Math.cos(th) * 230;
  const dir = Math.cos(TAU * f * t) >= 0 ? 1 : -1;
  const sx = cx + off(ys) + Math.sin(th) * 28, sy = ys + 6;
  return (
    <g>
      <T x={540} y={220} lines={['TAIPEI 101']} size={78} p={ap(t, 0.3, 0.8)} />
      <T x={540} y={290} lines={['Taiwan']} size={40} weight={600} p={ap(t, 0.8, 0.8)} />
      <rect x={cx - 140 + off(base)} y={base - 120} width={280} height={120} fill={C.bldD} stroke={C.navy} strokeWidth={5} />
      {tiers}
      <line x1={cx + off(base - 920)} y1={base - 920} x2={cx + off(base - 1060)} y2={base - 1060} stroke={C.navy} strokeWidth={10} strokeLinecap="round" />
      <circle cx={sx} cy={sy} r={30} fill={C.gold} stroke={C.navy} strokeWidth={5} />
      <g opacity={ap(t, 1.2, 0.8)}>
        <line x1={sx + 30} y1={sy - 20} x2={ccx - R + 40} y2={ccy + 30} stroke={C.gold} strokeWidth={5} strokeDasharray="12 10" />
        <defs>
          <clipPath id="bub"><circle cx={ccx} cy={ccy} r={R} /></clipPath>
          <radialGradient id="ball" cx="0.35" cy="0.3" r="0.8"><stop offset="0" stopColor="#fff0a8" /><stop offset="0.6" stopColor={C.gold} /><stop offset="1" stopColor="#b9821a" /></radialGradient>
        </defs>
        <circle cx={ccx} cy={ccy} r={R} fill="#0c1a33" />
        <g clipPath="url(#bub)">
          <rect x={ceilX - 150} y={ceilY - 20} width={300} height={22} rx={6} fill="#8795ad" />
          <line x1={ceilX} y1={ceilY} x2={bx} y2={by} stroke="#d9e2f0" strokeWidth={8} />
          <line x1={bx} y1={by} x2={ccx - 300 + 70 * Math.sin(TAU * f * t)} y2={by + 20} stroke="#8795ad" strokeWidth={16} />
          <line x1={bx} y1={by} x2={ccx + 300 + 70 * Math.sin(TAU * f * t)} y2={by + 20} stroke="#8795ad" strokeWidth={16} />
          <circle cx={bx} cy={by} r={92} fill="url(#ball)" stroke={C.navy} strokeWidth={6} />
          <text x={bx} y={by + 14} fontFamily={FONT} fontWeight={800} fontSize={40} fill={C.navy} textAnchor="middle">660 t</text>
        </g>
        <circle cx={ccx} cy={ccy} r={R} fill="none" stroke={C.gold} strokeWidth={10} />
      </g>
      <Pill x={720} y={1230} text="Bola baja ±660 ton" size={36} bg={C.gold} fg={C.navy} p={ap(t, 4)} />
      <g opacity={ap(t, 8.5)}>
        <T x={620} y={1360} lines={['Gedung']} size={34} />
        <Arrow x1={620 - dir * 60} y1={1400} x2={620 + dir * 60} y2={1400} color={C.red} w={14} />
        <T x={880} y={1360} lines={['Bola']} size={34} />
        <Arrow x1={880 + dir * 60} y1={1400} x2={880 - dir * 60} y2={1400} color={C.teal} w={14} />
      </g>
      <Pill x={540} y={1700} text="Arah berlawanan, ayunan berkurang" size={34} bg={C.teal} p={ap(t, 10)} />
    </g>
  );
};

const S7: React.FC<{t: number}> = ({t}) => {
  const rot = swy(t, 3.2, 0.45), uneasy = t > 4.5;
  const slosh = -rot * 1.4 + swy(t, 5, 0.9);
  return (
    <g>
      <rect width={WIDTH} height={HEIGHT} fill="#0b1d3a" opacity={0.45} />
      <T x={540} y={230} lines={['DI LANTAI ATAS']} size={66} p={ap(t, 0.2, 0.7)} />
      <g transform={`rotate(${rot} 540 1380)`}>
        <rect x={150} y={420} width={780} height={960} rx={30} fill="#1c2b47" stroke={C.navy} strokeWidth={8} />
        <rect x={210} y={480} width={660} height={430} rx={18} fill="#8ecdf0" stroke={C.navy} strokeWidth={6} />
        {[0, 1, 2, 3, 4].map(i => <rect key={i} x={240 + i * 125} y={900 - 150 - rnd(i + 5) * 170} width={90} height={150 + rnd(i + 5) * 170} fill="#5d84ad" />)}
        <rect x={150} y={1240} width={780} height={140} fill="#5b3a29" stroke={C.navy} strokeWidth={6} />
        {/* orang */}
        <rect x={290} y={1020} width={190} height={230} rx={70} fill="#4c7bd6" stroke={C.navy} strokeWidth={6} />
        <circle cx={385} cy={960} r={74} fill="#f0c29b" stroke={C.navy} strokeWidth={6} />
        {uneasy ? <g stroke={C.navy} strokeWidth={5} fill="none"><circle cx={358} cy={950} r={14} /><circle cx={412} cy={950} r={14} /><path d={`M355 995 q15 ${-14} 30 0 q15 14 30 0`} /></g>
          : <g fill={C.navy}><circle cx={358} cy={950} r={8} /><circle cx={412} cy={950} r={8} /><path d="M358 990 q27 24 54 0" stroke={C.navy} strokeWidth={5} fill="none" /></g>}
        {/* gelas */}
        <g transform="translate(700 1240)">
          <clipPath id="gl"><path d="M-70 -160 H70 L56 0 H-56 Z" /></clipPath>
          <g clipPath="url(#gl)"><g transform={`rotate(${slosh} 0 -70)`}><rect x={-120} y={-90} width={240} height={160} fill="#4cc3ff" /></g></g>
          <path d="M-70 -160 H70 L56 0 H-56 Z" fill="none" stroke="#fff" strokeWidth={7} strokeLinejoin="round" />
        </g>
      </g>
      <Pill x={540} y={1560} text="Aman secara struktur" size={40} bg={C.green} fg={C.navy} check p={ap(t, 1.2)} />
      <Pill x={540} y={1680} text="Tapi terasa tidak nyaman" size={40} bg={C.orange} p={ap(t, 4.5)} />
    </g>
  );
};

const S8: React.FC<{t: number}> = ({t}) => {
  const am = swy(t, 100, 0.5), pulse = 0.5 + 0.5 * Math.sin(t * 6);
  const cy = GROUND - 380, cxk = BX - 40 + offAt(8.2, 22, am);
  const mx = cxk + 70 + Math.sin(t * 1.6) * 40, my = cy - 20 + Math.cos(t * 1.3) * 30;
  return (
    <g>
      <T x={540} y={220} lines={['GERAKAN BERLEBIHAN', 'ATAU TANDA KERUSAKAN']} size={56} p={ap(t, 0.2, 0.6)} />
      <Building cx={BX} w={BW} h={BH} amp={am} stroke={C.red} sw={6 + pulse * 6} seed={7} lit={0.3} />
      <path d={`M${cxk - 30} ${cy - 90} l24 36 l-26 30 l30 36 l-18 40`} fill="none" stroke={C.red} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
      <g opacity={ap(t, 1.2)}>
        <circle cx={mx} cy={my} r={110} fill="#ffffff" fillOpacity={0.18} stroke="#fff" strokeWidth={14} />
        <line x1={mx + 78} y1={my + 78} x2={mx + 180} y2={my + 180} stroke="#fff" strokeWidth={22} strokeLinecap="round" />
      </g>
      <Pill x={540} y={1700} text="Tetap perlu diperiksa" size={44} bg={C.red} p={ap(t, 1.5)} />
    </g>
  );
};

const S9: React.FC<{t: number}> = ({t}) => {
  const am = swy(t, 28 * ap(t, 0, 0.6), 0.3);
  return (
    <g>
      <T x={540} y={230} lines={['GEDUNG TINGGI', 'TIDAK HARUS DIAM']} size={68} p={ap(t, 0.2, 0.6)} />
      <Building cx={BX} w={BW} h={BH} amp={am} seed={2} />
      <Pill x={540} y={1700} text="untuk tetap berdiri kokoh" size={44} bg={C.green} fg={C.navy} check p={ap(t, 1.6)} />
    </g>
  );
};

const S10: React.FC<{t: number}> = ({t}) => (
  <g>
    <rect width={WIDTH} height={HEIGHT} fill="#0b1d3a" opacity={0.6} />
    <g opacity={ap(t, 0.2, 0.6)}>
      <rect x={100} y={560} width={880} height={680} rx={48} fill="#101f3d" stroke={C.gold} strokeWidth={8} />
    </g>
    <Pill x={540} y={560} text="CATATAN" size={40} bg={C.gold} fg={C.navy} p={ap(t, 0.4)} />
    <T x={540} y={740} lines={['Pembahasan ini terutama', 'tentang angin.']} size={56} p={ap(t, 0.9)} />
    <T x={540} y={960} lines={['Respons terhadap gempa', 'punya pertimbangan', 'desain tambahan.']} size={52} fill="#d6e4fa" weight={700} p={ap(t, 2.6)} />
  </g>
);

const SCENE_FNS = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10];

export const Gedung: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  return (
    <AbsoluteFill style={{backgroundColor: C.navy}}>
      <Audio src={staticFile('audio.mp3')} />
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0}}>
        <Background t={t} />
        {SCENE_FNS.map((Fn, i) => {
          const a = SCENES[i], b = SCENES[i + 1];
          if (t < a || t >= b) return null;
          const op = Math.min(i === 0 ? 1 : prog(t, a, a + 0.4), 1 - prog(t, b - 0.3, b) * (i === SCENE_FNS.length - 1 ? 0 : 1));
          return <g key={i} opacity={op}><Fn t={t - a} /></g>;
        })}
        {/* watermark */}
        <text x={44} y={1868} fontFamily={FONT} fontWeight={700} fontSize={42} fill="#fff" fillOpacity={0.9} stroke="#000" strokeOpacity={0.5} strokeWidth={6} paintOrder="stroke">@semestakita</text>
      </svg>
    </AbsoluteFill>
  );
};
