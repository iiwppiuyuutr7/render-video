import React from 'react';
import {Composition} from 'remotion';
import {Gedung, FPS, WIDTH, HEIGHT, TOTAL_SECONDS} from './Gedung';

export const RemotionRoot: React.FC = () => (
  <Composition id="Gedung" component={Gedung} durationInFrames={Math.round(TOTAL_SECONDS * FPS)} fps={FPS} width={WIDTH} height={HEIGHT} />
);
