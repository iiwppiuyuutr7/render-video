import React from 'react';
import {Composition} from 'remotion';
import {Chip} from './Chip';

export const RemotionRoot: React.FC = () => (
  <Composition id="Chip" component={Chip} durationInFrames={5460} fps={60} width={1080} height={1920} />
);
