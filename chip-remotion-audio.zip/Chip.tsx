import React from 'react';
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as loadCond} from '@remotion/google-fonts/BarlowCondensed';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';
import {loadFont as loadMono} from '@remotion/google-fonts/JetBrainsMono';

/*
  BAGAIMANA KOMPONEN KOMPUTER BISA SEKECIL ITU?  (gaya terang, satu ide per layar)
  91 detik, vertikal 1080x1920, 60 fps. Semua waktu dalam DETIK (aman di 30 maupun 60 fps).
  3D voxel/isometrik murni SVG (tanpa WebGL). Waktu kalimat ada di SENT (sinkron dengan voice.mp3).
*/

const cond = loadCond('normal', {weights: ['600', '700'], subsets: ['latin']}).fontFamily;
const sans = loadInter('normal', {weights: ['500', '600', '700', '800'], subsets: ['latin']}).fontFamily;
const mono = loadMono('normal', {weights: ['500', '700'], subsets: ['latin']}).fontFamily;

const W = 1080;
const H = 1920;
const CX = 540;
const DUR = 91;
const WM_BOTTOM = 270; // jarak watermark dari bawah (naikkan/turunkan di sini)

const C = {
  orange: '#f26a0f',
  amber: '#ffb020',
  cyan: '#0e9bb5',
  cyanL: '#5ad1ff',
  bone: '#f4e8cf',
  ink: '#5a3d22',
  dark: '#14161c',
  red: '#e5484d',
  green: '#1f9d6b',
  bg: '#f6f5f0',
};

// batas scene (detik)
const SCT = [0, 7.7, 20.3, 33.4, 45.6, 60.4, 68.5, 74.4, 81.3, 87.6];
const CHAPTERS = ['PEMBUKA', 'ENIAC 1946', 'TRANSISTOR 1947', 'RANGKAIAN TERPADU', 'FOTOLITOGRAFI', 'HUKUM MOORE', 'CAHAYA EUV', 'ANGKA NANOMETER', 'KESIMPULAN'];

const SENT: {a: number; b: number; t: string}[] = [
  {a: 0.00, b: 3.35, t: "Ada chip di HP-mu yang berisi puluhan miliar komponen,"},
  {a: 3.50, b: 5.51, t: "masing-masing lebih kecil dari debu."},
  {a: 5.79, b: 7.52, t: "Bagaimana manusia bisa membuatnya?"},
  {a: 7.81, b: 12.74, t: "Ceritanya dimulai tahun 1946, dengan komputer ENIAC."},
  {a: 13.02, b: 14.86, t: "Beratnya sekitar 30 ton,"},
  {a: 15.00, b: 18.14, t: "memakai sekitar 18.000 tabung vakum"},
  {a: 18.28, b: 20.08, t: "yang besar, panas, dan gampang rusak."},
  {a: 20.36, b: 25.33, t: "Lalu pada 1947, peneliti Bell Labs menemukan transistor."},
  {a: 25.61, b: 28.16, t: "Ia bekerja seperti sakelar yang menyala dan mati,"},
  {a: 28.30, b: 30.05, t: "mewakili angka 1 dan 0,"},
  {a: 30.19, b: 33.25, t: "tapi jauh lebih kecil, hemat energi, dan awet."},
  {a: 33.53, b: 41.24, t: "Tahun 1958, Jack Kilby memperagakan rangkaian terpadu, dan Robert Noyce mengembangkannya berbasis silikon."},
  {a: 41.52, b: 44.90, t: "Hasilnya, banyak transistor bisa dibuat dalam satu keping:"},
  {a: 45.05, b: 45.44, t: "chip."},
  {a: 45.72, b: 47.49, t: "Rahasianya fotolitografi."},
  {a: 47.77, b: 50.29, t: "Wafer silikon dilapisi bahan peka cahaya,"},
  {a: 50.44, b: 52.86, t: "lalu disinari lewat cetakan pola rangkaian."},
  {a: 53.15, b: 57.67, t: "Bagian yang terkena cahaya berubah sifat dan bisa dihilangkan, lalu dietsa."},
  {a: 57.95, b: 60.30, t: "Proses ini diulang lapis demi lapis."},
  {a: 60.58, b: 68.30, t: "Pada 1965, Gordon Moore mengamati jumlah komponen dalam chip terus berlipat ganda, dikenal sebagai Hukum Moore."},
  {a: 68.58, b: 74.24, t: "Kini pabrik memakai cahaya ultraviolet ekstrem dengan panjang gelombang 13,5 nanometer."},
  {a: 74.53, b: 81.07, t: "Tapi angka 3 nm pada nama prosesor adalah nama generasi teknologi, bukan ukuran pasti transistornya."},
  {a: 81.35, b: 85.52, t: "Jadi chip sekecil itu bukan sulap, tapi hasil puluhan tahun fisika, kimia,"},
  {a: 85.66, b: 87.21, t: "dan rekayasa."},
];


// potongan subtitle dengan waktu per kata (sebanding panjang kata)
const CHUNKS = (() => {
  const out: {a: number; b: number; words: {w: string; a: number; b: number}[]}[] = [];
  for (const n of SENT) {
    const w = n.t.split(' ');
    const parts = Math.ceil(w.length / 7);
    const size = Math.ceil(w.length / parts);
    for (let i = 0; i < w.length; i += size) {
      const ws = w.slice(i, i + size);
      out.push({a: 0, b: 0, words: ws.map((x) => ({w: x, a: 0, b: 0}))});
      (out[out.length - 1] as any).src = n;
      (out[out.length - 1] as any).idx = i;
    }
  }
  // distribusi waktu per kalimat
  for (const n of SENT) {
    const mine = out.filter((c: any) => c.src === n);
    const total = mine.reduce((s, c) => s + c.words.reduce((q, x) => q + x.w.length + 2, 0), 0);
    let cur = n.a;
    for (const c of mine) {
      for (const x of c.words) {
        const d = ((n.b - n.a) * (x.w.length + 2)) / total;
        x.a = cur;
        x.b = cur + d;
        cur += d;
      }
      c.a = c.words[0].a;
      c.b = c.words[c.words.length - 1].b;
    }
  }
  return out;
})();

/* ---------- util ---------- */
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const ramp = (t: number, a: number, b: number) => clamp((t - a) / (b - a), 0, 1);
const eo = (x: number) => 1 - Math.pow(1 - x, 3);
const win = (t: number, a: number, b: number, f = 0.25) => ramp(t, a, a + f) * (1 - ramp(t, b - f, b));
const pop = (t: number, a: number) => {
  const x = ramp(t, a, a + 0.4);
  if (x <= 0) return 0;
  const c = 1.70158;
  return 1 + (c + 1) * Math.pow(x - 1, 3) + c * Math.pow(x - 1, 2);
};
const sh = (hex: string, f: number) => {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.round(((n >> 16) & 255) * f));
  const g = Math.min(255, Math.round(((n >> 8) & 255) * f));
  const b = Math.min(255, Math.round((n & 255) * f));
  return `rgb(${r},${g},${b})`;
};
type P = [number, number];
const pr = (o: P, s: number, x: number, y: number, z: number): P => [o[0] + (x - y) * 0.866 * s, o[1] + (x + y) * 0.5 * s - z * s];
const poly = (pts: P[]) => pts.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');

const IsoBox: React.FC<{o: P; s?: number; x: number; y: number; z?: number; w: number; d: number; h: number; c: string; op?: number}> = ({o, s = 1, x, y, z = 0, w, d, h, c, op = 1}) => {
  const q = (a: number, b: number, cc: number) => pr(o, s, a, b, cc);
  return (
    <g opacity={op}>
      <polygon points={poly([q(x, y + d, z), q(x + w, y + d, z), q(x + w, y + d, z + h), q(x, y + d, z + h)])} fill={sh(c, 0.82)} />
      <polygon points={poly([q(x + w, y, z), q(x + w, y + d, z), q(x + w, y + d, z + h), q(x + w, y, z + h)])} fill={sh(c, 0.62)} />
      <polygon points={poly([q(x, y, z + h), q(x + w, y, z + h), q(x + w, y + d, z + h), q(x, y + d, z + h)])} fill={sh(c, 1.08)} />
    </g>
  );
};

const Pill: React.FC<{x: number; y: number; s: string; t: number; a: number; bg?: string; fg?: string; size?: number}> = ({x, y, s, t, a, bg = C.dark, fg = '#ffffff', size = 36}) => {
  const p = pop(t, a);
  if (p <= 0.001) return null;
  const w = s.length * size * 0.62 + 56;
  const h = size * 1.7;
  return (
    <g transform={`translate(${x},${y}) scale(${p})`}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={h / 2} fill={bg} />
      <text textAnchor="middle" y={size * 0.36} fontFamily={mono} fontWeight={700} fontSize={size} fill={fg}>
        {s}
      </text>
    </g>
  );
};

const Big: React.FC<{x: number; y: number; s: string; t: number; a: number; size?: number; fill?: string; rot?: number}> = ({x, y, s, t, a, size = 110, fill = C.dark, rot = 0}) => {
  const p = pop(t, a);
  if (p <= 0.001) return null;
  return (
    <text transform={`translate(${x},${y}) rotate(${rot}) scale(${p})`} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill={fill}>
      {s}
    </text>
  );
};

const Title: React.FC<{t: number; a: number; lines: [string, number][][]}> = ({t, a, lines}) => {
  const longest = Math.max(...lines.map((l) => l.map((x) => x[0]).join('').length));
  const size = Math.min(118, 940 / (longest * 0.46));
  const o = ramp(t, a, a + 0.35);
  return (
    <g opacity={o} transform={`translate(0,${20 * (1 - eo(o))})`}>
      {lines.map((l, i) => (
        <text key={i} x={CX} y={205 + i * size * 1.02} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={size} fill={C.dark}>
          {l.map(([s, k], j) => (
            <tspan key={j} fill={k ? C.orange : C.dark}>
              {s}
            </tspan>
          ))}
        </text>
      ))}
    </g>
  );
};

/* ---------- maskot Fosi + meme ---------- */
const Fosi: React.FC<{x: number; y: number; sc?: number; mood: 'shock' | 'hmm'; t: number}> = ({x, y, sc = 1, mood, t}) => {
  const bob = Math.sin(t * 7) * 3;
  const eyeY = -8;
  return (
    <g transform={`translate(${x},${y + bob}) scale(${sc})`}>
      <ellipse cx={0} cy={86} rx={70} ry={12} fill="#00000022" />
      <ellipse cx={0} cy={10} rx={92} ry={82} fill={C.orange} />
      <ellipse cx={0} cy={34} rx={58} ry={44} fill="#ffb26b" />
      <path d="M -40 -70 L -62 -112 L -14 -80 Z" fill={C.orange} />
      <path d="M 40 -70 L 62 -112 L 14 -80 Z" fill={C.orange} />
      <circle cx={-34} cy={eyeY} r={26} fill="#ffffff" stroke="#14161c" strokeWidth={4} />
      <circle cx={34} cy={eyeY} r={26} fill="#ffffff" stroke="#14161c" strokeWidth={4} />
      {mood === 'shock' ? (
        <g>
          <circle cx={-34} cy={eyeY} r={7} fill="#14161c" />
          <circle cx={34} cy={eyeY} r={7} fill="#14161c" />
          <ellipse cx={0} cy={48} rx={16} ry={22} fill="#7a2b00" />
          <path d="M -62 -42 Q -34 -62 -8 -44" stroke="#14161c" strokeWidth={6} fill="none" strokeLinecap="round" />
          <path d="M 62 -42 Q 34 -62 8 -44" stroke="#14161c" strokeWidth={6} fill="none" strokeLinecap="round" />
          <path d="M 84 -30 q 10 18 0 28 q -10 -10 0 -28 Z" fill={C.cyanL} />
        </g>
      ) : (
        <g>
          <circle cx={-26} cy={eyeY + 4} r={9} fill="#14161c" />
          <circle cx={42} cy={eyeY + 4} r={9} fill="#14161c" />
          <path d="M -62 -30 L -10 -42" stroke="#14161c" strokeWidth={7} strokeLinecap="round" />
          <path d="M 10 -52 L 62 -34" stroke="#14161c" strokeWidth={7} strokeLinecap="round" />
          <path d="M -22 52 L 26 46" stroke="#7a2b00" strokeWidth={7} strokeLinecap="round" />
        </g>
      )}
    </g>
  );
};

const Meme: React.FC<{t: number; a: number; b: number; text: string; mood: 'shock' | 'hmm'; x: number; y: number; rot?: number}> = ({t, a, b, text, mood, x, y, rot = -4}) => {
  if (t < a || t > b + 0.3) return null;
  const pin = pop(t, a);
  const pout = 1 - ramp(t, b, b + 0.25);
  const sc = pin * pout;
  const fl = 1 - ramp(t, a, a + 0.3);
  return (
    <g>
      <rect x={0} y={0} width={W} height={H} fill="#000" opacity={0.28 * Math.min(1, ramp(t, a, a + 0.15)) * pout} />
      <circle cx={x} cy={y} r={120 + 500 * ramp(t, a, a + 0.35)} fill="none" stroke={C.orange} strokeWidth={14 * fl} opacity={fl} />
      <g transform={`translate(${x},${y}) rotate(${rot}) scale(${sc})`}>
        <rect x={-300} y={-200} width={600} height={400} rx={44} fill="#00000030" transform="translate(12,14)" />
        <rect x={-300} y={-200} width={600} height={400} rx={44} fill="#ffffff" stroke={C.dark} strokeWidth={10} />
        <Fosi x={0} y={-40} sc={1.3} mood={mood} t={t} />
        <text x={0} y={175} textAnchor="middle" fontFamily={cond} fontWeight={700} fontSize={92} fill="#ffffff" stroke={C.dark} strokeWidth={14} paintOrder="stroke" strokeLinejoin="round">
          {text}
        </text>
      </g>
    </g>
  );
};

/* ---------- objek 3D ---------- */
const Chip3D: React.FC<{o: P; s: number; t: number; reveal?: number}> = ({o, s, t, reveal = 1}) => {
  const q = (a: number, b: number, c: number) => pr(o, s, a, b, c);
  const cells: React.ReactNode[] = [];
  const n = 12;
  const cw = 200 / n;
  for (let i = 0; i < n; i++)
    for (let j = 0; j < n; j++) {
      const x0 = 30 + i * cw + 1.5;
      const y0 = 30 + j * cw + 1.5;
      const k = (i * 7 + j * 13) % 20 / 20;
      const on = clamp(reveal * 1.6 - k * 0.6, 0, 1);
      if (on <= 0) continue;
      const fl = 0.6 + 0.4 * Math.sin(t * 4 + i * 1.3 + j * 0.7);
      cells.push(<polygon key={i * 20 + j} points={poly([q(x0, y0, 27), q(x0 + cw - 3, y0, 27), q(x0 + cw - 3, y0 + cw - 3, 27), q(x0, y0 + cw - 3, 27)])} fill={C.cyanL} opacity={on * fl} />);
    }
  const pins: React.ReactNode[] = [];
  for (let i = 0; i < 10; i++) {
    pins.push(<IsoBox key={'a' + i} o={o} s={s} x={16 + i * 24} y={260} z={4} w={10} d={16} h={8} c="#c9ccd2" />);
    pins.push(<IsoBox key={'b' + i} o={o} s={s} x={260} y={16 + i * 24} z={4} w={16} d={10} h={8} c="#c9ccd2" />);
  }
  return (
    <g>
      {pins}
      <IsoBox o={o} s={s} x={0} y={0} w={260} d={260} h={26} c="#2b3340" />
      <polygon points={poly([q(24, 24, 26.5), q(236, 24, 26.5), q(236, 236, 26.5), q(24, 236, 26.5)])} fill="#141a22" />
      {cells}
    </g>
  );
};

const Tube2D: React.FC<{x: number; y: number; sc: number; lit?: number; t: number}> = ({x, y, sc, lit = 1, t}) => (
  <g transform={`translate(${x},${y}) scale(${sc})`}>
    <rect x={-55} y={-300} width={110} height={300} rx={55} fill="#ffe9b0" fillOpacity={0.35 + 0.4 * lit} stroke="#b88a2a" strokeWidth={6} />
    <path d="M -22 -40 L -22 -190 Q 0 -230 22 -190 L 22 -40" stroke={C.orange} strokeWidth={8} fill="none" opacity={0.5 + 0.5 * lit * (0.8 + 0.2 * Math.sin(t * 8))} />
    <rect x={-60} y={-4} width={120} height={34} rx={8} fill="#3b3f48" />
    {[-30, -10, 10, 30].map((v, i) => (
      <rect key={i} x={v - 3} y={26} width={6} height={30} fill="#c9ccd2" />
    ))}
  </g>
);

const Transistor3D: React.FC<{o: P; s: number}> = ({o, s}) => (
  <g>
    {[12, 36, 60].map((x, i) => (
      <IsoBox key={i} o={o} s={s} x={x} y={21} z={-70} w={8} d={8} h={70} c="#c9ccd2" />
    ))}
    <IsoBox o={o} s={s} x={0} y={0} w={80} d={50} h={100} c="#2a2f38" />
    <IsoBox o={o} s={s} x={8} y={10} z={100} w={64} d={30} h={4} c={C.cyan} />
  </g>
);

const Disc: React.FC<{cx: number; cy: number; rx: number; ry: number; th: number; top: string; side: string}> = ({cx, cy, rx, ry, th, top, side}) => (
  <g>
    <rect x={cx - rx} y={cy} width={rx * 2} height={th} fill={side} />
    <ellipse cx={cx} cy={cy + th} rx={rx} ry={ry} fill={side} />
    <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={top} />
  </g>
);
/* ---------- scene ---------- */
type SP = {t: number};

const S1: React.FC<SP> = ({t}) => {
  const dots: React.ReactNode[] = [];
  for (let i = 0; i < 7; i++)
    for (let j = 0; j < 6; j++) {
      const on = ramp(t, 3.4 + (i + j) * 0.06, 3.7 + (i + j) * 0.06);
      dots.push(<rect key={i * 9 + j} x={705 + i * 14} y={850 + j * 14} width={8} height={8} fill={C.cyan} opacity={on} />);
    }
  return (
    <g>
      <Title t={t} a={0.1} lines={[[['KOMPONEN DI', 0]], [['DALAM ', 0], ['CHIP', 1]]]} />
      <g transform={`translate(0,${Math.sin(t * 2) * 6})`}>
        <Chip3D o={[500, 400]} s={1.3} t={t} reveal={ramp(t, 0.5, 2.6)} />
      </g>
      <path d="M 560 720 Q 640 800 700 850" stroke={C.dark} strokeWidth={5} strokeDasharray="14 12" fill="none" opacity={ramp(t, 2.8, 3.2)} />
      <g opacity={ramp(t, 3.0, 3.5)}>
        <circle cx={770} cy={915} r={120} fill="#ffffff" stroke={C.dark} strokeWidth={10} />
        <line x1={855} y1={1000} x2={935} y2={1080} stroke={C.dark} strokeWidth={18} strokeLinecap="round" />
        <path d="M 715 880 Q 740 845 790 850 Q 840 860 835 910 Q 840 965 790 975 Q 735 985 715 940 Q 700 910 715 880 Z" fill="#a79f91" opacity={0.9} />
        {dots}
      </g>
      <Pill x={770} y={1070} s="DEBU" t={t} a={3.6} bg={C.orange} size={32} />
      <Big x={CX} y={1215} s="PULUHAN MILIAR" t={t} a={1.2} size={124} fill={C.dark} />
      <Pill x={CX} y={1265} s="KOMPONEN / CHIP" t={t} a={1.8} bg={C.cyan} size={30} />
      <Big x={245} y={1000} s="?" t={t} a={5.9} size={240} fill={C.orange} rot={-10} />
    </g>
  );
};

const S2: React.FC<SP> = ({t}) => {
  const s = 0.85;
  const o: P = [395, 743];
  const cab: React.ReactNode[] = [];
  for (let k = 0; k < 3; k++) {
    const x = k * 170;
    const c = pr(o, s, x, 130, 380);
    const tubes: React.ReactNode[] = [];
    for (let j = 0; j < 8; j++)
      for (let i = 0; i < 4; i++) {
        const idx = k * 32 + j * 4 + i;
        const lit = ramp(t, 8.2 + idx * 0.045, 8.4 + idx * 0.045);
        const broken = idx === 13 && t > 19.2;
        const u = 22 + i * 42;
        const v = 34 + j * 44;
        const fl = 0.75 + 0.25 * Math.sin(t * 9 + idx);
        tubes.push(
          <g key={idx}>
            <rect x={u - 8} y={v + 12} width={16} height={8} fill="#4a4f45" />
            <ellipse cx={u} cy={v} rx={10} ry={16} fill={broken ? '#3a3a3a' : lit > 0 ? C.amber : '#5a5f55'} opacity={broken ? 1 : lit > 0 ? 0.4 + 0.6 * lit * fl : 1} />
            {broken && <path d={`M ${u - 9} ${v - 9} L ${u + 9} ${v + 9} M ${u + 9} ${v - 9} L ${u - 9} ${v + 9}`} stroke={C.red} strokeWidth={4} />}
          </g>
        );
      }
    cab.push(
      <g key={k}>
        <IsoBox o={o} s={s} x={x} y={0} w={170} d={130} h={380} c="#8fa196" />
        <g transform={`matrix(${0.866 * s},${0.5 * s},0,${s},${c[0]},${c[1]})`}>{tubes}</g>
      </g>
    );
  }
  const heat = t > 18.3 ? ramp(t, 18.3, 18.8) : 0;
  return (
    <g>
      <Title t={t} a={7.8} lines={[[['ENIAC, KOMPUTER', 0]], [['RAKSASA', 1]]]} />
      <IsoBox o={o} s={s} x={-30} y={-30} z={-14} w={570} d={190} h={14} c="#d9d6cc" />
      {cab}
      {heat > 0 &&
        [0, 1, 2, 3].map((i) => {
          const x = 330 + i * 120;
          const y0 = 440 - ((t * 60 + i * 30) % 90);
          return <path key={i} d={`M ${x} ${y0} q 14 -22 0 -44 q -14 -22 0 -44`} stroke={C.red} strokeWidth={7} fill="none" strokeLinecap="round" opacity={heat * 0.8} />;
        })}
      <g transform={`translate(200,500) scale(${pop(t, 8.0)}) rotate(-8)`}>
        <circle r={78} fill={C.orange} />
        <text textAnchor="middle" y={22} fontFamily={cond} fontWeight={700} fontSize={70} fill="#ffffff">
          1946
        </text>
      </g>
      <Big x={290} y={1135} s="30 TON" t={t} a={13.0} size={110} fill={C.orange} />
      <Pill x={290} y={1195} s="BERAT" t={t} a={13.6} size={28} />
      <Big x={790} y={1135} s="18.000" t={t} a={15.0} size={110} fill={C.dark} />
      <Pill x={790} y={1195} s="TABUNG VAKUM" t={t} a={15.5} size={28} />
      <Pill x={205} y={1268} s="BESAR" t={t} a={18.3} bg={C.cyan} size={30} />
      <Pill x={385} y={1268} s="PANAS" t={t} a={18.8} bg={C.red} size={30} />
      <Pill x={665} y={1268} s="GAMPANG RUSAK" t={t} a={19.3} size={30} />
    </g>
  );
};

const S3: React.FC<SP> = ({t}) => {
  const on = t >= 25.6 && Math.floor((t - 25.6) / 0.55) % 2 === 0;
  const lamp = on || (t > 28.3 && Math.sin(t * 6) > 0);
  const A = win(t, 20.3, 30.1, 0.3);
  const Cc = win(t, 30.1, 33.4, 0.3);
  const bits = '10110010';
  return (
    <g>
      <Title t={t} a={20.4} lines={[[['TRANSISTOR,', 0]], [['SAKELAR ', 0], ['MUNGIL', 1]]]} />
      <g opacity={A}>
        <Transistor3D o={[300, 660]} s={1.55} />
        <path d="M 440 620 L 560 620 L 560 560 L 665 560" stroke={C.dark} strokeWidth={8} fill="none" strokeLinejoin="round" />
        <circle cx={760} cy={560} r={95} fill={lamp ? C.amber : '#d8d5cb'} stroke={C.dark} strokeWidth={8} filter={lamp ? 'url(#glow)' : undefined} />
        <rect x={715} y={650} width={90} height={40} rx={8} fill="#3b3f48" />
        <Pill x={760} y={420} s={lamp ? 'ON' : 'MATI'} t={t} a={25.0} bg={lamp ? C.green : C.red} size={34} />
      </g>
      <g opacity={Cc}>
        <Tube2D x={300} y={780} sc={1.1} lit={1} t={t} />
        <g transform="translate(690,780) scale(0.9)">
          <Transistor3D o={[0, 0]} s={0.7} />
        </g>
        <Pill x={540} y={900} s="JAUH LEBIH KECIL" t={t} a={30.3} bg={C.orange} size={32} />
        <Pill x={300} y={1040} s="HEMAT ENERGI" t={t} a={31.4} bg={C.green} size={30} />
        <Pill x={720} y={1040} s="AWET" t={t} a={32.3} bg={C.cyan} size={30} />
      </g>
      {bits.split('').map((b, i) => {
        const p = pop(t, 28.3 + i * 0.2);
        if (p <= 0) return null;
        return (
          <text key={i} transform={`translate(${540 - 367 + i * 105},${1010}) scale(${p})`} textAnchor="middle" fontFamily={mono} fontWeight={700} fontSize={110} fill={b === '1' ? C.green : C.red}>
            {b}
          </text>
        );
      })}
      <Pill x={540} y={1215} s="BELL LABS · 1947" t={t} a={20.8} bg={C.cyan} size={32} />
    </g>
  );
};

const S4: React.FC<SP> = ({t}) => {
  const parts = [
    {x: 220, y: 560, c: '#d9a066', w: 70, h: 30},
    {x: 450, y: 480, c: '#2a2f38', w: 60, h: 60},
    {x: 700, y: 560, c: '#4aa3df', w: 50, h: 80},
    {x: 300, y: 800, c: '#2a2f38', w: 60, h: 60},
    {x: 560, y: 840, c: '#d9a066', w: 70, h: 30},
    {x: 800, y: 820, c: '#7b6cf0', w: 60, h: 70},
  ];
  const fly = eo(ramp(t, 41.6, 44.0));
  const chipS = pop(t, 43.9);
  return (
    <g>
      <Title t={t} a={33.5} lines={[[['SATU KEPING,', 1]], [['BANYAK TRANSISTOR', 0]]]} />
      {fly < 1 && (
        <g opacity={1 - fly}>
          {parts.slice(0, -1).map((p, i) => {
            const q = parts[i + 1];
            return <line key={i} x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={C.dark} strokeWidth={4} strokeDasharray="10 8" opacity={0.6} />;
          })}
          {parts.map((p, i) => {
            const sc = pop(t, 34.2 + i * 0.25) * (1 - fly * 0.7);
            const x = p.x + (CX - p.x) * fly;
            const y = p.y + (700 - p.y) * fly;
            return (
              <g key={i} transform={`translate(${x},${y}) scale(${sc})`}>
                <rect x={-p.w / 2} y={-p.h / 2} width={p.w} height={p.h} rx={8} fill={p.c} stroke={C.dark} strokeWidth={5} />
                <line x1={-p.w / 2 - 22} y1={0} x2={-p.w / 2} y2={0} stroke={C.dark} strokeWidth={5} />
                <line x1={p.w / 2} y1={0} x2={p.w / 2 + 22} y2={0} stroke={C.dark} strokeWidth={5} />
              </g>
            );
          })}
        </g>
      )}
      {chipS > 0 && (
        <g transform={`translate(${CX},${700}) scale(${chipS}) translate(${-CX},${-700})`}>
          <Chip3D o={[540, 450]} s={1.2} t={t} reveal={ramp(t, 44.0, 45.0)} />
        </g>
      )}
      <Big x={790} y={560} s="CHIP!" t={t} a={45.05} size={150} fill={C.orange} rot={-8} />
      <Pill x={270} y={1130} s="KILBY · 1958" t={t} a={33.7} bg={C.cyan} size={32} />
      <Pill x={730} y={1130} s="NOYCE · SILIKON" t={t} a={38.6} bg={C.orange} size={32} />
      <Pill x={CX} y={1230} s="BANYAK TRANSISTOR = 1 KEPING" t={t} a={41.6} size={30} />
    </g>
  );
};

const S5: React.FC<SP> = ({t}) => {
  const beam = ramp(t, 50.4, 50.8) * (1 - ramp(t, 53.0, 53.4));
  const baseY = 905;
  const layerCols = ['#7ec8e3', '#ffb020', '#9b8cff', '#4ccf9b'];
  const nl = clamp(Math.floor((t - 58.0) / 0.5), 0, 4);
  const resist = ramp(t, 47.9, 48.5) * (1 - ramp(t, 55.6, 56.0));
  const steps: [number, string][] = [
    [47.77, '1 · LAPISI BAHAN PEKA CAHAYA'],
    [50.44, '2 · SINARI LEWAT CETAKAN'],
    [53.15, '3 · HILANGKAN BAGIAN TERKENA'],
    [55.9, '4 · ETSA POLA KE WAFER'],
    [57.95, '5 · ULANGI LAPIS DEMI LAPIS'],
  ];
  let cur = -1;
  steps.forEach((st, i) => {
    if (t >= st[0]) cur = i;
  });
  const topY = baseY - nl * 12;
  const sq: React.ReactNode[] = [];
  for (let i = 0; i < 5; i++)
    for (let j = 0; j < 3; j++) {
      const x = 540 + (i - 2) * 78;
      const y = topY - 4 + (j - 1) * 22;
      const exposed = ramp(t, 51.0 + i * 0.15, 51.4 + i * 0.15) * (1 - ramp(t, 53.2, 53.6));
      const etched = ramp(t, 55.6, 56.1);
      if (exposed > 0) sq.push(<ellipse key={'e' + i + j} cx={x} cy={y} rx={26} ry={8} fill="#8b5cf6" opacity={exposed} />);
      if (etched > 0 && nl === 0) sq.push(<ellipse key={'g' + i + j} cx={x} cy={y} rx={26} ry={8} fill="#2b3340" opacity={etched} />);
    }
  const holes = [420, 480, 540, 600, 660];
  return (
    <g>
      <Title t={t} a={45.7} lines={[[['FOTOLITOGRAFI', 1]], [['CETAK DENGAN CAHAYA', 0]]]} />
      <polygon points="520,470 560,470 680,560 400,560" fill="#8b5cf6" opacity={0.22 * beam} />
      <polygon points="410,595 670,595 570,860 510,860" fill="#8b5cf6" opacity={0.3 * beam} />
      <g filter="url(#glow)">
        <circle cx={540} cy={440} r={36} fill={beam > 0.1 ? '#c4b5fd' : '#fde68a'} />
      </g>
      {Array.from({length: 8}).map((_, i) => {
        const a = (i / 8) * Math.PI * 2 + t;
        return <line key={i} x1={540 + Math.cos(a) * 50} y1={440 + Math.sin(a) * 50} x2={540 + Math.cos(a) * 68} y2={440 + Math.sin(a) * 68} stroke={C.amber} strokeWidth={5} strokeLinecap="round" />;
      })}
      <Pill x={800} y={440} s="CAHAYA" t={t} a={46.3} size={28} />
      <rect x={400} y={568} width={280} height={34} fill="#14161c" />
      <rect x={400} y={560} width={280} height={30} fill="#3b3f48" />
      {holes.map((x) => (
        <rect key={x} x={x - 10} y={560} width={20} height={30} fill="#f6f5f0" />
      ))}
      <Pill x={850} y={575} s="CETAKAN POLA" t={t} a={46.9} size={28} />
      <ellipse cx={540} cy={705} rx={130} ry={34} fill="#5ad1ff" opacity={0.4} stroke={C.cyan} strokeWidth={6} />
      <Pill x={225} y={705} s="LENSA" t={t} a={47.2} size={28} />
      <Disc cx={540} cy={baseY} rx={230} ry={62} th={40} top="#c3c7cf" side="#8e939c" />
      {layerCols.slice(0, nl).map((c, i) => (
        <Disc key={i} cx={540} cy={baseY - (i + 1) * 12} rx={230} ry={62} th={12} top={c} side={sh(c, 0.7)} />
      ))}
      {resist > 0 && <ellipse cx={540} cy={baseY - 4} rx={226} ry={58} fill="#ff9ec4" opacity={0.85 * resist} />}
      {sq}
      <Pill x={800} y={1010} s="WAFER SILIKON" t={t} a={46.4} bg={C.cyan} size={28} />
      {cur >= 0 && <Pill key={cur} x={CX} y={1225} s={steps[cur][1]} t={t} a={steps[cur][0]} bg={C.orange} size={32} />}
    </g>
  );
};

const S6: React.FC<SP> = ({t}) => {
  const base = 1040;
  return (
    <g>
      <Title t={t} a={60.5} lines={[[['HUKUM MOORE:', 0]], [['BERLIPAT GANDA', 1]]]} />
      <rect x={70} y={base} width={940} height={14} rx={7} fill={C.dark} />
      {[1, 2, 4, 8, 16, 32, 64].map((v, i) => {
        const g = eo(ramp(t, 61.2 + i * 0.75, 61.8 + i * 0.75));
        const h = 8 * v * g;
        const x = 100 + i * 128;
        const w = 90;
        const c = ['#7ec8e3', '#5ad1ff', '#38bdf8', '#0ea5e9', '#0e9bb5', '#f59e0b', '#f26a0f'][i];
        return (
          <g key={i}>
            <rect x={x} y={base - h} width={w} height={h} fill={c} />
            <polygon points={`${x + w},${base - h} ${x + w + 26},${base - h - 20} ${x + w + 26},${base - 20} ${x + w},${base}`} fill={sh(c, 0.7)} />
            <polygon points={`${x},${base - h} ${x + 26},${base - h - 20} ${x + w + 26},${base - h - 20} ${x + w},${base - h}`} fill={sh(c, 1.15)} />
            {i > 0 && g > 0.5 && (
              <g transform={`translate(${x + w / 2 + 10},${base - h - 55}) scale(${pop(t, 61.4 + i * 0.75)})`}>
                <circle r={34} fill={C.dark} />
                <text textAnchor="middle" y={13} fontFamily={cond} fontWeight={700} fontSize={40} fill="#ffffff">
                  ×2
                </text>
              </g>
            )}
          </g>
        );
      })}
      <Pill x={CX} y={1150} s="GORDON MOORE · 1965" t={t} a={60.8} bg={C.cyan} size={32} />
      <Pill x={CX} y={1245} s="JUMLAH KOMPONEN TERUS BERLIPAT" t={t} a={65.0} size={28} />
    </g>
  );
};

const wave = (y: number, amp: number, wl: number, ph: number, prog: number) => {
  let d = '';
  const n = Math.floor(120 * prog);
  for (let i = 0; i <= n; i++) {
    const x = 70 + (940 * i) / 120;
    const yy = y + Math.sin(((x / wl) * Math.PI * 2) + ph) * amp;
    d += (i === 0 ? 'M ' : 'L ') + x.toFixed(1) + ' ' + yy.toFixed(1) + ' ';
  }
  return d;
};

const S7: React.FC<SP> = ({t}) => (
  <g>
    <Title t={t} a={68.6} lines={[[['CAHAYA ', 0], ['EUV', 1]], [['13,5 NANOMETER', 0]]]} />
    <defs>
      <linearGradient id="rb" x1="0" x2="1">
        <stop offset="0" stopColor="#ef4444" />
        <stop offset="0.5" stopColor="#22c55e" />
        <stop offset="1" stopColor="#3b82f6" />
      </linearGradient>
    </defs>
    <path d={wave(620, 80, 330, -t * 4, ramp(t, 69.0, 70.2))} stroke="url(#rb)" strokeWidth={14} fill="none" strokeLinecap="round" />
    <Pill x={CX} y={480} s="CAHAYA TAMPAK · 400–700 nm" t={t} a={69.4} size={28} />
    <path d={wave(900, 80, 26, -t * 14, ramp(t, 70.6, 71.8))} stroke="#7c3aed" strokeWidth={10} fill="none" strokeLinecap="round" />
    <Pill x={CX} y={760} s="EUV · 13,5 nm" t={t} a={71.0} bg="#7c3aed" size={32} />
    <Pill x={CX} y={1060} s="± 40× LEBIH PENDEK" t={t} a={72.2} bg={C.orange} size={32} />
    <Pill x={CX} y={1160} s="1 nm = SEPERMILIAR METER" t={t} a={73.0} size={28} />
  </g>
);

const S8: React.FC<SP> = ({t}) => {
  const strike = ramp(t, 77.0, 77.4);
  return (
    <g>
      <Title t={t} a={74.5} lines={[[['ANGKA 3 NM', 0]], [['BUKAN UKURAN', 1]]]} />
      <g transform={`translate(${CX},720) scale(${pop(t, 74.9)})`}>
        <rect x={-340} y={-190} width={680} height={380} rx={40} fill="#ffffff" stroke={C.dark} strokeWidth={8} />
        <text textAnchor="middle" y={55} fontFamily={cond} fontWeight={700} fontSize={250} fill={C.dark}>
          3 nm
        </text>
        <text textAnchor="middle" y={-120} fontFamily={mono} fontWeight={700} fontSize={30} fill={C.cyan}>
          NAMA PROSESOR
        </text>
      </g>
      <g opacity={ramp(t, 76.0, 76.4)}>
        <text x={CX} y={1010} textAnchor="middle" fontFamily={mono} fontWeight={700} fontSize={44} fill={C.dark}>
          = UKURAN TRANSISTOR?
        </text>
        <line x1={150} y1={1000} x2={150 + 780 * strike} y2={1000} stroke={C.red} strokeWidth={10} strokeLinecap="round" />
      </g>
      <Pill x={CX} y={1130} s="NAMA GENERASI TEKNOLOGI" t={t} a={78.0} bg={C.green} size={36} />
    </g>
  );
};

const S9: React.FC<SP> = ({t}) => {
  const nodes = [
    {x: 140, y: '1946', l: 'ENIAC'},
    {x: 340, y: '1947', l: 'TRANSISTOR'},
    {x: 540, y: '1958', l: 'IC'},
    {x: 740, y: '1965', l: 'MOORE'},
    {x: 940, y: 'KINI', l: 'EUV'},
  ];
  const prog = ramp(t, 81.6, 85.4);
  return (
    <g>
      <Title t={t} a={81.4} lines={[[['BUKAN SULAP,', 0]], [['TAPI ', 0], ['SAINS', 1]]]} />
      <line x1={140} y1={760} x2={940} y2={760} stroke="#cfcabb" strokeWidth={12} strokeLinecap="round" />
      <line x1={140} y1={760} x2={140 + 800 * prog} y2={760} stroke={C.orange} strokeWidth={12} strokeLinecap="round" />
      {nodes.map((n, i) => {
        const p = pop(t, 81.8 + i * 0.9);
        return (
          <g key={i} transform={`translate(${n.x},760) scale(${p})`}>
            <circle r={26} fill={C.orange} stroke="#ffffff" strokeWidth={8} />
            <text textAnchor="middle" y={-52} fontFamily={cond} fontWeight={700} fontSize={56} fill={C.dark}>
              {n.y}
            </text>
            <text textAnchor="middle" y={84} fontFamily={mono} fontWeight={700} fontSize={24} fill={C.cyan}>
              {n.l}
            </text>
          </g>
        );
      })}
      <Pill x={CX} y={980} s="FISIKA" t={t} a={85.7} bg={C.cyan} size={44} />
      <Pill x={CX} y={1090} s="KIMIA" t={t} a={86.1} bg={C.orange} size={44} />
      <Pill x={CX} y={1200} s="REKAYASA" t={t} a={86.5} size={44} />
    </g>
  );
};

const Logo: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="-50 -50 100 100">
    <ellipse rx={44} ry={16} fill="none" stroke={C.dark} strokeWidth={6} transform="rotate(-25)" />
    <circle r={24} fill={C.orange} />
    <circle cx={30} cy={-22} r={7} fill={C.cyan} />
  </svg>
);

const Subs: React.FC<{t: number}> = ({t}) => {
  if (t > 87.5) return null;
  let ci = -1;
  CHUNKS.forEach((c, i) => {
    if (c.a <= t + 0.02) ci = i;
  });
  if (ci < 0) return null;
  const c = CHUNKS[ci];
  if (t > c.b + 0.35) return null;
  return (
    <div style={{position: 'absolute', left: 56, width: 968, top: 1385, textAlign: 'center', fontFamily: sans, fontWeight: 800, fontSize: 62, lineHeight: 1.3, color: C.dark}}>
      {c.words.map((w, i) => {
        const cur = t >= w.a && t < w.b;
        return (
          <span key={i} style={{display: 'inline-block', margin: '0 7px', padding: '0 10px', borderRadius: 14, background: cur ? C.cyanL : 'transparent'}}>
            {w.w}
          </span>
        );
      })}
    </div>
  );
};

const SCENES = [S1, S2, S3, S4, S5, S6, S7, S8, S9];

export const Chip: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const endO = ramp(t, 87.5, 88.1);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Audio src={staticFile('audio.mp3')} />
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <pattern id="dots" width={44} height={44} patternUnits="userSpaceOnUse">
            <circle cx={22} cy={22} r={2.4} fill="#14161c" opacity={0.09} />
          </pattern>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation={9} result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <rect width={W} height={H} fill="url(#dots)" />
        <rect x={0} y={0} width={W * (t / DUR)} height={8} fill={C.cyan} />
        {SCENES.map((S, i) => {
          const a = SCT[i];
          const b = SCT[i + 1];
          if (t < a - 0.05 || t > b + 0.05) return null;
          const o = (i === 0 ? 1 : ramp(t, a, a + 0.3)) * (1 - ramp(t, b - 0.2, b));
          const ty = i === 0 ? 0 : 30 * (1 - eo(ramp(t, a, a + 0.4)));
          return (
            <g key={i} opacity={o} transform={`translate(0,${ty})`}>
              <S t={t} />
            </g>
          );
        })}
        <Meme t={t} a={13.0} b={14.9} text="30 TON?!" mood="shock" x={CX} y={900} rot={-4} />
        <Meme t={t} a={78.9} b={80.8} text="NAMANYA DOANG?!" mood="hmm" x={CX} y={900} rot={3} />
      </svg>
      <Subs t={t} />
      <div style={{position: 'absolute', left: 52, bottom: WM_BOTTOM, fontFamily: mono, fontWeight: 700, fontSize: 30, color: '#14161c99'}}>@semestakita</div>
      <div style={{position: 'absolute', right: 52, bottom: WM_BOTTOM - 14, display: 'flex', alignItems: 'center', gap: 10, opacity: 0.92}}>
        <Logo size={52} />
        <span style={{fontFamily: sans, fontWeight: 800, fontSize: 42, color: C.dark}}>SemestaKita</span>
      </div>
      {endO > 0 && (
        <AbsoluteFill style={{background: C.bg, opacity: endO, alignItems: 'center', justifyContent: 'center'}}>
          <div style={{transform: `scale(${0.9 + 0.1 * eo(endO)})`, textAlign: 'center'}}>
            <Logo size={260} />
            <div style={{fontFamily: cond, fontWeight: 700, fontSize: 150, color: C.dark, lineHeight: 1}}>
              SEMESTA<span style={{color: C.orange}}>KITA</span>
            </div>
            <div style={{fontFamily: sans, fontWeight: 800, fontSize: 44, color: C.dark, marginTop: 28}}>Follow untuk fakta semesta lainnya</div>
            <div style={{fontFamily: mono, fontWeight: 700, fontSize: 32, color: C.cyan, marginTop: 20}}>KOMEN TOPIK BERIKUTNYA</div>
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
