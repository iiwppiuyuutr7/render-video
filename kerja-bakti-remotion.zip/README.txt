Taruh Edit.tsx & Root.tsx di src/ (ganti Root.tsx lama), folder public/ digabung ke public/ proyekmu.
Butuh: remotion, @remotion/google-fonts.
Preview : npx remotion studio   (composition id: Edit)
Render  : npx remotion render Edit out/edit.mp4
1920x1080 · 30 fps · 8 detik (240 frame) - sesuai klip asli (suara klip dipertahankan).
Teks & waktu tampil ada di konstanta TEKS dan T (bagian atas Edit.tsx). SFX ada di array paling bawah.
