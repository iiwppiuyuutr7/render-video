import React from 'react';
import {Composition} from 'remotion';
import {Edit, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Edit';
export const RemotionRoot: React.FC = () => (
  <Composition id="Edit" component={Edit} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
