/**
 * Edit "Kerja Bakti" - 1920x1080 · 30 fps · 8 detik (240 frame)
 * Klip: public/clip.mp4 (suara asli klip dipertahankan) + public/sfx/*.wav
 * Semua waktu dalam DETIK. Teks & waktu tampil bisa diubah di konstanta TEKS / T di bawah.
 */
import React from 'react';
import {AbsoluteFill, Audio, Easing, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;
const OUT = '#2a1a2c';

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_SECONDS = 8;
export const TOTAL_FRAMES = TOTAL_SECONDS * FPS;

/* ── teks & waktu (detik) ── */
const TEKS = {
  judul: ['KERJA', 'BAKTI'],
  sub: 'bareng-bareng, jadi ringan',
  lower: 'GOTONG ROYONG',
  lowerSub: 'bersih-bersih bersama di sekolah',
  penutup: 'lingkungan bersih, hati senang',
};
const T = {judulIn: 0.45, judulOut: 3.0, subIn: 1.2, lowerIn: 3.4, lowerOut: 6.3, penutupIn: 6.0, punch: 3.0};

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));

const strokeText: React.CSSProperties = {
  fontFamily: FONT,
  fontWeight: 800,
  color: '#fff',
  WebkitTextStroke: '14px rgba(42,26,44,0.92)',
  paintOrder: 'stroke fill',
  textShadow: '0 8px 20px rgba(0,0,0,0.5)',
};

export const Edit: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  // gerak kamera: dorong pelan + "punch" zoom
  const punch = Math.sin(Math.PI * prog(t, T.punch, 0.7)) * 0.07;
  const zoom = 1.04 + 0.07 * (t / TOTAL_SECONDS) + punch;
  // buka dari blur, tutup ke blur
  const blur = 26 * (1 - eo(t, 0, 0.9)) + 22 * prog(t, TOTAL_SECONDS - 1.0, 1.0);
  const fadeOut = prog(t, TOTAL_SECONDS - 0.5, 0.5);
  const dim = 0.42 * (1 - prog(t, 0, 0.9)) + 0.25 * (t > T.judulIn && t < T.judulOut + 0.3 ? 1 : 0);

  const judulO = 1 - prog(t, T.judulOut, 0.4);
  const lowerP = eo(t, T.lowerIn, 0.5) * (1 - prog(t, T.lowerOut, 0.4));
  const penutupO = eo(t, T.penutupIn, 0.6) * (1 - prog(t, TOTAL_SECONDS - 0.9, 0.4));

  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <AbsoluteFill style={{transform: `scale(${zoom})`, filter: `blur(${blur}px) saturate(1.18) contrast(1.06) brightness(1.03)`}}>
        <OffthreadVideo src={staticFile('clip.mp4')} style={{width: WIDTH, height: HEIGHT, objectFit: 'cover'}} />
      </AbsoluteFill>
      <AbsoluteFill style={{background: `rgba(10,6,20,${dim})`}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)'}} />

      {/* judul */}
      {t >= T.judulIn && t < T.judulOut + 0.5 && (
        <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', opacity: judulO}}>
          <div style={{display: 'flex', gap: 40, transform: `translateY(${-prog(t, T.judulOut, 0.4) * 40}px)`}}>
            {TEKS.judul.map((w, i) => {
              const p = pop(t, T.judulIn + i * 0.18, 0.45);
              return (
                <div key={i} style={{...strokeText, fontSize: 210, lineHeight: 1, letterSpacing: -2, transform: `scale(${p}) rotate(${(1 - p) * (i ? 8 : -8)}deg)`, opacity: p > 0 ? 1 : 0, color: i ? '#ffe27a' : '#fff'}}>
                  {w}
                </div>
              );
            })}
          </div>
          <svg width={900} height={60} viewBox="0 0 900 60" style={{marginTop: 4}}>
            <path d="M20,36 C200,6 420,52 640,20 S820,30 880,16" fill="none" stroke={OUT} strokeWidth={26} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - eo(t, T.judulIn + 0.5, 0.6)} />
            <path d="M20,36 C200,6 420,52 640,20 S820,30 880,16" fill="none" stroke="#ffd45a" strokeWidth={14} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - eo(t, T.judulIn + 0.5, 0.6)} />
          </svg>
          <div style={{fontFamily: HAND, fontWeight: 700, fontSize: 92, color: '#fff', marginTop: 6, opacity: eo(t, T.subIn, 0.5), transform: `rotate(-2deg) translateY(${(1 - eo(t, T.subIn, 0.5)) * 20}px)`, textShadow: '0 6px 16px rgba(0,0,0,0.7)'}}>
            {TEKS.sub}
          </div>
        </AbsoluteFill>
      )}

      {/* lower third */}
      {lowerP > 0.001 && (
        <div style={{position: 'absolute', left: 90, bottom: 210, transform: `translateX(${(1 - lowerP) * -700}px)`, opacity: lowerP}}>
          <div style={{display: 'flex', alignItems: 'stretch', boxShadow: '0 10px 0 rgba(0,0,0,0.35)', borderRadius: 18, overflow: 'hidden', border: `6px solid ${OUT}`}}>
            <div style={{width: 26, background: '#ffd45a'}} />
            <div style={{background: 'rgba(18,12,30,0.92)', padding: '18px 44px 20px 34px'}}>
              <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 74, color: '#fff', letterSpacing: 3, lineHeight: 1.05}}>{TEKS.lower}</div>
              <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 34, color: '#ffd45a', marginTop: 4}}>{TEKS.lowerSub}</div>
            </div>
          </div>
        </div>
      )}

      {/* penutup */}
      {penutupO > 0.001 && (
        <div style={{position: 'absolute', left: 0, right: 0, bottom: 120, textAlign: 'center', fontFamily: HAND, fontWeight: 700, fontSize: 104, color: '#ffe27a', opacity: penutupO, transform: `translateY(${(1 - penutupO) * 24}px) rotate(-1.5deg)`, textShadow: '0 6px 18px rgba(0,0,0,0.75)'}}>
          {TEKS.penutup}
        </div>
      )}

      {/* watermark */}
      <div style={{position: 'absolute', left: 40, bottom: 36, fontFamily: FONT, fontWeight: 800, fontSize: 38, color: '#fff', opacity: 0.9, WebkitTextStroke: '8px rgba(22,12,34,0.75)', paintOrder: 'stroke fill', textShadow: '0 3px 8px rgba(0,0,0,0.45)'}}>
        @semestakita
      </div>
      <AbsoluteFill style={{background: '#000', opacity: fadeOut, pointerEvents: 'none'}} />

      {/* efek suara */}
      {([[0.4, 'whoosh', 0.35], [T.judulIn + 0.1, 'pop', 0.4], [T.judulIn + 0.3, 'pop', 0.4], [T.lowerIn, 'whoosh', 0.35], [T.penutupIn, 'chime', 0.3], [TOTAL_SECONDS - 1.1, 'whoosh', 0.3]] as Array<[number, string, number]>).map(([at, n, v], i) => (
        <Sequence key={i} from={Math.round(at * FPS)} durationInFrames={Math.round(2 * FPS)}>
          <Audio src={staticFile(`sfx/${n}.wav`)} volume={v} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
export default Edit;
