Bola - animasi gol kartun (16:9, 1920x1080, 60fps, 35.57 detik)
File: Bola.tsx, Root.tsx, trackdata.ts (data posisi pemain/bola/kamera hasil lacak dari videomu), public/audio.mp3
Taruh semuanya di src/ proyek Remotion (audio di public/).
Render: npx remotion render Bola out/bola.mp4
