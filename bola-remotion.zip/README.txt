Bola - animasi gol kartun (16:9, 1920x1080, 60fps, 35.57 detik)
Taruh Bola.tsx + Root.tsx di src/ proyek Remotion, public/audio.mp3 di folder public/.
Render: npx remotion render Bola out/bola.mp4
