import React from 'react';
import {Composition} from 'remotion';
import {Bola, FPS, WIDTH, HEIGHT, TOTAL_SECONDS} from './Bola';

export const RemotionRoot: React.FC = () => (
  <Composition id="Bola" component={Bola} durationInFrames={Math.round(TOTAL_SECONDS * FPS)} fps={FPS} width={WIDTH} height={HEIGHT} />
);
