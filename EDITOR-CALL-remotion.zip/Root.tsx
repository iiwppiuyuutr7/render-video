import React from 'react';
import {Composition} from 'remotion';
import {EditorCall, EDITOR_TOTAL_SECONDS} from './EditorCall';

const FPS = 30;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EditorCall"
    component={EditorCall}
    durationInFrames={Math.round(EDITOR_TOTAL_SECONDS * FPS)}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
