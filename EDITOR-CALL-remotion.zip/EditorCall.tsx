/**
 * Edit video "cari editor" – vertikal 1080x1920 (9:16), 30 fps, ±74 detik.
 * Gaya: clean, aesthetic, modern. Subtitle animasi per frasa (kata kunci disorot),
 * zoom halus, callout motion graphics, color grading hangat natural, SFX tipis, closing singkat.
 * Audio memakai suara asli video (sesuai ajakan "pakai sound ini"); tidak ada musik tambahan.
 *
 * Isi data (teks subtitle + waktu callout) ada di data.ts. Waktu kata diperkirakan dari audio.
 * Ganti YOUR_NAME di bawah dengan namamu / akun editormu (kosong = tidak ditampilkan).
 * Aset: public/editorcall/video.mp4, public/editorcall/sfx/*.mp3
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  OffthreadVideo,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {CAPTIONS, CALLOUTS, Cap, Callout} from './data';

const YOUR_NAME = ''; // contoh: '@namakamu'
const HASHTAG = '#AlishaYesCariEditor';

const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const CREAM = '#f7ede3';
const PEACH = '#ffcf9e';
const ROSE = '#e9a98a';
const BROWN = '#3a2a24';

const VIDEO_SEC = 70.77;
const OUTRO_SEC = 3.6;
export const EDITOR_TOTAL_SECONDS = VIDEO_SEC + OUTRO_SEC;

const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const useFr = () => {
  const {fps} = useVideoConfig();
  return (s: number) => Math.round(s * fps);
};

/* ── zoom halus: tiap beberapa detik mendekat / menjauh, tanpa lompatan ── */
const ZOOM: [number, number][] = [
  [0, 1.0],
  [7, 1.07],
  [14, 1.02],
  [22, 1.08],
  [29, 1.03],
  [37, 1.09],
  [44, 1.04],
  [50, 1.08],
  [57, 1.03],
  [63, 1.09],
  [70.77, 1.04],
];
const zoomAt = (t: number) =>
  interpolate(t, ZOOM.map((z) => z[0]), ZOOM.map((z) => z[1]), {...clampOpts, easing: Easing.inOut(Easing.sin)});

const GRADE = 'saturate(1.06) contrast(1.05) brightness(1.02) sepia(0.06)';

const Shadow = '0 4px 22px rgba(0,0,0,0.55)';

/* ── subtitle ── */
const CaptionView: React.FC<{cap: Cap; dur: number}> = ({cap, dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t0 = cap.s;
  const pop = spring({frame: f, fps, config: {damping: 16, stiffness: 190}, durationInFrames: 12});
  const out = interpolate(f, [dur - 4, dur], [1, 0], clampOpts);
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center'}}>
      <div
        style={{
          position: 'absolute',
          bottom: 1920 - 1470,
          width: 900,
          textAlign: 'center',
          opacity: Math.min(1, pop * 1.4) * out,
          transform: `translateY(${(1 - pop) * 26}px) scale(${0.94 + 0.06 * pop})`,
        }}
      >
        <div
          style={{
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 74,
            lineHeight: 1.18,
            color: '#fff',
            textShadow: Shadow,
            letterSpacing: -0.5,
          }}
        >
          {cap.w.map((w, i) => {
            const on = f / fps + t0 >= w.s - 0.02;
            return (
              <span
                key={i}
                style={{
                  color: w.k ? PEACH : '#fff',
                  opacity: on ? 1 : 0.55,
                  transition: 'none',
                }}
              >
                {w.t}{' '}
              </span>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ── ikon sederhana ── */
const Icon: React.FC<{name: string}> = ({name}) => {
  const p = {fill: 'none', stroke: BROWN, strokeWidth: 2.4, strokeLinecap: 'round', strokeLinejoin: 'round'} as const;
  const paths: Record<string, React.ReactNode> = {
    bulb: (
      <>
        <path {...p} d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z" />
      </>
    ),
    spark: <path {...p} d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z" />,
    home: <path {...p} d="M4 11l8-7 8 7M6 10v10h12V10M10 20v-5h4v5" />,
    coin: (
      <>
        <circle {...p} cx="12" cy="12" r="8.5" />
        <path {...p} d="M12 7v10M9.5 9.5c0-1 1-1.6 2.5-1.6s2.5.6 2.5 1.6-1 1.4-2.5 1.7-2.5.7-2.5 1.7 1 1.6 2.5 1.6 2.5-.6 2.5-1.6" />
      </>
    ),
    play: (
      <>
        <rect {...p} x="3.5" y="5" width="17" height="14" rx="3" />
        <path {...p} d="M10.5 9.5v5l4-2.5z" />
      </>
    ),
    pin: (
      <>
        <path {...p} d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z" />
        <circle {...p} cx="12" cy="10" r="2.4" />
      </>
    ),
  };
  return (
    <svg width="46" height="46" viewBox="0 0 24 24">
      {paths[name]}
    </svg>
  );
};

const Badge: React.FC<{ic: string}> = ({ic}) => (
  <div
    style={{
      width: 74,
      height: 74,
      borderRadius: 37,
      background: PEACH,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flex: 'none',
    }}
  >
    <Icon name={ic} />
  </div>
);

/* ── callout (kartu kecil bergaya glass terang) ── */
const Card: React.FC<{children: React.ReactNode; dur: number; top?: number}> = ({children, dur, top = 1085}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const inn = spring({frame: f, fps, config: {damping: 15, stiffness: 140}, durationInFrames: 16});
  const out = interpolate(f, [dur - 8, dur], [1, 0], clampOpts);
  return (
    <AbsoluteFill style={{alignItems: 'center'}}>
      <div
        style={{
          position: 'absolute',
          top,
          opacity: Math.min(1, inn * 1.5) * out,
          transform: `translateY(${(1 - inn) * -34}px) scale(${0.92 + 0.08 * inn})`,
          display: 'flex',
          alignItems: 'center',
          gap: 22,
          padding: '14px 40px 14px 14px',
          borderRadius: 999,
          background: 'rgba(255,248,240,0.93)',
          boxShadow: '0 10px 40px rgba(0,0,0,0.28)',
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};
const CardText: React.FC<{t: string; sub?: string}> = ({t, sub}) => (
  <div style={{fontFamily: FONT, color: BROWN, lineHeight: 1.15}}>
    <div style={{fontWeight: 800, fontSize: 44}}>{t}</div>
    {sub ? <div style={{fontWeight: 600, fontSize: 28, color: '#8a6a5c', marginTop: 4}}>{sub}</div> : null}
  </div>
);

const CalloutView: React.FC<{c: Callout; dur: number}> = ({c, dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (c.k === 'tag') {
    const pulse = 0.6 + 0.4 * Math.sin(f / 6);
    return (
      <Card dur={dur} top={190}>
        <div style={{width: 22, height: 22, borderRadius: 11, background: '#e5533d', opacity: pulse, marginLeft: 22}} />
        <CardText t={c.t || ''} sub={c.sub} />
      </Card>
    );
  }
  if (c.k === 'chip') {
    return (
      <Card dur={dur}>
        <Badge ic={c.ic || 'spark'} />
        <CardText t={c.t || ''} />
      </Card>
    );
  }
  if (c.k === 'pin') {
    const showB = f / fps >= (c.s2 || 0) - c.s;
    return (
      <Card dur={dur}>
        <Badge ic="pin" />
        <CardText t={c.t || ''} sub={showB ? c.sub : undefined} />
      </Card>
    );
  }
  if (c.k === 'hash') {
    return (
      <Card dur={dur}>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 50, color: BROWN, padding: '8px 14px 8px 26px'}}>{c.t}</div>
      </Card>
    );
  }
  // pills: muncul bergantian sesuai kata
  const out = interpolate(f, [dur - 8, dur], [1, 0], clampOpts);
  return (
    <AbsoluteFill style={{alignItems: 'center'}}>
      <div style={{position: 'absolute', top: 1085, display: 'flex', gap: 16, opacity: out}}>
        {(c.items || []).map((it, i) => {
          const st = Math.round((it.s - c.s) * fps);
          const sp = spring({frame: f - st, fps, config: {damping: 14, stiffness: 170}, durationInFrames: 14});
          return (
            <div
              key={i}
              style={{
                fontFamily: FONT,
                fontWeight: 800,
                fontSize: 42,
                color: BROWN,
                padding: '18px 34px',
                borderRadius: 999,
                background: 'rgba(255,248,240,0.93)',
                boxShadow: '0 10px 40px rgba(0,0,0,0.28)',
                opacity: Math.min(1, sp * 1.6),
                transform: `translateY(${(1 - sp) * 30}px) scale(${0.9 + 0.1 * sp})`,
              }}
            >
              {it.t}
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

/* ── SFX tipis ── */
const Sfx: React.FC<{file: string; at: number; vol: number}> = ({file, at, vol}) => {
  const fr = useFr();
  return (
    <Sequence from={Math.max(0, fr(at))}>
      <Audio src={staticFile(`editorcall/sfx/${file}.mp3`)} volume={vol} />
    </Sequence>
  );
};

/* ── closing ── */
const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  const bg = interpolate(f, [0, fr(0.7)], [0, 1], clampOpts);
  const rise = (d: number) => interpolate(f, [fr(d), fr(d + 0.6)], [30, 0], {...clampOpts, easing: Easing.out(Easing.cubic)});
  const op = (d: number) => interpolate(f, [fr(d), fr(d + 0.6)], [0, 1], clampOpts);
  return (
    <AbsoluteFill
      style={{
        opacity: bg,
        background: `radial-gradient(ellipse at 50% 35%, ${CREAM} 0%, #f0d9c6 60%, #e6c3aa 100%)`,
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
      }}
    >
      <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 40, letterSpacing: 8, color: '#8a6a5c', opacity: op(0.5), transform: `translateY(${rise(0.5)}px)`}}>
        TERIMA KASIH
      </div>
      <div style={{width: 120, height: 5, borderRadius: 3, background: ROSE, margin: '34px 0'}} />
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 64, color: BROWN, opacity: op(0.9), transform: `translateY(${rise(0.9)}px)`}}>
        {HASHTAG}
      </div>
      {YOUR_NAME ? (
        <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 40, color: '#8a6a5c', marginTop: 28, opacity: op(1.3)}}>{YOUR_NAME}</div>
      ) : null}
    </AbsoluteFill>
  );
};

/* ── komposisi ── */
export const EditorCall: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const fr = useFr();
  const t = f / fps;
  const open = interpolate(f, [0, fr(0.5)], [1, 0], clampOpts);

  return (
    <AbsoluteFill style={{background: CREAM}}>
      {/* video + zoom halus + grading */}
      <Sequence from={0} durationInFrames={fr(VIDEO_SEC)}>
        <AbsoluteFill style={{overflow: 'hidden'}}>
          <OffthreadVideo
            src={staticFile('editorcall/video.mp4')}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: `scale(${zoomAt(t)})`,
              transformOrigin: '50% 32%',
              filter: GRADE,
            }}
          />
          {/* vignette tipis + gradasi bawah agar subtitle terbaca */}
          <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 40%, rgba(0,0,0,0) 55%, rgba(40,20,10,0.28) 100%)'}} />
          <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(30,15,8,0.55) 0%, rgba(30,15,8,0) 38%)'}} />
        </AbsoluteFill>

        {/* subtitle */}
        {CAPTIONS.map((cap, i) => {
          const from = Math.max(0, fr(cap.s));
          const dur = Math.max(6, fr(cap.e) - from);
          return (
            <Sequence key={i} from={from} durationInFrames={dur}>
              <CaptionView cap={cap} dur={dur} />
            </Sequence>
          );
        })}

        {/* callout */}
        {CALLOUTS.map((c, i) => {
          const from = Math.max(0, fr(c.s));
          const dur = fr(c.d);
          return (
            <Sequence key={i} from={from} durationInFrames={dur}>
              <CalloutView c={c} dur={dur} />
            </Sequence>
          );
        })}
      </Sequence>

      {/* fade-in halus dari krem */}
      <AbsoluteFill style={{background: CREAM, opacity: open, pointerEvents: 'none'}} />

      {/* closing */}
      <Sequence from={fr(VIDEO_SEC - 0.1)} durationInFrames={fr(OUTRO_SEC + 0.1)}>
        <Outro />
      </Sequence>

      {/* SFX tipis saat grafis muncul */}
      {CALLOUTS.map((c, i) => (
        <Sfx key={i} file="pop" at={c.s + 0.05} vol={0.16} />
      ))}
      <Sfx file="transition" at={VIDEO_SEC - 0.1} vol={0.25} />
    </AbsoluteFill>
  );
};
