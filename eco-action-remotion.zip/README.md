# ECO-ACTION 4 DAYS (Remotion)

Taruh `Root.tsx` dan `EcoAction.tsx` di folder `src/`, dan isi folder `public/` ke `public/` project Remotion kamu.

    npm i @remotion/google-fonts
    npx remotion studio
    npx remotion render EcoAction out/eco-action.mp4

- 1920x1080, 30 fps, 139,8 detik (4194 frame)
- Audio klip asli dimatikan (tanpa suara orang bicara). Musik & SFX ada di public/.
- Ganti urutan/durasi klip lewat array `SHOTS` di EcoAction.tsx. Durasi scene di `SCENE_DUR`.
