/**
 * ECO-ACTION 4 DAYS — Video dokumentasi kokurikuler
 * SMA Negeri 1 Doro · Kelas X E7 · Kelompok 5 — Video kampanye
 * 1920x1080 (16:9) · 30 fps · 139,8 detik (4194 frame)
 *
 * Footage asli di public/clip1..clip6.mp4 (audio klip dimatikan, tanpa suara orang bicara).
 * Musik + sound effect: public/music.mp3, whoosh.mp3, impact.mp3
 * Semua waktu di file ini dalam DETIK.
 *
 * Mau ganti klip / urutan? Edit array SHOTS di bawah.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';

const {fontFamily} = loadFont('normal', {weights: ['400', '500', '600', '700', '800'], subsets: ['latin']});
const FONT = `${fontFamily}, 'Segoe UI', Arial, sans-serif`;

/* ───────────────────────── konfigurasi ───────────────────────── */
export const FPS = 30;
export const SCENE_DUR = [13.8, 20, 25, 30, 25, 26]; // detik tiap scene
export const TOTAL_SECONDS = SCENE_DUR.reduce((a, b) => a + b, 0); // 139.8
export const TOTAL_FRAMES = Math.round(TOTAL_SECONDS * FPS);

const ST: number[] = [];
SCENE_DUR.reduce((acc, d, i) => {
  ST[i] = acc;
  return acc + d;
}, 0);

const C = {
  forest: '#1f5130',
  deep: '#0d2817',
  sage: '#9fcf9f',
  beige: '#efe6d2',
  white: '#ffffff',
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.bezier(0.22, 1, 0.36, 1);
const sec = (s: number) => Math.round(s * FPS);
const OV = 0.6; // lama dissolve antar klip

/* ───────────────────────── daftar footage ─────────────────────────
 * src      : file di /public
 * start    : detik mulai di klip asli
 * dur      : lama tampil (kecepatan tetap 1x, tidak dipercepat)
 * z0 → z1  : zoom perlahan (1 = tanpa zoom)
 * ox, oy   : titik fokus zoom (%)
 * Kamera & kecepatan asli dipertahankan; zoom dibuat sangat halus.
 */
type Shot = {src: string; start: number; dur: number; z0?: number; z1?: number; ox?: number; oy?: number};

const SHOTS: Shot[][] = [
  // Scene 1 — opening: klip kamera dari atas bergerak turun (tanpa zoom tambahan)
  [{src: 'clip1.mp4', start: 0, dur: 13.8, z0: 1, z1: 1}],
  // Scene 2 — pengenalan kegiatan
  [
    {src: 'clip6.mp4', start: 0, dur: 8, z0: 1, z1: 1.06},
    {src: 'clip5.mp4', start: 0, dur: 6, z0: 1.04, z1: 1},
    {src: 'clip2.mp4', start: 0, dur: 6, z0: 1, z1: 1.06},
  ],
  // Scene 3 — agenda hari pertama
  [
    {src: 'clip3.mp4', start: 0, dur: 8.6, z0: 1, z1: 1.05},
    {src: 'clip5.mp4', start: 5.8, dur: 7.4, z0: 1.05, z1: 1},
    {src: 'clip1.mp4', start: 4, dur: 9, z0: 1.55, z1: 1.45, ox: 68, oy: 72},
  ],
  // Scene 4 — diskusi dan perencanaan
  [
    {src: 'clip2.mp4', start: 4.5, dur: 7, z0: 1.02, z1: 1.08},
    {src: 'clip4.mp4', start: 0, dur: 1.1, z0: 1, z1: 1},
    {src: 'clip3.mp4', start: 1, dur: 7.4, z0: 1.08, z1: 1.02},
    {src: 'clip5.mp4', start: 0, dur: 7, z0: 1, z1: 1.05},
    {src: 'clip6.mp4', start: 0, dur: 7.5, z0: 1.4, z1: 1.3, ox: 70, oy: 65},
  ],
  // Scene 5 — Kelompok 5
  [
    {src: 'clip2.mp4', start: 0, dur: 8.2, z0: 1.12, z1: 1.04, ox: 40, oy: 50},
    {src: 'clip3.mp4', start: 0.5, dur: 8, z0: 1, z1: 1.06},
    {src: 'clip1.mp4', start: 5, dur: 8.8, z0: 1.2, z1: 1.1, ox: 50, oy: 70},
  ],
  // Scene 6 — closing
  [
    {src: 'clip6.mp4', start: 0, dur: 7.5, z0: 1.12, z1: 1, ox: 50, oy: 60},
    {src: 'clip5.mp4', start: 4, dur: 9, z0: 1, z1: 1.06},
    {src: 'clip1.mp4', start: 4.3, dur: 9.5, z0: 1, z1: 1.05},
  ],
];

/* ───────────────────────── komponen dasar ───────────────────────── */
const ShotView: React.FC<{s: Shot; first: boolean}> = ({s, first}) => {
  const f = useCurrentFrame();
  const d = sec(s.dur);
  const op = first ? interpolate(f, [0, sec(1.2)], [0, 1], clamp) : interpolate(f, [0, sec(OV)], [0, 1], clamp);
  const sc = interpolate(f, [0, d], [s.z0 ?? 1, s.z1 ?? 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const from = sec(s.start);
  return (
    <AbsoluteFill style={{opacity: op, backgroundColor: '#000'}}>
      <OffthreadVideo
        src={staticFile(s.src)}
        startFrom={from}
        endAt={from + d + sec(OV) + 2}
        muted
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${sc})`,
          transformOrigin: `${s.ox ?? 50}% ${s.oy ?? 50}%`,
        }}
      />
    </AbsoluteFill>
  );
};

const Footage: React.FC = () => {
  let idx = 0;
  return (
    <AbsoluteFill style={{filter: 'saturate(1.06) contrast(1.05) sepia(0.09) brightness(0.98)'}}>
      {SHOTS.map((scene, si) => {
        let at = ST[si];
        return scene.map((s, j) => {
          const from = at;
          at += s.dur;
          const key = idx++;
          return (
            <Sequence key={key} from={sec(from)} durationInFrames={sec(s.dur + OV)} layout="none">
              <ShotView s={s} first={si === 0 && j === 0} />
            </Sequence>
          );
        });
      })}
    </AbsoluteFill>
  );
};

/** Vignette + gradasi halus agar teks terbaca tanpa menutup footage */
const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background:
        'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(5,20,10,0.45) 100%), linear-gradient(to top, rgba(5,20,10,0.35) 0%, rgba(0,0,0,0) 35%)',
    }}
  />
);

/** Lapisan teks: fade + naik halus, muncul `at` detik selama `dur` detik */
const Layer: React.FC<{at: number; dur: number; children: React.ReactNode; rise?: number}> = ({at, dur, children, rise = 24}) => (
  <Sequence from={sec(at)} durationInFrames={sec(dur)} layout="none">
    <LayerInner dur={dur} rise={rise}>{children}</LayerInner>
  </Sequence>
);
const LayerInner: React.FC<{dur: number; rise: number; children: React.ReactNode}> = ({dur, rise, children}) => {
  const f = useCurrentFrame();
  const d = sec(dur);
  const i = interpolate(f, [0, sec(0.8)], [0, 1], {...clamp, easing: ease});
  const o = interpolate(f, [d - sec(0.7), d], [1, 0], clamp);
  return (
    <AbsoluteFill style={{opacity: Math.min(i, o), transform: `translateY(${(1 - i) * rise}px)`}}>{children}</AbsoluteFill>
  );
};

/** Muncul bertahap di dalam Layer (frame lokal) */
const Rise: React.FC<{delay: number; children: React.ReactNode; style?: React.CSSProperties; x?: number}> = ({delay, children, style, x = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.8)], [0, 1], {...clamp, easing: ease});
  return <div style={{opacity: p, transform: `translate(${(1 - p) * x}px, ${(1 - p) * 26}px)`, ...style}}>{children}</div>;
};

const Glass: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      background: 'rgba(13,40,23,0.66)',
      backdropFilter: 'blur(16px)',
      border: '1px solid rgba(239,230,210,0.26)',
      borderRadius: 24,
      boxShadow: '0 18px 60px rgba(0,0,0,0.35)',
      ...style,
    }}
  >
    {children}
  </div>
);

/* ───────────────────────── ikon sederhana ───────────────────────── */
const Leaf: React.FC<{size?: number; color?: string}> = ({size = 40, color = C.sage}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <path d="M20 3C10 3 4 8 4 15c0 2 .6 3.6 1.6 5C7 14 11 10 16 8c-4 3-7 7-8.4 12.2C9 21 10.4 21 12 21c6 0 8-6 8-18z" fill={color} />
  </svg>
);

const Check: React.FC<{size?: number; delay?: number}> = ({size = 44, delay = 0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f, [sec(delay), sec(delay + 0.6)], [0, 1], {...clamp, easing: ease});
  return (
    <svg width={size} height={size} viewBox="0 0 44 44">
      <circle cx="22" cy="22" r="20" fill={C.forest} stroke={C.sage} strokeWidth="2" />
      <path d="M12 23l7 7 13-15" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="40" strokeDashoffset={40 * (1 - p)} />
    </svg>
  );
};

const Chip: React.FC<{children: React.ReactNode; light?: boolean; style?: React.CSSProperties}> = ({children, light, style}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 14,
      padding: '12px 28px',
      borderRadius: 999,
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 30,
      letterSpacing: 0.3,
      background: light ? C.beige : C.forest,
      color: light ? C.deep : C.beige,
      border: light ? 'none' : `1.5px solid ${C.sage}`,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Logo kecil di pojok setelah opening */
const Bug: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(ST[1]), sec(ST[1] + 1), sec(TOTAL_SECONDS - 14), sec(TOTAL_SECONDS - 12)], [0, 0.95, 0.95, 0], clamp);
  return (
    <div style={{position: 'absolute', top: 44, left: 56, opacity: o, display: 'flex', alignItems: 'center', gap: 12, fontFamily: FONT, color: C.white, fontWeight: 700, fontSize: 24, letterSpacing: 2, textShadow: '0 2px 10px rgba(0,0,0,0.6)'}}>
      <Leaf size={30} color={C.sage} />
      ECO-ACTION 4 DAYS
    </div>
  );
};

const ProgressBar: React.FC = () => {
  const f = useCurrentFrame();
  const w = interpolate(f, [0, TOTAL_FRAMES], [0, 100], clamp);
  return (
    <div style={{position: 'absolute', left: 0, bottom: 0, height: 5, width: `${w}%`, background: `linear-gradient(90deg, ${C.forest}, ${C.sage})`, opacity: 0.9}} />
  );
};

/* ───────────────────────── SCENE 1 — opening ───────────────────────── */
const Opening: React.FC = () => {
  const f = useCurrentFrame();
  const line = interpolate(f, [sec(0.3), sec(1.6)], [0, 1], {...clamp, easing: ease});
  const letter = interpolate(f, [0, sec(2.4)], [26, 8], {...clamp, easing: ease});
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', fontFamily: FONT, color: C.white, textAlign: 'center'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(5,25,12,0.62) 0%, rgba(5,25,12,0.15) 62%, rgba(0,0,0,0) 100%)'}} />
      <div style={{position: 'relative'}}>
        <Rise delay={0}>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 20}}>
            <Leaf size={74} color={C.sage} />
          </div>
        </Rise>
        <Rise delay={0.2}>
          <div style={{fontWeight: 800, fontSize: 118, letterSpacing: letter, textShadow: '0 6px 30px rgba(0,0,0,0.55)', paddingLeft: letter}}>ECO-ACTION 4 DAYS</div>
        </Rise>
        <div style={{height: 3, width: `${line * 760}px`, background: C.beige, margin: '26px auto 26px', borderRadius: 2}} />
        <Rise delay={1.2}>
          <div style={{fontWeight: 500, fontSize: 40, color: C.beige, textShadow: '0 3px 16px rgba(0,0,0,0.6)'}}>Aksi nyata pelajar hijau untuk sekolah asri dan berkelanjutan</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};
const OpeningFooter: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', fontFamily: FONT, paddingBottom: 70}}>
    <Rise delay={0}>
      <div style={{display: 'flex', gap: 20}}>
        <Chip light>Kelas X E7</Chip>
        <Chip>Kelompok 5 — video kampanye</Chip>
      </div>
    </Rise>
  </AbsoluteFill>
);

/* ───────────────────────── SCENE 2 — pengenalan ───────────────────────── */
const Intro: React.FC = () => (
  <AbsoluteFill style={{justifyContent: 'flex-end', padding: '0 0 110px 90px', fontFamily: FONT}}>
    <Glass style={{padding: '44px 60px', width: 1040}}>
      <Rise delay={0}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.sage, fontWeight: 600, fontSize: 28, marginBottom: 14, letterSpacing: 1}}>
          <Leaf size={34} /> Pengenalan kegiatan
        </div>
      </Rise>
      <Rise delay={0.3}>
        <div style={{fontWeight: 800, fontSize: 68, lineHeight: 1.1, color: C.white}}>Kokurikuler gaya hidup berkelanjutan</div>
      </Rise>
      <Rise delay={1.4}>
        <div style={{marginTop: 26}}>
          <Chip light>Fokus kegiatan: tamanisasi</Chip>
        </div>
      </Rise>
    </Glass>
  </AbsoluteFill>
);

/* ───────────────────────── SCENE 3 — agenda hari pertama ───────────────────────── */
const Agenda: React.FC = () => {
  const items = ['Pengamatan lingkungan', 'Identifikasi permasalahan', 'Analisis kondisi lingkungan'];
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-end', padding: '0 80px', fontFamily: FONT}}>
      <Glass style={{padding: '48px 56px', width: 860}}>
        <Rise delay={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
            <div style={{width: 112, height: 112, borderRadius: '50%', background: C.beige, color: C.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 64, flexShrink: 0}}>1</div>
            <div>
              <div style={{fontWeight: 800, fontSize: 62, color: C.white, lineHeight: 1.05}}>Hari pertama</div>
              <div style={{fontWeight: 500, fontSize: 34, color: C.beige, marginTop: 8}}>Audit dan diagnosa lingkungan</div>
            </div>
          </div>
        </Rise>
        <Rise delay={0.7}>
          <div style={{margin: '26px 0 6px'}}>
            <Chip style={{fontSize: 28}}>Discover &amp; Brainstorm</Chip>
          </div>
        </Rise>
        <div style={{marginTop: 24, display: 'flex', flexDirection: 'column', gap: 18}}>
          {items.map((t, i) => (
            <Rise key={t} delay={1.8 + i * 1.3} x={60}>
              <div style={{display: 'flex', alignItems: 'center', gap: 22, fontWeight: 600, fontSize: 38, color: C.white}}>
                <Check delay={2.2 + i * 1.3} />
                {t}
              </div>
            </Rise>
          ))}
        </div>
      </Glass>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 4 — diskusi dan perencanaan ───────────────────────── */
const Discuss: React.FC = () => {
  const f = useCurrentFrame();
  const steps = ['Observasi', 'Analisis', 'Diskusi', 'Perencanaan'];
  const dim = interpolate(f, [0, sec(1)], [0, 1], {...clamp});
  return (
    <AbsoluteFill style={{fontFamily: FONT, justifyContent: 'center', alignItems: 'center'}}>
      <AbsoluteFill style={{background: 'rgba(10,36,20,0.62)', backdropFilter: 'blur(10px)', opacity: dim}} />
      <div style={{position: 'relative', textAlign: 'center', width: 1640}}>
        <Rise delay={0.3}>
          <div style={{fontWeight: 800, fontSize: 84, color: C.white}}>Diskusi dan perencanaan</div>
        </Rise>
        <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: 70}}>
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <Rise delay={1.6 + i * 1.2}>
                <div style={{width: 300, padding: '34px 10px', borderRadius: 22, background: i === 3 ? C.beige : 'rgba(31,81,48,0.9)', border: `2px solid ${C.sage}`, color: i === 3 ? C.deep : C.white}}>
                  <div style={{fontSize: 24, fontWeight: 600, opacity: 0.8, marginBottom: 8}}>Langkah {i + 1}</div>
                  <div style={{fontSize: 40, fontWeight: 800}}>{s}</div>
                </div>
              </Rise>
              {i < 3 && (
                <Rise delay={2.2 + i * 1.2}>
                  <svg width="70" height="30" viewBox="0 0 70 30" style={{margin: '0 6px'}}>
                    <path d="M4 15h54M46 5l14 10-14 10" fill="none" stroke={C.beige} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </Rise>
              )}
            </React.Fragment>
          ))}
        </div>
        <Rise delay={7}>
          <div style={{marginTop: 70, fontWeight: 500, fontSize: 42, color: C.beige, lineHeight: 1.35}}>Menentukan permasalahan dan merancang solusi<br />untuk lingkungan sekolah.</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 5 — Kelompok 5 ───────────────────────── */
const Group: React.FC = () => {
  const items = ['Menentukan target audiens', 'Menentukan tema kampanye', 'Menyusun pesan utama', 'Membuat konsep dan storyboard'];
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'flex-start', padding: '0 0 0 90px', fontFamily: FONT}}>
      <Glass style={{padding: '48px 60px', width: 960}}>
        <Rise delay={0}>
          <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
            <div style={{position: 'relative', width: 150, height: 150, flexShrink: 0}}>
              <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: `4px solid ${C.sage}`}} />
              <div style={{position: 'absolute', inset: 14, borderRadius: '50%', background: C.beige, color: C.deep, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 88}}>5</div>
            </div>
            <div>
              <div style={{fontWeight: 800, fontSize: 76, color: C.white, lineHeight: 1}}>Kelompok 5</div>
              <div style={{fontWeight: 500, fontSize: 36, color: C.beige, marginTop: 10}}>Video kampanye lingkungan</div>
            </div>
          </div>
        </Rise>
        <div style={{height: 2, background: 'rgba(239,230,210,0.3)', margin: '34px 0 28px'}} />
        <div style={{display: 'flex', flexDirection: 'column', gap: 20}}>
          {items.map((t, i) => (
            <Rise key={t} delay={1.4 + i * 1.3} x={-60}>
              <div style={{display: 'flex', alignItems: 'center', gap: 22, fontWeight: 600, fontSize: 40, color: C.white}}>
                <Check delay={1.8 + i * 1.3} />
                {t}
              </div>
            </Rise>
          ))}
        </div>
      </Glass>
    </AbsoluteFill>
  );
};

/* ───────────────────────── SCENE 6 — closing ───────────────────────── */
const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const dim = interpolate(f, [0, sec(1.6)], [0, 1], {...clamp});
  return (
    <AbsoluteFill style={{fontFamily: FONT, justifyContent: 'center', alignItems: 'center', textAlign: 'center'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, rgba(13,40,23,0.78) 0%, rgba(8,28,15,0.9) 100%)', opacity: dim}} />
      <div style={{position: 'relative'}}>
        <Rise delay={0.4}>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 22}}>
            <Leaf size={80} />
          </div>
        </Rise>
        <Rise delay={0.8}>
          <div style={{fontWeight: 800, fontSize: 104, color: C.white, textShadow: '0 6px 30px rgba(0,0,0,0.5)'}}>Langkah kecil, dampak besar.</div>
        </Rise>
        <Rise delay={2.4}>
          <div style={{fontWeight: 500, fontSize: 42, color: C.beige, marginTop: 28}}>Mewujudkan lingkungan sekolah yang lebih asri dan berkelanjutan.</div>
        </Rise>
        <Rise delay={5}>
          <div style={{height: 2, width: 420, background: C.sage, margin: '54px auto 36px'}} />
          <div style={{fontWeight: 800, fontSize: 56, letterSpacing: 10, color: C.white}}>ECO-ACTION 4 DAYS</div>
          <div style={{fontWeight: 500, fontSize: 34, color: C.beige, marginTop: 16}}>Kelas X E7 — Kelompok 5</div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── fade out akhir ───────────────────────── */
const EndFade: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [sec(TOTAL_SECONDS - 3), TOTAL_FRAMES], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  return <AbsoluteFill style={{background: '#000', opacity: o}} />;
};

/* ───────────────────────── komposisi ───────────────────────── */
export const EcoAction: React.FC = () => {
  const musicVol = (frame: number) =>
    interpolate(frame, [0, sec(3), sec(TOTAL_SECONDS - 5), TOTAL_FRAMES], [0, 0.85, 0.85, 0], clamp);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <Footage />
      <Vignette />

      {/* Scene 1 */}
      <Layer at={1.2} dur={ST[1] - 1.2 - 0.2} rise={30}>
        <Opening />
      </Layer>
      <Layer at={5.5} dur={ST[1] - 5.5 - 0.2} rise={20}>
        <OpeningFooter />
      </Layer>
      {/* Scene 2 */}
      <Layer at={ST[1] + 1.2} dur={11}>
        <Intro />
      </Layer>
      {/* Scene 3 */}
      <Layer at={ST[2] + 1} dur={SCENE_DUR[2] - 2}>
        <Agenda />
      </Layer>
      {/* Scene 4 */}
      <Layer at={ST[3] + 0.5} dur={SCENE_DUR[3] - 3} rise={0}>
        <Discuss />
      </Layer>
      {/* Scene 5 */}
      <Layer at={ST[4] + 1} dur={SCENE_DUR[4] - 2}>
        <Group />
      </Layer>
      {/* Scene 6 */}
      <Layer at={ST[5] + 7} dur={SCENE_DUR[5] - 7 - 0.2} rise={0}>
        <Closing />
      </Layer>

      <Bug />
      <ProgressBar />
      <EndFade />

      {/* Audio: musik cinematic instrumental + sound effect halus */}
      <Audio src={staticFile('music.mp3')} volume={musicVol} />
      {[ST[1], ST[2], ST[3], ST[4], ST[5] + 7].map((t, i) => (
        <Sequence key={`w${i}`} from={sec(t - 0.5)}>
          <Audio src={staticFile('whoosh.mp3')} volume={0.35} />
        </Sequence>
      ))}
      {[1.4, ST[5] + 8].map((t, i) => (
        <Sequence key={`i${i}`} from={sec(t)}>
          <Audio src={staticFile('impact.mp3')} volume={0.5} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
