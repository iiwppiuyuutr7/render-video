/**
 * ECO-ACTION 4 DAYS – Hari Kedua: Aksi Nyata dan Eksekusi Tamanisasi
 * 1920x1080 (16:9) · 30 fps · ±55 detik
 *
 * Sambungan dari hari pertama: tanpa pembuka program dan tanpa ending (pembuka ada di hari 1, ending di hari 4).
 * Hanya ada tulisan "Hari 2" di awal. Tanpa backsound (dipasang sendiri saat digabung). SFX tetap ada.
 * Semua waktu dalam DETIK, diubah ke frame sesuai fps composition (useVideoConfig).
 * Pastikan durationInFrames di Root = ECO2_TOTAL_SECONDS x fps.
 *
 * Aset: public/eco2/clips (klip asli, 30fps, tanpa audio), public/eco2/sfx
 * Footage hari kedua hanya 4 klip. Info yang tidak punya footage (jadwal lengkap, pembagian tugas,
 * fokus Kelompok 5, TOGA) tetap ditampilkan sebagai kartu teks polos (tanpa visual pengganti).
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const WHITE = '#ffffff';
const BEIGE = '#efe5cf';
const GREEN = '#9fcf86';
const DEEP = '#0f2e1c';

const OVERLAP_S = 0.5; // durasi dissolve antar klip

/* ───────────────────────── urutan klip (detik) ───────────────────────── */
type Seg = {id: string; src: string; sec: number; zoom: 'in' | 'out'};

const SEGS: Seg[] = [
  {id: 'a', src: 'a-persiapan', sec: 13.6, zoom: 'in'}, // suasana sekolah → siswa mengecat wadah daur ulang
  {id: 'b', src: 'b-media-tanam', sec: 8.0, zoom: 'in'}, // memotong galon bekas
  {id: 'c', src: 'c-kolaborasi', sec: 8.0, zoom: 'out'}, // kerja kelompok memotong galon bekas
  {id: 'd', src: 'd-eksekusi', sec: 10.0, zoom: 'in'}, // menggemburkan tanah & menanam bibit
];

const START_S: Record<string, number> = {};
let acc = 0;
SEGS.forEach((s, i) => {
  const st = i === 0 ? 0 : acc - OVERLAP_S;
  START_S[s.id] = st;
  acc = st + s.sec;
});
const VIDEO_END_S = acc; // klip terakhir selesai di ±38,1 detik

/* ───────────────────────── kartu teks (info tanpa footage) ─────────────────────────
 * Jadwal lengkap, pembagian tugas, fokus Kelompok 5, dan TOGA ditampilkan di kartu teks polos
 * (tanpa visual pengganti). Isi teks mengikuti panduan kegiatan hari ke-2.
 */
const CARDS_START_S = VIDEO_END_S - OVERLAP_S; // latar kartu masuk dissolve di atas klip terakhir
const C0 = VIDEO_END_S + 0.2;
const CARD = {
  jadwal: {start: C0, end: C0 + 7.5},
  tugas: {start: C0 + 7.6, end: C0 + 15.1},
  k5: {start: C0 + 15.2, end: C0 + 21.7},
  toga: {start: C0 + 21.8, end: C0 + 28.3},
};
export const ECO2_TOTAL_SECONDS = CARD.toga.end; // ±66,6 detik

/* ───────────────────────── util ───────────────────────── */
const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const useFr = () => {
  const {fps} = useVideoConfig();
  return (s: number) => Math.round(s * fps);
};

const fadeWindow = (f: number, dur: number, fi: number, fo: number) =>
  interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], clampOpts);

const rise = (f: number, delay: number, len: number, dist: number) =>
  interpolate(f, [delay, delay + len], [dist, 0], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });

const shadow = '0 3px 24px rgba(0,0,0,0.38)';

/* ───────────────────────── klip video ───────────────────────── */
// Color grading ringan: sedikit hangat, saturasi hijau natural, kontras seimbang.
const GRADE = 'saturate(1.12) contrast(1.05) brightness(0.98) sepia(0.10)';

const VideoSeg: React.FC<{seg: Seg; index: number}> = ({seg, index}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const dur = fr(seg.sec);
  // klip pertama langsung tampil penuh (tanpa fade dari gelap) supaya mulus saat disambung dari hari pertama
  const opacity = index === 0 ? 1 : interpolate(f, [0, fr(OVERLAP_S)], [0, 1], clampOpts);
  const scale =
    seg.zoom === 'in'
      ? interpolate(f, [0, dur], [1.0, 1.045], clampOpts)
      : interpolate(f, [0, dur], [1.045, 1.0], clampOpts);
  return (
    <AbsoluteFill style={{opacity}}>
      <OffthreadVideo
        src={staticFile(`eco2/clips/${seg.src}.mp4`)}
        volume={0}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${scale})`,
          filter: GRADE,
        }}
      />
    </AbsoluteFill>
  );
};

/* ───────────────────────── teks ───────────────────────── */
const Pill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 28,
      color: WHITE,
      padding: '8px 24px',
      borderRadius: 999,
      border: '2px solid rgba(255,255,255,0.7)',
      background: 'rgba(255,255,255,0.12)',
      textShadow: shadow,
    }}
  >
    {children}
  </div>
);

// Judul bagian di kiri bawah, dengan scrim gradasi halus di bawahnya. start/end dalam detik.
const LowerThird: React.FC<{
  start: number;
  end: number;
  title: string;
  sub: string;
  extra?: string;
}> = ({start, end, title, sub, extra}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <LowerThirdInner dur={fr(end) - fr(start)} title={title} sub={sub} extra={extra} />
    </Sequence>
  );
};

const LowerThirdInner: React.FC<{dur: number; title: string; sub: string; extra?: string}> = ({
  dur,
  title,
  sub,
  extra,
}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = fadeWindow(f, dur, fr(0.47), fr(0.4));
  const bar = interpolate(f, [0, fr(0.67)], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: op,
          background:
            'linear-gradient(to top, rgba(6,22,11,0.70) 0%, rgba(6,22,11,0.38) 28%, rgba(6,22,11,0) 52%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 120,
          display: 'flex',
          gap: 30,
          alignItems: 'stretch',
          opacity: op,
        }}
      >
        <div
          style={{
            width: 7,
            borderRadius: 4,
            background: GREEN,
            transform: `scaleY(${bar})`,
            transformOrigin: 'bottom',
          }}
        />
        <div style={{transform: `translateY(${rise(f, 0, fr(0.53), 18)}px)`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 68,
              lineHeight: 1.12,
              color: WHITE,
              textShadow: shadow,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 36,
              marginTop: 14,
              color: BEIGE,
              textShadow: shadow,
              transform: `translateY(${rise(f, fr(0.2), fr(0.53), 12)}px)`,
            }}
          >
            {sub}
          </div>
          {extra ? (
            <div style={{marginTop: 26, display: 'flex'}}>
              <Pill>{extra}</Pill>
            </div>
          ) : null}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Panel teks di tengah layar (opening). start/end dalam detik.
const CenterPanel: React.FC<{start: number; end: number; children: React.ReactNode}> = ({
  start,
  end,
  children,
}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <CenterInner dur={fr(end) - fr(start)}>{children}</CenterInner>
    </Sequence>
  );
};

const CenterInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, fr(0.6), fr(0.47)),
        transform: `translateY(${rise(f, 0, fr(0.53), 22)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const Line: React.FC<{
  size: number;
  weight: 600 | 800;
  color: string;
  mt?: number;
  spacing?: number;
  children: React.ReactNode;
}> = ({size, weight, color, mt = 0, spacing = 0, children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: weight,
      fontSize: size,
      color,
      marginTop: mt,
      letterSpacing: spacing,
      lineHeight: 1.15,
      textShadow: shadow,
      maxWidth: 1700,
      ...({textWrap: 'balance'} as React.CSSProperties),
    }}
  >
    {children}
  </div>
);

const Rule: React.FC<{width?: number}> = ({width = 220}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const w = interpolate(f, [fr(0.27), fr(1.13)], [0, width], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });
  return <div style={{height: 5, width: w, borderRadius: 3, background: GREEN, marginTop: 30}} />;
};

// Peredup lembut agar teks putih terbaca di atas footage terang. start/end dalam detik.
const Dim: React.FC<{start: number; end: number; strength: number}> = ({start, end, strength}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <DimInner dur={fr(end) - fr(start)} strength={strength} />
    </Sequence>
  );
};
const DimInner: React.FC<{dur: number; strength: number}> = ({dur, strength}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        background: `rgba(8,26,14,${strength})`,
        opacity: interpolate(f, [0, fr(0.73), dur - fr(0.73), dur], [0, 1, 1, 0], clampOpts),
      }}
    />
  );
};

// Kilau halus saat judul muncul (sinkron dengan efek kamera flash). at dalam detik.
const SoftFlash: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const a = fr(at);
  const o = interpolate(f, [a, a + fr(0.1), a + fr(0.47)], [0, 0.1, 0], clampOpts);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

// Latar kartu teks: hijau tua polos dengan gradasi halus, masuk dengan dissolve.
const CardsBg: React.FC = () => {
  const fr = useFr();
  return (
    <Sequence from={fr(CARDS_START_S)} durationInFrames={fr(ECO2_TOTAL_SECONDS) - fr(CARDS_START_S)}>
      <CardsBgInner />
    </Sequence>
  );
};
const CardsBgInner: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(f, [0, fr(OVERLAP_S)], [0, 1], clampOpts),
        background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)',
      }}
    />
  );
};

const PlantPill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 38,
      color: WHITE,
      padding: '12px 34px',
      borderRadius: 999,
      border: '2px solid rgba(239,229,207,0.75)',
      background: 'rgba(255,255,255,0.08)',
    }}
  >
    {children}
  </div>
);

/* ───────────────────────── audio ───────────────────────── */
const Sfx: React.FC<{file: string; at: number; vol?: number}> = ({file, at, vol = 0.5}) => {
  const fr = useFr();
  return (
    <Sequence from={Math.max(0, fr(at))}>
      <Audio src={staticFile(`eco2/sfx/${file}.mp3`)} volume={vol} />
    </Sequence>
  );
};

/* ───────────────────────── komposisi ───────────────────────── */
const SCHED_L: [string, string][] = [
  ['07.00–07.20', 'Persiapan dan Pengecekan'],
  ['07.20–07.40', 'Pengarahan dan K3'],
  ['07.40–09.30', 'Persiapan Area Taman'],
  ['09.30–09.45', 'Istirahat'],
  ['09.45–11.15', 'Penanaman dan Penataan Taman'],
  ['11.15–11.45', 'Penyelesaian dan Dokumentasi'],
];
const SCHED_R: [string, string][] = [
  ['11.45–12.30', 'ISHOMA'],
  ['12.30–13.20', 'Produksi Media Kampanye'],
  ['13.20–13.40', 'Pemeriksaan Hasil Kegiatan'],
  ['13.40–13.50', 'Laporan Harian'],
  ['13.50–14.00', 'Penutupan'],
];
const GROUPS: {no: number; name: string; desc: string}[] = [
  {no: 1, name: 'Desain Taman', desc: 'Mengarahkan desain dan penataan area taman.'},
  {no: 2, name: 'Jenis Tanaman', desc: 'Menentukan dan mendukung pemilihan tanaman.'},
  {no: 3, name: 'Eksekusi', desc: 'Melaksanakan persiapan area dan kegiatan fisik tamanisasi.'},
  {no: 4, name: 'Pemeliharaan', desc: 'Mendukung kegiatan dan memperhatikan kebutuhan perawatan tanaman.'},
  {no: 5, name: 'Video Kampanye', desc: 'Mendokumentasikan kegiatan dan membuat media kampanye.'},
  {no: 6, name: 'Penanaman TOGA', desc: 'Melaksanakan penanaman tanaman obat keluarga serta menyiapkan label dan informasi edukasi.'},
];
const K5_TASKS = [
  'Mendokumentasikan proses kegiatan tamanisasi',
  'Mengumpulkan materi dokumentasi dari kelompok lain',
  'Membuat dan mengedit video kampanye',
  'Menyiapkan poster atau media edukasi',
  'Menyiapkan media kampanye untuk Gallery Walk pada hari ketiga',
];

// Muncul bertahap di dalam CenterPanel (waktu lokal sequence).
const Stagger: React.FC<{i: number; step?: number; children: React.ReactNode}> = ({i, step = 0.25, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const d = fr(0.7 + i * step);
  return (
    <div
      style={{
        opacity: interpolate(f, [d, d + fr(0.45)], [0, 1], clampOpts),
        transform: `translateY(${rise(f, d, fr(0.45), 14)}px)`,
      }}
    >
      {children}
    </div>
  );
};

const SchedRow: React.FC<{i: number; time: string; title: string}> = ({i, time, title}) => (
  <Stagger i={i} step={0.2}>
    <div style={{display: 'flex', alignItems: 'baseline', gap: 22, padding: '9px 0'}}>
      <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 30, color: GREEN, width: 220, textShadow: shadow}}>
        {time}
      </div>
      <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 36, color: WHITE, textShadow: shadow}}>{title}</div>
    </div>
  </Stagger>
);

export const EcoActionDay2: React.FC = () => {
  const S = START_S;
  const TITLE_LEN = 4.0;

  const T_PERSIAPAN = 4.6; // setelah tulisan "Hari 2"
  const T_MEDIA = S.b + 0.7;
  const T_KOLAB = S.c + 0.7;
  const T_EKSEKUSI = S.d + 0.8;

  return (
    <AbsoluteFill style={{backgroundColor: DEEP}}>
      {/* ── video (urut, dissolve) ── */}
      <VideoTrack />

      {/* vignette tipis di seluruh video */}
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(8,24,12,0.34) 100%)',
        }}
      />

      {/* ── Tulisan "Hari 2" (tanpa pembuka program: itu ada di hari 1) ── */}
      <Dim start={0} end={4.3} strength={0.3} />
      <CenterPanel start={0.4} end={4.1}>
        <Line size={168} weight={800} color={WHITE} spacing={2}>
          Hari 2
        </Line>
        <Rule />
        <Line size={54} weight={600} color={BEIGE} mt={30}>
          Do &amp; Create
        </Line>
        <Line size={36} weight={600} color={BEIGE} mt={12}>
          Pelaksanaan rencana tamanisasi
        </Line>
      </CenterPanel>

      {/* ── footage + judul bagian (sesuai jadwal resmi) ── */}
      <LowerThird
        start={T_PERSIAPAN}
        end={T_PERSIAPAN + TITLE_LEN}
        title="Persiapan dan Pengecekan"
        sub="Alat, bahan, bibit tanaman, dan area kegiatan"
        extra="07.00–07.20"
      />
      <LowerThird
        start={T_MEDIA}
        end={T_MEDIA + TITLE_LEN}
        title="Persiapan Area Taman"
        sub="Mempersiapkan media tanam"
        extra="07.40–09.30"
      />
      <LowerThird
        start={T_KOLAB}
        end={T_KOLAB + TITLE_LEN}
        title="Pekerjaan Awal Tamanisasi"
        sub="Menyiapkan dan menata area sesuai desain"
        extra="07.40–09.30"
      />
      <LowerThird
        start={T_EKSEKUSI}
        end={T_EKSEKUSI + TITLE_LEN}
        title="Penanaman dan Penataan Taman"
        sub="Menyiapkan tanah dan menanam bibit"
        extra="09.45–11.15"
      />

      {/* ── KARTU TEKS: info tanpa footage ── */}
      <CardsBg />

      {/* Jadwal resmi */}
      <CenterPanel start={CARD.jadwal.start} end={CARD.jadwal.end}>
        <Line size={64} weight={800} color={WHITE}>
          Jadwal Kegiatan Hari Ke-2
        </Line>
        <Rule />
        <div style={{display: 'flex', gap: 80, marginTop: 40, textAlign: 'left'}}>
          <div>
            {SCHED_L.map(([t, n], i) => (
              <SchedRow key={t} i={i} time={t} title={n} />
            ))}
          </div>
          <div>
            {SCHED_R.map(([t, n], i) => (
              <SchedRow key={t} i={i + SCHED_L.length} time={t} title={n} />
            ))}
          </div>
        </div>
      </CenterPanel>

      {/* Pembagian tugas kelompok */}
      <CenterPanel start={CARD.tugas.start} end={CARD.tugas.end}>
        <Line size={62} weight={800} color={WHITE}>
          Pembagian Tugas Kelompok
        </Line>
        <Rule />
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 540px)', gap: 26, marginTop: 40, textAlign: 'left'}}>
          {GROUPS.map((g, i) => (
            <Stagger key={g.no} i={i} step={0.2}>
              <div
                style={{
                  height: '100%',
                  boxSizing: 'border-box',
                  padding: '22px 26px',
                  borderRadius: 20,
                  border: g.no === 5 ? `3px solid ${GREEN}` : '2px solid rgba(239,229,207,0.35)',
                  background: g.no === 5 ? 'rgba(159,207,134,0.16)' : 'rgba(255,255,255,0.06)',
                }}
              >
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 28, color: GREEN}}>Kelompok {g.no}</div>
                <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 40, color: WHITE, marginTop: 4}}>{g.name}</div>
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 27, color: BEIGE, marginTop: 10, lineHeight: 1.3}}>
                  {g.desc}
                </div>
              </div>
            </Stagger>
          ))}
        </div>
      </CenterPanel>

      {/* Fokus Kelompok 5 */}
      <CenterPanel start={CARD.k5.start} end={CARD.k5.end}>
        <Line size={62} weight={800} color={WHITE}>
          Fokus Kelompok 5 — Video Kampanye
        </Line>
        <Rule />
        <div style={{marginTop: 38, textAlign: 'left'}}>
          {K5_TASKS.map((t, i) => (
            <Stagger key={t} i={i} step={0.3}>
              <div style={{display: 'flex', gap: 24, alignItems: 'baseline', padding: '9px 0'}}>
                <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 38, color: GREEN, width: 40}}>{i + 1}</div>
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 38, color: WHITE, textShadow: shadow}}>{t}</div>
              </div>
            </Stagger>
          ))}
        </div>
      </CenterPanel>

      {/* Penanaman TOGA */}
      <CenterPanel start={CARD.toga.start} end={CARD.toga.end}>
        <Line size={66} weight={800} color={WHITE}>
          Penanaman TOGA
        </Line>
        <Rule />
        <Line size={40} weight={600} color={BEIGE} mt={28}>
          TOGA adalah singkatan dari Tanaman Obat Keluarga
        </Line>
        <div style={{display: 'flex', gap: 22, marginTop: 38}}>
          <PlantPill>Lidah Buaya</PlantPill>
          <PlantPill>Kumis Kucing</PlantPill>
          <PlantPill>Pohon Jeruk</PlantPill>
        </div>
        <Line size={32} weight={600} color={BEIGE} mt={38}>
          Dilaksanakan oleh Kelompok 6: pemilihan tanaman, persiapan media tanam, penanaman, pemasangan label, dan informasi edukasi
        </Line>
      </CenterPanel>

      {/* (tanpa closing / end card: ending ada di hari 4) */}

      {/* ── SFX (tanpa backsound) ── */}
      <Sfx file="pop" at={0.45} vol={0.45} />
      <Sfx file="click" at={T_PERSIAPAN + 0.1} vol={0.4} />
      <Sfx file="transition" at={S.b} vol={0.35} />
      <Sfx file="click" at={T_MEDIA + 0.1} vol={0.4} />
      <Sfx file="whoosh" at={S.c - 0.4} vol={0.3} />
      <Sfx file="click" at={T_KOLAB + 0.1} vol={0.4} />
      <Sfx file="whoosh" at={S.d - 0.4} vol={0.3} />
      <Sfx file="click" at={T_EKSEKUSI + 0.1} vol={0.4} />
      <Sfx file="whoosh" at={CARDS_START_S - 0.3} vol={0.3} />
      <Sfx file="click" at={CARD.jadwal.start + 0.1} vol={0.4} />
      <Sfx file="click" at={CARD.tugas.start + 0.1} vol={0.4} />
      <Sfx file="click" at={CARD.k5.start + 0.1} vol={0.4} />
      <Sfx file="click" at={CARD.toga.start + 0.1} vol={0.4} />
      <Sfx file="pop" at={CARD.toga.start + 2.3} vol={0.35} />
    </AbsoluteFill>
  );
};

const VideoTrack: React.FC = () => {
  const {fps} = useVideoConfig();
  return (
    <>
      {SEGS.map((seg, i) => (
        <Sequence
          key={seg.id}
          from={Math.round(START_S[seg.id] * fps)}
          durationInFrames={Math.round(seg.sec * fps)}
        >
          <VideoSeg seg={seg} index={i} />
        </Sequence>
      ))}
    </>
  );
};
