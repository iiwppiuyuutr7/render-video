import React from 'react';
import {Composition} from 'remotion';
import {EcoActionDay2, ECO2_TOTAL_SECONDS} from './EcoActionDay2';

const FPS = 30;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EcoActionDay2"
    component={EcoActionDay2}
    durationInFrames={Math.round(ECO2_TOTAL_SECONDS * FPS)}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
