import React from 'react';
import { Composition } from 'remotion';
import {
  DURATION_IN_FRAMES,
  FPS,
  Handphone,
  VIDEO_HEIGHT,
  VIDEO_WIDTH,
} from './Handphone';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="IphoneTeardown"
      component={Handphone}
      durationInFrames={DURATION_IN_FRAMES}
      fps={FPS}
      width={VIDEO_WIDTH}
      height={VIDEO_HEIGHT}
    />
  );
};
