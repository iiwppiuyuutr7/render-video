import React from 'react';
import {
  AbsoluteFill,
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';

/* ============================================================
 * 1. KONSTANTA UTAMA
 * Semua timing dihitung dari konstanta di bagian ini.
 * ============================================================ */
export const VIDEO_WIDTH = 1920;
export const VIDEO_HEIGHT = 1080;
export const FPS = 60;
export const DURATION_IN_FRAMES = 1800;

// Ukuran bodi HP di ruang 3D (px)
const PW = 350;
const PH = 736;
const BODY_R = 54;

const ACCENT = '#5ee7ff';
const GOLD = '#d4b062';
const FONT = 'Inter, "SF Pro Display", "Helvetica Neue", Arial, sans-serif';

// Kamera & jarak antar layer
const PERSPECTIVE = 3000;
const EXPLODED_STEP = 130; // jarak antar layer saat terpisah
const ASSEMBLED_STEP = 2; // jarak antar layer saat menyatu
const ROT_Y = -56; // sudut putar horizontal saat exploded (derajat)
const ROT_X = 12; // kemiringan vertikal saat exploded (derajat)
const TOUR_TX = -330; // posisi fokus (kiri layar) saat tour
const OVERVIEW_SCALE = 0.88; // skala saat exploded tanpa fokus

/* ============================================================
 * 2. DATA BAGIAN (urutan depan -> belakang, 1 stop = 1 layer)
 * anchor = titik fokus relatif terhadap pusat layer (px)
 * ============================================================ */
type Vec2 = readonly [number, number];

interface Stop {
  title: string;
  desc: string;
  anchor: Vec2;
  zoom: number;
}

const STOPS: readonly Stop[] = [
  {
    title: 'Kaca Pelindung Layar',
    desc: 'Lapisan terdepan yang melindungi layar dari goresan dan benturan.',
    anchor: [0, -20],
    zoom: 1.15,
  },
  {
    title: 'Panel Display',
    desc: 'Menampilkan gambar dan warna, sekaligus membaca sentuhan jari.',
    anchor: [0, 40],
    zoom: 1.15,
  },
  {
    title: 'Logic Board & Chip Utama',
    desc: 'Papan sirkuit utama. Chip di atasnya menjalankan sistem dan semua aplikasi.',
    anchor: [-35, -212],
    zoom: 1.5,
  },
  {
    title: 'Modul Kamera Belakang',
    desc: 'Lensa dan sensor bekerja bersama untuk menangkap foto dan video.',
    anchor: [-66, -253],
    zoom: 1.6,
  },
  {
    title: 'Baterai',
    desc: 'Menyimpan energi listrik untuk menyalakan seluruh perangkat.',
    anchor: [-4, 79],
    zoom: 1.3,
  },
  {
    title: 'Taptic Engine',
    desc: 'Motor getar presisi yang memberi umpan balik sentuhan saat kamu mengetuk.',
    anchor: [-77, 272],
    zoom: 1.9,
  },
  {
    title: 'Speaker',
    desc: 'Mengubah sinyal audio menjadi suara musik, panggilan, dan notifikasi.',
    anchor: [93, 290],
    zoom: 2.0,
  },
  {
    title: 'Antena',
    desc: 'Pita antena pada rangka menangkap sinyal seluler, Wi-Fi, dan Bluetooth.',
    anchor: [163, -255],
    zoom: 1.8,
  },
  {
    title: 'Port USB-C',
    desc: 'Jalur untuk mengisi daya dan mentransfer data lewat kabel.',
    anchor: [-5, 303],
    zoom: 2.0,
  },
  {
    title: 'Casing Belakang',
    desc: 'Menutup dan melindungi semua komponen di dalamnya agar tetap aman.',
    anchor: [0, 120],
    zoom: 1.15,
  },
];

const N = STOPS.length;

/* ============================================================
 * 3. TIMELINE (frame)
 * ============================================================ */
const INTRO_FADE = 50; // fade-in HP utuh
const INTRO_SPRING = 90; // durasi spring scale intro
const ROT_START = 40; // mulai rotasi 3D pelan
const SPLIT_START = 150; // mulai terbelah
const SPLIT_STAGGER = 6; // jeda antar layer saat terbelah
const SPLIT_DUR = 66; // durasi gerak tiap layer

const TOUR_START = 260;
const STOP_LEN = 128; // durasi tiap bagian (~2,1 detik)
const TOUR_END = TOUR_START + N * STOP_LEN;

const MERGE_START = TOUR_END; // mulai menyatu kembali
const MERGE_STAGGER = 5;
const MERGE_DUR = 80;
const ROT_RETURN_DUR = 150; // HP kembali menghadap depan

const FADE_OUT_START = DURATION_IN_FRAMES - 80;

const CAM_LEAD = 10; // kamera mulai bergerak sebelum stop dimulai
const CAM_TRANS = 44; // durasi perpindahan kamera antar bagian

// Timeline callout (relatif terhadap awal stop)
const LINE_IN: Vec2 = [18, 44];
const CARD_IN_DELAY = 24;
const DESC_IN: Vec2 = [34, 54];
const CALLOUT_OUT: Vec2 = [STOP_LEN - 22, STOP_LEN - 8];

// Posisi callout di layar
const CARD_X = 1130;
const CARD_Y = 380;
const CARD_W = 660;
const LINE_END: Vec2 = [CARD_X, CARD_Y + 60];

/* ============================================================
 * 4. HELPER ANIMASI
 * ============================================================ */
const CLAMP = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
const EASE_SMOOTH = Easing.bezier(0.45, 0, 0.2, 1);
const EASE_ROTATE = Easing.bezier(0.4, 0, 0.2, 1);

const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
const stopStart = (i: number): number => TOUR_START + i * STOP_LEN;
const pad2 = (n: number): string => String(n).padStart(2, '0');

const zAssembled = (i: number): number => ((N - 1) / 2 - i) * ASSEMBLED_STEP;
const zExploded = (i: number): number => ((N - 1) / 2 - i) * EXPLODED_STEP;
const layerZ = (i: number, e: number): number =>
  lerp(zAssembled(i), zExploded(i), e);

/** Progres exploded 0..1 untuk layer ke-i (terbelah dari depan, menyatu dari belakang). */
function explodeAmount(frame: number, fps: number, i: number): number {
  const open = spring({
    frame: frame - SPLIT_START - i * SPLIT_STAGGER,
    fps,
    config: { damping: 200 },
    durationInFrames: SPLIT_DUR,
  });
  const close = spring({
    frame: frame - MERGE_START - (N - 1 - i) * MERGE_STAGGER,
    fps,
    config: { damping: 200 },
    durationInFrames: MERGE_DUR,
  });
  return open - close;
}

/** Posisi kamera sebagai bilangan pecahan 0..N-1 (antar stop, dengan easing). */
function stopPosition(frame: number): number {
  let pos = 0;
  for (let i = 1; i < N; i++) {
    const from = stopStart(i) - CAM_LEAD;
    pos += interpolate(frame, [from, from + CAM_TRANS], [0, 1], {
      ...CLAMP,
      easing: EASE_SMOOTH,
    });
  }
  return pos;
}

/* ============================================================
 * 5. KAMERA
 * Titik fokus (fx, fy, fz) dijadikan pusat putaran, lalu digeser ke
 * (tx, ty) di layar. Jadi titik fokus selalu persis di (960+tx, 540+ty),
 * dan ujung garis callout tinggal mengikuti titik itu.
 * ============================================================ */
const STOP_INDEXES: number[] = STOPS.map((_, i) => i);
const POSE = {
  fx: STOPS.map((s) => s.anchor[0]),
  fy: STOPS.map((s) => s.anchor[1]),
  fz: STOPS.map((_, i) => zExploded(i)),
  zoom: STOPS.map((s) => s.zoom),
  ty: STOPS.map((s) => s.anchor[1] * s.zoom * 0.4),
};

interface Camera {
  tx: number;
  ty: number;
  scale: number;
  rx: number;
  ry: number;
  fx: number;
  fy: number;
  fz: number;
  pos: number;
  mix: number; // 0 = tampilan keseluruhan, 1 = mode fokus tour
}

function getCamera(frame: number, introScale: number, eAvg: number): Camera {
  const pos = stopPosition(frame);

  const mixIn = interpolate(frame, [TOUR_START - 50, TOUR_START + 20], [0, 1], {
    ...CLAMP,
    easing: EASE_SMOOTH,
  });
  const mixOut = interpolate(frame, [TOUR_END - 30, TOUR_END + 40], [0, 1], {
    ...CLAMP,
    easing: EASE_SMOOTH,
  });
  const mix = mixIn - mixOut;

  // Rotasi 3D pelan: depan -> miring (intro + split), lalu kembali saat outro
  const rotIn = interpolate(frame, [ROT_START, TOUR_START + 20], [0, 1], {
    ...CLAMP,
    easing: EASE_ROTATE,
  });
  const rotOut = interpolate(
    frame,
    [MERGE_START, MERGE_START + ROT_RETURN_DUR],
    [0, 1],
    { ...CLAMP, easing: EASE_SMOOTH }
  );
  const rot = rotIn - rotOut;
  const drift = Math.sin(frame / 140) * 2.5 * mix;

  const tourScale = interpolate(pos, STOP_INDEXES, POSE.zoom);
  const overviewScale = lerp(1, OVERVIEW_SCALE, eAvg);
  const float = Math.sin(frame / 45) * 5 * (1 - mix);

  return {
    tx: mix * TOUR_TX,
    ty: mix * interpolate(pos, STOP_INDEXES, POSE.ty) + float,
    scale: lerp(overviewScale, tourScale, mix) * introScale,
    rx: ROT_X * rot,
    ry: ROT_Y * rot + drift,
    fx: mix * interpolate(pos, STOP_INDEXES, POSE.fx),
    fy: mix * interpolate(pos, STOP_INDEXES, POSE.fy),
    fz: mix * interpolate(pos, STOP_INDEXES, POSE.fz),
    pos,
    mix,
  };
}

/* ============================================================
 * 6. LAYER-LAYER HP (SVG murni, tanpa aset eksternal)
 * ============================================================ */
interface LayerProps {
  hl: number; // intensitas sorotan 0..1
  uid: string; // prefix id unik untuk gradient SVG
}

const Svg: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    width={PW}
    height={PH}
    viewBox={`0 0 ${PW} ${PH}`}
    style={{ display: 'block', overflow: 'visible' }}
  >
    {children}
  </svg>
);

/** Garis sorot aksen di sekeliling komponen yang aktif. */
const Outline: React.FC<{
  hl: number;
  x: number;
  y: number;
  w: number;
  h: number;
  r: number;
}> = ({ hl, x, y, w, h, r }) =>
  hl <= 0.01 ? null : (
    <g>
      <rect
        x={x - 4}
        y={y - 4}
        width={w + 8}
        height={h + 8}
        rx={r + 4}
        fill="none"
        stroke={ACCENT}
        strokeWidth={10}
        opacity={0.18 * hl}
      />
      <rect
        x={x - 2}
        y={y - 2}
        width={w + 4}
        height={h + 4}
        rx={r + 2}
        fill="none"
        stroke={ACCENT}
        strokeWidth={3}
        opacity={hl}
      />
    </g>
  );

/** Path persegi bertepi bulat. */
const roundRectPath = (
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
): string =>
  `M${x + r} ${y}H${x + w - r}A${r} ${r} 0 0 1 ${x + w} ${y + r}V${y + h - r}` +
  `A${r} ${r} 0 0 1 ${x + w - r} ${y + h}H${x + r}A${r} ${r} 0 0 1 ${x} ${y + h - r}` +
  `V${y + r}A${r} ${r} 0 0 1 ${x + r} ${y}Z`;

/* --- 0. Kaca pelindung layar --- */
const GlassLayer: React.FC<LayerProps> = ({ hl, uid }) => (
  <Svg>
    <defs>
      <linearGradient id={`${uid}-glare`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#ffffff" stopOpacity="0.28" />
        <stop offset="0.38" stopColor="#ffffff" stopOpacity="0.05" />
        <stop offset="0.55" stopColor="#ffffff" stopOpacity="0" />
        <stop offset="1" stopColor="#9fd8ff" stopOpacity="0.12" />
      </linearGradient>
    </defs>
    <rect
      x={1.5}
      y={1.5}
      width={PW - 3}
      height={PH - 3}
      rx={BODY_R}
      fill="rgba(160,200,255,0.06)"
      stroke="rgba(255,255,255,0.5)"
      strokeWidth={3}
    />
    <rect
      x={1.5}
      y={1.5}
      width={PW - 3}
      height={PH - 3}
      rx={BODY_R}
      fill={`url(#${uid}-glare)`}
    />
    <rect
      x={14}
      y={14}
      width={PW - 28}
      height={PH - 28}
      rx={BODY_R - 12}
      fill="none"
      stroke="rgba(255,255,255,0.14)"
      strokeWidth={2}
    />
    <Outline hl={hl} x={1.5} y={1.5} w={PW - 3} h={PH - 3} r={BODY_R} />
  </Svg>
);

/* --- 1. Panel display --- */
const DisplayLayer: React.FC<LayerProps> = ({ hl, uid }) => {
  const iconXs = [34, 109, 184, 259];
  const iconYs = [214, 300, 386, 472];
  const colors = ['#ffffff', '#6ee7ff', '#ffd166', '#ff7a8a', '#9b8cff', '#7ee787'];
  return (
    <Svg>
      <defs>
        <linearGradient id={`${uid}-bg`} x1="0" y1="0" x2="0.6" y2="1">
          <stop offset="0" stopColor="#1b2a6b" />
          <stop offset="0.55" stopColor="#5b2c8f" />
          <stop offset="1" stopColor="#f08a4b" />
        </linearGradient>
        <radialGradient id={`${uid}-orb`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#6ee7ff" stopOpacity="0.55" />
          <stop offset="1" stopColor="#6ee7ff" stopOpacity="0" />
        </radialGradient>
        <clipPath id={`${uid}-clip`}>
          <rect x={8} y={8} width={PW - 16} height={PH - 16} rx={BODY_R - 8} />
        </clipPath>
      </defs>
      <rect
        x={8}
        y={8}
        width={PW - 16}
        height={PH - 16}
        rx={BODY_R - 8}
        fill={`url(#${uid}-bg)`}
      />
      <g clipPath={`url(#${uid}-clip)`}>
        <circle cx={90} cy={170} r={190} fill={`url(#${uid}-orb)`} />
        <circle cx={300} cy={560} r={170} fill={`url(#${uid}-orb)`} opacity={0.5} />
        {/* widget */}
        <rect x={34} y={78} width={PW - 68} height={112} rx={26} fill="rgba(255,255,255,0.16)" />
        {/* ikon aplikasi generik */}
        {iconYs.flatMap((y, r) =>
          iconXs.map((x, c) => (
            <rect
              key={`${r}-${c}`}
              x={x}
              y={y}
              width={56}
              height={56}
              rx={15}
              fill={colors[(r * 4 + c) % colors.length]}
              opacity={0.34}
            />
          ))
        )}
        {/* dock */}
        <rect x={22} y={PH - 120} width={PW - 44} height={92} rx={32} fill="rgba(255,255,255,0.18)" />
        {iconXs.map((x) => (
          <rect
            key={`d-${x}`}
            x={x}
            y={PH - 102}
            width={56}
            height={56}
            rx={15}
            fill="#ffffff"
            opacity={0.4}
          />
        ))}
      </g>
      {/* lubang kamera depan (generik) */}
      <rect x={PW / 2 - 52} y={22} width={104} height={32} rx={16} fill="#02030a" />
      <Outline hl={hl} x={8} y={8} w={PW - 16} h={PH - 16} r={BODY_R - 8} />
    </Svg>
  );
};

/* --- 2. Logic board + chip utama --- */
const LogicBoardLayer: React.FC<LayerProps> = ({ hl, uid }) => {
  const topChips: ReadonlyArray<readonly [number, number, number, number]> = [
    [52, 74, 36, 30],
    [206, 70, 60, 40],
    [280, 70, 28, 56],
    [206, 128, 44, 40],
    [52, 214, 64, 34],
    [150, 226, 48, 34],
    [226, 214, 70, 48],
  ];
  const bottomChips: ReadonlyArray<readonly [number, number, number, number]> = [
    [170, 610, 44, 32],
    [228, 606, 64, 44],
    [170, 658, 122, 24],
  ];
  const board = `url(#${uid}-pcb)`;
  return (
    <Svg>
      <defs>
        <linearGradient id={`${uid}-pcb`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1c5c53" />
          <stop offset="1" stopColor="#0f3a37" />
        </linearGradient>
        <linearGradient id={`${uid}-chip`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#4a5160" />
          <stop offset="1" stopColor="#2a2f3a" />
        </linearGradient>
      </defs>
      {/* papan atas, strip penghubung, papan bawah */}
      <rect x={30} y={44} width={290} height={250} rx={26} fill={board} stroke="#2f8f80" strokeWidth={1.5} />
      <rect x={262} y={280} width={46} height={320} rx={16} fill={board} stroke="#2f8f80" strokeWidth={1.5} />
      <rect x={150} y={588} width={158} height={108} rx={22} fill={board} stroke="#2f8f80" strokeWidth={1.5} />
      {/* jalur tembaga */}
      <path
        d="M60 160H96M184 156H206M140 200V226M96 156H70V110M250 168V214M290 126V196M285 300V560"
        stroke="#3fb8a3"
        strokeWidth={2}
        fill="none"
        opacity={0.55}
      />
      {/* chip kecil */}
      {[...topChips, ...bottomChips].map(([x, y, w, h]) => (
        <rect
          key={`${x}-${y}`}
          x={x}
          y={y}
          width={w}
          height={h}
          rx={5}
          fill={`url(#${uid}-chip)`}
          stroke="#7b8494"
          strokeWidth={1}
        />
      ))}
      {/* chip utama */}
      <rect x={96} y={112} width={88} height={88} rx={10} fill={`url(#${uid}-chip)`} stroke="#aab2bf" strokeWidth={2} />
      <rect x={112} y={128} width={56} height={56} rx={6} fill="#1a1f29" stroke="#6c7686" strokeWidth={1.5} />
      <circle cx={104} cy={120} r={2.5} fill="#aab2bf" />
      <Outline hl={hl} x={30} y={44} w={290} h={250} r={26} />
      <Outline hl={hl} x={96} y={112} w={88} h={88} r={10} />
    </Svg>
  );
};

/* --- 3. Modul kamera belakang --- */
const CameraLayer: React.FC<LayerProps> = ({ hl, uid }) => {
  const lenses: ReadonlyArray<Vec2> = [
    [66, 76],
    [66, 156],
    [142, 116],
  ];
  const R = 31;
  return (
    <Svg>
      <defs>
        <radialGradient id={`${uid}-lens`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#1b3a5c" />
          <stop offset="0.55" stopColor="#0a1626" />
          <stop offset="1" stopColor="#02050a" />
        </radialGradient>
      </defs>
      <rect x={24} y={30} width={170} height={170} rx={40} fill="#1d2128" stroke="#4a5260" strokeWidth={3} />
      {lenses.map(([cx, cy]) => (
        <g key={`${cx}-${cy}`}>
          <circle cx={cx} cy={cy} r={R + 7} fill="#2d333d" stroke="#59616f" strokeWidth={2} />
          <circle cx={cx} cy={cy} r={R} fill="#07090d" />
          <circle cx={cx} cy={cy} r={R - 8} fill={`url(#${uid}-lens)`} />
          <circle cx={cx} cy={cy} r={R - 18} fill="#0b1422" stroke="rgba(94,231,255,0.3)" strokeWidth={1.5} />
          <circle cx={cx - R / 3} cy={cy - R / 3} r={R / 7} fill="rgba(255,255,255,0.7)" />
        </g>
      ))}
      {/* flash & sensor kecil */}
      <circle cx={150} cy={52} r={9} fill="#e9edf4" opacity={0.85} />
      <circle cx={150} cy={180} r={8} fill="#0a0c10" stroke="#59616f" strokeWidth={2} />
      <Outline hl={hl} x={24} y={30} w={170} h={170} r={40} />
    </Svg>
  );
};

/* --- 4. Baterai --- */
const BatteryLayer: React.FC<LayerProps> = ({ hl, uid }) => (
  <Svg>
    <defs>
      <linearGradient id={`${uid}-batt`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#8b94a5" />
        <stop offset="1" stopColor="#566070" />
      </linearGradient>
    </defs>
    <rect x={40} y={306} width={262} height={282} rx={22} fill={`url(#${uid}-batt)`} stroke="#b4bcc9" strokeWidth={2} />
    <line x1={171} y1={318} x2={171} y2={576} stroke="rgba(0,0,0,0.18)" strokeWidth={2} />
    <rect x={64} y={372} width={214} height={132} rx={12} fill="rgba(255,255,255,0.1)" />
    {[400, 430, 460].map((y) => (
      <rect key={y} x={84} y={y} width={174} height={6} rx={3} fill="rgba(255,255,255,0.18)" />
    ))}
    <rect x={140} y={294} width={62} height={16} rx={4} fill={GOLD} />
    <rect x={70} y={560} width={64} height={10} rx={5} fill="#c7cfdb" />
    <rect x={208} y={560} width={64} height={10} rx={5} fill="#c7cfdb" />
    <Outline hl={hl} x={40} y={306} w={262} h={282} r={22} />
  </Svg>
);

/* --- 5. Taptic Engine --- */
const TapticLayer: React.FC<LayerProps> = ({ hl }) => (
  <Svg>
    <rect x={44} y={590} width={108} height={100} rx={16} fill="#252a33" stroke="#5a6372" strokeWidth={2} />
    <rect x={70} y={606} width={56} height={68} rx={10} fill="#8c95a4" />
    <polyline points="56,640 62,628 66,652 70,640" fill="none" stroke={GOLD} strokeWidth={3} strokeLinejoin="round" />
    <polyline points="126,640 130,628 134,652 140,640" fill="none" stroke={GOLD} strokeWidth={3} strokeLinejoin="round" />
    <Outline hl={hl} x={44} y={590} w={108} h={100} r={16} />
  </Svg>
);

/* --- 6. Speaker --- */
const SpeakerLayer: React.FC<LayerProps> = ({ hl }) => {
  const cols = [238, 256, 274, 292];
  const rows = [636, 652, 668, 684];
  return (
    <Svg>
      <rect x={222} y={616} width={92} height={84} rx={16} fill="#252a33" stroke="#5a6372" strokeWidth={2} />
      {rows.flatMap((cy) =>
        cols.map((cx) => (
          <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={3.6} fill="#0a0c10" />
        ))
      )}
      <Outline hl={hl} x={222} y={616} w={92} h={84} r={16} />
    </Svg>
  );
};

/* --- 7. Antena + rangka --- */
const AntennaLayer: React.FC<LayerProps> = ({ hl, uid }) => {
  const ring =
    roundRectPath(4, 4, PW - 8, PH - 8, 52) + roundRectPath(20, 20, PW - 40, PH - 40, 38);
  return (
    <Svg>
      <defs>
        <linearGradient id={`${uid}-ti`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#9aa1ab" />
          <stop offset="0.5" stopColor="#5f6670" />
          <stop offset="1" stopColor="#8a919c" />
        </linearGradient>
      </defs>
      <path d={ring} fillRule="evenodd" fill={`url(#${uid}-ti)`} />
      {/* celah antena di kedua sisi */}
      {[110, 630].flatMap((y) => [
        <rect key={`l${y}`} x={2} y={y} width={22} height={6} fill="#070a12" />,
        <rect key={`r${y}`} x={PW - 24} y={y} width={22} height={6} fill="#070a12" />,
      ])}
      {/* tombol samping */}
      <rect x={0} y={170} width={6} height={36} rx={3} fill="#8a919c" />
      <rect x={0} y={222} width={6} height={36} rx={3} fill="#8a919c" />
      <rect x={PW - 6} y={240} width={6} height={84} rx={3} fill="#8a919c" />
      <Outline hl={hl} x={4} y={4} w={PW - 8} h={PH - 8} r={52} />
    </Svg>
  );
};

/* --- 8. Port USB-C --- */
const UsbLayer: React.FC<LayerProps> = ({ hl }) => (
  <Svg>
    <rect x={120} y={640} width={100} height={62} rx={14} fill="#252a33" stroke="#5a6372" strokeWidth={2} />
    <rect x={136} y={656} width={68} height={30} rx={15} fill="#05070b" stroke="#aab2bf" strokeWidth={2} />
    <rect x={148} y={667} width={44} height={8} rx={4} fill="#7b8494" />
    <Outline hl={hl} x={120} y={640} w={100} h={62} r={14} />
  </Svg>
);

/* --- 9. Casing belakang --- */
const CasingLayer: React.FC<LayerProps> = ({ hl, uid }) => (
  <Svg>
    <defs>
      <linearGradient id={`${uid}-back`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#3b414b" />
        <stop offset="1" stopColor="#20242b" />
      </linearGradient>
    </defs>
    <rect x={2} y={2} width={PW - 4} height={PH - 4} rx={BODY_R - 2} fill={`url(#${uid}-back)`} stroke="#59616f" strokeWidth={3} />
    <rect x={24} y={30} width={170} height={170} rx={40} fill="rgba(255,255,255,0.06)" stroke="rgba(255,255,255,0.18)" strokeWidth={2} />
    {[
      [66, 76],
      [66, 156],
      [142, 116],
    ].map(([cx, cy]) => (
      <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r={38} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth={2} />
    ))}
    <Outline hl={hl} x={2} y={2} w={PW - 4} h={PH - 4} r={BODY_R - 2} />
  </Svg>
);

// Urutan HARUS sama dengan STOPS (depan -> belakang)
const LAYERS: ReadonlyArray<React.FC<LayerProps>> = [
  GlassLayer,
  DisplayLayer,
  LogicBoardLayer,
  CameraLayer,
  BatteryLayer,
  TapticLayer,
  SpeakerLayer,
  AntennaLayer,
  UsbLayer,
  CasingLayer,
];

/* ============================================================
 * 7. CALLOUT (garis penunjuk + judul + keterangan)
 * ============================================================ */
const Callouts: React.FC<{
  frame: number;
  fps: number;
  ax: number;
  ay: number;
}> = ({ frame, fps, ax, ay }) => {
  const [ex, ey] = LINE_END;
  return (
    <>
      {STOPS.map((stop, i) => {
        const t = frame - stopStart(i);
        if (t < 0 || t > STOP_LEN) return null;

        const out = interpolate(t, CALLOUT_OUT, [0, 1], {
          ...CLAMP,
          easing: EASE_SMOOTH,
        });
        const line =
          interpolate(t, LINE_IN, [0, 1], { ...CLAMP, easing: EASE_SMOOTH }) *
          (1 - out);
        const cardIn = spring({
          frame: t - CARD_IN_DELAY,
          fps,
          config: { damping: 200 },
          durationInFrames: 26,
        });
        const card = cardIn * (1 - out);
        const desc =
          interpolate(t, DESC_IN, [0, 1], { ...CLAMP, easing: EASE_SMOOTH }) *
          (1 - out);
        const marker =
          interpolate(t, [10, 24], [0, 1], CLAMP) * (1 - out);
        const pulse = (t % 60) / 60;
        const path = `M ${ax} ${ay} L ${ex - 110} ${ey} L ${ex} ${ey}`;

        return (
          <React.Fragment key={stop.title}>
            <svg
              width={VIDEO_WIDTH}
              height={VIDEO_HEIGHT}
              viewBox={`0 0 ${VIDEO_WIDTH} ${VIDEO_HEIGHT}`}
              style={{ position: 'absolute', left: 0, top: 0 }}
            >
              {line > 0.002 && (
                <>
                  <path
                    d={path}
                    pathLength={1}
                    fill="none"
                    stroke={ACCENT}
                    strokeWidth={9}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeDasharray={1}
                    strokeDashoffset={1 - line}
                    opacity={0.16}
                  />
                  <path
                    d={path}
                    pathLength={1}
                    fill="none"
                    stroke={ACCENT}
                    strokeWidth={3}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeDasharray={1}
                    strokeDashoffset={1 - line}
                  />
                </>
              )}
              <circle cx={ax} cy={ay} r={7} fill={ACCENT} opacity={marker} />
              <circle
                cx={ax}
                cy={ay}
                r={12 + 16 * pulse}
                fill="none"
                stroke={ACCENT}
                strokeWidth={2}
                opacity={0.6 * (1 - pulse) * marker}
              />
              <circle cx={ex} cy={ey} r={6} fill={ACCENT} opacity={line > 0.98 ? 1 : 0} />
            </svg>

            <div
              style={{
                position: 'absolute',
                left: CARD_X,
                top: CARD_Y,
                width: CARD_W,
                boxSizing: 'border-box',
                padding: '28px 36px 34px',
                borderRadius: 28,
                background: 'rgba(8,12,24,0.78)',
                border: '1.5px solid rgba(94,231,255,0.35)',
                boxShadow: '0 24px 70px rgba(0,0,0,0.5)',
                fontFamily: FONT,
                opacity: card,
                transform: `translateX(${(1 - cardIn) * 50 - out * 20}px)`,
              }}
            >
              <div style={{ fontSize: 28, fontWeight: 600, letterSpacing: 4, color: ACCENT }}>
                {`${pad2(i + 1)} / ${pad2(N)}`}
              </div>
              <div
                style={{
                  fontSize: 52,
                  lineHeight: 1.12,
                  fontWeight: 700,
                  color: '#ffffff',
                  marginTop: 10,
                }}
              >
                {stop.title}
              </div>
              <div
                style={{
                  fontSize: 32,
                  lineHeight: 1.4,
                  color: '#cdd6e4',
                  marginTop: 16,
                  opacity: desc,
                }}
              >
                {stop.desc}
              </div>
            </div>
          </React.Fragment>
        );
      })}
    </>
  );
};

/* ============================================================
 * 8. KOMPOSISI UTAMA
 * ============================================================ */
export const Handphone: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // Intro: fade + scale halus; outro: fade out
  const introSpring = spring({
    frame,
    fps,
    config: { damping: 200 },
    durationInFrames: INTRO_SPRING,
  });
  const introScale = lerp(0.86, 1, introSpring);
  const introOpacity = interpolate(frame, [0, INTRO_FADE], [0, 1], {
    ...CLAMP,
    easing: EASE_SMOOTH,
  });
  const outroOpacity = interpolate(
    frame,
    [FADE_OUT_START, DURATION_IN_FRAMES],
    [1, 0],
    { ...CLAMP, easing: EASE_SMOOTH }
  );

  // Progres exploded tiap layer
  const explode = STOPS.map((_, i) => explodeAmount(frame, fps, i));
  const eAvg = explode.reduce((sum, v) => sum + v, 0) / N;

  const cam = getCamera(frame, introScale, eAvg);

  const sceneTransform =
    `translate3d(${cam.tx}px, ${cam.ty}px, 0px) ` +
    `scale(${cam.scale}) ` +
    `rotateX(${cam.rx}deg) rotateY(${cam.ry}deg) ` +
    `translate3d(${-cam.fx}px, ${-cam.fy}px, ${-cam.fz}px)`;

  return (
    <AbsoluteFill
      style={{
        background:
          'radial-gradient(ellipse 80% 70% at 35% 40%, #17213d 0%, #0a0f1f 55%, #04060c 100%)',
      }}
    >
      {/* cahaya lembut */}
      <AbsoluteFill
        style={{
          background:
            'radial-gradient(ellipse 50% 40% at 62% 62%, rgba(94,231,255,0.07), transparent 70%)',
        }}
      />

      <AbsoluteFill style={{ opacity: introOpacity * outroOpacity }}>
        {/* ruang 3D */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: VIDEO_WIDTH,
            height: VIDEO_HEIGHT,
            perspective: `${PERSPECTIVE}px`,
            perspectiveOrigin: '50% 50%',
          }}
        >
          <div
            style={{
              position: 'absolute',
              left: VIDEO_WIDTH / 2,
              top: VIDEO_HEIGHT / 2,
              width: 0,
              height: 0,
              transformStyle: 'preserve-3d',
              transform: sceneTransform,
            }}
          >
            {LAYERS.map((Layer, i) => {
              // d = jarak layer dari bagian yang sedang aktif
              const d = i - cam.pos;
              const tourOpacity = interpolate(
                d,
                [-2, -1, 0, 1, 3, 6],
                [0, 0.1, 1, 0.4, 0.15, 0],
                CLAMP
              );
              const opacity = lerp(1, tourOpacity, cam.mix);
              const hl = Math.max(0, 1 - Math.abs(d)) * cam.mix;
              return (
                <div
                  key={i}
                  style={{
                    position: 'absolute',
                    left: -PW / 2,
                    top: -PH / 2,
                    width: PW,
                    height: PH,
                    opacity,
                    transform: `translateZ(${layerZ(i, explode[i])}px)`,
                  }}
                >
                  <Layer hl={hl} uid={`l${i}`} />
                </div>
              );
            })}
          </div>
        </div>

        {/* callout: ujung garis = titik fokus kamera */}
        <Callouts
          frame={frame}
          fps={fps}
          ax={VIDEO_WIDTH / 2 + cam.tx}
          ay={VIDEO_HEIGHT / 2 + cam.ty}
        />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
