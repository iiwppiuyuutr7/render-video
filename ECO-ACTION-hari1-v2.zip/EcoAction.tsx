/**
 * ECO-ACTION 4 DAYS – Hari Pertama: Audit dan Diagnosa Lingkungan
 * 1920x1080 (16:9) · 60 fps · ±106 detik
 *
 * Isi: pembuka program + 8 klip asli, lalu kartu info (pembagian tugas, fokus Kelompok 5, jadwal,
 * penjelasan Hari 1) dan transisi ke Hari 2. Tanpa narasi.
 * Logo tamanisasi (kiri atas) dan logo SMA 1 Doro (kanan atas) tampil sepanjang video.
 * Backsound turun volumenya setiap ada SFX, lalu naik lagi (ducking).
 *
 * Semua waktu dalam DETIK, diubah ke frame sesuai fps composition (useVideoConfig).
 * Pastikan durationInFrames di Root = ECO_TOTAL_SECONDS x fps.
 *
 * Klip memakai frame rate aslinya (25/26/30/60 fps), tidak dipaksa jadi 30 fps.
 * Aset: public/eco1/clips, public/eco1/sfx, public/eco1/music.mp3, public/eco1/logo-*.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

/* ───────────────────────── konfigurasi ───────────────────────── */
const WITH_MUSIC = true; // false = tanpa backsound (kalau mau dipasang sendiri)

const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const WHITE = '#ffffff';
const BEIGE = '#efe5cf';
const GREEN = '#9fcf86';
const DEEP = '#0f2e1c';

const OVERLAP_S = 0.5; // durasi dissolve antar klip

/* ───────────────────────── urutan klip (detik) ───────────────────────── */
type Seg = {id: string; src: string; sec: number; zoom: 'in' | 'out'};

const SEGS: Seg[] = [
  {id: 'a', src: 'a-opening', sec: 8.0, zoom: 'in'},
  {id: 'b', src: 'b-lingkungan', sec: 6.5, zoom: 'in'},
  {id: 'c', src: 'c-audit-pohon', sec: 9.0, zoom: 'out'},
  {id: 'd', src: 'd-audit-lahan', sec: 7.4, zoom: 'in'},
  {id: 'e', src: 'e-analisis', sec: 12.0, zoom: 'in'},
  {id: 'f', src: 'f-diskusi', sec: 12.0, zoom: 'out'},
  {id: 'g', src: 'g-perencanaan', sec: 9.2, zoom: 'in'},
  {id: 'h', src: 'h-closing', sec: 5.8667, zoom: 'out'},
];

const START_S: Record<string, number> = {};
let acc = 0;
SEGS.forEach((s, i) => {
  const st = i === 0 ? 0 : acc - OVERLAP_S;
  START_S[s.id] = st;
  acc = st + s.sec;
});
const VIDEO_END_S = acc; // klip terakhir selesai di ±66,47 detik

/* ───────────────────────── kartu info (setelah klip) ───────────────────────── */
const CARDS_START_S = VIDEO_END_S - OVERLAP_S; // latar kartu masuk dissolve di atas klip terakhir
const C0 = VIDEO_END_S + 0.2;
const CARD = {
  tugas: {start: C0, end: C0 + 8.2},
  fokus: {start: C0 + 8.3, end: C0 + 15.3},
  jadwal: {start: C0 + 15.4, end: C0 + 25.4},
  jelas: {start: C0 + 25.5, end: C0 + 35.5},
  next: {start: C0 + 35.6, end: C0 + 39.2},
};
export const ECO_TOTAL_SECONDS = CARD.next.end; // ±105,9 detik

/* ───────────────────────── util ───────────────────────── */
const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const useFr = () => {
  const {fps} = useVideoConfig();
  return (s: number) => Math.round(s * fps);
};

const fadeWindow = (f: number, dur: number, fi: number, fo: number) =>
  interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], clampOpts);

const rise = (f: number, delay: number, len: number, dist: number) =>
  interpolate(f, [delay, delay + len], [dist, 0], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });

const shadow = '0 3px 24px rgba(0,0,0,0.38)';

/* ───────────────────────── klip video ───────────────────────── */
// Color grading ringan: sedikit hangat, saturasi hijau natural, kontras seimbang.
const GRADE = 'saturate(1.12) contrast(1.05) brightness(0.98) sepia(0.10)';

// Jenis transisi masuk tiap klip (selama OVERLAP_S): dissolve, zoom-through, push, iris.
type Enter = 'fade' | 'dissolve' | 'zoom' | 'push' | 'iris';
const ENTER: Record<string, Enter> = {
  a: 'fade',
  b: 'iris',
  c: 'zoom',
  d: 'dissolve',
  e: 'push',
  f: 'zoom',
  g: 'iris',
  h: 'dissolve',
};

const VideoSeg: React.FC<{seg: Seg; index: number}> = ({seg, index}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const dur = fr(seg.sec);
  const kind = ENTER[seg.id];
  const inLen = index === 0 ? fr(0.8) : fr(OVERLAP_S);
  const t = interpolate(f, [0, inLen], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const scale =
    seg.zoom === 'in'
      ? interpolate(f, [0, dur], [1.0, 1.045], clampOpts)
      : interpolate(f, [0, dur], [1.045, 1.0], clampOpts);

  let opacity = 1;
  let wrapTransform = 'none';
  let wrapFilter = 'none';
  let clip = 'none';
  if (kind === 'fade' || kind === 'dissolve') {
    opacity = t;
  } else if (kind === 'zoom') {
    opacity = Math.min(1, t * 1.6);
    wrapTransform = `scale(${1 + 0.2 * (1 - t)})`;
    wrapFilter = `blur(${(1 - t) * 10}px)`;
  } else if (kind === 'push') {
    wrapTransform = `translateX(${(1 - t) * 1920}px)`;
    wrapFilter = `blur(${Math.sin(Math.PI * t) * 9}px)`;
  } else if (kind === 'iris') {
    clip = `circle(${t * 75}% at 50% 50%)`;
  }
  return (
    <AbsoluteFill style={{opacity, transform: wrapTransform, filter: wrapFilter, clipPath: clip}}>
      <OffthreadVideo
        src={staticFile(`eco1/clips/${seg.src}.mp4`)}
        volume={0}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${scale})`,
          filter: GRADE,
        }}
      />
    </AbsoluteFill>
  );
};

/* ───────────────────────── teks ───────────────────────── */
const Pill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 28,
      color: WHITE,
      padding: '8px 24px',
      borderRadius: 999,
      border: '2px solid rgba(255,255,255,0.7)',
      background: 'rgba(255,255,255,0.12)',
      textShadow: shadow,
    }}
  >
    {children}
  </div>
);

// Judul bagian di kiri bawah, dengan scrim gradasi halus di bawahnya. start/end dalam detik.
const LowerThird: React.FC<{
  start: number;
  end: number;
  title: string;
  sub: string;
  extra?: string;
}> = ({start, end, title, sub, extra}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <LowerThirdInner dur={fr(end) - fr(start)} title={title} sub={sub} extra={extra} />
    </Sequence>
  );
};

const LowerThirdInner: React.FC<{dur: number; title: string; sub: string; extra?: string}> = ({
  dur,
  title,
  sub,
  extra,
}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = fadeWindow(f, dur, fr(0.47), fr(0.4));
  const bar = interpolate(f, [0, fr(0.67)], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: op,
          background:
            'linear-gradient(to top, rgba(6,22,11,0.70) 0%, rgba(6,22,11,0.38) 28%, rgba(6,22,11,0) 52%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 120,
          display: 'flex',
          gap: 30,
          alignItems: 'stretch',
          opacity: op,
        }}
      >
        <div
          style={{
            width: 7,
            borderRadius: 4,
            background: GREEN,
            transform: `scaleY(${bar})`,
            transformOrigin: 'bottom',
          }}
        />
        <div style={{transform: `translateY(${rise(f, 0, fr(0.53), 18)}px)`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 68,
              lineHeight: 1.12,
              color: WHITE,
              textShadow: shadow,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 36,
              marginTop: 14,
              color: BEIGE,
              textShadow: shadow,
              transform: `translateY(${rise(f, fr(0.2), fr(0.53), 12)}px)`,
            }}
          >
            {sub}
          </div>
          {extra ? (
            <div style={{marginTop: 26, display: 'flex'}}>
              <Pill>{extra}</Pill>
            </div>
          ) : null}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Panel teks di tengah layar (opening). start/end dalam detik.
const CenterPanel: React.FC<{start: number; end: number; children: React.ReactNode}> = ({
  start,
  end,
  children,
}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <CenterInner dur={fr(end) - fr(start)}>{children}</CenterInner>
    </Sequence>
  );
};

const CenterInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, fr(0.6), fr(0.47)),
        transform: `translateY(${rise(f, 0, fr(0.53), 22)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const Line: React.FC<{
  size: number;
  weight: 600 | 800;
  color: string;
  mt?: number;
  spacing?: number;
  children: React.ReactNode;
}> = ({size, weight, color, mt = 0, spacing = 0, children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: weight,
      fontSize: size,
      color,
      marginTop: mt,
      letterSpacing: spacing,
      lineHeight: 1.15,
      textShadow: shadow,
      maxWidth: 1500,
    }}
  >
    {children}
  </div>
);

const Rule: React.FC<{width?: number}> = ({width = 220}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const w = interpolate(f, [fr(0.27), fr(1.13)], [0, width], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });
  return <div style={{height: 5, width: w, borderRadius: 3, background: GREEN, marginTop: 30}} />;
};

// Peredup lembut agar teks putih terbaca di atas footage terang. start/end dalam detik.
const Dim: React.FC<{start: number; end: number; strength: number}> = ({start, end, strength}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <DimInner dur={fr(end) - fr(start)} strength={strength} />
    </Sequence>
  );
};
const DimInner: React.FC<{dur: number; strength: number}> = ({dur, strength}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        background: `rgba(8,26,14,${strength})`,
        opacity: interpolate(f, [0, fr(0.73), dur - fr(0.73), dur], [0, 1, 1, 0], clampOpts),
      }}
    />
  );
};

// Kilau halus saat judul muncul (sinkron dengan efek kamera flash). at dalam detik.
const SoftFlash: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const a = fr(at);
  const o = interpolate(f, [a, a + fr(0.1), a + fr(0.47)], [0, 0.1, 0], clampOpts);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

/* ───────────────────────── latar kartu, logo, komponen kartu ───────────────────────── */
const CardsBg: React.FC = () => {
  const fr = useFr();
  return (
    <Sequence from={fr(CARDS_START_S)} durationInFrames={fr(ECO_TOTAL_SECONDS) - fr(CARDS_START_S)}>
      <CardsBgInner />
    </Sequence>
  );
};
const CardsBgInner: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(f, [0, fr(OVERLAP_S)], [0, 1], clampOpts),
        background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)',
      }}
    />
  );
};

// Logo kecil di pojok atas, tampil sepanjang video.
const Logos: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = interpolate(f, [fr(0.8), fr(1.6)], [0, 0.96], clampOpts);
  const base: React.CSSProperties = {
    position: 'absolute',
    top: 44,
    height: 96,
    opacity: op,
    filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.45))',
  };
  return (
    <AbsoluteFill>
      <Img src={staticFile('eco1/logo-taman.svg')} style={{...base, left: 56}} />
      <Img src={staticFile('eco1/logo-sma.png')} style={{...base, right: 56}} />
    </AbsoluteFill>
  );
};

// Muncul bertahap di dalam CenterPanel (waktu lokal sequence).
const Stagger: React.FC<{i: number; step?: number; children: React.ReactNode}> = ({i, step = 0.25, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const d = fr(0.7 + i * step);
  return (
    <div
      style={{
        opacity: interpolate(f, [d, d + fr(0.45)], [0, 1], clampOpts),
        transform: `translateY(${rise(f, d, fr(0.45), 14)}px)`,
      }}
    >
      {children}
    </div>
  );
};

const SCHED_L: [string, string][] = [
  ['07.00–07.20', 'Pembukaan'],
  ['07.20–07.40', 'Kedatangan, Presensi, dan Pengondisian'],
  ['07.40–08.00', 'Orientasi Proyek dan K3'],
  ['08.00–09.30', 'Audit Lingkungan Sekolah'],
  ['09.30–09.45', 'Istirahat'],
  ['09.45–10.45', 'Analisis Hasil Audit'],
];
const SCHED_R: [string, string][] = [
  ['10.45–11.30', 'Diskusi dan Brainstorming'],
  ['11.30–11.45', 'Presentasi Awal Kelompok'],
  ['11.45–12.30', 'ISHOMA'],
  ['12.30–13.30', 'Penyusunan Rencana Kerja'],
  ['13.30–13.50', 'Konsultasi dan Validasi Guru'],
  ['13.50–14.00', 'Penutup dan Tindak Lanjut'],
];

// Jadwal bergaya timeline: garis vertikal hijau dengan titik di tiap sesi.
const SchedCol: React.FC<{rows: [string, string][]; offset: number}> = ({rows, offset}) => (
  <div style={{position: 'relative', paddingLeft: 38}}>
    <div style={{position: 'absolute', left: 8, top: 18, bottom: 18, width: 3, borderRadius: 2, background: 'rgba(159,207,134,0.45)'}} />
    {rows.map(([t, n], i) => (
      <Stagger key={t} i={i + offset} step={0.2}>
        <div style={{position: 'relative', padding: '10px 0'}}>
          <div style={{position: 'absolute', left: -38, top: 26, width: 19, height: 19, borderRadius: 10, background: GREEN, boxShadow: '0 0 0 5px rgba(159,207,134,0.22)'}} />
          <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 27, color: GREEN, textShadow: shadow}}>{t}</div>
          <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 33, color: WHITE, textShadow: shadow, marginTop: 2}}>{n}</div>
        </div>
      </Stagger>
    ))}
  </div>
);

const GROUPS: {no: number; name: string; desc: string}[] = [
  {no: 1, name: 'Desain Taman', desc: 'Audit lokasi, pengukuran area, dan rancangan tata letak taman.'},
  {no: 2, name: 'Jenis Tanaman', desc: 'Memilih tanaman sesuai kondisi lokasi dan kebutuhan tumbuh.'},
  {no: 3, name: 'Eksekusi', desc: 'Mengidentifikasi kebutuhan alat, bahan, kondisi lahan, dan urutan kerja.'},
  {no: 4, name: 'Pemeliharaan dan Perawatan', desc: 'Mengidentifikasi kebutuhan penyiraman, kebersihan, pemantauan, dan jadwal piket.'},
  {no: 5, name: 'Video Kampanye', desc: 'Menentukan sasaran audiens, tema, pesan utama, dan konsep atau storyboard awal.'},
  {no: 6, name: 'Penanaman TOGA', desc: 'Memilih jenis TOGA, lokasi, kebutuhan media, dan informasi edukatif.'},
];
const K5_TASKS = [
  'Menentukan target audiens kampanye',
  'Menentukan tema kampanye',
  'Menentukan pesan utama',
  'Membuat konsep awal video kampanye',
  'Menyusun storyboard sebagai persiapan produksi media kampanye',
];
const GOALS = [
  'Mengamati kondisi lingkungan sekolah',
  'Mengidentifikasi permasalahan lingkungan',
  'Menganalisis kondisi vegetasi, tanah, dan area kosong',
  'Merumuskan masalah prioritas',
  'Mengembangkan ide dan solusi tamanisasi',
  'Menyusun konsep dan rencana aksi untuk hari berikutnya',
];

// Transisi ke Hari 2: angka 1 bergulir menjadi 2 di dalam lingkaran, lalu panel memudar.
const NextDay: React.FC<{dur: number}> = ({dur}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const roll = interpolate(f, [fr(1.0), fr(1.8)], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const ring = interpolate(f, [fr(0.2), fr(1.6)], [0.6, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  const out = interpolate(f, [dur - fr(0.6), dur], [1, 0], clampOpts);
  const inn = interpolate(f, [0, fr(0.5)], [0, 1], clampOpts);
  const digit: React.CSSProperties = {
    fontFamily: FONT,
    fontWeight: 800,
    fontSize: 230,
    lineHeight: '250px',
    height: 250,
    color: WHITE,
    textAlign: 'center',
    textShadow: shadow,
  };
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: inn * out}}>
      <Line size={42} weight={600} color={BEIGE}>
        Selanjutnya
      </Line>
      <div style={{display: 'flex', alignItems: 'center', gap: 48, marginTop: 26}}>
        <Line size={130} weight={800} color={WHITE} spacing={2}>
          Hari
        </Line>
        <div
          style={{
            width: 280,
            height: 280,
            borderRadius: 140,
            border: `6px solid ${GREEN}`,
            background: 'rgba(159,207,134,0.12)',
            transform: `scale(${ring})`,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-start',
            overflow: 'hidden',
            paddingTop: 15,
            boxSizing: 'border-box',
          }}
        >
          <div style={{width: 280, transform: `translateY(${-roll * 250}px)`}}>
            <div style={digit}>1</div>
            <div style={digit}>2</div>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

/* ───────────────────────── audio ───────────────────────── */
// Daftar SFX: dipakai untuk memutar suara DAN untuk menurunkan volume backsound (ducking).
type SfxItem = {file: 'flash' | 'pop' | 'whoosh' | 'transition' | 'click'; at: number; vol: number};
const SFX_LEN = {flash: 1.2, pop: 0.45, whoosh: 1.2, transition: 0.4, click: 0.37};

const S0 = START_S;
const SECTION_STARTS = [S0.b, S0.c, S0.e, S0.f, S0.g]; // awal tiap bagian baru
const TITLE_AT = SECTION_STARTS.map((s) => s + 0.67);
const SFX: SfxItem[] = [
  {file: 'flash', at: 0.6, vol: 0.4},
  {file: 'pop', at: 4.57, vol: 0.45},
  ...SECTION_STARTS.map((s) => ({file: 'whoosh' as const, at: s - 0.4, vol: 0.3})),
  {file: 'transition', at: S0.d, vol: 0.35},
  {file: 'transition', at: S0.h, vol: 0.35},
  ...TITLE_AT.map((t) => ({file: 'click' as const, at: t + 0.1, vol: 0.4})),
  {file: 'whoosh', at: CARDS_START_S - 0.3, vol: 0.3},
  {file: 'click', at: CARD.tugas.start + 0.1, vol: 0.4},
  {file: 'click', at: CARD.fokus.start + 0.1, vol: 0.4},
  {file: 'click', at: CARD.jadwal.start + 0.1, vol: 0.4},
  {file: 'click', at: CARD.jelas.start + 0.1, vol: 0.4},
  {file: 'whoosh', at: CARD.next.start + 0.35, vol: 0.35},
  {file: 'transition', at: CARD.next.start + 1.35, vol: 0.4},
];

const MUSIC_BASE = 0.3; // volume normal backsound
const MUSIC_DUCK = 0.38; // dikali ini saat ada SFX (turun), lalu naik lagi
const duckAt = (t: number) => {
  let g = 1;
  for (const s of SFX) {
    const a = s.at - 0.12; // mulai turun sedikit sebelum SFX
    const h = s.at + SFX_LEN[s.file]; // SFX selesai
    let v = 1;
    if (t >= a && t < a + 0.12) v = 1 - (1 - MUSIC_DUCK) * ((t - a) / 0.12);
    else if (t >= a + 0.12 && t < h) v = MUSIC_DUCK;
    else if (t >= h && t < h + 0.8) {
      const k = (t - h) / 0.8;
      v = MUSIC_DUCK + (1 - MUSIC_DUCK) * (k * k * (3 - 2 * k));
    }
    if (v < g) g = v;
  }
  return g;
};

const Sfx: React.FC<{file: string; at: number; vol?: number}> = ({file, at, vol = 0.5}) => {
  const fr = useFr();
  return (
    <Sequence from={Math.max(0, fr(at))}>
      <Audio src={staticFile(`eco1/sfx/${file}.mp3`)} volume={vol} />
    </Sequence>
  );
};

/* ───────────────────────── komposisi ───────────────────────── */
export const EcoAction: React.FC = () => {
  const {fps} = useVideoConfig();
  const S = START_S;
  const OPEN_END = S.b + 0.27;
  const TITLE_LEN = 4.0;

  // Backsound: naik dari pelan di awal, lalu stabil; turun setiap ada SFX. Tidak ada fade-out
  // (video disambung ke hari kedua; Hari 2 melanjutkan musik dari detik yang sama).
  const musicVolume = (f: number) => {
    const t = f / fps;
    return interpolate(t, [0, 3], [0, MUSIC_BASE], clampOpts) * duckAt(t);
  };

  return (
    <AbsoluteFill style={{backgroundColor: DEEP}}>
      {/* ── video (urut, transisi bervariasi) ── */}
      {SEGS.map((seg, i) => (
        <Sequence
          key={seg.id}
          from={Math.round(START_S[seg.id] * fps)}
          durationInFrames={Math.round(seg.sec * fps)}
        >
          <VideoSeg seg={seg} index={i} />
        </Sequence>
      ))}

      {/* vignette tipis di seluruh video */}
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(8,24,12,0.34) 100%)',
        }}
      />

      {/* ── 1. OPENING ── */}
      <Dim start={0} end={OPEN_END} strength={0.32} />
      <CenterPanel start={0.67} end={4.5}>
        <Line size={128} weight={800} color={WHITE} spacing={4}>
          ECO-ACTION 4 DAYS
        </Line>
        <Rule />
        <Line size={40} weight={600} color={BEIGE} mt={30}>
          Aksi Nyata Pelajar Hijau untuk Sekolah Asri dan Berkelanjutan
        </Line>
      </CenterPanel>
      <CenterPanel start={4.57} end={OPEN_END}>
        <Line size={58} weight={800} color={WHITE}>
          Kokurikuler Gaya Hidup Berkelanjutan
        </Line>
        <Line size={40} weight={600} color={BEIGE} mt={16}>
          Hari Pertama: Audit dan Diagnosa Lingkungan
        </Line>
        <div style={{display: 'flex', gap: 18, marginTop: 40}}>
          <Pill>Kelas X E7</Pill>
          <Pill>Kelompok 5 — Video Kampanye</Pill>
        </div>
      </CenterPanel>
      <SoftFlash at={0.6} />

      {/* ── 2. PENGENALAN LINGKUNGAN SEKOLAH ── */}
      <LowerThird
        start={TITLE_AT[0]}
        end={TITLE_AT[0] + TITLE_LEN}
        title="Mengenali Lingkungan di Sekitar Kita"
        sub="Setiap Perubahan Dimulai dari Kepedulian"
      />

      {/* ── 3. AUDIT DAN OBSERVASI LINGKUNGAN ── */}
      <LowerThird
        start={TITLE_AT[1]}
        end={TITLE_AT[1] + TITLE_LEN}
        title="Audit dan Diagnosa Lingkungan"
        sub="Mengamati, Mengidentifikasi, dan Memahami"
      />

      {/* ── 4. ANALISIS PERMASALAHAN LINGKUNGAN ── */}
      <LowerThird
        start={TITLE_AT[2]}
        end={TITLE_AT[2] + TITLE_LEN}
        title="Memahami Permasalahan Lingkungan"
        sub="Menemukan Potensi, Menentukan Prioritas"
      />

      {/* ── 5. DISKUSI DAN BRAINSTORMING ── */}
      <LowerThird
        start={TITLE_AT[3]}
        end={TITLE_AT[3] + TITLE_LEN}
        title="Discover & Brainstorm"
        sub="Merancang Solusi untuk Lingkungan yang Lebih Baik"
      />

      {/* ── 6. PERENCANAAN AKSI TAMANISASI ── */}
      <LowerThird
        start={TITLE_AT[4]}
        end={TITLE_AT[4] + TITLE_LEN}
        title="Dari Pengamatan Menuju Perencanaan"
        sub="Merancang Aksi Nyata Pelajar Hijau"
        extra="Kelompok 5 — Video Kampanye"
      />

      {/* ── KARTU INFO (setelah klip) ── */}
      <CardsBg />

      {/* Pembagian tugas kelompok */}
      <CenterPanel start={CARD.tugas.start} end={CARD.tugas.end}>
        <Line size={62} weight={800} color={WHITE}>
          Pembagian Tugas Kelompok
        </Line>
        <Rule />
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 540px)', gap: 26, marginTop: 40, textAlign: 'left'}}>
          {GROUPS.map((g, i) => (
            <Stagger key={g.no} i={i} step={0.2}>
              <div
                style={{
                  height: '100%',
                  boxSizing: 'border-box',
                  padding: '22px 26px',
                  borderRadius: 20,
                  border: g.no === 5 ? `3px solid ${GREEN}` : '2px solid rgba(239,229,207,0.35)',
                  background: g.no === 5 ? 'rgba(159,207,134,0.16)' : 'rgba(255,255,255,0.06)',
                }}
              >
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 28, color: GREEN}}>Kelompok {g.no}</div>
                <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 38, color: WHITE, marginTop: 4, lineHeight: 1.15}}>{g.name}</div>
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 27, color: BEIGE, marginTop: 10, lineHeight: 1.3}}>
                  {g.desc}
                </div>
              </div>
            </Stagger>
          ))}
        </div>
      </CenterPanel>

      {/* Fokus Kelompok 5 */}
      <CenterPanel start={CARD.fokus.start} end={CARD.fokus.end}>
        <Line size={62} weight={800} color={WHITE}>
          Fokus Kelompok 5 — Video Kampanye
        </Line>
        <Rule />
        <Line size={38} weight={600} color={BEIGE} mt={26}>
          Aktivitas Kelompok 5 pada Hari Pertama
        </Line>
        <div style={{marginTop: 28, textAlign: 'left'}}>
          {K5_TASKS.map((t, i) => (
            <Stagger key={t} i={i} step={0.3}>
              <div style={{display: 'flex', gap: 24, alignItems: 'baseline', padding: '9px 0'}}>
                <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 38, color: GREEN, width: 40}}>{i + 1}</div>
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 38, color: WHITE, textShadow: shadow}}>{t}</div>
              </div>
            </Stagger>
          ))}
        </div>
      </CenterPanel>

      {/* Jadwal Hari 1 */}
      <CenterPanel start={CARD.jadwal.start} end={CARD.jadwal.end}>
        <Line size={62} weight={800} color={WHITE}>
          Jadwal Kegiatan Hari Pertama
        </Line>
        <Rule />
        <div style={{display: 'flex', gap: 70, marginTop: 34, textAlign: 'left'}}>
          <SchedCol rows={SCHED_L} offset={0} />
          <SchedCol rows={SCHED_R} offset={SCHED_L.length} />
        </div>
      </CenterPanel>

      {/* Penjelasan Hari 1 */}
      <CenterPanel start={CARD.jelas.start} end={CARD.jelas.end}>
        <Line size={60} weight={800} color={WHITE}>
          Apa yang Dikerjakan di Hari Pertama
        </Line>
        <Rule />
        <Line size={38} weight={600} color={BEIGE} mt={24}>
          Tahap Discover &amp; Brainstorm: audit dan diagnosa lingkungan sekolah
        </Line>
        <div style={{marginTop: 26, textAlign: 'left'}}>
          {GOALS.map((t, i) => (
            <Stagger key={t} i={i} step={0.3}>
              <div style={{display: 'flex', gap: 22, alignItems: 'baseline', padding: '7px 0'}}>
                <div style={{width: 14, height: 14, borderRadius: 7, background: GREEN, flex: 'none', transform: 'translateY(-4px)'}} />
                <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 35, color: WHITE, textShadow: shadow}}>{t}</div>
              </div>
            </Stagger>
          ))}
        </div>
        <Line size={30} weight={600} color={BEIGE} mt={26}>
          Hari pertama adalah tahap pengamatan dan perencanaan, bukan pelaksanaan penanaman.
        </Line>
      </CenterPanel>

      {/* Transisi ke Hari 2 */}
      <Sequence from={Math.round(CARD.next.start * fps)} durationInFrames={Math.round((CARD.next.end - CARD.next.start) * fps)}>
        <NextDay dur={Math.round((CARD.next.end - CARD.next.start) * fps)} />
      </Sequence>

      {/* logo kecil di pojok atas, sepanjang video */}
      <Logos />

      {/* ── AUDIO ── */}
      {WITH_MUSIC ? <Audio src={staticFile('eco1/music.mp3')} volume={musicVolume} /> : null}
      {SFX.map((x, i) => (
        <Sfx key={i} file={x.file} at={x.at} vol={x.vol} />
      ))}
    </AbsoluteFill>
  );
};
