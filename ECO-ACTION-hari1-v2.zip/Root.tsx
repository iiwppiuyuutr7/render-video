import React from 'react';
import {Composition} from 'remotion';
import {EcoAction, ECO_TOTAL_SECONDS} from './EcoAction';

const FPS = 60;

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EcoAction"
    component={EcoAction}
    durationInFrames={Math.round(ECO_TOTAL_SECONDS * FPS)}
    fps={FPS}
    width={1920}
    height={1080}
  />
);
