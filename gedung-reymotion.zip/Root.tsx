import React from 'react';
import {Composition} from 'remotion';
import {Gedung, FPS, WIDTH, HEIGHT, TOTAL_FRAMES} from './Gedung';
export const RemotionRoot: React.FC = () => (
  <Composition id="Gedung" component={Gedung} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
