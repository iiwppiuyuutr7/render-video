Taruh Gedung.tsx & Root.tsx di src/ (ganti Root.tsx lama), folder public/ digabung ke public/ proyekmu.
Butuh: remotion, @remotion/google-fonts   (npm i remotion @remotion/google-fonts)
Preview : npx remotion studio   (composition id: Gedung)
Render  : npx remotion render Gedung out/gedung.mp4
1080x1920 (9:16) · 60 fps · 94 detik (5640 frame). Narasi: public/narration.mp3. Watermark @semestakita kiri bawah (komponen Watermark).
Sinkron kata: array WORDS di Gedung.tsx ([kata, mulai, selesai] dalam detik) - semua visual & caption mengikuti W('kata', urutanKe).
Efek suara: array SFX di bagian bawah Gedung.tsx, file di public/sfx (flash, pop, whoosh, trans, click). Volume: SFX_VOL / SFX_GAIN.
