/**
 * "Mengapa Gedung Tinggi Bisa Bergoyang Tanpa Rusak?"
 * 1080x1920 (9:16) · 60 fps · 94 detik (5640 frame)
 * Audio: public/narration.mp3 (voiceover) + public/sfx/*.mp3 (efek suara, diatur di bagian SFX paling bawah)
 * Semua waktu di file ini dalam DETIK pada audio narasi.
 * Watermark "@semestakita" di kiri bawah (komponen Watermark, bagian paling bawah).
 */
import React, {createContext, useContext} from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Sequence,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadCaveat} from '@remotion/google-fonts/Caveat';

/* ───────────────────────── konfigurasi ───────────────────────── */
const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const caveat = loadCaveat('normal', {weights: ['700'], subsets: ['latin']}).fontFamily;

export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const TOTAL_SECONDS = 94;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SECONDS * FPS);

const OUT = '#2a1a2c';
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;
const HAND = `${caveat}, 'Segoe Script', 'Comic Sans MS', cursive`;

/* ───────────────── timestamp kata [kata, mulai, selesai] ─────────────────
 * Hasil alignment narasi (public/narration.mp3). Kalau ada kata yang terasa
 * meleset, cukup ubah angka mulai/selesainya di sini - semua visual & caption
 * mengikuti lewat W('kata', urutanKe).
 */
const WORDS: Array<[string, number, number]> = [
  ["Gedung", 0.00, 0.36],
  ["pencakar", 0.36, 0.85],
  ["langit", 0.85, 1.21],
  ["tidak", 1.36, 1.70],
  ["selalu", 1.70, 2.17],
  ["benar-benar", 2.17, 2.76],
  ["diam.", 2.76, 3.10],
  ["Saat", 3.51, 3.81],
  ["terkena", 3.81, 4.24],
  ["angin", 4.24, 4.54],
  ["kencang", 4.54, 4.84],
  ["atau", 4.84, 5.26],
  ["getaran", 5.26, 5.69],
  ["gempa,", 5.69, 5.99],
  ["bagian", 6.27, 6.70],
  ["atas", 6.70, 7.00],
  ["gedung", 7.00, 7.31],
  ["bisa", 7.31, 7.62],
  ["bergerak", 7.62, 8.04],
  ["sedikit.", 8.04, 8.47],
  ["Gerakan", 9.04, 9.46],
  ["ini", 9.46, 9.77],
  ["sudah", 9.77, 10.07],
  ["diperhitungkan", 10.07, 10.73],
  ["sejak", 10.73, 11.03],
  ["tahap", 11.03, 11.34],
  ["desain,", 11.34, 11.76],
  ["dan", 12.02, 12.23],
  ["gedung", 12.23, 12.56],
  ["yang", 12.56, 12.77],
  ["sedikit", 12.77, 13.23],
  ["bergoyang", 13.23, 13.70],
  ["bukan", 13.70, 14.03],
  ["berarti", 14.03, 14.50],
  ["akan", 14.50, 14.83],
  ["runtuh.", 14.83, 15.17],
  ["Justru", 15.60, 15.82],
  ["kemampuan", 15.82, 16.22],
  ["bergerak", 16.40, 16.89],
  ["secara", 16.89, 17.38],
  ["terkendali", 17.38, 18.00],
  ["adalah", 18.00, 18.49],
  ["bagian", 18.49, 18.98],
  ["penting", 18.98, 19.34],
  ["dari", 19.34, 19.69],
  ["keselamatan", 19.69, 20.45],
  ["bangunan.", 20.45, 20.94],
  ["Penyebab", 21.33, 21.77],
  ["utamanya", 21.77, 22.34],
  ["adalah", 22.34, 22.78],
  ["angin,", 22.78, 23.10],
  ["getaran", 23.34, 23.88],
  ["gempa,", 23.88, 24.27],
  ["dan", 24.43, 24.61],
  ["gerakan", 24.61, 25.03],
  ["udara", 25.03, 25.44],
  ["di", 25.44, 25.62],
  ["sekitar", 25.62, 26.03],
  ["gedung.", 26.03, 26.33],
  ["Semakin", 26.72, 27.22],
  ["tinggi", 27.22, 27.59],
  ["gedungnya,", 27.59, 28.09],
  ["semakin", 28.31, 28.76],
  ["besar", 28.76, 29.09],
  ["pengaruh", 29.09, 29.54],
  ["angin", 29.54, 29.86],
  ["di", 29.86, 30.06],
  ["bagian", 30.06, 30.51],
  ["atas.", 30.51, 30.84],
  ["Karena", 31.15, 31.54],
  ["itu,", 31.54, 31.83],
  ["insinyur", 32.07, 32.57],
  ["menyeimbangkan", 32.57, 33.35],
  ["tiga", 33.35, 33.71],
  ["hal:", 33.71, 33.93],
  ["kekakuan,", 34.31, 35.04],
  ["massa,", 35.34, 35.82],
  ["dan", 35.82, 36.11],
  ["peredaman.", 36.11, 36.95],
  ["Terlalu", 37.32, 37.73],
  ["kaku", 37.73, 38.03],
  ["membuat", 38.03, 38.44],
  ["desain", 38.44, 38.86],
  ["tidak", 38.86, 39.15],
  ["efisien,", 39.15, 39.68],
  ["sedangkan", 40.00, 40.49],
  ["terlalu", 40.49, 40.98],
  ["fleksibel", 40.98, 41.47],
  ["membuat", 41.66, 42.12],
  ["gerakan", 42.12, 42.58],
  ["berlebihan", 42.58, 43.17],
  ["dan", 43.17, 43.38],
  ["mengganggu", 43.38, 43.84],
  ["kenyamanan", 43.84, 44.43],
  ["penghuni.", 44.43, 44.89],
  ["Untuk", 45.32, 45.65],
  ["meredam", 45.65, 46.12],
  ["getaran,", 46.12, 46.58],
  ["gedung", 46.77, 47.14],
  ["dipasangi", 47.14, 47.78],
  ["damper.", 47.78, 48.15],
  ["Salah", 48.55, 48.93],
  ["satu", 48.93, 49.31],
  ["jenisnya", 49.31, 49.84],
  ["adalah", 49.84, 50.37],
  ["Tuned", 50.37, 50.75],
  ["Mass", 50.75, 50.99],
  ["Damper,", 50.99, 51.37],
  ["yaitu", 51.68, 52.14],
  ["massa", 52.14, 52.47],
  ["tambahan", 52.47, 52.92],
  ["yang", 52.92, 53.12],
  ["bergerak", 53.12, 53.58],
  ["melawan", 53.58, 54.04],
  ["arah", 54.04, 54.36],
  ["ayunan", 54.36, 54.82],
  ["gedung.", 54.82, 55.15],
  ["Contohnya", 55.50, 55.96],
  ["Taipei", 55.96, 56.55],
  ["101", 56.55, 57.19],
  ["di", 57.19, 57.39],
  ["Taiwan,", 57.39, 57.85],
  ["yang", 58.04, 58.26],
  ["menggantung", 58.26, 58.75],
  ["bola", 58.75, 59.11],
  ["baja", 59.11, 59.46],
  ["raksasa", 59.46, 59.95],
  ["seberat", 59.95, 60.44],
  ["sekitar", 60.44, 60.94],
  ["660", 60.94, 61.62],
  ["ton", 61.62, 61.84],
  ["di", 61.84, 62.06],
  ["bagian", 62.06, 62.55],
  ["atasnya.", 62.55, 63.04],
  ["Saat", 63.43, 63.73],
  ["gedung", 63.73, 64.02],
  ["bergoyang", 64.02, 64.43],
  ["ke", 64.43, 64.62],
  ["satu", 64.62, 64.91],
  ["arah,", 64.91, 65.21],
  ["bola", 65.50, 65.83],
  ["itu", 65.83, 66.16],
  ["bergerak", 66.16, 66.62],
  ["ke", 66.62, 66.82],
  ["arah", 66.82, 67.15],
  ["berlawanan", 67.15, 67.73],
  ["sehingga", 67.73, 68.19],
  ["ayunannya", 68.19, 68.77],
  ["berkurang.", 68.77, 69.23],
  ["Penghuni", 69.57, 70.00],
  ["lantai", 70.00, 70.43],
  ["atas", 70.43, 70.74],
  ["kadang", 70.74, 71.05],
  ["masih", 71.05, 71.37],
  ["bisa", 71.37, 71.68],
  ["merasakan", 71.68, 72.23],
  ["goyangan", 72.23, 72.66],
  ["akibat", 72.66, 73.09],
  ["angin.", 73.09, 73.40],
  ["Gedung", 73.66, 74.01],
  ["bisa", 74.01, 74.37],
  ["aman", 74.37, 74.72],
  ["secara", 74.72, 75.21],
  ["struktur,", 75.21, 75.56],
  ["tetapi", 75.85, 76.32],
  ["gerakannya", 76.32, 76.93],
  ["tetap", 76.93, 77.27],
  ["terasa", 77.27, 77.74],
  ["tidak", 77.74, 78.08],
  ["nyaman.", 78.08, 78.42],
  ["Namun,", 78.73, 79.22],
  ["gerakan", 79.39, 79.83],
  ["yang", 79.83, 80.02],
  ["berlebihan", 80.02, 80.58],
  ["atau", 80.58, 81.02],
  ["tanda", 81.02, 81.34],
  ["kerusakan", 81.34, 81.90],
  ["tetap", 81.90, 82.21],
  ["perlu", 82.21, 82.53],
  ["diperiksa.", 82.53, 83.09],
  ["Jadi,", 83.38, 83.89],
  ["gedung", 84.07, 84.38],
  ["tinggi", 84.38, 84.69],
  ["tidak", 84.69, 85.00],
  ["harus", 85.00, 85.31],
  ["diam", 85.31, 85.63],
  ["untuk", 85.63, 85.94],
  ["tetap", 85.94, 86.25],
  ["berdiri", 86.25, 86.68],
  ["kokoh.", 86.68, 86.99],
  ["Pembahasan", 87.41, 87.98],
  ["ini", 87.98, 88.30],
  ["terutama", 88.30, 88.87],
  ["tentang", 88.87, 89.19],
  ["angin.", 89.19, 89.51],
  ["Respons", 89.85, 90.20],
  ["terhadap", 90.20, 90.69],
  ["gempa", 90.69, 91.04],
  ["memiliki", 91.04, 91.66],
  ["pertimbangan", 91.66, 92.29],
  ["desain", 92.29, 92.77],
  ["tambahan.", 92.77, 93.26],
];

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const easeOut = Easing.out(Easing.cubic);
const easeIn = Easing.in(Easing.cubic);
const easeInOut = Easing.inOut(Easing.cubic);
const backOut = Easing.out(Easing.back(1.9));
const eo = (t: number, a: number, d: number) => easeOut(prog(t, a, d));
const pop = (t: number, a: number, d = 0.35) => backOut(prog(t, a, d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9áéíóúñ-]/g, '');
/** waktu mulai kata ke-`nth` (mulai dari 0) yang cocok dengan `text` */
const W = (text: string, nth = 0): number => {
  const n = norm(text);
  let c = 0;
  for (const [w, s] of WORDS) {
    if (norm(w) === n) {
      if (c === nth) return s;
      c++;
    }
  }
  throw new Error('kata tidak ditemukan: ' + text);
};
/* ───────────────────────── konteks waktu ───────────────────────── */
const TCtx = createContext(0); // detik-audio absolut
const LCtx = createContext(0); // detik sejak scene mulai
const useT = () => useContext(TCtx);
const useLT = () => useContext(LCtx);

const Scene: React.FC<{a: number; b: number; fade?: number; children?: React.ReactNode}> = ({
  a,
  b,
  fade = 0.2,
  children,
}) => {
  const t = useT();
  if (t < a || t >= b + fade + 0.05) return null;
  const lt = t - a;
  return (
    <LCtx.Provider value={lt}>
      <AbsoluteFill style={{opacity: fade > 0 ? clamp(lt / fade) : 1, overflow: 'hidden'}}>
        {children}
      </AbsoluteFill>
    </LCtx.Provider>
  );
};

type Shake = {a: number; d: number; amp: number};
const Cam: React.FC<{
  z0?: number;
  z1?: number;
  dur?: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  r0?: number;
  r1?: number;
  shakes?: Shake[];
  children?: React.ReactNode;
}> = ({z0 = 1, z1 = 1, dur = 5, x0 = 0, x1 = 0, y0 = 0, y1 = 0, r0 = 0, r1 = 0, shakes = [], children}) => {
  const lt = useLT();
  const t = useT();
  const p = easeInOut(prog(lt, 0, dur));
  let sx = 0;
  let sy = 0;
  for (const s of shakes) {
    const q = prog(t, s.a, s.d);
    if (q > 0 && q < 1) {
      const k = (1 - q) * s.amp;
      sx += Math.sin(t * 93) * k;
      sy += Math.cos(t * 71) * k;
    }
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${lerp(x0, x1, p) + sx}px,${lerp(y0, y1, p) + sy}px) scale(${lerp(z0, z1, p)}) rotate(${lerp(r0, r1, p)}deg)`,
        transformOrigin: '50% 50%',
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── SVG dasar ───────────────────────── */
const Defs = () => (
  <defs>
    <radialGradient id="glowYellow">
      <stop offset="0" stopColor="#fff6b0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ffc93a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff9a2e" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowCyan">
      <stop offset="0" stopColor="#e8ffff" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#6fe6ff" stopOpacity="0.55" />
      <stop offset="1" stopColor="#2fb4ff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowWhite">
      <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowBlue">
      <stop offset="0.72" stopColor="#7ccfff" stopOpacity="0.6" />
      <stop offset="1" stopColor="#7ccfff" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowGreen">
      <stop offset="0" stopColor="#b8ffd0" stopOpacity="0.9" />
      <stop offset="1" stopColor="#4cff9a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="glowRed">
      <stop offset="0" stopColor="#ffd0c0" stopOpacity="0.95" />
      <stop offset="0.4" stopColor="#ff5a3a" stopOpacity="0.55" />
      <stop offset="1" stopColor="#ff2a1a" stopOpacity="0" />
    </radialGradient>
    <radialGradient id="earthShade" cx="0.35" cy="0.3" r="0.9">
      <stop offset="0.5" stopColor="#000" stopOpacity="0" />
      <stop offset="1" stopColor="#000" stopOpacity="0.5" />
    </radialGradient>
    <linearGradient id="seaGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#3aa6e6" />
      <stop offset="0.45" stopColor="#1668b0" />
      <stop offset="1" stopColor="#0a2a5c" />
    </linearGradient>
    <linearGradient id="deepGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#0f4a86" />
      <stop offset="0.5" stopColor="#082a58" />
      <stop offset="1" stopColor="#030d24" />
    </linearGradient>
    <linearGradient id="sandGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#e8c98a" />
      <stop offset="1" stopColor="#b88f55" />
    </linearGradient>
    <linearGradient id="sandDeep" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#5b5b7a" />
      <stop offset="1" stopColor="#2c2c48" />
    </linearGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#fff" stopOpacity="0.3" />
      <stop offset="1" stopColor="#fff" stopOpacity="0" />
    </linearGradient>
  </defs>
);

const S: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg
    viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
    width={WIDTH}
    height={HEIGHT}
    style={{position: 'absolute', left: 0, top: 0}}
  >
    <Defs />
    {children}
  </svg>
);

/* ───────────────────────── background ───────────────────────── */
const Vignette = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
    }}
  />
);

/* ───────────────────────── objek umum ───────────────────────── */
const Check: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = '#3ddc84'}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill={color} stroke={OUT} strokeWidth={7} />
    <path d="M-22,2 L-6,20 L26,-18" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" />
  </g>
);

const Cross: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={46} fill="#ff4b4b" stroke={OUT} strokeWidth={7} />
    <path d="M-20,-20 L20,20 M20,-20 L-20,20" fill="none" stroke="#fff" strokeWidth={11} strokeLinecap="round" />
  </g>
);

const Person: React.FC<{
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  shirt?: string;
  pants?: string;
  hair?: string;
  glasses?: boolean;
  armL?: number;
  armR?: number;
  mouth?: 'smile' | 'o' | 'flat';
  look?: number;
}> = ({x, y, s = 1, flip = false, shirt = '#4a7bb5', pants = '#2b2f55', hair = '#4a2f22', glasses = false, armL = 15, armR = 15, mouth = 'smile', look = 0}) => {
  const arm = (ang: number, side: number) => {
    const sx = side * 36;
    const sy = -172;
    const a = (ang * side * Math.PI) / 180;
    const L = 88;
    const ex = sx + Math.sin(a) * L;
    const ey = sy + Math.cos(a) * L;
    return (
      <g>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={OUT} strokeWidth={31} strokeLinecap="round" />
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={shirt} strokeWidth={20} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={13} fill="#f7efe4" stroke={OUT} strokeWidth={4} />
      </g>
    );
  };
  return (
    <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`}>
      <ellipse cx={0} cy={4} rx={60} ry={10} fill="#000" opacity={0.2} />
      <rect x={-29} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <rect x={6} y={-100} width={23} height={100} rx={9} fill={pants} stroke={OUT} strokeWidth={5} />
      <ellipse cx={-20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      <ellipse cx={20} cy={-2} rx={25} ry={10} fill="#1c1420" stroke={OUT} strokeWidth={4} />
      {arm(armL, -1)}
      <rect x={-42} y={-195} width={84} height={112} rx={28} fill={shirt} stroke={OUT} strokeWidth={6} />
      {arm(armR, 1)}
      <circle cx={look * 5} cy={-248} r={50} fill="#f7efe4" stroke={OUT} strokeWidth={6} />
      <path
        d={`M${-50 + look * 5},-252 A50,50 0 0 1 ${50 + look * 5},-252 Q${look * 5},-292 ${-50 + look * 5},-252Z`}
        fill={hair}
        stroke={OUT}
        strokeWidth={4}
      />
      <circle cx={-17 + look * 6} cy={-250} r={6} fill={OUT} />
      <circle cx={17 + look * 6} cy={-250} r={6} fill={OUT} />
      {glasses && (
        <g fill="none" stroke={OUT} strokeWidth={4}>
          <circle cx={-17 + look * 6} cy={-250} r={14} />
          <circle cx={17 + look * 6} cy={-250} r={14} />
          <line x1={-3 + look * 6} y1={-250} x2={3 + look * 6} y2={-250} />
        </g>
      )}
      {mouth === 'smile' && <path d={`M${-14 + look * 5},-226 Q${look * 5},-212 ${14 + look * 5},-226`} fill="none" stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
      {mouth === 'o' && <ellipse cx={look * 5} cy={-222} rx={8} ry={10} fill={OUT} />}
      {mouth === 'flat' && <line x1={-12 + look * 5} y1={-222} x2={12 + look * 5} y2={-222} stroke={OUT} strokeWidth={4} strokeLinecap="round" />}
    </g>
  );
};

/* ───────────────────────── efek ───────────────────────── */
const Sparks: React.FC<{
  x: number;
  y: number;
  t0: number;
  n?: number;
  speed?: number;
  life?: number;
  g?: number;
  color?: string;
  size?: number;
  seed?: string;
}> = ({x, y, t0, n = 30, speed = 500, life = 1.2, g = 600, color = '#ffc85a', size = 7, seed = 'sp'}) => {
  const t = useT();
  const age = t - t0;
  if (age < 0 || age > life) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const a = random(`${seed}a${i}`) * Math.PI * 2;
        const v = (0.3 + random(`${seed}v${i}`) * 0.7) * speed;
        const px = x + Math.cos(a) * v * age;
        const py = y + Math.sin(a) * v * age + 0.5 * g * age * age;
        const o = 1 - age / life;
        return <circle key={i} cx={px} cy={py} r={size * (0.5 + random(`${seed}r${i}`)) * o} fill={color} opacity={o} />;
      })}
    </g>
  );
};

const Ring: React.FC<{x: number; y: number; t0: number; max?: number; dur?: number; color?: string; w?: number}> = ({x, y, t0, max = 300, dur = 0.9, color = '#fff', w = 12}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (p <= 0 || p >= 1) return null;
  return <circle cx={x} cy={y} r={max * easeOut(p)} fill="none" stroke={color} strokeWidth={w * (1 - p)} opacity={1 - p * 0.7} />;
};

const Flash: React.FC<{t0: number; dur?: number; color?: string}> = ({t0, dur = 0.5, color = '#fff'}) => {
  const t = useT();
  const p = prog(t, t0, dur);
  if (t < t0 || p >= 1) return null;
  return <AbsoluteFill style={{background: color, opacity: 0.85 * (1 - easeOut(p))}} />;
};

/* ───────────────────────── UI: label, caption ───────────────────────── */
const Pill: React.FC<{
  x: number;
  y: number;
  text: string;
  at: number;
  color?: string;
  size?: number;
  rot?: number;
  sub?: string;
  until?: number;
  bg?: string;
}> = ({x, y, text, at, color = '#ffb84d', size = 54, rot = 0, sub, until, bg = 'rgba(18,12,30,0.88)'}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const outP = until !== undefined ? 1 - prog(t, until - 0.2, 0.2) : 1;
  const p = pop(t, at, 0.4) * (outP > 0 ? outP : 0);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${p})`,
        background: bg,
        border: `5px solid ${color}`,
        color: '#fff',
        padding: sub ? '12px 38px' : '14px 36px',
        borderRadius: sub ? 44 : 999,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: size,
        letterSpacing: 2,
        whiteSpace: 'nowrap',
        textAlign: 'center',
        boxShadow: '0 8px 0 rgba(0,0,0,0.35)',
      }}
    >
      {text}
      {sub && <div style={{fontSize: size * 0.52, fontWeight: 600, opacity: 0.85, letterSpacing: 1}}>{sub}</div>}
    </div>
  );
};

/** catatan tulisan tangan */
const Note: React.FC<{x: number; y: number; text: string; at: number; color?: string; size?: number; rot?: number; until?: number}> = ({
  x,
  y,
  text,
  at,
  color = '#ffe27a',
  size = 62,
  rot = -4,
  until,
}) => {
  const t = useT();
  if (t < at || (until !== undefined && t > until)) return null;
  const p = eo(t, at, 0.35);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${0.8 + 0.2 * p})`,
        opacity: p,
        fontFamily: HAND,
        fontWeight: 700,
        fontSize: size,
        color,
        whiteSpace: 'nowrap',
        textShadow: '0 4px 10px rgba(0,0,0,0.55)',
      }}
    >
      {text}
    </div>
  );
};

const Caption: React.FC = () => {
  const t = useT();
  let idx = -1;
  for (let i = 0; i < WORDS.length; i++) {
    if (WORDS[i][1] <= t) idx = i;
    else break;
  }
  if (idx < 0) return null;
  const [w, s, e] = WORDS[idx];
  if (t > e + 0.28) return null;
  const sc = 0.82 + 0.18 * backOut(prog(t, s, 0.16));
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '46%',
        textAlign: 'center',
        transform: `translateY(-50%) scale(${sc})`,
        fontFamily: FONT,
        fontWeight: 800,
        fontSize: 92,
        color: '#fff',
        letterSpacing: -1,
        WebkitTextStroke: '12px rgba(22,12,34,0.9)',
        paintOrder: 'stroke fill',
        textShadow: '0 6px 14px rgba(0,0,0,0.55)',
        padding: '0 40px',
      }}
    >
      {w}
    </div>
  );
};



/* ───────────────────────── helper khusus video ini ───────────────────────── */
const hex = (s: string) => [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];
const mix = (a: string, b: string, p: number) => {
  const A = hex(a);
  const B = hex(b);
  return `rgb(${Math.round(lerp(A[0], B[0], p))},${Math.round(lerp(A[1], B[1], p))},${Math.round(lerp(A[2], B[2], p))})`;
};
const sway = (t: number, per = 3, ph = 0) => Math.sin((t / per) * Math.PI * 2 + ph);
const f1 = (v: number) => v.toFixed(1);
const poly = (p: Array<[number, number]>) => p.map(([a, b]) => `${f1(a)},${f1(b)}`).join(' ');
const polar = (cx: number, cy: number, r: number, deg: number): [number, number] => [
  cx + r * Math.sin((deg * Math.PI) / 180),
  cy - r * Math.cos((deg * Math.PI) / 180),
];
const arcPath = (cx: number, cy: number, r: number, a0: number, a1: number) => {
  const [x0, y0] = polar(cx, cy, r, a0);
  const [x1, y1] = polar(cx, cy, r, a1);
  return `M${f1(x0)},${f1(y0)} A${r},${r} 0 ${Math.abs(a1 - a0) > 180 ? 1 : 0} 1 ${f1(x1)},${f1(y1)}`;
};
/** posisi tangan Person (sama persis dengan rumus lengan di Person) */
const handOf = (x: number, y: number, s: number, side: 1 | -1, ang: number, flip = false): [number, number] => {
  const a = (ang * side * Math.PI) / 180;
  const ex = side * 36 + Math.sin(a) * 88;
  const ey = -172 + Math.cos(a) * 88;
  return [x + (flip ? -ex : ex) * s, y + ey * s];
};

/* ───────────────────────── background ───────────────────────── */
const TONES: Record<string, [string, string, string, string, string]> = {
  // atas, tengah, bawah, siluet kota, tanah
  sunset: ['#e2603b', '#f5a050', '#ffd99a', '#7b3f5e', '#4b3a48'],
  day: ['#4fb0ec', '#92d4f6', '#e3f5fd', '#86a9c6', '#6d7a86'],
  storm: ['#3b4766', '#66738f', '#a1abc0', '#4f5a74', '#39414f'],
  night: ['#0b0f30', '#1d2257', '#3f3677', '#161a45', '#14152e'],
};

const Cloud: React.FC<{x: number; y: number; s?: number; sp?: number; o?: number}> = ({x, y, s = 1, sp = 10, o = 0.38}) => {
  const t = useT();
  const cx = ((x + t * sp) % 1500) - 210;
  return (
    <g transform={`translate(${f1(cx)} ${y}) scale(${s})`} opacity={o} fill="#fff">
      <ellipse cx={0} cy={0} rx={110} ry={34} />
      <ellipse cx={-50} cy={-24} rx={60} ry={34} />
      <ellipse cx={34} cy={-34} rx={72} ry={40} />
    </g>
  );
};

const Sky: React.FC<{tone?: string; ground?: number; sun?: boolean; skyline?: boolean}> = ({
  tone = 'sunset',
  ground = 1650,
  sun = true,
  skyline = true,
}) => {
  const [c0, c1, c2, cs, cg] = TONES[tone];
  return (
    <g>
      <defs>
        <linearGradient id={`sky_${tone}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={c0} />
          <stop offset="0.55" stopColor={c1} />
          <stop offset="1" stopColor={c2} />
        </linearGradient>
      </defs>
      <rect x={0} y={0} width={WIDTH} height={HEIGHT} fill={`url(#sky_${tone})`} />
      {sun && tone === 'sunset' && (
        <g>
          <circle cx={830} cy={ground - 430} r={300} fill="#ffe7a0" opacity={0.28} />
          <circle cx={830} cy={ground - 430} r={150} fill="#fff1c0" opacity={0.95} />
        </g>
      )}
      {sun && tone === 'day' && <circle cx={850} cy={330} r={95} fill="#fff6b8" opacity={0.95} />}
      {tone === 'night' &&
        Array.from({length: 50}).map((_, i) => (
          <circle key={i} cx={random(`gx${i}`) * WIDTH} cy={random(`gy${i}`) * 900} r={1.5 + random(`gr${i}`) * 2.5} fill="#fff" opacity={0.5} />
        ))}
      {skyline &&
        Array.from({length: 14}).map((_, k) => {
          const bw = 70 + random(`sbw${k}`) * 40;
          const bh = 120 + random(`sbh${k}`) * 320;
          return <rect key={k} x={k * 82 - 30} y={ground - bh} width={bw} height={bh + 4} fill={cs} opacity={0.9} />;
        })}
      <rect x={0} y={ground} width={WIDTH} height={HEIGHT - ground} fill={cg} />
      <rect x={0} y={ground} width={WIDTH} height={30} fill="#fff" opacity={0.12} />
      <rect x={0} y={ground} width={WIDTH} height={6} fill={OUT} opacity={0.6} />
      {Array.from({length: 7}).map((_, k) => (
        <rect key={k} x={k * 190 + 20} y={ground + 150} width={110} height={12} rx={6} fill="#fff" opacity={0.25} />
      ))}
    </g>
  );
};

const LabBG = () => (
  <g>
    <rect x={0} y={0} width={WIDTH} height={HEIGHT} fill="#3a8e86" />
    <rect x={0} y={0} width={WIDTH} height={70} fill="#2c746e" />
    {[130, 540, 950].map((x) => (
      <rect key={x} x={x - 110} y={28} width={220} height={26} rx={12} fill="#f4fbff" opacity={0.85} />
    ))}
    <rect x={0} y={1040} width={WIDTH} height={570} fill="#48a197" />
    {Array.from({length: 10}).map((_, i) => (
      <line key={`v${i}`} x1={i * 120} y1={1040} x2={i * 120} y2={1610} stroke="#2f7d75" strokeWidth={5} />
    ))}
    {Array.from({length: 6}).map((_, i) => (
      <line key={`h${i}`} x1={0} y1={1040 + i * 114} x2={WIDTH} y2={1040 + i * 114} stroke="#2f7d75" strokeWidth={5} />
    ))}
    <rect x={0} y={1030} width={WIDTH} height={16} fill="#2c746e" />
    <rect x={0} y={1610} width={WIDTH} height={310} fill="#dac9a1" />
    <rect x={0} y={1610} width={WIDTH} height={8} fill={OUT} opacity={0.5} />
    {Array.from({length: 7}).map((_, i) => (
      <line key={i} x1={i * 200 - 20} y1={1618} x2={i * 260 - 300} y2={1920} stroke="#bfae84" strokeWidth={5} />
    ))}
  </g>
);

const BluePrintBG = () => (
  <g>
    <rect x={0} y={0} width={WIDTH} height={HEIGHT} fill="#143060" />
    {Array.from({length: 14}).map((_, i) => (
      <line key={`v${i}`} x1={i * 90} y1={0} x2={i * 90} y2={HEIGHT} stroke="#2a4f93" strokeWidth={i % 4 === 0 ? 4 : 2} opacity={0.7} />
    ))}
    {Array.from({length: 22}).map((_, i) => (
      <line key={`h${i}`} x1={0} y1={i * 90} x2={WIDTH} y2={i * 90} stroke="#2a4f93" strokeWidth={i % 4 === 0 ? 4 : 2} opacity={0.7} />
    ))}
  </g>
);

/* ───────────────────────── objek ───────────────────────── */
const WindLines: React.FC<{
  y0: number;
  y1: number;
  n?: number;
  t0?: number;
  speed?: number;
  seed?: string;
  o?: number;
  len?: number;
  color?: string;
}> = ({y0, y1, n = 10, t0 = 0, speed = 0.9, seed = 'wl', o = 0.8, len = 190, color = '#fff'}) => {
  const t = useT();
  if (t < t0) return null;
  const fadeIn = eo(t, t0, 0.5);
  return (
    <g fill="none" stroke={color} strokeWidth={9} strokeLinecap="round" opacity={o * fadeIn}>
      {Array.from({length: n}).map((_, i) => {
        const y = lerp(y0, y1, random(`${seed}y${i}`));
        const ph = (t * speed * (0.7 + random(`${seed}s${i}`) * 0.6) + random(`${seed}p${i}`)) % 1;
        const x = lerp(-320, WIDTH + 80, ph);
        const L = len * (0.7 + random(`${seed}l${i}`) * 0.7);
        return <path key={i} d={`M${f1(x)},${f1(y)} H${f1(x + L)} q38,0 38,-28 q0,-24 -30,-20`} />;
      })}
    </g>
  );
};

const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; color?: string; w?: number; head?: number; o?: number}> = ({
  x1,
  y1,
  x2,
  y2,
  color = '#fff',
  w = 14,
  head = 42,
  o = 1,
}) => {
  const a = Math.atan2(y2 - y1, x2 - x1);
  const c = Math.cos(a);
  const s = Math.sin(a);
  const bx = x2 - c * head * 0.8;
  const by = y2 - s * head * 0.8;
  const hp: Array<[number, number]> = [
    [x2, y2],
    [x2 - c * head + s * head * 0.55, y2 - s * head - c * head * 0.55],
    [x2 - c * head - s * head * 0.55, y2 - s * head + c * head * 0.55],
  ];
  return (
    <g opacity={o} strokeLinejoin="round" strokeLinecap="round">
      <line x1={x1} y1={y1} x2={bx} y2={by} stroke={OUT} strokeWidth={w + 10} />
      <polygon points={poly(hp)} fill={OUT} stroke={OUT} strokeWidth={10} />
      <line x1={x1} y1={y1} x2={bx} y2={by} stroke={color} strokeWidth={w} />
      <polygon points={poly(hp)} fill={color} />
    </g>
  );
};

/** gedung: lantai ditumpuk, makin ke atas makin bergeser (melengkung) sebesar `amp` px di puncak */
const Tower: React.FC<{
  x: number;
  y: number;
  w?: number;
  n?: number;
  fh?: number;
  amp?: number;
  body?: string;
  shade?: string;
  win?: string;
  off?: string;
  cols?: number;
  lit?: number;
  shape?: (i: number) => [number, number];
  fill?: (i: number) => string;
  seed?: string;
  spire?: number;
  braces?: boolean;
  sw?: number;
}> = ({
  x,
  y,
  w = 200,
  n = 24,
  fh = 52,
  amp = 0,
  body = '#5d86c4',
  shade = '#4f77b5',
  win = '#ffe9a0',
  off = '#2f4a7a',
  cols = 4,
  lit = 0.7,
  shape,
  fill,
  seed = 'tw',
  spire = 0,
  braces = false,
  sw = 6,
}) => {
  const t = useT();
  const nn = Math.max(0.05, n);
  const cnt = Math.ceil(nn - 1e-6);
  const dx = (h: number) => amp * (h / nn) * (h / nn);
  const P = (u: number, i: number, f: number): [number, number] => {
    const top = Math.min(i + 1, nn);
    const h = i + f * (top - i);
    const [a, b] = shape ? shape(i) : [w, w];
    return [x + u * lerp(a, b, f) + dx(h), y - h * fh];
  };
  const tp = P(0, cnt - 1, 1);
  return (
    <g>
      <ellipse cx={x} cy={y + 6} rx={w * 0.85} ry={14} fill="#000" opacity={0.22} />
      {spire > 0 && (
        <g strokeLinecap="round">
          <line x1={tp[0]} y1={tp[1]} x2={tp[0] + amp * 0.06} y2={tp[1] - spire} stroke={OUT} strokeWidth={14} />
          <line x1={tp[0]} y1={tp[1]} x2={tp[0] + amp * 0.06} y2={tp[1] - spire} stroke="#e8e8f0" strokeWidth={5} />
          <circle cx={tp[0] + amp * 0.06} cy={tp[1] - spire} r={9} fill="#ff4b4b" stroke={OUT} strokeWidth={4} opacity={0.55 + 0.45 * Math.abs(Math.sin(t * 4))} />
        </g>
      )}
      {Array.from({length: cnt}).map((_, i) => {
        const c = fill ? fill(i) : i % 2 ? shade : body;
        return (
          <g key={i}>
            <polygon points={poly([P(-0.5, i, 0), P(0.5, i, 0), P(0.5, i, 1), P(-0.5, i, 1)])} fill={c} stroke={OUT} strokeWidth={sw} strokeLinejoin="round" />
            <polygon points={poly([P(0.3, i, 0), P(0.5, i, 0), P(0.5, i, 1), P(0.3, i, 1)])} fill="#000" opacity={0.12} />
            {Array.from({length: cols}).map((__, j) => {
              const u = -0.5 + (j + 0.5) / cols;
              const hw = (0.5 / cols) * 0.52;
              const on = random(`${seed}${i}_${j}`) < lit;
              return <polygon key={j} points={poly([P(u - hw, i, 0.28), P(u + hw, i, 0.28), P(u + hw, i, 0.72), P(u - hw, i, 0.72)])} fill={on ? win : off} />;
            })}
            {braces && (
              <g stroke="#8a2f3a" strokeWidth={8} strokeLinecap="round">
                <line x1={P(-0.5, i, 0)[0]} y1={P(-0.5, i, 0)[1]} x2={P(0.5, i, 1)[0]} y2={P(0.5, i, 1)[1]} />
                <line x1={P(0.5, i, 0)[0]} y1={P(0.5, i, 0)[1]} x2={P(-0.5, i, 1)[0]} y2={P(-0.5, i, 1)[1]} />
              </g>
            )}
          </g>
        );
      })}
    </g>
  );
};

const Hardhat: React.FC<{x: number; y: number; s?: number; flip?: boolean}> = ({x, y, s = 1, flip = false}) => (
  <g transform={`translate(${x} ${y}) scale(${flip ? -s : s} ${s})`} strokeLinejoin="round">
    <path d="M-54,-264 A54,54 0 0 1 54,-264 Z" fill="#ffc533" stroke={OUT} strokeWidth={6} />
    <rect x={-64} y={-270} width={128} height={15} rx={7} fill="#ffc533" stroke={OUT} strokeWidth={5} />
    <rect x={-10} y={-312} width={20} height={44} rx={5} fill="#ffd95e" stroke={OUT} strokeWidth={4} />
  </g>
);

const Clipboard: React.FC<{x: number; y: number; s?: number; rot?: number}> = ({x, y, s = 1, rot = 0}) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} strokeLinejoin="round">
    <rect x={-48} y={-62} width={96} height={124} rx={10} fill="#a8794a" stroke={OUT} strokeWidth={5} />
    <rect x={-37} y={-47} width={74} height={102} rx={5} fill="#f7efe4" stroke={OUT} strokeWidth={3} />
    <rect x={-20} y={-72} width={40} height={20} rx={6} fill="#8a8fa8" stroke={OUT} strokeWidth={4} />
    {[-24, -6, 12, 30].map((yy) => (
      <line key={yy} x1={-26} y1={yy} x2={26} y2={yy} stroke="#7a7280" strokeWidth={4} strokeLinecap="round" />
    ))}
  </g>
);

const PopMark: React.FC<{x: number; y: number; at: number; s?: number; kind: 'ok' | 'no'}> = ({x, y, at, s = 1, kind}) => {
  const t = useT();
  if (t < at) return null;
  const p = pop(t, at, 0.45);
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      {kind === 'ok' ? <Check x={0} y={0} s={s} /> : <Cross x={0} y={0} s={s} />}
    </g>
  );
};

const Card: React.FC<{x: number; y: number; w: number; h: number; at: number; label: string; color?: string; children?: React.ReactNode}> = ({
  x,
  y,
  w,
  h,
  at,
  label,
  color = '#ffc93a',
  children,
}) => {
  const t = useT();
  if (t < at) return null;
  const p = pop(t, at, 0.45);
  const act = t < at + 1.3;
  return (
    <g transform={`translate(${x} ${y}) scale(${p})`}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={40} fill="#1f3a75" stroke={act ? color : OUT} strokeWidth={act ? 11 : 7} />
      <rect x={-w / 2 + 16} y={-h / 2 + 16} width={w - 32} height={h - 32} rx={28} fill="#2a4a92" opacity={0.6} />
      {children}
      <text x={0} y={h / 2 - 38} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={36} fill="#fff" stroke={OUT} strokeWidth={8} paintOrder="stroke" letterSpacing={1}>
        {label}
      </text>
    </g>
  );
};

const IconWind: React.FC = () => (
  <g fill="none" strokeLinecap="round" strokeWidth={13}>
    {[[-52, '#bfeaff'], [-4, '#fff'], [44, '#9fdcff']].map(([y, c], i) => (
      <g key={i}>
        <path d={`M-80,${y} H${20 + i * 10} q44,0 44,-30 q0,-28 -34,-24`} stroke={OUT} strokeWidth={25} />
        <path d={`M-80,${y} H${20 + i * 10} q44,0 44,-30 q0,-28 -34,-24`} stroke={c as string} />
      </g>
    ))}
  </g>
);

const IconQuake: React.FC = () => {
  const t = useT();
  return (
    <g strokeLinecap="round" strokeLinejoin="round" fill="none">
      <g transform={`translate(${Math.sin(t * 40) * 4} 0)`}>
        <rect x={-34} y={-76} width={68} height={104} fill="#8aa7d6" stroke={OUT} strokeWidth={7} />
        {[-52, -22].map((y) => (
          <g key={y}>
            <rect x={-22} y={y} width={16} height={16} fill="#ffe9a0" />
            <rect x={6} y={y} width={16} height={16} fill="#ffe9a0" />
          </g>
        ))}
      </g>
      <path d="M-88,50 L-56,50 L-38,28 L-14,76 L10,24 L34,66 L52,50 L88,50" stroke={OUT} strokeWidth={24} />
      <path d="M-88,50 L-56,50 L-38,28 L-14,76 L10,24 L34,66 L52,50 L88,50" stroke="#ffb06a" strokeWidth={11} />
    </g>
  );
};

const IconSwirl: React.FC = () => {
  const t = useT();
  return (
    <g fill="none" strokeLinecap="round" transform={`rotate(${t * 120})`}>
      <path d="M0,0 m-12,0 a12,12 0 1,1 24,0 a26,26 0 1,1 -52,0 a42,42 0 1,1 84,0 a58,58 0 1,1 -116,0" stroke={OUT} strokeWidth={24} />
      <path d="M0,0 m-12,0 a12,12 0 1,1 24,0 a26,26 0 1,1 -52,0 a42,42 0 1,1 84,0 a58,58 0 1,1 -116,0" stroke="#7ce8ff" strokeWidth={11} />
    </g>
  );
};

/** ruang TMD: kotak gedung + pendulum di dalamnya */
const Pendulum: React.FC<{
  cx: number;
  top: number;
  bot: number;
  w: number;
  A: number;
  B: number;
  per?: number;
  sphere?: boolean;
  r?: number;
  arrows?: boolean;
  on?: number;
}> = ({cx, top, bot, w, A, B, per = 2.4, sphere = false, r = 120, arrows = false, on = 1}) => {
  const t = useT();
  const ph = sway(t, per);
  const vel = Math.cos((t / per) * Math.PI * 2);
  const xb = A * ph * on;
  const xm = -B * ph * on;
  const bobY = top + (bot - top) * 0.62;
  const ax = cx + xb;
  const bx = cx + xm;
  return (
    <g strokeLinejoin="round" strokeLinecap="round">
      <defs>
        <radialGradient id="goldG" cx="0.35" cy="0.3" r="0.85">
          <stop offset="0" stopColor="#fff3b0" />
          <stop offset="0.5" stopColor="#f0b429" />
          <stop offset="1" stopColor="#a8661a" />
        </radialGradient>
      </defs>
      <rect x={cx - w / 2 + xb} y={top} width={w} height={bot - top} rx={18} fill="#243a6b" stroke={OUT} strokeWidth={9} />
      <rect x={cx - w / 2 + xb + 20} y={top + 20} width={w - 40} height={bot - top - 40} rx={10} fill="#34549a" opacity={0.75} />
      <rect x={cx - w / 2 + xb} y={top} width={w} height={26} rx={10} fill="#8a8fa8" stroke={OUT} strokeWidth={7} />
      {[-1, 1].map((sg) => (
        <line key={sg} x1={ax + sg * 62} y1={top + 26} x2={bx + sg * r * 0.42} y2={bobY - r * 0.9} stroke={OUT} strokeWidth={12} />
      ))}
      {[-1, 1].map((sg) => (
        <line key={sg} x1={ax + sg * 62} y1={top + 26} x2={bx + sg * r * 0.42} y2={bobY - r * 0.9} stroke="#dfe3ee" strokeWidth={5} />
      ))}
      {sphere ? (
        <g>
          <circle cx={bx} cy={bobY} r={r} fill="url(#goldG)" stroke={OUT} strokeWidth={9} />
          <ellipse cx={bx - r * 0.35} cy={bobY - r * 0.4} rx={r * 0.18} ry={r * 0.1} fill="#fff" opacity={0.7} transform={`rotate(-35 ${bx - r * 0.35} ${bobY - r * 0.4})`} />
        </g>
      ) : (
        <g>
          <rect x={bx - r} y={bobY - r * 0.8} width={r * 2} height={r * 1.6} rx={22} fill="#f0b429" stroke={OUT} strokeWidth={9} />
          <rect x={bx - r + 14} y={bobY - r * 0.8 + 14} width={r * 2 - 28} height={r * 0.35} rx={10} fill="#ffe08a" opacity={0.8} />
        </g>
      )}
      <rect x={cx - w / 2 + xb} y={bot - 22} width={w} height={22} rx={8} fill="#10204a" stroke={OUT} strokeWidth={6} />
      {arrows && on > 0.5 && Math.abs(vel) > 0.25 && (
        <g>
          <Arrow x1={ax - 80 * Math.sign(vel)} y1={top - 54} x2={ax + 80 * Math.sign(vel)} y2={top - 54} color="#ff6b5a" />
          <Arrow x1={bx + 70 * Math.sign(vel)} y1={bot + 64} x2={bx - 70 * Math.sign(vel)} y2={bot + 64} color="#4fc3ff" />
        </g>
      )}
    </g>
  );
};

/* ═══════════════════════════ SCENE ═══════════════════════════ */

/* 1 ─ Gedung tidak selalu diam (0 – 3.5) */
const SceneHook = () => {
  const t = useT();
  const tS = W('benar-benar');
  const amp = 40 * eo(t, tS, 1.0) * sway(t, 3.4);
  const titleO = eo(t, 0.1, 0.6);
  return (
    <>
      <S>
        <Sky tone="sunset" ground={1650} />
        <Cloud x={100} y={470} s={1.3} sp={12} />
        <Cloud x={700} y={640} s={0.9} sp={9} />
        <Tower x={540} y={1650} w={210} n={26} fh={52} amp={amp} />
        <Person x={190} y={1795} s={0.55} shirt="#e38b3d" look={1} mouth={t > tS ? 'o' : 'smile'} />
        <Person x={900} y={1805} s={0.55} flip shirt="#6bbf8a" look={-1} mouth={t > tS ? 'o' : 'smile'} />
        <WindLines y0={420} y1={1000} n={8} t0={tS + 0.4} speed={0.7} o={0.55} />
      </S>
      <div
        style={{
          position: 'absolute',
          top: 70,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: titleO,
          transform: `translateY(${(1 - titleO) * -30}px)`,
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          WebkitTextStroke: '10px rgba(42,26,44,0.85)',
          paintOrder: 'stroke fill',
        }}
      >
        <div style={{fontSize: 90}}>GEDUNG TINGGI</div>
        <div style={{fontSize: 64, color: '#ffe27a'}}>BISA GOYANG?</div>
      </div>
      <Note x={850} y={470} text="?" at={tS + 0.2} size={240} color="#ffe27a" rot={8} />
    </>
  );
};

/* 2 ─ Angin kencang / getaran gempa → puncak bergerak (3.5 – 9) */
const SceneSway = () => {
  const t = useT();
  const tA = W('angin', 0);
  const tG = W('getaran', 0);
  const tB = W('bagian', 0);
  const tM = W('bergerak', 0);
  const q = t > tG && t < tG + 2.6 ? 1 : 0;
  const amp = 64 * eo(t, 0, 0.6) * sway(t, 2.2);
  const topX = 540 + amp;
  const ringP = pop(t, tB, 0.45);
  return (
    <>
      <S>
        <g transform={`translate(${f1(q * Math.sin(t * 70) * 7)} ${f1(q * Math.cos(t * 53) * 4)})`}>
          <Sky tone="storm" ground={1650} sun={false} />
          <Cloud x={200} y={420} s={1.4} sp={26} o={0.3} />
          <Cloud x={800} y={600} s={1.0} sp={20} o={0.3} />
          <Tower x={540} y={1650} w={210} n={26} fh={52} amp={amp} body="#6f8fc0" shade="#5f80b3" off="#33476e" />
          {t > tG && (
            <path
              d="M110,1700 l70,22 l-34,34 l86,26 l-40,44 M900,1700 l-60,26 l36,30 l-70,28"
              fill="none"
              stroke={OUT}
              strokeWidth={9}
              strokeLinecap="round"
              strokeLinejoin="round"
              pathLength={1}
              strokeDasharray={1}
              strokeDashoffset={1 - eo(t, tG, 0.6)}
            />
          )}
        </g>
        <Sparks x={540} y={1650} t0={tG} n={26} speed={280} life={1.3} g={300} color="#d7c4a4" size={9} seed="dust" />
        <WindLines y0={330} y1={1050} n={14} t0={tA} speed={1.2} />
        {t >= tB && (
          <g transform={`translate(${f1(topX)} 300) scale(${ringP})`}>
            <circle r={150} fill="none" stroke={OUT} strokeWidth={18} strokeDasharray="24 18" />
            <circle r={150} fill="none" stroke="#ffd45a" strokeWidth={10} strokeDasharray="24 18" />
          </g>
        )}
        {t >= tM && (
          <g opacity={eo(t, tM, 0.4)}>
            <line x1={540} y1={150} x2={540} y2={1650} stroke="#fff" strokeWidth={5} strokeDasharray="14 14" opacity={0.6} />
            <Arrow x1={540} y1={190} x2={640} y2={190} color="#ffd45a" w={12} head={34} />
            <Arrow x1={540} y1={190} x2={440} y2={190} color="#ffd45a" w={12} head={34} />
          </g>
        )}
      </S>
      <Pill x={230} y={560} text="ANGIN" at={tA} color="#7ccfff" size={48} />
      <Pill x={850} y={1500} text="GEMPA" at={tG} color="#ffb06a" size={48} />
      <Pill x={250} y={140} text="BAGIAN ATAS" at={tB} color="#ffd45a" size={44} />
      <Note x={820} y={190} text="sedikit saja" at={tM + 0.2} size={74} color="#ffe27a" rot={-4} />
    </>
  );
};

/* 3 ─ Sudah diperhitungkan sejak desain (9 – 15.6) */
const SceneDesign = () => {
  const t = useT();
  const tC = W('diperhitungkan');
  const tG = W('bergoyang', 0);
  const tN = W('bukan');
  const env = (sg: number) => {
    let d = '';
    for (let k = 0; k <= 14; k++) {
      const h = k / 14;
      d += `${k ? 'L' : 'M'}${f1(540 + sg * (68 + 76 * h * h))},${f1(870 - h * 504)} `;
    }
    return d;
  };
  const amp = 38 * eo(t, tG, 0.7) * sway(t, 2.0);
  const paperP = pop(t, 0.15, 0.5);
  return (
    <>
      <S>
        <BluePrintBG />
        <g transform={`translate(540 560) scale(${paperP}) rotate(-2) translate(-540 -560)`}>
          <rect x={110} y={170} width={860} height={780} rx={20} fill="#f3e9cf" stroke={OUT} strokeWidth={9} />
          {Array.from({length: 7}).map((_, i) => (
            <line key={i} x1={140} y1={300 + i * 90} x2={940} y2={300 + i * 90} stroke="#cdbf9c" strokeWidth={3} />
          ))}
          <line x1={150} y1={870} x2={930} y2={870} stroke={OUT} strokeWidth={6} />
          {t >= tC && (
            <g opacity={eo(t, tC, 0.5)} fill="none" stroke="#d23a3a" strokeWidth={7} strokeDasharray="16 12" strokeLinecap="round">
              <path d={env(1)} />
              <path d={env(-1)} />
            </g>
          )}
          <Tower x={540} y={870} w={130} n={14} fh={36} amp={amp} body="#cfe0f5" shade="#b9cfe9" win="#6b8fc4" off="#9db8dc" cols={3} lit={0.5} sw={5} />
        </g>
        <rect x={0} y={1650} width={WIDTH} height={270} fill="#0e2147" />
        <rect x={0} y={1650} width={WIDTH} height={8} fill={OUT} />
        <Person x={240} y={1790} s={1.5} shirt="#4a7bb5" glasses mouth="smile" armR={100} armL={55} look={1} />
        <Hardhat x={240} y={1790} s={1.5} />
        {(() => {
          const [hx, hy] = handOf(240, 1790, 1.5, -1, 55);
          return <Clipboard x={hx + 8} y={hy - 62} s={1.1} rot={-8} />;
        })()}
        {t >= tN && (
          <g transform="translate(900 1560) rotate(-80 0 100)" opacity={0.95}>
            <Tower x={0} y={100} w={110} n={8} fh={44} body="#8d8794" shade="#7c7683" off="#45404f" cols={3} lit={0.1} sw={5} />
          </g>
        )}
        <Sparks x={730} y={1640} t0={tN} n={22} speed={260} life={1.2} g={300} color="#cdbb9e" size={9} seed="rub" />
        <PopMark x={730} y={1450} at={tN} s={2.4} kind="no" />
      </S>
      <Note x={540} y={250} text="DESAIN GEDUNG" at={0.4} size={92} color="#2b4f9a" rot={-2} />
      <Note x={830} y={600} text="batas goyang" at={tC + 0.3} size={60} color="#c2282a" rot={6} />
      <Pill x={730} y={1745} text="RUNTUH" at={tN} color="#ff6b6b" size={44} />
    </>
  );
};

/* 4 ─ Bergerak terkendali = keselamatan (15.6 – 21.3) */
const SceneControlled = () => {
  const t = useT();
  const tSnap = W('bergerak', 1) + 0.5;
  const tOk = W('terkendali');
  const tShield = W('keselamatan');
  const gust = eo(t, 0.2, 0.8);
  // buluh bambu yang melengkung
  const b = (0.75 + 0.45 * sway(t, 2.4)) * gust;
  const pts: Array<[number, number, number]> = [[780, 1700, 0]];
  let ang = 0;
  for (let i = 0; i < 12; i++) {
    ang += b * (0.02 + 0.06 * (i / 12));
    const [px, py] = pts[pts.length - 1];
    pts.push([px + Math.sin(ang) * 62, py - Math.cos(ang) * 62, ang]);
  }
  const reed = pts.map(([px, py], i) => `${i ? 'L' : 'M'}${f1(px)},${f1(py)}`).join(' ');
  // tiang kaku
  const snapP = prog(t, tSnap, 0.7);
  const fall = easeIn(snapP) * 75;
  const wob = t < tSnap ? sway(t, 0.5) * 0.8 * gust : 0;
  return (
    <>
      <S>
        <Sky tone="sunset" ground={1700} />
        <Cloud x={300} y={440} s={1.2} sp={14} />
        {/* tiang kaku */}
        <g>
          <rect x={277} y={1340} width={46} height={360} fill="#8a6a4a" stroke={OUT} strokeWidth={7} />
          <g transform={`rotate(${f1(t < tSnap ? wob : fall)} 300 1340)`}>
            <rect x={277} y={1000} width={46} height={340} fill="#8a6a4a" stroke={OUT} strokeWidth={7} />
            {[1060, 1140, 1230].map((y) => (
              <line key={y} x1={286} y1={y} x2={314} y2={y} stroke="#6a4f35" strokeWidth={5} strokeLinecap="round" />
            ))}
          </g>
          {t >= tSnap && <path d="M277,1340 l10,-20 l12,18 l12,-22 l12,24 Z" fill="#d9b88a" stroke={OUT} strokeWidth={5} strokeLinejoin="round" />}
        </g>
        <Sparks x={300} y={1340} t0={tSnap} n={18} speed={300} life={0.9} g={500} color="#d9b88a" size={8} seed="snap" />
        {/* bambu */}
        <path d={reed} fill="none" stroke={OUT} strokeWidth={42} strokeLinecap="round" strokeLinejoin="round" />
        <path d={reed} fill="none" stroke="#4fa65b" strokeWidth={28} strokeLinecap="round" strokeLinejoin="round" />
        {pts.slice(1).map(([px, py, a], i) =>
          i % 2 === 1 ? (
            <g key={i}>
              <line x1={px - 14 * Math.cos(a)} y1={py - 14 * Math.sin(a)} x2={px + 14 * Math.cos(a)} y2={py + 14 * Math.sin(a)} stroke="#2f7a3c" strokeWidth={6} strokeLinecap="round" />
              <ellipse cx={px + 48 * (i % 4 === 1 ? 1 : -1)} cy={py - 14} rx={46} ry={14} fill="#6fc472" stroke={OUT} strokeWidth={5} transform={`rotate(${(i % 4 === 1 ? -25 : 25) + (a * 180) / Math.PI} ${px + 48 * (i % 4 === 1 ? 1 : -1)} ${py - 14})`} />
            </g>
          ) : null,
        )}
        <WindLines y0={300} y1={1000} n={12} t0={0.1} speed={1.1} />
        <PopMark x={300} y={760} at={tSnap + 0.2} s={1.7} kind="no" />
        <PopMark x={780} y={760} at={tOk} s={1.7} kind="ok" />
        {t >= tShield && (
          <g transform={`translate(540 480) scale(${pop(t, tShield, 0.5) * 1.35})`}>
            <path d="M0,-110 L92,-76 Q92,40 0,110 Q-92,40 -92,-76 Z" fill="#3ddc84" stroke={OUT} strokeWidth={9} strokeLinejoin="round" />
            <path d="M-38,0 L-10,30 L42,-32" fill="none" stroke="#fff" strokeWidth={17} strokeLinecap="round" strokeLinejoin="round" />
          </g>
        )}
      </S>
      <Pill x={330} y={1745} text="KAKU" at={0.5} color="#ff8a7a" size={52} />
      <Pill x={780} y={1745} text="LENTUR" at={0.7} color="#7be28f" size={52} />
    </>
  );
};

/* 5 ─ Penyebab: angin, gempa, aliran udara (21.3 – 26.7) */
const SceneCauses = () => {
  const t = useT();
  const tA = W('angin', 1);
  const tG = W('getaran', 1);
  const tU = W('udara');
  const q = t > tG && t < tG + 1.6 ? 1 : 0;
  const amp = 36 * eo(t, tA, 0.6) * sway(t, 1.9);
  return (
    <>
      <S>
        <BluePrintBG />
        <g transform={`translate(${f1(q * Math.sin(t * 70) * 6)} 0)`}>
          <rect x={90} y={820} width={900} height={14} fill="#8a8fa8" stroke={OUT} strokeWidth={6} />
          <Tower x={540} y={820} w={130} n={12} fh={36} amp={amp} />
        </g>
        <WindLines y0={470} y1={780} n={6} t0={tA} speed={1.2} len={150} />
        {t >= tU && (
          <g transform={`translate(540 560)`} opacity={eo(t, tU, 0.4) * 0.9}>
            {[0, 1, 2].map((i) => (
              <ellipse key={i} cx={Math.sin(t * 3 + i) * 10} cy={i * 90 - 90} rx={150 + Math.sin(t * 4 + i) * 12} ry={34} fill="none" stroke="#7ce8ff" strokeWidth={8} strokeDasharray="26 18" transform={`rotate(${(t * 40 * (i % 2 ? -1 : 1)) % 360} 0 ${i * 90 - 90})`} />
            ))}
          </g>
        )}
        <Card x={210} y={1350} w={300} h={400} at={tA} label="ANGIN">
          <g transform="translate(0 -30) scale(0.95)">
            <IconWind />
          </g>
        </Card>
        <Card x={540} y={1350} w={300} h={400} at={tG} label="GEMPA" color="#ffb06a">
          <g transform="translate(0 -30) scale(0.95)">
            <IconQuake />
          </g>
        </Card>
        <Card x={870} y={1350} w={300} h={400} at={tU - 0.2} label="ARUS UDARA" color="#7ce8ff">
          <g transform="translate(0 -30) scale(0.9)">
            <IconSwirl />
          </g>
        </Card>
      </S>
      <Pill x={540} y={190} text="PENYEBAB UTAMA" at={0.1} color="#ffd45a" size={64} />
    </>
  );
};

/* 6 ─ Makin tinggi, angin makin besar di atas (26.7 – 31.1) */
const SceneTaller = () => {
  const t = useT();
  const tH = W('tinggi', 0);
  const tW = W('semakin', 1);
  const grow = eo(t, tH, 1.6);
  const n = lerp(9, 28, grow);
  const amp = (6 + (n / 28) * 74) * sway(t, 2.3);
  const topY = 1650 - n * 48;
  const ys = [1500, 1280, 1060, 840, 620, 400];
  return (
    <>
      <S>
        <Sky tone="day" ground={1650} sun={false} />
        <Cloud x={500} y={380} s={1.2} sp={18} o={0.6} />
        <Cloud x={50} y={1000} s={0.9} sp={11} o={0.5} />
        <Tower x={380} y={1650} w={210} n={n} fh={48} amp={amp} spire={n > 26 ? 90 : 0} />
        {ys.map((y, i) => {
          if (y < topY + 40) return null;
          const frac = (1650 - y) / 1250;
          const L = 90 + frac * 150;
          const o = eo(t, tW + i * 0.22, 0.4);
          return <Arrow key={i} x1={265 - L} y1={y} x2={265} y2={y} color={mix('#7ccfff', '#ff5a4a', frac)} w={12 + frac * 14} head={36 + frac * 20} o={o} />;
        })}
        {/* tanda tinggi */}
        <g opacity={eo(t, tH, 0.5)}>
          <Arrow x1={1010} y1={1640} x2={1010} y2={Math.max(topY, 420)} color="#fff" w={14} />
        </g>
      </S>
      <Pill x={800} y={1400} text="SEMAKIN TINGGI" at={tH} color="#ffffff" size={40} />
      <Pill x={790} y={560} text="ANGIN LEBIH KUAT" at={tW + 0.5} color="#ff7a6a" size={38} />
    </>
  );
};

/* 7 ─ Tiga hal: kekakuan, massa, peredaman (31.1 – 37.3) */
const SceneTrio = () => {
  const t = useT();
  const tK = W('kekakuan');
  const tM = W('massa', 0);
  const tP = W('peredaman');
  const tB = W('menyeimbangkan');
  const ang = t < tB ? 0 : 16 * Math.exp(-(t - tB) * 0.9) * sway(t - tB, 1.2) + 0 * 0;
  return (
    <>
      <S>
        <LabBG />
        {/* timbangan */}
        <g transform={`translate(540 560)`}>
          <polygon points="-40,230 40,230 14,10 -14,10" fill="#8a8fa8" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
          <rect x={-110} y={222} width={220} height={26} rx={10} fill="#6a6f88" stroke={OUT} strokeWidth={7} />
          <g transform={`rotate(${f1(ang)})`}>
            <rect x={-270} y={-12} width={540} height={26} rx={13} fill="#ffcf3d" stroke={OUT} strokeWidth={7} />
            {[-1, 1].map((sg) => (
              <g key={sg} transform={`translate(${sg * 250} 0) rotate(${f1(-ang)})`}>
                <line x1={0} y1={0} x2={-70} y2={120} stroke={OUT} strokeWidth={6} />
                <line x1={0} y1={0} x2={70} y2={120} stroke={OUT} strokeWidth={6} />
                <path d="M-90,120 H90 Q80,170 0,170 Q-80,170 -90,120 Z" fill="#d9dbe6" stroke={OUT} strokeWidth={7} strokeLinejoin="round" />
              </g>
            ))}
          </g>
          <circle cx={0} cy={0} r={22} fill="#ff7a5a" stroke={OUT} strokeWidth={7} />
        </g>
        {/* ikon kartu */}
        <Card x={200} y={1330} w={300} h={440} at={tK} label="KEKAKUAN" color="#ffc93a">
          <g transform="translate(0 -30)" strokeLinejoin="round">
            <rect x={-110} y={-10} width={220} height={44} rx={8} fill="#aab2c8" stroke={OUT} strokeWidth={7} />
            <rect x={-110} y={-10} width={220} height={14} rx={6} fill="#dfe4f2" />
            <polygon points="-110,34 -70,34 -90,92" fill="#6a6f88" stroke={OUT} strokeWidth={6} />
            <polygon points="110,34 70,34 90,92" fill="#6a6f88" stroke={OUT} strokeWidth={6} />
            {[-70, -20, 30, 80].map((x) => (
              <circle key={x} cx={x} cy={12} r={6} fill="#6a6f88" stroke={OUT} strokeWidth={3} />
            ))}
          </g>
        </Card>
        <Card x={540} y={1330} w={300} h={440} at={tM} label="MASSA" color="#ffc93a">
          <g transform="translate(0 -20)" strokeLinejoin="round" strokeLinecap="round">
            <path d="M-34,-40 a34,34 0 0 1 68,0" fill="none" stroke={OUT} strokeWidth={22} />
            <path d="M-34,-40 a34,34 0 0 1 68,0" fill="none" stroke="#6a6f88" strokeWidth={10} />
            <path d="M-78,80 L-52,-30 H52 L78,80 Z" fill="#8a8fa8" stroke={OUT} strokeWidth={8} />
            <path d="M-56,-18 H56" stroke="#c9cde0" strokeWidth={8} />
            <text x={0} y={52} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={44} fill="#fff" stroke={OUT} strokeWidth={7} paintOrder="stroke">
              kg
            </text>
          </g>
        </Card>
        <Card x={880} y={1330} w={300} h={440} at={tP} label="PEREDAMAN" color="#ffc93a">
          <g transform="translate(0 -30)" strokeLinejoin="round" strokeLinecap="round">
            <circle cx={0} cy={-92} r={14} fill="#8a8fa8" stroke={OUT} strokeWidth={6} />
            <path d="M-46,-70 L46,-58 L-46,-40 L46,-22 L-46,-4 L46,14 L-46,32 L0,44" fill="none" stroke={OUT} strokeWidth={17} />
            <path d="M-46,-70 L46,-58 L-46,-40 L46,-22 L-46,-4 L46,14 L-46,32 L0,44" fill="none" stroke="#ffcf3d" strokeWidth={8} />
            <rect x={-26} y={-72} width={52} height={90} rx={8} fill="#4a90d9" stroke={OUT} strokeWidth={7} />
            <line x1={0} y1={18} x2={0} y2={82} stroke={OUT} strokeWidth={22} />
            <line x1={0} y1={18} x2={0} y2={82} stroke="#cfd3e4" strokeWidth={10} />
            <circle cx={0} cy={96} r={14} fill="#8a8fa8" stroke={OUT} strokeWidth={6} />
          </g>
        </Card>
      </S>
      <Note x={540} y={190} text="3 hal yang diseimbangkan" at={W('tiga')} size={86} color="#fff4b8" rot={-2} />
    </>
  );
};

/* 8 ─ Terlalu kaku vs terlalu fleksibel (37.3 – 45.3) */
const SceneExtremes = () => {
  const t = useT();
  const tK = W('kaku');
  const tE = W('efisien');
  const tF = W('fleksibel');
  const tB = W('berlebihan', 0);
  const ampF = (40 + 110 * eo(t, tB - 0.6, 1.2)) * sway(t, 1.6) * eo(t, tF, 0.6);
  const dizzy = t > tB;
  return (
    <>
      <S>
        <Sky tone="sunset" ground={1420} skyline={false} />
        <line x1={540} y1={120} x2={540} y2={1920} stroke="#fff" strokeWidth={6} strokeDasharray="20 18" opacity={0.55} />
        {/* kaku */}
        <Tower x={280} y={1420} w={190} n={16} fh={50} body="#7b7f8c" shade="#6c707d" win="#c9cde0" off="#464a58" cols={2} lit={0.3} braces sw={7} />
        {[0, 1, 2].map((k) => (
          <g key={k}>
            {Array.from({length: 6}).map((_, i) => (
              <ellipse key={i} cx={180 + k * 100} cy={1790 - i * 17} rx={46} ry={15} fill="#ffcf3d" stroke={OUT} strokeWidth={5} />
            ))}
          </g>
        ))}
        <text x={280} y={1700} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={60} fill="#fff" stroke={OUT} strokeWidth={9} paintOrder="stroke">
          $$$
        </text>
        <PopMark x={280} y={540} at={tE} s={2.2} kind="no" />
        {/* fleksibel */}
        <Tower x={800} y={1420} w={170} n={16} fh={50} amp={ampF} />
        <g transform={`rotate(${f1(dizzy ? sway(t, 1.2) * 7 : 0)} 800 1770)`}>
          <Person x={800} y={1770} s={1.0} shirt="#e38b3d" mouth={dizzy ? 'o' : 'smile'} armL={dizzy ? 150 : 15} armR={dizzy ? 150 : 15} look={dizzy ? sway(t, 0.9) : 0} />
        </g>
        {dizzy &&
          [0, 1, 2].map((i) => {
            const a = t * 5 + (i * Math.PI * 2) / 3;
            return <circle key={i} cx={800 + Math.cos(a) * 60} cy={1490 + Math.sin(a) * 16} r={11} fill="#ffe27a" stroke={OUT} strokeWidth={4} />;
          })}
      </S>
      <Pill x={280} y={230} text="TERLALU KAKU" at={tK} color="#ff8a7a" size={36} />
      <Pill x={810} y={230} text="TERLALU FLEKSIBEL" at={tF} color="#7ccfff" size={34} />
      <Note x={280} y={360} text="boros & tidak efisien" at={tE + 0.3} size={50} color="#ffe27a" rot={-4} />
      <Note x={810} y={360} text="bikin pusing!" at={tB + 0.5} size={54} color="#ffe27a" rot={4} />
    </>
  );
};

/* 9 ─ Damper (45.3 – 48.5) */
const SceneDamper = () => {
  const t = useT();
  const tD = W('damper', 0);
  const amp = 70 * sway(t, 2.2) * (1 - 0.82 * eo(t, tD, 1.0));
  const topX = 300 + amp;
  const cp = pop(t, W('meredam') + 0.2, 0.5);
  return (
    <>
      <S>
        <LabBG />
        <Tower x={300} y={1650} w={170} n={22} fh={50} amp={amp} />
        {t > W('meredam') && (
          <g>
            <line x1={topX + 60} y1={560} x2={560} y2={600} stroke={OUT} strokeWidth={9} strokeDasharray="14 12" />
            <circle cx={topX} cy={550} r={44} fill="none" stroke="#ffd45a" strokeWidth={10} />
            <g transform={`translate(720 640) scale(${cp})`}>
              <circle r={260} fill="#f3e9cf" stroke={OUT} strokeWidth={10} />
              <g transform="scale(1.9)" strokeLinejoin="round" strokeLinecap="round">
                <circle cx={0} cy={-92} r={14} fill="#8a8fa8" stroke={OUT} strokeWidth={6} />
                <path d="M-46,-70 L46,-58 L-46,-40 L46,-22 L-46,-4 L46,14 L-46,32 L0,44" fill="none" stroke={OUT} strokeWidth={17} />
                <path d="M-46,-70 L46,-58 L-46,-40 L46,-22 L-46,-4 L46,14 L-46,32 L0,44" fill="none" stroke="#ff9a2e" strokeWidth={8} />
                <rect x={-26} y={-72} width={52} height={90} rx={8} fill="#4a90d9" stroke={OUT} strokeWidth={7} />
                <line x1={0} y1={18} x2={0} y2={82} stroke={OUT} strokeWidth={22} />
                <line x1={0} y1={18} x2={0} y2={82} stroke="#cfd3e4" strokeWidth={10} />
                <circle cx={0} cy={96} r={14} fill="#8a8fa8" stroke={OUT} strokeWidth={6} />
              </g>
            </g>
          </g>
        )}
        <Person x={820} y={1650} s={1.5} flip shirt="#4a7bb5" glasses armR={100} armL={20} mouth="smile" />
        <Hardhat x={820} y={1650} s={1.5} flip />
      </S>
      <Pill x={720} y={270} text="DAMPER" at={tD} color="#ffd45a" size={80} />
    </>
  );
};

/* 10 ─ Tuned Mass Damper: massa bergerak melawan arah (48.5 – 55.5) */
const SceneTMD = () => {
  const t = useT();
  const tT = W('Tuned');
  const tM = W('Mass');
  const tD = W('Damper', 1);
  const on = eo(t, tT, 0.8);
  return (
    <>
      <S>
        <BluePrintBG />
        <Pendulum cx={540} top={1020} bot={1640} w={800} A={44} B={118} per={2.4} arrows on={on} r={120} />
      </S>
      <div style={{position: 'absolute', left: 0, right: 0, top: 160, textAlign: 'center', fontFamily: FONT, fontWeight: 800, lineHeight: 1.0, WebkitTextStroke: '12px rgba(22,12,34,0.9)', paintOrder: 'stroke fill'}}>
        {([['TUNED', tT, '#ffe27a'], ['MASS', tM, '#ffffff'], ['DAMPER', tD, '#7ce8ff']] as Array<[string, number, string]>).map(([txt, at, c], i) => {
          const p = pop(t, at, 0.4);
          return (
            <div key={i} style={{fontSize: 130, color: c, opacity: p > 0 ? 1 : 0, transform: `scale(${p})`}}>
              {txt}
            </div>
          );
        })}
      </div>
      <Pill x={300} y={1745} text="GEDUNG" at={W('ayunan')} color="#ff6b5a" size={38} />
      <Pill x={780} y={1745} text="MASSA TAMBAHAN" at={W('massa', 1)} color="#4fc3ff" size={38} />
    </>
  );
};

/* 11 ─ Taipei 101 (55.5 – 63.4) */
const TAIPEI_SHAPE = (i: number): [number, number] => {
  if (i < 4) return [250 - i * 14, 250 - (i + 1) * 14];
  if (i >= 36) return i === 36 ? [120, 74] : i === 37 ? [74, 46] : [46, 30];
  const j = (i - 4) % 4;
  return [lerp(150, 196, j / 4), lerp(150, 196, (j + 1) / 4)];
};
const SceneTaipei = () => {
  const t = useT();
  const tT = W('Taipei');
  const tG = W('menggantung');
  const tB = W('bola', 0);
  const t6 = W('660');
  const amp = 22 * sway(t, 2.6);
  const swing = 0.2 * sway(t, 2.6, 1) * eo(t, tB, 0.6);
  const L = 190;
  const bx = 790 + Math.sin(swing) * L;
  const by = 600 + Math.cos(swing) * L - 60;
  const cp = pop(t, tG, 0.5);
  const floorY = 1700 - 34 * 30;
  return (
    <>
      <S>
        <Sky tone="night" ground={1700} sun={false} skyline={false} />
        <polygon points="270,0 390,0 760,1700 -100,1700" fill="url(#beam)" opacity={0.55} />
        <Tower
          x={330}
          y={1700}
          n={38}
          fh={30}
          amp={amp}
          shape={TAIPEI_SHAPE}
          fill={(i) => (i < 4 ? '#3c6f9a' : (i - 4) % 4 === 0 ? '#e0b54a' : (i - 4) % 8 < 4 ? '#3fb5a8' : '#35a096')}
          cols={3}
          lit={0.8}
          win="#e9fff9"
          off="#1d6a63"
          spire={120}
          sw={5}
        />
        {t >= tG && (
          <g>
            <line x1={330 + amp * 0.82 + 40} y1={floorY} x2={560} y2={600} stroke="#ffd45a" strokeWidth={8} strokeDasharray="14 12" />
            <circle cx={330 + amp * 0.82} cy={floorY} r={36} fill="none" stroke="#ffd45a" strokeWidth={8} />
            <g transform={`translate(790 600) scale(${cp})`}>
              <clipPath id="clipTP">
                <circle r={250} />
              </clipPath>
              <circle r={250} fill="#1b2347" />
              <g clipPath="url(#clipTP)"><g transform="translate(-790 -600)">
                <rect x={500} y={330} width={600} height={40} fill="#8a8fa8" stroke={OUT} strokeWidth={7} />
                {t >= tB && (
                  <g strokeLinecap="round">
                    {[-1, 1].map((sg) => (
                      <line key={sg} x1={790 + sg * 60} y1={370} x2={bx + sg * 56} y2={by - 112} stroke={OUT} strokeWidth={13} />
                    ))}
                    {[-1, 1].map((sg) => (
                      <line key={sg} x1={790 + sg * 60} y1={370} x2={bx + sg * 56} y2={by - 112} stroke="#dfe3ee" strokeWidth={5} />
                    ))}
                    <circle cx={bx} cy={by} r={128} fill="url(#goldBall)" stroke={OUT} strokeWidth={9} />
                    <ellipse cx={bx - 44} cy={by - 50} rx={24} ry={13} fill="#fff" opacity={0.7} transform={`rotate(-35 ${bx - 44} ${by - 50})`} />
                  </g>
                )}
                <rect x={500} y={820} width={600} height={60} fill="#34549a" />
                <Person x={640} y={850} s={0.34} shirt="#e38b3d" mouth="o" look={1} />
              </g></g>
              <circle r={250} fill="none" stroke={OUT} strokeWidth={10} />
            </g>
          </g>
        )}
        <defs>
          <radialGradient id="goldBall" cx="0.35" cy="0.3" r="0.85">
            <stop offset="0" stopColor="#fff3b0" />
            <stop offset="0.5" stopColor="#f0b429" />
            <stop offset="1" stopColor="#a8661a" />
          </radialGradient>
        </defs>
      </S>
      <Pill x={540} y={190} text="TAIPEI 101" sub="Taiwan" at={tT} color="#ffd45a" size={72} />
      <Pill x={790} y={1000} text="660 TON" at={t6} color="#ff9a5a" size={84} />
    </>
  );
};

/* 12 ─ Bola bergerak berlawanan → ayunan berkurang (63.4 – 69.6) */
const SceneOpposite = () => {
  const t = useT();
  const t0 = W('Saat', 1) + 0.3;
  const tA = W('berlawanan');
  const tR = W('berkurang');
  const p = prog(t, t0, tR + 0.8 - t0);
  const X0 = 140;
  const X1 = 940;
  const yc = 480;
  const curve = (damp: boolean) => {
    let d = '';
    const N = 140;
    for (let k = 0; k <= N * p; k++) {
      const u = k / N;
      const a = damp ? 150 * Math.exp(-3.4 * u) : 150;
      d += `${k ? 'L' : 'M'}${f1(lerp(X0, X1, u))},${f1(yc - a * Math.sin(u * Math.PI * 14))} `;
    }
    return d;
  };
  const on = eo(t, 0, 0.6);
  return (
    <>
      <S>
        <BluePrintBG />
        <g transform="translate(540 480) rotate(-1.5) translate(-540 -480)">
          <rect x={90} y={200} width={900} height={560} rx={22} fill="#f3e9cf" stroke={OUT} strokeWidth={9} />
          <line x1={X0} y1={yc} x2={X1} y2={yc} stroke="#7a7280" strokeWidth={4} />
          <line x1={X0} y1={260} x2={X0} y2={700} stroke="#7a7280" strokeWidth={4} />
          {p > 0 && (
            <g fill="none" strokeLinecap="round" strokeLinejoin="round">
              <path d={curve(false)} stroke="#9a94a6" strokeWidth={7} strokeDasharray="14 12" />
              <path d={curve(true)} stroke={OUT} strokeWidth={17} />
              <path d={curve(true)} stroke="#2fbf6a" strokeWidth={9} />
            </g>
          )}
        </g>
        <Pendulum cx={540} top={1020} bot={1640} w={800} A={44} B={118} per={2.4} sphere r={125} arrows on={on} />
        <PopMark x={900} y={250} at={tR + 0.3} s={1.2} kind="ok" />
      </S>
      <Note x={300} y={250} text="tanpa damper" at={t0 + 0.4} size={54} color="#7a7280" rot={-3} />
      <Note x={650} y={700} text="dengan bola baja" at={tA} size={58} color="#1f9a54" rot={-2} />
      <Pill x={300} y={1745} text="GEDUNG" at={0.4} color="#ff6b5a" size={38} />
      <Pill x={780} y={1745} text="BOLA BAJA" at={0.6} color="#4fc3ff" size={38} />
    </>
  );
};

/* 13 ─ Penghuni lantai atas masih terasa goyang (69.6 – 78.7) */
const SceneRoom = () => {
  const t = useT();
  const tM = W('merasakan');
  const tOk = W('aman');
  const tNo = W('tidak', 2);
  const k = eo(t, tM - 0.3, 0.8);
  const rot = 1.5 * sway(t, 3.4) * k;
  const shift = 22 * sway(t, 3.4, 0.4) * k;
  const sloshing = k;
  const [hx, hy] = handOf(380, 1560, 1.9, 1, 60);
  const wv = (x0: number, w: number) => {
    let d = `M${f1(x0)},0`;
    for (let i = 0; i <= 8; i++) d += ` L${f1(x0 + (w * i) / 8)},${f1(Math.sin(t * 7 + i) * 7 * sloshing)}`;
    return d;
  };
  return (
    <>
      <S>
        <g transform={`translate(${f1(shift)} 0) rotate(${f1(rot)} 540 1700)`}>
          <rect x={-60} y={-120} width={1200} height={1680} fill="#d9bb8c" />
          <rect x={-60} y={-120} width={1200} height={250} fill="#c9aa7c" />
          <rect x={-60} y={1500} width={1200} height={60} fill="#b8946a" stroke={OUT} strokeWidth={5} />
          <rect x={-60} y={1560} width={1200} height={500} fill="#8a5a3a" />
          {Array.from({length: 8}).map((_, i) => (
            <line key={i} x1={-60 + i * 160} y1={1560} x2={-200 + i * 220} y2={2000} stroke="#6f4528" strokeWidth={5} />
          ))}
          {/* jendela */}
          <rect x={640} y={330} width={340} height={700} rx={14} fill="#8fd3f4" stroke={OUT} strokeWidth={11} />
          {[0, 1, 2, 3].map((i) => (
            <rect key={i} x={660 + i * 80} y={840 - (i % 2) * 70} width={60} height={190 - 0} fill="#6b8fb0" opacity={0.85} />
          ))}
          <ellipse cx={780 + sway(t, 14) * 30} cy={520} rx={80} ry={26} fill="#fff" opacity={0.85} />
          <line x1={810} y1={330} x2={810} y2={1030} stroke={OUT} strokeWidth={9} />
          <line x1={640} y1={680} x2={980} y2={680} stroke={OUT} strokeWidth={9} />
          {/* lampu gantung */}
          <g transform={`rotate(${f1(11 * sway(t, 2.0, 1) * k)} 330 130)`}>
            <line x1={330} y1={130} x2={330} y2={440} stroke={OUT} strokeWidth={8} />
            <path d="M262,520 L398,520 L362,440 L298,440 Z" fill="#ffcf3d" stroke={OUT} strokeWidth={8} strokeLinejoin="round" />
            <ellipse cx={330} cy={524} rx={44} ry={12} fill="#fff6b0" />
          </g>
          {/* bingkai */}
          <g transform={`rotate(${f1(7 * sway(t, 3.4, 1.2) * k)} 170 640)`}>
            <rect x={90} y={560} width={160} height={130} fill="#f7efe4" stroke={OUT} strokeWidth={9} />
            <path d="M100,680 L150,610 L185,650 L205,625 L240,680 Z" fill="#7be28f" stroke={OUT} strokeWidth={4} strokeLinejoin="round" />
          </g>
          {/* orang + gelas */}
          <Person x={380} y={1560} s={1.9} shirt="#4a7bb5" mouth={t > tM ? 'o' : 'smile'} armR={60} armL={15} look={1} />
          <g transform={`translate(${f1(hx)} ${f1(hy - 30)})`}>
            <path d="M-26,-40 L26,-40 L20,34 L-20,34 Z" fill="#d8f0ff" opacity={0.85} stroke={OUT} strokeWidth={5} strokeLinejoin="round" />
            <g transform="translate(0 -18)">
              <clipPath id="glassClip">
                <path d="M-25,-22 L25,-22 L19,52 L-19,52 Z" />
              </clipPath>
              <g clipPath="url(#glassClip)">
                <path d={`${wv(-30, 60)} V60 H-30 Z`} fill="#4fb6ff" />
              </g>
            </g>
          </g>
          <ellipse cx={380} cy={1566} rx={120} ry={16} fill="#000" opacity={0.2} />
        </g>
      </S>
      <Pill x={540} y={1610} text="STRUKTUR: AMAN" at={tOk} color="#3ddc84" size={46} />
      <Pill x={540} y={1700} text="GERAKAN: TIDAK NYAMAN" at={tNo} color="#ff6b6b" size={42} />
    </>
  );
};

/* 14 ─ Gerakan berlebihan / kerusakan tetap diperiksa (78.7 – 83.4) */
const CRACK = 'M760,1060 L735,1130 L772,1190 L728,1260 L772,1330 L740,1410 L782,1480 L750,1570';
const SceneInspect = () => {
  const t = useT();
  const tE = W('berlebihan', 1);
  const tC = W('kerusakan');
  const tI = W('diperiksa');
  const needle = t < tE ? 10 * sway(t, 2.2) : lerp(10, 46, eo(t, tE, 0.5)) + sway(t, 0.25) * 3 * eo(t, tE + 0.5, 0.3);
  const [nx, ny] = polar(540, 730, 250, needle);
  const lensP = eo(t, tI - 0.2, 0.6);
  const lx = lerp(1010, 740, lensP);
  const ly = 1300;
  const [hx, hy] = handOf(240, 1700, 1.5, -1, 55);
  return (
    <>
      <S>
        <LabBG />
        {/* panel gauge */}
        <rect x={150} y={190} width={780} height={620} rx={26} fill="#8a5a32" stroke={OUT} strokeWidth={9} />
        <rect x={210} y={230} width={660} height={80} rx={12} fill="#2a2630" stroke={OUT} strokeWidth={6} />
        <text x={540} y={288} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={40} fill="#e8e0d0" letterSpacing={3}>
          GERAKAN GEDUNG
        </text>
        <rect x={190} y={335} width={700} height={430} rx={30} fill="#f3e9cf" stroke={OUT} strokeWidth={7} />
        <path d={arcPath(540, 730, 285, -62, 26)} fill="none" stroke="#3ddc84" strokeWidth={24} strokeLinecap="butt" />
        <path d={arcPath(540, 730, 285, 26, 62)} fill="none" stroke="#ff4b4b" strokeWidth={24} strokeLinecap="butt" />
        {Array.from({length: 13}).map((_, i) => {
          const d = -60 + i * 10;
          const [x0, y0] = polar(540, 730, 250, d);
          const [x1, y1] = polar(540, 730, i % 3 === 0 ? 215 : 230, d);
          return <line key={i} x1={x0} y1={y0} x2={x1} y2={y1} stroke={OUT} strokeWidth={5} />;
        })}
        <line x1={540} y1={730} x2={nx} y2={ny} stroke={OUT} strokeWidth={11} strokeLinecap="round" />
        <circle cx={540} cy={730} r={22} fill="#8a8fa8" stroke={OUT} strokeWidth={7} />
        {/* dinding retak */}
        <rect x={470} y={1000} width={540} height={680} fill="#b8b2a6" stroke={OUT} strokeWidth={9} />
        {[1120, 1240, 1360, 1480, 1600].map((y) => (
          <line key={y} x1={470} y1={y} x2={1010} y2={y} stroke="#9a948a" strokeWidth={4} />
        ))}
        {t >= tC && (
          <g fill="none" strokeLinejoin="round" strokeLinecap="round" pathLength={1}>
            <path d={CRACK} pathLength={1} stroke={OUT} strokeWidth={9} strokeDasharray={1} strokeDashoffset={1 - eo(t, tC, 0.9)} />
          </g>
        )}
        {/* insinyur */}
        <Person x={240} y={1700} s={1.5} shirt="#4a7bb5" glasses armR={95} armL={55} mouth="flat" look={1} />
        <Hardhat x={240} y={1700} s={1.5} />
        <Clipboard x={hx + 8} y={hy - 62} s={1.1} rot={-8} />
        <PopMark x={hx + 8} y={hy - 62} at={tI + 0.9} s={0.9} kind="ok" />
        {/* kaca pembesar */}
        {t >= tI - 0.2 && (
          <g>
            <clipPath id="lensClip">
              <circle cx={lx} cy={ly} r={130} />
            </clipPath>
            <circle cx={lx} cy={ly} r={130} fill="#efe8d8" />
            <g clipPath="url(#lensClip)">
              <g transform={`translate(${lx} ${ly}) scale(2.3) translate(-740 -1300)`}>
                <path d={CRACK} fill="none" stroke={OUT} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" />
              </g>
            </g>
            <circle cx={lx} cy={ly} r={130} fill="none" stroke={OUT} strokeWidth={16} />
            <circle cx={lx} cy={ly} r={130} fill="none" stroke="#c9ced8" strokeWidth={7} />
            <line x1={lx + 92} y1={ly + 92} x2={lx + 190} y2={ly + 190} stroke={OUT} strokeWidth={34} strokeLinecap="round" />
            <line x1={lx + 92} y1={ly + 92} x2={lx + 190} y2={ly + 190} stroke="#a8794a" strokeWidth={18} strokeLinecap="round" />
          </g>
        )}
      </S>
      <Note x={540} y={870} text="" at={999} />
      <Pill x={830} y={960} text="BERLEBIHAN!" at={tE + 0.5} until={tC} color="#ff6b6b" size={48} />
    </>
  );
};

/* 15 ─ Tidak harus diam untuk tetap kokoh (83.4 – 87.4) */
const SceneClose = () => {
  const t = useT();
  const tJ = W('Jadi');
  const tK = W('kokoh');
  const amp = 30 * sway(t, 3.0);
  const titleO = eo(t, tJ + 0.1, 0.5);
  return (
    <>
      <S>
        <Sky tone="sunset" ground={1650} />
        <Cloud x={200} y={430} s={1.2} sp={12} />
        <Cloud x={820} y={760} s={0.9} sp={8} />
        <Tower x={500} y={1650} w={210} n={26} fh={52} amp={amp} />
        <Person x={170} y={1795} s={0.55} shirt="#e38b3d" look={1} />
        <Person x={920} y={1805} s={0.55} flip shirt="#6bbf8a" look={-1} />
        <WindLines y0={420} y1={1000} n={6} t0={tJ} speed={0.6} o={0.45} />
        <PopMark x={870} y={530} at={tK} s={2.0} kind="ok" />
      </S>
      <div
        style={{
          position: 'absolute',
          top: 70,
          left: 0,
          right: 0,
          textAlign: 'center',
          opacity: titleO,
          transform: `translateY(${(1 - titleO) * -30}px)`,
          fontFamily: FONT,
          fontWeight: 800,
          color: '#fff',
          lineHeight: 1.05,
          WebkitTextStroke: '10px rgba(42,26,44,0.85)',
          paintOrder: 'stroke fill',
        }}
      >
        <div style={{fontSize: 84}}>TIDAK HARUS DIAM</div>
        <div style={{fontSize: 58, color: '#ffe27a'}}>UNTUK KOKOH</div>
      </div>
      <Pill x={870} y={690} text="KOKOH" at={tK} color="#3ddc84" size={56} />
    </>
  );
};

/* 16 ─ Catatan: terutama angin; gempa ada pertimbangan tambahan (87.4 – akhir) */
const SceneNote = () => {
  const t = useT();
  const tA = W('angin', 4);
  const tG = W('gempa', 2);
  const tX = W('tambahan', 1);
  return (
    <>
      <S>
        <BluePrintBG />
        <Card x={540} y={520} w={800} h={420} at={tA - 0.3} label="" color="#7ccfff">
          <g transform="translate(-230 -10) scale(1.2)">
            <IconWind />
          </g>
          <text x={140} y={14} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={88} fill="#fff" stroke={OUT} strokeWidth={14} paintOrder="stroke">
            ANGIN
          </text>
        </Card>
        <Card x={540} y={1330} w={800} h={420} at={tG - 0.3} label="" color="#ffb06a">
          <g transform="translate(-230 -10) scale(1.2)">
            <IconQuake />
          </g>
          <text x={140} y={14} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={88} fill="#fff" stroke={OUT} strokeWidth={14} paintOrder="stroke">
            GEMPA
          </text>
        </Card>
      </S>
      <Note x={540} y={210} text="Catatan" at={0.1} size={110} color="#fff4b8" rot={-3} />
      <Pill x={540} y={190 + 0} text="" at={999} />
      <Note x={540} y={780} text="fokus pembahasan ini" at={tA + 0.5} size={64} color="#9fe3ff" rot={-2} />
      <Pill x={540} y={1620} text="+ PERTIMBANGAN DESAIN TAMBAHAN" at={tX} color="#ffb06a" size={38} />
    </>
  );
};

const Watermark = () => (
  <div
    style={{
      position: 'absolute',
      left: 38,
      bottom: 46,
      fontFamily: FONT,
      fontWeight: 800,
      fontSize: 40,
      color: '#fff',
      opacity: 0.88,
      letterSpacing: 0.5,
      WebkitTextStroke: '8px rgba(22,12,34,0.75)',
      paintOrder: 'stroke fill',
      textShadow: '0 3px 8px rgba(0,0,0,0.45)',
    }}
  >
    @semestakita
  </div>
);

/* ═══════════════════════════ SFX ═══════════════════════════ */
const SFX_VOL = 1; // pengali volume semua efek
const SFX_GAIN: Record<string, number> = {click: 2.2, flash: 0.9, pop: 0.8, whoosh: 0.9, trans: 1}; // koreksi loudness tiap file
const SFX: Array<[number, string, number]> = [
  [0.05, 'whoosh', 0.25],
  [W('benar-benar'), 'click', 0.3],
  [W('Saat', 0), 'trans', 0.28],
  [W('angin', 0), 'whoosh', 0.4],
  [W('getaran', 0), 'whoosh', 0.45],
  [W('bagian', 0), 'pop', 0.35],
  [W('Gerakan', 0), 'trans', 0.28],
  [W('diperhitungkan'), 'pop', 0.32],
  [W('bukan'), 'pop', 0.3],
  [W('Justru'), 'trans', 0.28],
  [W('bergerak', 1) + 0.5, 'click', 0.35],
  [W('terkendali'), 'click', 0.3],
  [W('keselamatan'), 'flash', 0.32],
  [W('Penyebab'), 'trans', 0.28],
  [W('angin', 1), 'whoosh', 0.4],
  [W('getaran', 1), 'whoosh', 0.4],
  [W('udara'), 'trans', 0.35],
  [W('Semakin', 0), 'trans', 0.28],
  [W('tinggi', 0), 'trans', 0.25],
  [W('Karena'), 'trans', 0.28],
  [W('kekakuan'), 'pop', 0.35],
  [W('massa', 0), 'pop', 0.35],
  [W('peredaman'), 'pop', 0.35],
  [W('Terlalu', 0), 'trans', 0.28],
  [W('efisien'), 'pop', 0.3],
  [W('fleksibel'), 'pop', 0.35],
  [W('Untuk'), 'trans', 0.28],
  [W('damper', 0), 'click', 0.35],
  [W('Salah'), 'trans', 0.28],
  [W('Tuned'), 'pop', 0.35],
  [W('Mass'), 'pop', 0.35],
  [W('Damper', 1), 'pop', 0.35],
  [W('Contohnya'), 'whoosh', 0.28],
  [W('Taipei'), 'flash', 0.34],
  [W('bola', 0), 'click', 0.4],
  [W('660'), 'flash', 0.5],
  [W('Saat', 1), 'trans', 0.28],
  [W('berlawanan'), 'trans', 0.35],
  [W('berkurang'), 'click', 0.32],
  [W('Penghuni', 1), 'trans', 0.28],
  [W('merasakan'), 'click', 0.35],
  [W('aman'), 'click', 0.3],
  [W('nyaman'), 'pop', 0.28],
  [W('Namun'), 'trans', 0.28],
  [W('berlebihan', 1), 'trans', 0.28],
  [W('kerusakan'), 'flash', 0.4],
  [W('diperiksa'), 'click', 0.3],
  [W('Jadi'), 'whoosh', 0.28],
  [W('kokoh'), 'flash', 0.36],
  [W('Pembahasan'), 'trans', 0.28],
  [W('angin', 4), 'pop', 0.35],
  [W('gempa', 2), 'whoosh', 0.3],
];

/* ═══════════════════════════ ROOT ═══════════════════════════ */
export const Gedung: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const endFade = interpolate(t, [TOTAL_SECONDS - 0.7, TOTAL_SECONDS], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <TCtx.Provider value={t}>
      <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
        {/* ───── visual ───── */}
        <Scene a={0} b={W('Saat', 0)} fade={0}><SceneHook /></Scene>
        <Scene a={W('Saat', 0)} b={W('Gerakan', 0)}><SceneSway /></Scene>
        <Scene a={W('Gerakan', 0)} b={W('Justru')}><SceneDesign /></Scene>
        <Scene a={W('Justru')} b={W('Penyebab')}><SceneControlled /></Scene>
        <Scene a={W('Penyebab')} b={W('Semakin', 0)}><SceneCauses /></Scene>
        <Scene a={W('Semakin', 0)} b={W('Karena')}><SceneTaller /></Scene>
        <Scene a={W('Karena')} b={W('Terlalu', 0)}><SceneTrio /></Scene>
        <Scene a={W('Terlalu', 0)} b={W('Untuk')}><SceneExtremes /></Scene>
        <Scene a={W('Untuk')} b={W('Salah')}><SceneDamper /></Scene>
        <Scene a={W('Salah')} b={W('Contohnya')}><SceneTMD /></Scene>
        <Scene a={W('Contohnya')} b={W('Saat', 1)}><SceneTaipei /></Scene>
        <Scene a={W('Saat', 1)} b={W('Penghuni', 1)}><SceneOpposite /></Scene>
        <Scene a={W('Penghuni', 1)} b={W('Namun')}><SceneRoom /></Scene>
        <Scene a={W('Namun')} b={W('Jadi')}><SceneInspect /></Scene>
        <Scene a={W('Jadi')} b={W('Pembahasan')}><SceneClose /></Scene>
        <Scene a={W('Pembahasan')} b={TOTAL_SECONDS + 1} fade={0.25}><SceneNote /></Scene>
        <Vignette />
        <Caption />
        <Watermark />
        <AbsoluteFill style={{background: '#000', opacity: endFade, pointerEvents: 'none'}} />

        {/* ───── audio: narasi ───── */}
        <Audio src={staticFile('narration.mp3')} />

        {/* ───── audio: efek suara ───── */}
        {SFX.map(([at, name, vol], i) => (
          <Sequence key={i} from={Math.max(0, Math.round(at * FPS))} durationInFrames={Math.round(2.6 * FPS)}>
            <Audio src={staticFile(`sfx/${name}.mp3`)} volume={Math.min(1, vol * SFX_VOL * (SFX_GAIN[name] ?? 1))} />
          </Sequence>
        ))}
      </AbsoluteFill>
    </TCtx.Provider>
  );
};

export default Gedung;
