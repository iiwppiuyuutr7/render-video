import {loadFont} from "@remotion/google-fonts/Poppins";

const {fontFamily} = loadFont("normal", {
  weights: ["400", "600", "700", "800"],
  subsets: ["latin"],
});

export const FONT: string = fontFamily;
