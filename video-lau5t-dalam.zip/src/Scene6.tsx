import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {C, HEIGHT, WIDTH, fmt, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Glow, Particles, Txt, popIn} from "./common";
import {Amphipod, Snailfish} from "./creatures";

const TRENCH =
  "M0 560 L300 600 L430 1000 L500 1500 L540 1680 L580 1500 L650 1000 L780 600 L1080 540 L1080 1920 L0 1920 Z";

export const Scene6: React.FC = () => {
  const t = useT();

  const label = prog(t, 72.3, 73.0);
  const probe = prog(t, 72.6, 75.7, Easing.inOut(Easing.cubic));
  const depth = 10935 * probe;
  const probeY = 560 + probe * 1120;
  const probeX = 540 + (1 - Math.min(1, probe * 1.15)) * 0 + Math.sin(t * 1.2) * 6;
  const chip = (t0: number) => popIn(t, t0, 0.5);
  const lifeP = prog(t, 75.6, 76.5);
  const marker = prog(t, 74.2, 74.9);

  return (
    <AbsoluteFill style={{background: "linear-gradient(180deg,#04112b 0%,#020817 50%,#01030a 100%)"}}>
      <Particles count={30} seed="s6" color="#bfe9ff" speed={14} dir={1} opacity={0.3} maxR={2.5} />

      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <path d={TRENCH} fill="#0a1830" stroke="#25497f" strokeWidth={5} />
        <path d="M0 560 L300 600 L430 1000 L500 1500 L540 1680 L580 1500 L650 1000 L780 600 L1080 540" fill="none" stroke="#3b6fb8" strokeWidth={5} opacity={0.8} />
        {/* Lampu penjelajah */}
        <polygon points={`${probeX},${probeY} ${probeX - 120},${probeY + 240} ${probeX + 120},${probeY + 240}`} fill="#fff6c8" opacity={0.09} />
        <Glow x={probeX} y={probeY} r={90} color="#fff1a8" intensity={0.8} />
        <circle cx={probeX} cy={probeY} r={10} fill="#fffbe0" />
        <line x1={probeX} y1={560} x2={probeX} y2={probeY} stroke="#fff6c8" strokeWidth={2} opacity={0.3} strokeDasharray="6 10" />
        {/* Penanda dasar palung */}
        <g opacity={marker}>
          <line x1={540} y1={1700} x2={540} y2={1760} stroke={C.cyan} strokeWidth={4} />
          <path d="M520 1740 L540 1770 L560 1740" fill="none" stroke={C.cyan} strokeWidth={4} />
        </g>
        {/* Kehidupan di dasar */}
        <g opacity={lifeP} transform={`translate(630 1610) scale(0.34)`}>
          <Snailfish t={t} glow={0.5} />
        </g>
        <g opacity={lifeP} transform={`translate(420 1650) scale(0.4)`}>
          <Amphipod t={t} />
        </g>
      </svg>

      <Txt y={200} size={40} weight={600} spacing={8} color="#bdeeff" opacity={label}>
        PALUNG MARIANA
      </Txt>
      <Txt y={255} size={32} weight={400} spacing={3} color="#8fb8d6" opacity={label}>
        Samudra Pasifik bagian barat
      </Txt>
      <div
        style={{
          position: "absolute",
          top: 330,
          left: 0,
          width: WIDTH,
          textAlign: "center",
          fontFamily: FONT,
          fontWeight: 800,
          fontSize: 190,
          color: "#ffffff",
          opacity: label,
          lineHeight: 1.1,
          textShadow: "0 6px 30px rgba(0,0,0,0.5)",
        }}
      >
        {fmt(depth)}
        <span style={{fontSize: 90, fontWeight: 600, marginLeft: 14, color: C.cyan}}>m</span>
      </div>
      <Txt y={580} size={46} weight={700} color={C.cyan} opacity={marker}>
        Challenger Deep
      </Txt>

      {/* Chip penghuni */}
      <div style={{position: "absolute", left: 0, top: 1300, width: WIDTH, display: "flex", flexDirection: "column", alignItems: "center", gap: 18}}>
        {[
          {n: "Amphipoda", t0: 76.0},
          {n: "Mikroorganisme", t0: 76.7},
          {n: "Snailfish", t0: 77.3},
        ].map((c) => {
          const p = chip(c.t0);
          return (
            <div
              key={c.n}
              style={{
                fontFamily: FONT,
                fontWeight: 700,
                fontSize: 44,
                color: "#04112b",
                background: "#e6f9ff",
                padding: "8px 38px",
                borderRadius: 50,
                opacity: Math.min(1, p),
                transform: `scale(${0.7 + 0.3 * p})`,
                boxShadow: "0 0 30px rgba(34,211,238,0.5)",
              }}
            >
              {c.n}
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
