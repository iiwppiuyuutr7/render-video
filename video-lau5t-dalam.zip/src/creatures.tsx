import React from "react";
import {Glow} from "./common";

// Semua makhluk digambar di koordinat lokal (pusat = 0,0) agar mudah diposisikan dengan <g transform>.

export const Angler: React.FC<{t: number; glow?: number}> = ({t, glow = 1}) => {
  const bob = Math.sin(t * 1.6) * 8;
  const pulse = 0.78 + 0.22 * Math.sin(t * 4.2);
  const teeth: React.ReactNode[] = [];
  for (let i = 0; i < 7; i++) {
    const x = -150 + i * 20;
    const y = 22 + i * 2.2;
    teeth.push(<path key={i} d={`M${x} ${y} L${x + 7} ${y + 26} L${x + 14} ${y}`} fill="#dff4ff" />);
  }
  return (
    <g transform={`translate(0 ${bob})`}>
      <path d="M150 0 L262 -72 Q240 0 262 72 Z" fill="#101f3d" stroke="#2b5aa0" strokeWidth={4} />
      <path
        d="M-170 10 C-175 -90 -60 -130 40 -110 C120 -95 170 -50 170 0 C170 60 100 110 10 115 C-80 118 -165 90 -170 10 Z"
        fill="#0d1b36"
        stroke="#2b5aa0"
        strokeWidth={4}
      />
      <path d="M-170 12 C-120 44 -60 54 5 42" stroke="#3b6fb8" strokeWidth={4} fill="none" />
      {teeth}
      <path d="M20 -105 Q60 -160 100 -110 Z" fill="#14305e" stroke="#2b5aa0" strokeWidth={3} />
      <path d="M40 100 Q80 150 110 98 Z" fill="#14305e" stroke="#2b5aa0" strokeWidth={3} />
      <circle cx={-108} cy={-28} r={20} fill="#e8f6ff" />
      <circle cx={-114} cy={-28} r={9} fill="#04112b" />
      <path d="M-86 -108 Q-120 -240 -232 -218" stroke="#2b5aa0" strokeWidth={5} fill="none" strokeLinecap="round" />
      <Glow x={-232} y={-218} r={150 * pulse} color="#5eead4" intensity={glow * 0.9} />
      <circle cx={-232} cy={-218} r={15} fill="#e9fffb" opacity={glow} />
    </g>
  );
};

export const SmallFish: React.FC<{t: number; color?: string; phase?: number}> = ({t, color = "#ffd166", phase = 0}) => {
  const wag = Math.sin(t * 7 + phase) * 6;
  return (
    <g>
      <path d={`M40 0 L72 ${-22 + wag} Q60 0 72 ${22 + wag} Z`} fill={color} opacity={0.9} />
      <ellipse cx={0} cy={0} rx={48} ry={24} fill={color} />
      <ellipse cx={-4} cy={8} rx={34} ry={10} fill="#fff" opacity={0.25} />
      <circle cx={-26} cy={-6} r={5} fill="#04112b" />
    </g>
  );
};

export const Lanternfish: React.FC<{t: number}> = ({t}) => {
  const dots: React.ReactNode[] = [];
  for (let i = 0; i < 9; i++) {
    const x = -110 + i * 24;
    dots.push(<circle key={i} cx={x} cy={26 - Math.abs(i - 4) * 1.5} r={5} fill="#7ff5ff" opacity={0.6 + 0.4 * Math.sin(t * 3 + i)} />);
  }
  const wag = Math.sin(t * 5) * 8;
  return (
    <g>
      <path d={`M150 0 L220 ${-50 + wag} Q200 0 220 ${50 + wag} Z`} fill="#6f8fb3" />
      <path d="M-170 0 C-150 -70 20 -80 150 -8 C20 70 -150 70 -170 0 Z" fill="#7f9fc4" stroke="#bcd7f2" strokeWidth={3} />
      <path d="M-160 8 C-60 40 40 40 140 0 C40 56 -120 60 -160 8 Z" fill="#c7dcf0" opacity={0.55} />
      <path d="M-20 -72 Q10 -110 50 -64 Z" fill="#6f8fb3" />
      <circle cx={-118} cy={-12} r={16} fill="#eaf6ff" />
      <circle cx={-124} cy={-12} r={8} fill="#04112b" />
      {dots}
    </g>
  );
};

export const Dumbo: React.FC<{t: number}> = ({t}) => {
  const flap = Math.sin(t * 3) * 14;
  const tent: React.ReactNode[] = [];
  for (let i = 0; i < 7; i++) {
    const x = -90 + i * 30;
    tent.push(
      <path
        key={i}
        d={`M${x} 60 Q${x + Math.sin(t * 2 + i) * 14} 120 ${x} 170`}
        stroke="#f4b8c9"
        strokeWidth={9}
        fill="none"
        strokeLinecap="round"
        opacity={0.85}
      />,
    );
  }
  return (
    <g>
      <path d={`M-100 -20 Q-190 ${-70 + flap} -170 ${-10 + flap} Q-140 20 -100 20 Z`} fill="#f7c9d6" opacity={0.9} />
      <path d={`M100 -20 Q190 ${-70 + flap} 170 ${-10 + flap} Q140 20 100 20 Z`} fill="#f7c9d6" opacity={0.9} />
      <path d="M-110 50 C-120 -60 120 -60 110 50 C70 80 -70 80 -110 50 Z" fill="#f4b8c9" />
      {tent}
      <circle cx={-40} cy={0} r={10} fill="#04112b" />
      <circle cx={40} cy={0} r={10} fill="#04112b" />
    </g>
  );
};

export const Snailfish: React.FC<{t: number; glow?: number}> = ({t, glow = 0.4}) => {
  const wag = Math.sin(t * 2.4) * 14;
  return (
    <g>
      <path
        d={`M40 -20 C140 ${-40 + wag} 230 ${-10 + wag} 300 ${wag} C230 ${20 + wag} 140 ${40 + wag} 40 24 Z`}
        fill="#f3d9e6"
        opacity={0.55}
        stroke="#ffe9f3"
        strokeWidth={3}
      />
      <path d={`M130 -26 Q190 ${-70 + wag} 240 -10 Z`} fill="#f3d9e6" opacity={0.35} />
      <path d="M-70 0 C-70 -66 60 -70 70 0 C60 70 -70 66 -70 0 Z" fill="#f6e3ee" opacity={0.7} stroke="#ffe9f3" strokeWidth={3} />
      <circle cx={-34} cy={-10} r={13} fill="#04112b" />
      <circle cx={-38} cy={-14} r={4} fill="#ffffff" />
      <Glow x={-20} y={0} r={130} color="#ffd6ea" intensity={glow} />
    </g>
  );
};

export const Amphipod: React.FC<{t: number}> = ({t}) => {
  const seg: React.ReactNode[] = [];
  for (let i = 0; i < 7; i++) {
    const x = -90 + i * 30;
    const y = -Math.sin((i / 6) * Math.PI) * 36;
    const w = 20 - i * 1.2;
    seg.push(<ellipse key={i} cx={x} cy={y} rx={22} ry={w} fill="#f2c9a4" stroke="#ffe2c4" strokeWidth={2} />);
    seg.push(
      <path
        key={`l${i}`}
        d={`M${x} ${y + w - 2} L${x - 8 + Math.sin(t * 6 + i) * 5} ${y + w + 26}`}
        stroke="#ffe2c4"
        strokeWidth={3}
        strokeLinecap="round"
      />,
    );
  }
  return (
    <g>
      {seg}
      <path d="M-104 -6 Q-150 -34 -176 -24" stroke="#ffe2c4" strokeWidth={3} fill="none" />
      <path d="M-104 -2 Q-150 -4 -180 8" stroke="#ffe2c4" strokeWidth={3} fill="none" />
      <circle cx={-98} cy={-8} r={5} fill="#04112b" />
    </g>
  );
};

export const CombJelly: React.FC<{t: number}> = ({t}) => {
  const rows: React.ReactNode[] = [];
  const hues = ["#5eead4", "#7dd3fc", "#c4b5fd", "#f9a8d4"];
  for (let r = 0; r < 8; r++) {
    const a = ((r - 3.5) / 4) * 1.1;
    for (let k = 0; k < 9; k++) {
      const yy = -95 + k * 24;
      const xx = Math.sin(a) * 90 * Math.cos((k / 8) * Math.PI - Math.PI / 2 + 0.0001) * 1.0;
      const lit = 0.25 + 0.75 * Math.max(0, Math.sin(t * 6 - k * 0.9 + r * 0.5));
      rows.push(<circle key={`${r}-${k}`} cx={xx * 0.9 + Math.sin(a) * 40} cy={yy} r={4.5} fill={hues[(r + k) % 4]} opacity={lit} />);
    }
  }
  return (
    <g transform={`rotate(${Math.sin(t * 0.8) * 6})`}>
      <ellipse cx={0} cy={0} rx={92} ry={118} fill="#a5d8ff" opacity={0.14} stroke="#bfe7ff" strokeWidth={3} />
      {rows}
      <path d={`M-20 116 Q${-34 + Math.sin(t * 2) * 10} 190 -10 250`} stroke="#bfe7ff" strokeWidth={4} fill="none" opacity={0.6} />
      <path d={`M20 116 Q${34 + Math.sin(t * 2 + 1) * 10} 190 10 250`} stroke="#bfe7ff" strokeWidth={4} fill="none" opacity={0.6} />
    </g>
  );
};

export const Atolla: React.FC<{t: number}> = ({t}) => {
  const lights: React.ReactNode[] = [];
  const n = 16;
  for (let i = 0; i < n; i++) {
    const a = Math.PI + (i / (n - 1)) * Math.PI;
    const x = Math.cos(a) * 112;
    const y = Math.sin(a) * 78 * -1;
    const lit = Math.max(0, Math.sin(t * 7 - i * 0.7));
    lights.push(<circle key={i} cx={x} cy={y * -1 + 6} r={6 + lit * 3} fill="#7dd3fc" opacity={0.25 + 0.75 * lit} />);
  }
  const tent: React.ReactNode[] = [];
  for (let i = 0; i < 9; i++) {
    const x = -96 + i * 24;
    tent.push(
      <path
        key={i}
        d={`M${x} 16 Q${x + Math.sin(t * 2 + i) * 16} 80 ${x} 140`}
        stroke="#b91c3c"
        strokeWidth={6}
        fill="none"
        strokeLinecap="round"
        opacity={0.8}
      />,
    );
  }
  return (
    <g>
      {tent}
      <path d="M-124 12 C-124 -110 124 -110 124 12 Z" fill="#9f1239" stroke="#fb7185" strokeWidth={3} />
      <path d="M-100 8 C-96 -70 96 -70 100 8 Z" fill="#be123c" opacity={0.65} />
      {lights}
    </g>
  );
};
