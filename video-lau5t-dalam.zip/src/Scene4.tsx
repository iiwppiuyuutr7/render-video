import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {C, HEIGHT, WIDTH, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Glow, Particles, Txt, popIn} from "./common";
import {Angler, Atolla, CombJelly} from "./creatures";

const HEART = "M0 22 C-44 -10 -44 -52 -12 -52 C-2 -52 0 -42 0 -38 C0 -42 2 -52 12 -52 C44 -52 44 -10 0 22 Z";

const Icon: React.FC<{kind: number; t: number}> = ({kind, t}) => {
  const pulse = 0.7 + 0.3 * Math.sin(t * 5);
  if (kind === 0) {
    const fx = 330 - ((t * 60) % 150);
    return (
      <g>
        <Glow x={150} y={115} r={70} color="#5eead4" intensity={pulse} />
        <circle cx={150} cy={115} r={9} fill="#eafffb" />
        <g transform={`translate(${fx} 115) scale(0.55) scale(-1 1)`}>
          <ellipse cx={0} cy={0} rx={48} ry={24} fill="#7a93b8" />
          <path d="M40 0 L72 -22 Q60 0 72 22 Z" fill="#7a93b8" />
          <circle cx={-26} cy={-6} r={5} fill="#04112b" />
        </g>
      </g>
    );
  }
  if (kind === 1) {
    const lines: React.ReactNode[] = [];
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const len = 26 + 22 * Math.abs(Math.sin(t * 6 + i));
      lines.push(
        <line key={i} x1={150 + Math.cos(a) * 36} y1={115 + Math.sin(a) * 36} x2={150 + Math.cos(a) * (36 + len)} y2={115 + Math.sin(a) * (36 + len)} stroke="#e0fbff" strokeWidth={4} strokeLinecap="round" />,
      );
    }
    const px = 290 + ((t * 70) % 120);
    return (
      <g>
        <Glow x={150} y={115} r={90} color="#7dd3fc" intensity={pulse} />
        {lines}
        <circle cx={150} cy={115} r={22} fill="#ffffff" />
        <g transform={`translate(${px} 115) scale(0.7)`} opacity={Math.max(0, 1 - ((px - 290) / 120) * 0.9)}>
          <path d="M-60 0 C-40 -50 40 -50 70 0 C40 50 -40 50 -60 0 Z" fill="#1c2c4d" stroke="#3b5a8c" strokeWidth={3} />
          <circle cx={-34} cy={-8} r={7} fill="#fff" />
        </g>
      </g>
    );
  }
  if (kind === 2) {
    const arcs: React.ReactNode[] = [];
    for (let i = 0; i < 3; i++) {
      const k = (t * 0.9 + i / 3) % 1;
      arcs.push(<circle key={i} cx={85} cy={115} r={20 + k * 130} fill="none" stroke="#7dd3fc" strokeWidth={4} opacity={(1 - k) * 0.8} />);
    }
    return (
      <g>
        {arcs}
        <Glow x={85} y={115} r={50} color="#5eead4" intensity={pulse} />
        <circle cx={85} cy={115} r={10} fill="#eafffb" />
        <Glow x={365} y={115} r={50} color="#5eead4" intensity={0.7 + 0.3 * Math.sin(t * 5 + 2)} />
        <circle cx={365} cy={115} r={10} fill="#eafffb" />
      </g>
    );
  }
  const near = 0.5 + 0.5 * Math.sin(t * 2);
  return (
    <g>
      <Glow x={110 + near * 25} y={130} r={55} color="#5eead4" intensity={pulse} />
      <circle cx={110 + near * 25} cy={130} r={10} fill="#eafffb" />
      <Glow x={340 - near * 25} y={130} r={55} color="#f9a8d4" intensity={pulse} />
      <circle cx={340 - near * 25} cy={130} r={10} fill="#fff1f7" />
      <g transform={`translate(225 ${105 - near * 6}) scale(${0.9 + 0.2 * near})`}>
        <path d={HEART} fill="#f9a8d4" opacity={0.95} />
      </g>
    </g>
  );
};

const CARDS = ["Menarik mangsa", "Membingungkan predator", "Berkomunikasi", "Menarik pasangan"];
const CARD_T = [49.8, 51.0, 52.3, 53.5];

const ORGS = [
  {name: "Anglerfish", sub: "Organ bercahaya sebagai umpan", t0: 54.9},
  {name: "Comb jelly", sub: "Menghasilkan cahaya", t0: 56.0},
  {name: "Ubur-ubur Atolla", sub: "Pola cahaya saat terganggu", t0: 57.1},
];

export const Scene4: React.FC = () => {
  const t = useT();

  const dotP = prog(t, 43.5, 44.4);
  const bodyP = prog(t, 44.6, 46.8, Easing.inOut(Easing.cubic));
  const moveUp = prog(t, 48.9, 49.9, Easing.inOut(Easing.cubic));
  const gridO = prog(t, 49.3, 49.8) * (1 - prog(t, 54.4, 54.8));
  const orgO = prog(t, 54.8, 55.0);
  const mainO = 1 - prog(t, 54.3, 54.8);

  // Posisi dan skala angler utama
  const cx = 560;
  const cy = 900 - 380 * moveUp;
  const s = 1.15 - 0.45 * moveUp;
  const bob = Math.sin(t * 1.6) * 8;
  const lureX = cx + s * -232;
  const lureY = cy + s * (-218 + bob);

  const titleP = prog(t, 47.0, 47.8);
  const capP = prog(t, 46.3, 47.0) * (1 - prog(t, 48.6, 49.0));

  return (
    <AbsoluteFill style={{background: "radial-gradient(ellipse at 50% 40%, #04142e 0%, #01040d 75%)"}}>
      <Particles count={35} seed="s4" color="#5eead4" speed={10} dir={-1} opacity={0.35} maxR={3} sway={30} />

      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        <g opacity={mainO}>
          {/* Titik cahaya awal */}
          <g>
            <Glow x={lureX} y={lureY} r={(60 + 90 * bodyP) * dotP} color="#5eead4" intensity={0.9} />
            <circle cx={lureX} cy={lureY} r={11 * dotP} fill="#eafffb" />
          </g>
          <g transform={`translate(${cx} ${cy}) scale(${s})`} opacity={bodyP}>
            <Angler t={t} glow={1} />
          </g>
        </g>
      </svg>

      <Txt y={190} size={78} weight={800} spacing={8} color={C.cyan} opacity={titleP} dy={(1 - titleP) * 30}>
        BIOLUMINESENSI
      </Txt>
      <Txt y={1390} size={48} weight={600} color="#d6f6ff" opacity={capP}>
        cahaya dari reaksi kimia
      </Txt>

      {/* Empat fungsi cahaya */}
      <div style={{opacity: gridO}}>
        {CARDS.map((label, i) => {
          const p = popIn(t, CARD_T[i], 0.6);
          const col = i % 2;
          const row = Math.floor(i / 2);
          return (
            <div
              key={label}
              style={{
                position: "absolute",
                left: 60 + col * 480,
                top: 870 + row * 340,
                width: 450,
                height: 310,
                borderRadius: 30,
                background: "rgba(10,40,84,0.6)",
                border: "2px solid rgba(94,234,212,0.35)",
                boxShadow: "0 0 40px rgba(34,211,238,0.12)",
                transform: `scale(${0.75 + 0.25 * p})`,
                opacity: Math.min(1, p),
                overflow: "hidden",
              }}
            >
              <svg width={450} height={310}>
                <Icon kind={i} t={t} />
              </svg>
              <div
                style={{
                  position: "absolute",
                  bottom: 18,
                  width: "100%",
                  textAlign: "center",
                  fontFamily: FONT,
                  fontWeight: 700,
                  fontSize: 32,
                  color: "#ffffff",
                }}
              >
                {label}
              </div>
            </div>
          );
        })}
      </div>

      {/* Tiga contoh organisme */}
      <div style={{opacity: orgO}}>
        {ORGS.map((o, i) => {
          const p = popIn(t, o.t0, 0.7);
          const y = 520 + i * 440;
          return (
            <div key={o.name} style={{opacity: Math.min(1, p), transform: `translateX(${(1 - p) * -120}px)`}}>
              <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
                <Glow x={260} y={y} r={190} color={i === 2 ? "#7dd3fc" : "#5eead4"} intensity={0.35} />
                <g transform={`translate(260 ${y + (i === 0 ? 40 : i === 1 ? 10 : 0)}) scale(${i === 0 ? 0.5 : i === 1 ? 0.85 : 1.05})`}>
                  {i === 0 && <Angler t={t} glow={1} />}
                  {i === 1 && <CombJelly t={t} />}
                  {i === 2 && <Atolla t={t} />}
                </g>
              </svg>
              <Txt y={y - 70} x={500} width={540} align="left" size={56} weight={800}>
                {o.name}
              </Txt>
              <Txt y={y + 15} x={500} width={540} align="left" size={36} weight={400} color="#bfe9ff">
                {o.sub}
              </Txt>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
