import React from "react";
import {AbsoluteFill, Easing, random} from "remotion";
import {C, HEIGHT, WIDTH, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Glow, Particles, Txt, popIn} from "./common";

const SEA_Y = 1560;

// ---------- Marine snow ----------
const Plankton: React.FC<{t: number}> = ({t}) => {
  const items: React.ReactNode[] = [];
  for (let i = 0; i < 14; i++) {
    const x = 60 + random(`pk-x-${i}`) * 960;
    const y = 120 + random(`pk-y-${i}`) * 260 + Math.sin(t * 1.2 + i) * 10;
    const r = 6 + random(`pk-r-${i}`) * 10;
    items.push(<circle key={i} cx={x} cy={y} r={r} fill="#c8f7d8" opacity={0.7} />);
    items.push(<circle key={`c${i}`} cx={x} cy={y} r={r * 0.4} fill="#4ade80" opacity={0.8} />);
  }
  return <g>{items}</g>;
};

const DeadFish: React.FC = () => (
  <g>
    <ellipse cx={0} cy={0} rx={60} ry={26} fill="#5b7493" />
    <path d="M52 0 L88 -24 Q76 0 88 24 Z" fill="#5b7493" />
    <path d="M-30 -4 L-10 4 M-30 4 L-10 -4" stroke="#031024" strokeWidth={4} strokeLinecap="round" />
  </g>
);

// ---------- Whale fall ----------
const WhaleSilhouette: React.FC = () => (
  <g>
    <path d="M-330 0 C-330 -110 -120 -150 120 -110 C240 -90 300 -40 350 -60 L430 -120 C430 -40 400 20 380 40 C400 80 430 140 430 190 L350 130 C300 110 240 120 120 110 C-120 150 -330 110 -330 0 Z" fill="#2f5a8e" stroke="#7fb2ee" strokeWidth={5} />
    <path d="M-200 60 C-100 130 60 140 150 100" stroke="#2b5aa0" strokeWidth={4} fill="none" opacity={0.6} />
    <path d="M-40 70 L40 190 L70 70 Z" fill="#2f5a8e" stroke="#7fb2ee" strokeWidth={4} />
    <circle cx={-250} cy={-20} r={9} fill="#9fc3ea" />
  </g>
);

const Skeleton: React.FC<{p: number}> = ({p}) => {
  const ribs: React.ReactNode[] = [];
  for (let i = 0; i < 8; i++) {
    const x = -150 + i * 55;
    const h = 120 - Math.abs(i - 3) * 14;
    ribs.push(
      <path key={i} d={`M${x} 0 Q${x + 40} ${-h} ${x + 8} ${-h - 20}`} stroke="#e8e0cf" strokeWidth={9} fill="none" strokeLinecap="round" />,
    );
  }
  const dash = 1200;
  return (
    <g opacity={p}>
      <path d="M-330 0 L330 0" stroke="#e8e0cf" strokeWidth={14} strokeDasharray={`${dash * p} ${dash}`} strokeLinecap="round" />
      {Array.from({length: 22}).map((_, i) => (
        <circle key={i} cx={-300 + i * 30} cy={0} r={11} fill="#efe8d8" opacity={Math.min(1, p * 2 - i / 40)} />
      ))}
      {ribs}
      <path d="M-330 -24 C-420 -40 -480 0 -470 28 C-440 52 -360 40 -330 26 Z" fill="#efe8d8" stroke="#cfc6b0" strokeWidth={3} />
    </g>
  );
};

const Crab: React.FC<{t: number; phase: number}> = ({t, phase}) => (
  <g>
    <ellipse cx={0} cy={0} rx={18} ry={11} fill="#fb923c" />
    <path d={`M-16 4 L-30 ${14 + Math.sin(t * 8 + phase) * 3} M16 4 L30 ${14 + Math.sin(t * 8 + phase + 1) * 3} M-12 8 L-22 ${18 + Math.sin(t * 8 + phase + 2) * 3} M12 8 L22 ${18 + Math.sin(t * 8 + phase + 3) * 3}`} stroke="#fb923c" strokeWidth={3} strokeLinecap="round" />
    <circle cx={-6} cy={-8} r={3} fill="#fff" />
    <circle cx={6} cy={-8} r={3} fill="#fff" />
  </g>
);

// ---------- Ventilasi hidrotermal ----------
const Smoke: React.FC<{x: number; baseY: number; t: number; seed: string}> = ({x, baseY, t, seed}) => {
  const puffs: React.ReactNode[] = [];
  for (let i = 0; i < 16; i++) {
    const k = (t * 0.28 + i / 16) % 1;
    const y = baseY - k * 760;
    const px = x + Math.sin(k * 9 + random(`${seed}${i}`) * 6) * (14 + k * 50) + k * 40;
    const r = 18 + k * 70;
    puffs.push(<circle key={i} cx={px} cy={y} r={r} fill="#6b5a8e" opacity={(1 - k) * 0.55} />);
  }
  return <g>{puffs}</g>;
};

const Microbes: React.FC<{t: number; p: number}> = ({t, p}) => {
  const items: React.ReactNode[] = [];
  for (let i = 0; i < 22; i++) {
    const a = random(`mb-a-${i}`) * Math.PI;
    const d = 60 + random(`mb-d-${i}`) * 200;
    const x = 480 + Math.cos(a) * d * 1.8 * (random(`mb-s-${i}`) > 0.5 ? 1 : -1);
    const y = SEA_Y - 20 - Math.sin(a) * d * 0.6 + Math.sin(t * 2 + i) * 6;
    items.push(
      <g key={i} transform={`translate(${x} ${y}) rotate(${random(`mb-r-${i}`) * 180})`} opacity={p}>
        <Glow x={0} y={0} r={26} color="#86efac" intensity={0.7} />
        <rect x={-10} y={-4} width={20} height={8} rx={4} fill="#d9ffe3" />
      </g>,
    );
  }
  return <g>{items}</g>;
};

export const Scene5: React.FC = () => {
  const t = useT();

  // Sub-scene
  const snowO = 1 - prog(t, 63.9, 64.4);
  const whaleO = prog(t, 63.9, 64.4) * (1 - prog(t, 66.6, 67.1));
  const ventO = prog(t, 66.6, 67.1);
  const groundIn = prog(t, 61.5, 64.0, Easing.inOut(Easing.cubic));

  // Teks marine snow
  const noPhoto = prog(t, 58.8, 59.4) * (1 - prog(t, 61.6, 62.0));
  const snowLabel = prog(t, 61.9, 62.5) * (1 - prog(t, 63.8, 64.1));
  const sink = prog(t, 59.0, 63.6, Easing.inOut(Easing.quad));

  // Whale fall
  const whaleDrop = prog(t, 64.1, 65.9, Easing.inOut(Easing.cubic));
  const skel = prog(t, 65.6, 66.8);
  const flesh = 1 - prog(t, 65.5, 66.4);
  const wfLabel = prog(t, 64.3, 64.9);

  // Hidrotermal
  const ventLabel = prog(t, 67.0, 67.7);
  const microP = prog(t, 68.6, 69.4);
  const diagP1 = popIn(t, 69.7, 0.6);
  const diagP2 = popIn(t, 70.7, 0.6);

  return (
    <AbsoluteFill style={{background: "linear-gradient(180deg,#073766 0%,#04142e 55%,#020b1c 100%)"}}>
      {/* Marine snow berlaku di semua bagian */}
      <Particles count={90} seed="snow" color="#eaf6ff" speed={70} dir={1} opacity={0.65} maxR={5} sway={22} />

      {/* ---- Marine snow ---- */}
      <AbsoluteFill style={{opacity: snowO}}>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <g opacity={1 - prog(t, 59.5, 61.5)}>
            <Plankton t={t} />
          </g>
          <g transform={`translate(${300 + Math.sin(t) * 10} ${250 + 1100 * sink}) rotate(${-12 + sink * 10})`} opacity={0.9 - sink * 0.2}>
            <DeadFish />
          </g>
          <g transform={`translate(0 ${(1 - groundIn) * 500})`}>
            <path d={`M0 ${SEA_Y} C200 ${SEA_Y - 40} 400 ${SEA_Y + 20} 620 ${SEA_Y - 20} C820 ${SEA_Y - 50} 940 ${SEA_Y} 1080 ${SEA_Y - 30} L1080 1920 L0 1920 Z`} fill="#0b1c3a" stroke="#1d3a6b" strokeWidth={4} />
          </g>
        </svg>
        <div style={{position: "absolute", left: 0, top: 250, width: WIDTH, textAlign: "center", opacity: noPhoto, fontFamily: FONT, color: "#fff"}}>
          <svg width={150} height={150} viewBox="-75 -75 150 150" style={{display: "block", margin: "0 auto"}}>
            <circle r={30} fill="#fbbf24" />
            {Array.from({length: 8}).map((_, i) => (
              <line key={i} x1={Math.cos((i / 8) * 6.283) * 44} y1={Math.sin((i / 8) * 6.283) * 44} x2={Math.cos((i / 8) * 6.283) * 62} y2={Math.sin((i / 8) * 6.283) * 62} stroke="#fbbf24" strokeWidth={8} strokeLinecap="round" />
            ))}
            <line x1={-62} y1={62} x2={62} y2={-62} stroke="#ef4444" strokeWidth={12} strokeLinecap="round" />
          </svg>
          <div style={{fontSize: 62, fontWeight: 800, marginTop: 10}}>Tanpa fotosintesis</div>
        </div>
        <Txt y={300} size={92} weight={800} opacity={snowLabel} dy={(1 - snowLabel) * 30} color={C.white}>
          Marine snow
        </Txt>
        <Txt y={430} size={42} weight={400} opacity={snowLabel} color="#bfe9ff">
          butiran organik yang perlahan tenggelam
        </Txt>
      </AbsoluteFill>

      {/* ---- Whale fall ---- */}
      <AbsoluteFill style={{opacity: whaleO}}>
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <path d={`M0 ${SEA_Y} C200 ${SEA_Y - 40} 400 ${SEA_Y + 20} 620 ${SEA_Y - 20} C820 ${SEA_Y - 50} 940 ${SEA_Y} 1080 ${SEA_Y - 30} L1080 1920 L0 1920 Z`} fill="#0b1c3a" stroke="#1d3a6b" strokeWidth={4} />
          <g transform={`translate(560 ${-250 + whaleDrop * (SEA_Y - 130 + 250)}) scale(0.95) rotate(${-8 + whaleDrop * 8})`} opacity={flesh}>
            <WhaleSilhouette />
          </g>
          <g transform={`translate(560 ${SEA_Y - 40}) scale(0.95)`}>
            <Skeleton p={skel} />
          </g>
          {[0, 1, 2, 3, 4, 5].map((i) => {
            const side = i % 2 === 0 ? -1 : 1;
            const x0 = 560 + side * (520 - prog(t, 65.8, 67.0) * (180 + i * 40));
            return (
              <g key={i} transform={`translate(${x0} ${SEA_Y - 8 - (i % 3) * 6})`} opacity={skel}>
                <Crab t={t} phase={i} />
              </g>
            );
          })}
        </svg>
        <Txt y={300} size={110} weight={800} opacity={wfLabel} dy={(1 - wfLabel) * 30}>
          Whale fall
        </Txt>
        <Txt y={440} size={42} weight={400} opacity={wfLabel} color="#bfe9ff">
          bangkai paus di dasar laut
        </Txt>
      </AbsoluteFill>

      {/* ---- Ventilasi hidrotermal ---- */}
      <AbsoluteFill style={{opacity: ventO}}>
        <AbsoluteFill style={{background: "linear-gradient(180deg,rgba(2,11,28,0.0),rgba(60,20,10,0.55) 100%)"}} />
        <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
          <Smoke x={330} baseY={SEA_Y - 120} t={t} seed="a" />
          <Smoke x={720} baseY={SEA_Y - 70} t={t + 3} seed="b" />
          <path d={`M0 ${SEA_Y} L180 ${SEA_Y - 20} L260 ${SEA_Y - 140} L300 ${SEA_Y - 150} L360 ${SEA_Y - 150} L400 ${SEA_Y - 120} L470 ${SEA_Y - 20} L620 ${SEA_Y - 10} L670 ${SEA_Y - 90} L700 ${SEA_Y - 100} L760 ${SEA_Y - 100} L800 ${SEA_Y - 70} L860 ${SEA_Y - 10} L1080 ${SEA_Y - 30} L1080 1920 L0 1920 Z`} fill="#150f26" stroke="#3a2a52" strokeWidth={4} />
          <Glow x={330} y={SEA_Y - 140} r={110} color="#fb923c" intensity={0.8} />
          <Glow x={730} y={SEA_Y - 92} r={90} color="#fb923c" intensity={0.7} />
          <Microbes t={t} p={microP} />
        </svg>
        <Txt y={250} size={72} weight={800} opacity={ventLabel} dy={(1 - ventLabel) * 30}>
          Ventilasi hidrotermal
        </Txt>
        <Txt y={350} size={42} weight={400} opacity={microP} color="#bfe9ff">
          mikroorganisme memanfaatkan reaksi kimia
        </Txt>

        {/* Diagram: fotosintesis vs kemosintesis */}
        <div style={{position: "absolute", left: 60, top: 520, width: 450, opacity: Math.min(1, diagP1), transform: `scale(${0.8 + 0.2 * diagP1})`}}>
          <DiagramCard title="Fotosintesis" lead="Cahaya" color="#fbbf24" kind="sun" />
        </div>
        <div style={{position: "absolute", left: 570, top: 520, width: 450, opacity: Math.min(1, diagP2), transform: `scale(${0.8 + 0.2 * diagP2})`}}>
          <DiagramCard title="Kemosintesis" lead="Reaksi kimia" color="#86efac" kind="flask" />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

const DiagramCard: React.FC<{title: string; lead: string; color: string; kind: "sun" | "flask"}> = ({title, lead, color, kind}) => (
  <div
    style={{
      height: 480,
      borderRadius: 30,
      background: "rgba(6,22,48,0.82)",
      border: `3px solid ${color}`,
      boxShadow: `0 0 36px ${color}55`,
      fontFamily: FONT,
      color: "#fff",
      textAlign: "center",
      padding: "34px 20px",
      boxSizing: "border-box",
    }}
  >
    <svg width={150} height={130} viewBox="-75 -65 150 130">
      {kind === "sun" ? (
        <g>
          <circle r={28} fill={color} />
          {Array.from({length: 8}).map((_, i) => (
            <line key={i} x1={Math.cos((i / 8) * 6.283) * 40} y1={Math.sin((i / 8) * 6.283) * 40} x2={Math.cos((i / 8) * 6.283) * 58} y2={Math.sin((i / 8) * 6.283) * 58} stroke={color} strokeWidth={7} strokeLinecap="round" />
          ))}
        </g>
      ) : (
        <g>
          <path d="M-14 -56 L14 -56 M-10 -56 L-10 -10 L-46 48 Q-52 60 -38 60 L38 60 Q52 60 46 48 L10 -10 L10 -56" stroke={color} strokeWidth={7} fill="none" strokeLinejoin="round" strokeLinecap="round" />
          <path d="M-30 30 L30 30 L40 52 L-40 52 Z" fill={color} opacity={0.8} />
          <circle cx={-6} cy={14} r={5} fill={color} />
          <circle cx={8} cy={0} r={4} fill={color} />
        </g>
      )}
    </svg>
    <div style={{fontSize: 46, fontWeight: 800, marginTop: 6, color}}>{title}</div>
    <div style={{fontSize: 38, fontWeight: 600, marginTop: 14}}>{lead}</div>
    <svg width={60} height={50} viewBox="-30 -25 60 50" style={{marginTop: 8}}>
      <path d="M0 -20 L0 14 M-16 0 L0 18 L16 0" stroke="#ffffff" strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
    <div style={{fontSize: 38, fontWeight: 700}}>Bahan organik</div>
  </div>
);
