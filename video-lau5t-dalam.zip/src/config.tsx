import React from "react";
import {Easing, interpolate, useCurrentFrame} from "remotion";

// ---- Pengaturan utama (satu sumber kebenaran untuk waktu) ----
export const COMPOSITION_ID = "DeepOcean";
export const FPS = 60;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SEC = 108; // audio asli 107,5 dtk + sedikit jeda di akhir
export const DURATION_FRAMES = DURATION_SEC * FPS;

export const sec = (s: number): number => Math.round(s * FPS);

export const C = {
  space: "#020817",
  navy: "#04112b",
  deep: "#062a5c",
  cyan: "#22d3ee",
  turq: "#2dd4bf",
  white: "#f4fbff",
  dim: "#8fb8d6",
  glow: "#5eead4",
  amber: "#fbbf24",
};

// Waktu scene & animasi ditulis pada "timeline 90 dtk"; SPEED mengubahnya ke audio asli (107,546 dtk / 90,044 dtk).
export const SPEED = 107.546063 / 90.044082;

// Batas scene (detik, timeline 90 dtk) disesuaikan dengan jeda napas pada audio narasi.
export const T = {
  s1: [0, 10.9],
  s2: [10.9, 35.2],
  s3: [35.2, 43.2],
  s4: [43.2, 58.5],
  s5: [58.5, 72.2],
  s6: [72.2, 78.0],
  s7: [78.0, DURATION_SEC / SPEED],
} as const;

export const fmt = (n: number): string =>
  Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ".");

type EasingFn = (t: number) => number;

// Progres 0..1 antara detik a dan b (a harus < b).
export const prog = (
  t: number,
  a: number,
  b: number,
  easing: EasingFn = Easing.out(Easing.cubic),
): number =>
  interpolate(t, [a, b], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing,
  });

export const SceneContext = React.createContext<{offset: number}>({offset: 0});

// Waktu absolut (detik, timeline 90 dtk) di dalam sebuah scene; offset = detik nyata di dalam sebuah scene.
export const useT = (): number => {
  const frame = useCurrentFrame();
  const {offset} = React.useContext(SceneContext);
  return (frame / FPS + offset) / SPEED;
};
