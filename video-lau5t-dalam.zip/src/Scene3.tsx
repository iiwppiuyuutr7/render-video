import React from "react";
import {AbsoluteFill, Easing, interpolate, interpolateColors} from "remotion";
import {C, FPS, HEIGHT, WIDTH, fmt, prog, useT} from "./config";
import {FONT} from "./fonts";
import {Particles, Txt} from "./common";

// Kecepatan cincin tekanan naik seiring cerita.
const ringSpeed = (t: number): number =>
  interpolate(t, [35.2, 37.4, 39.6, 41.5], [0.25, 0.55, 1.0, 1.6], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

const Submarine: React.FC<{t: number; shake: number}> = ({t, shake}) => {
  const sx = Math.sin(t * 38) * shake;
  const sy = Math.cos(t * 31) * shake;
  return (
    <g transform={`translate(${sx} ${sy})`}>
      <polygon points="150,10 520,-120 520,140" fill="#fff6c8" opacity={0.1} />
      <rect x={-60} y={-185} width={20} height={40} rx={6} fill="#5b7aa3" />
      <rect x={-80} y={-195} width={60} height={14} rx={7} fill="#5b7aa3" />
      <rect x={-170} y={-100} width={340} height={200} rx={100} fill="#f2f6fb" stroke="#9fb7d4" strokeWidth={6} />
      <rect x={-170} y={20} width={340} height={80} rx={40} fill="#d7e3f1" opacity={0.7} />
      <circle cx={60} cy={-10} r={56} fill="#0b2a50" stroke="#9fb7d4" strokeWidth={10} />
      <circle cx={60} cy={-10} r={40} fill="#1a6fb0" opacity={0.7} />
      <path d="M30 -30 Q60 -56 90 -30" stroke="#bfe7ff" strokeWidth={6} fill="none" opacity={0.7} strokeLinecap="round" />
      <circle cx={-80} cy={-5} r={28} fill="#0b2a50" stroke="#9fb7d4" strokeWidth={8} />
      <rect x={-210} y={-18} width={50} height={36} rx={10} fill="#5b7aa3" />
      <path d={`M-215 -40 L-250 ${-50 + Math.sin(t * 20) * 4} L-250 ${50 + Math.sin(t * 20) * 4} L-215 40`} fill="#7c97ba" opacity={0.7} />
      <rect x={-120} y={100} width={240} height={14} rx={7} fill="#5b7aa3" />
      <circle cx={170} cy={-10} r={10} fill="#fff6c8" />
    </g>
  );
};

export const Scene3: React.FC = () => {
  const t = useT();

  // Fase: 35.3 "+10 m" | 37.4 "+1 atm" | 39.6 "Challenger Deep, sekitar 1.000x"
  const p1 = prog(t, 35.3, 35.9, Easing.out(Easing.back(1.5))) * (1 - prog(t, 39.3, 39.7));
  const p2 = prog(t, 37.4, 38.0, Easing.out(Easing.back(1.5))) * (1 - prog(t, 39.3, 39.7));
  const p3 = prog(t, 39.6, 40.3, Easing.out(Easing.cubic));
  const mult = 1000 * prog(t, 39.8, 42.2, Easing.inOut(Easing.cubic));

  // Cincin konsentris (tekanan)
  let phase = 0;
  const startF = Math.round(35.2 * FPS);
  const nowF = Math.round(t * FPS);
  for (let f = startF; f < nowF; f++) phase += ringSpeed(f / FPS) / FPS;
  const rings: React.ReactNode[] = [];
  const N = 10;
  const pressure = prog(t, 35.2, 42.5, Easing.in(Easing.quad));
  const ringColor = interpolateColors(pressure, [0, 0.6, 1], ["#22d3ee", "#7dd3fc", "#fb923c"]);
  for (let i = 0; i < N; i++) {
    const k = (((i / N + phase) % 1) + 1) % 1;
    const r = 700 * (1 - k) + 30;
    const o = Math.sin(k * Math.PI) * (0.25 + 0.4 * pressure);
    rings.push(<circle key={i} cx={540} cy={900} r={r} fill="none" stroke={ringColor} strokeWidth={4 + 8 * pressure} opacity={o} />);
  }
  const shake = 1 + 7 * pressure * pressure;
  const subY = 900 + Math.sin(t * 1.5) * 10;

  // Penggaris +10 m di sisi kiri
  const ruler: React.ReactNode[] = [];
  const rulerO = p1 * (1 - prog(t, 39.3, 39.7));
  for (let i = 0; i < 7; i++) {
    ruler.push(<line key={i} x1={90} x2={i % 3 === 0 ? 150 : 125} y1={560 + i * 100} y2={560 + i * 100} stroke="#ffffff" strokeWidth={4} opacity={0.6} />);
  }
  const arrowP = prog(t, 35.4, 37.0, Easing.inOut(Easing.cubic));

  // Bar perbandingan
  const cmpP = prog(t, 40.6, 41.6);
  const cmpFull = prog(t, 40.9, 42.2, Easing.inOut(Easing.cubic));

  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${C.deep}, #020a1f)`}}>
      <Particles count={45} seed="s3" color="#bfe9ff" speed={45} dir={-1} opacity={0.35} maxR={3} />
      <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
        {rings}
        <g transform={`translate(540 ${subY}) scale(1.05)`}>
          <Submarine t={t} shake={shake} />
        </g>
        <g opacity={rulerO}>
          <line x1={150} x2={150} y1={560} y2={1160} stroke="#ffffff" strokeWidth={4} opacity={0.6} />
          {ruler}
          <rect x={80} y={560} width={14} height={600 * arrowP} fill={C.cyan} opacity={0.9} />
        </g>
      </svg>

      <Txt y={250} size={40} weight={600} spacing={10} color="#bdeeff" opacity={prog(t, 35.3, 35.9) * (1 - prog(t, 39.3, 39.7))}>
        TEKANAN AIR
      </Txt>

      {/* +10 m  =>  +1 atm */}
      <div style={{position: "absolute", top: 330, left: 0, width: WIDTH, textAlign: "center", fontFamily: FONT, fontWeight: 800, color: "#fff"}}>
        <span style={{fontSize: 150, opacity: p1, display: "inline-block", transform: `scale(${0.7 + 0.3 * p1})`}}>+10 m</span>
      </div>
      <div style={{position: "absolute", top: 1190, left: 0, width: WIDTH, textAlign: "center", fontFamily: FONT, fontWeight: 800, color: C.cyan}}>
        <span style={{fontSize: 150, opacity: p2, display: "inline-block", transform: `scale(${0.7 + 0.3 * p2})`}}>+1 atm</span>
      </div>

      {/* Challenger Deep */}
      <Txt y={290} size={64} weight={700} color="#ffffff" opacity={p3} dy={(1 - p3) * 30} spacing={2}>
        Challenger Deep
      </Txt>
      <div style={{position: "absolute", top: 380, left: 0, width: WIDTH, textAlign: "center", fontFamily: FONT, fontWeight: 800, color: "#fdba74", opacity: p3}}>
        <span style={{fontSize: 190}}>{fmt(mult)}×</span>
      </div>
      <Txt y={625} size={44} weight={600} color="#e6f7ff" opacity={p3}>
        tekanan di permukaan
      </Txt>

      <div style={{position: "absolute", left: 90, top: 1290, width: 780, opacity: cmpP, fontFamily: FONT, color: "#fff"}}>
        <div style={{fontSize: 34, fontWeight: 600, marginBottom: 10, color: "#bdeeff"}}>Permukaan · 1 atm</div>
        <div style={{height: 22, width: 6, borderRadius: 4, background: C.cyan, marginBottom: 30}} />
        <div style={{fontSize: 34, fontWeight: 600, marginBottom: 10, color: "#fdba74"}}>Challenger Deep · sekitar 1.000 atm</div>
        <div style={{height: 22, width: Math.max(6, 780 * cmpFull), borderRadius: 11, background: "linear-gradient(90deg,#fb923c,#ef4444)", boxShadow: "0 0 24px rgba(251,146,60,0.7)"}} />
      </div>
    </AbsoluteFill>
  );
};
