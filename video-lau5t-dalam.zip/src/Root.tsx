import React from "react";
import {Composition} from "remotion";
import {COMPOSITION_ID, DURATION_FRAMES, FPS, HEIGHT, WIDTH} from "./config";
import {MainVideo} from "./MainVideo";

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id={COMPOSITION_ID}
      component={MainVideo}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  </>
);

export default RemotionRoot;
