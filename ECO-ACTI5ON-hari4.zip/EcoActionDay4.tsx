/**
 * ECO-ACTION 4 DAYS – Hari Keempat: Jalan Sehat dan Penutup
 * 1920x1080 (16:9) · 60 fps · ±115 detik
 *
 * Sambungan langsung dari Hari 3 (file Hari 3 yang sudah ada, tidak diubah): mulai dari layar hijau
 * akhir Hari 3, lingkaran langsung membuka ke footage jalan sehat tanpa jeda.
 * Backsound melanjutkan musik dari detik ke-249,0 (akhir Hari 3), lanjut alami (file musik panjang, tanpa loop),
 * volumenya turun setiap ada SFX, dan memudar di akhir.
 * Isi: jalan sehat (footage), jadwal Hari 4, rangkaian empat hari,
 * kilas balik dari footage Hari 1-3, lalu credit penutup bergaya film dokumenter.
 * Klip memakai frame rate aslinya (30 fps). Tidak ada naskah/narasi.
 * Aset: public/eco4/clips (a-e = jalan sehat, fb1-fb7 = kilas balik), sfx, music.mp3, logo-*.
 */
import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  OffthreadVideo,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';

/* ───────────────────────── konfigurasi ───────────────────────── */
const WITH_MUSIC = true; // false = tanpa backsound (kalau mau dipasang sendiri)

const poppins = loadPoppins('normal', {weights: ['600', '800'], subsets: ['latin']}).fontFamily;
const FONT = `${poppins}, 'Segoe UI', Arial, sans-serif`;

const WHITE = '#ffffff';
const BEIGE = '#efe5cf';
const GREEN = '#9fcf86';
const DEEP = '#0f2e1c';

const OVERLAP_S = 0.5; // durasi dissolve antar klip


/* ───────────────────────── urutan klip (detik) ───────────────────────── */
type Seg = {id: string; src: string; sec: number; zoom: 'in' | 'out'};
const OFF = 0; // mulai langsung: lingkaran membuka dari layar hijau akhir Hari 3, tanpa jeda
const SEGS: Seg[] = [
  {id: 'a', src: 'a-gerbang', sec: 6.9, zoom: 'in'},
  {id: 'b', src: 'b-berangkat', sec: 8.85, zoom: 'in'},
  {id: 'c', src: 'c-jalan1', sec: 10.6, zoom: 'out'},
  {id: 'd', src: 'd-jalan2', sec: 12.2, zoom: 'in'},
  {id: 'e', src: 'e-setapak', sec: 8.6, zoom: 'out'},
];
const START_S: Record<string, number> = {};
let acc = OFF;
SEGS.forEach((s, i) => {
  const st = i === 0 ? OFF : acc - OVERLAP_S;
  START_S[s.id] = st;
  acc = st + s.sec;
});
const VIDEO_END_S = acc; // ±45,75 detik

/* kartu info */
const CARDS_START_S = VIDEO_END_S - OVERLAP_S;
const C0 = VIDEO_END_S + 0.2;
const CARD = {
  jadwal: {start: C0, end: C0 + 11},
  empat: {start: C0 + 11.1, end: C0 + 20.1},
};
/* kilas balik: 7 potongan footage Hari 1-4 */
const FB0 = C0 + 20.2;
const FB_STEP = 2.0;
const FB_LEN = 2.4;
const FB = [
  {src: 'fb1', day: 'Hari 1', sub: 'Audit dan Diagnosa Lingkungan'},
  {src: 'fb2', day: 'Hari 1', sub: 'Audit dan Diagnosa Lingkungan'},
  {src: 'fb3', day: 'Hari 2', sub: 'Aksi Nyata dan Eksekusi Tamanisasi'},
  {src: 'fb4', day: 'Hari 2', sub: 'Aksi Nyata dan Eksekusi Tamanisasi'},
  {src: 'fb5', day: 'Hari 3', sub: 'Share & Reflect'},
  {src: 'fb6', day: 'Hari 3', sub: 'Share & Reflect'},
  {src: 'fb7', day: 'Hari 4', sub: 'Jalan Sehat'},
];
const FB_END = FB0 + (FB.length - 1) * FB_STEP + FB_LEN;
/* credit penutup */
const CB0 = FB_END + 0.4;
const CREDIT_BG_START = FB_END - 1.0;
const BLACK_START = CB0 + 30.7;
export const ECO4_TOTAL_SECONDS = CB0 + 34.2; // ±115 detik

/* ───────────────────────── util ───────────────────────── */
const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const useFr = () => {
  const {fps} = useVideoConfig();
  return (s: number) => Math.round(s * fps);
};

const fadeWindow = (f: number, dur: number, fi: number, fo: number) =>
  interpolate(f, [0, fi, dur - fo, dur], [0, 1, 1, 0], clampOpts);

const rise = (f: number, delay: number, len: number, dist: number) =>
  interpolate(f, [delay, delay + len], [dist, 0], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });

const shadow = '0 3px 24px rgba(0,0,0,0.38)';

/* ───────────────────────── klip video ───────────────────────── */
// Color grading ringan: sedikit hangat, saturasi hijau natural, kontras seimbang.
const GRADE = 'saturate(1.12) contrast(1.05) brightness(0.98) sepia(0.10)';

// Jenis transisi masuk tiap klip (selama OVERLAP_S): dissolve, zoom-through, push, iris.
type Enter = 'fade' | 'dissolve' | 'zoom' | 'push' | 'iris';
const ENTER: Record<string, Enter> = {
  a: 'iris',
  b: 'zoom',
  c: 'dissolve',
  d: 'push',
  e: 'iris',
};

const VideoSeg: React.FC<{seg: Seg; index: number}> = ({seg, index}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const dur = fr(seg.sec);
  const kind = ENTER[seg.id];
  const inLen = index === 0 ? fr(1.0) : fr(OVERLAP_S);
  const t = interpolate(f, [0, inLen], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const scale =
    seg.zoom === 'in'
      ? interpolate(f, [0, dur], [1.0, 1.045], clampOpts)
      : interpolate(f, [0, dur], [1.045, 1.0], clampOpts);

  let opacity = 1;
  let wrapTransform = 'none';
  let wrapFilter = 'none';
  let clip = 'none';
  if (kind === 'fade' || kind === 'dissolve') {
    opacity = t;
  } else if (kind === 'zoom') {
    opacity = Math.min(1, t * 1.6);
    wrapTransform = `scale(${1 + 0.2 * (1 - t)})`;
    wrapFilter = `blur(${(1 - t) * 10}px)`;
  } else if (kind === 'push') {
    wrapTransform = `translateX(${(1 - t) * 1920}px)`;
    wrapFilter = `blur(${Math.sin(Math.PI * t) * 9}px)`;
  } else if (kind === 'iris') {
    clip = `circle(${t * 75}% at 50% 50%)`;
  }
  return (
    <AbsoluteFill style={{opacity, transform: wrapTransform, filter: wrapFilter, clipPath: clip}}>
      <OffthreadVideo
        src={staticFile(`eco4/clips/${seg.src}.mp4`)}
        volume={0}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${scale})`,
          filter: GRADE,
        }}
      />
    </AbsoluteFill>
  );
};

/* ───────────────────────── teks ───────────────────────── */
const Pill: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: 600,
      fontSize: 28,
      color: WHITE,
      padding: '8px 24px',
      borderRadius: 999,
      border: '2px solid rgba(255,255,255,0.7)',
      background: 'rgba(255,255,255,0.12)',
      textShadow: shadow,
    }}
  >
    {children}
  </div>
);

// Judul bagian di kiri bawah, dengan scrim gradasi halus di bawahnya. start/end dalam detik.
const LowerThird: React.FC<{
  start: number;
  end: number;
  title: string;
  sub: string;
  extra?: string;
}> = ({start, end, title, sub, extra}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <LowerThirdInner dur={fr(end) - fr(start)} title={title} sub={sub} extra={extra} />
    </Sequence>
  );
};

const LowerThirdInner: React.FC<{dur: number; title: string; sub: string; extra?: string}> = ({
  dur,
  title,
  sub,
  extra,
}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = fadeWindow(f, dur, fr(0.47), fr(0.4));
  const bar = interpolate(f, [0, fr(0.67)], [0, 1], {...clampOpts, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          opacity: op,
          background:
            'linear-gradient(to top, rgba(6,22,11,0.70) 0%, rgba(6,22,11,0.38) 28%, rgba(6,22,11,0) 52%)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: 120,
          bottom: 120,
          display: 'flex',
          gap: 30,
          alignItems: 'stretch',
          opacity: op,
        }}
      >
        <div
          style={{
            width: 7,
            borderRadius: 4,
            background: GREEN,
            transform: `scaleY(${bar})`,
            transformOrigin: 'bottom',
          }}
        />
        <div style={{transform: `translateY(${rise(f, 0, fr(0.53), 18)}px)`}}>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 800,
              fontSize: 68,
              lineHeight: 1.12,
              color: WHITE,
              textShadow: shadow,
            }}
          >
            {title}
          </div>
          <div
            style={{
              fontFamily: FONT,
              fontWeight: 600,
              fontSize: 36,
              marginTop: 14,
              color: BEIGE,
              textShadow: shadow,
              transform: `translateY(${rise(f, fr(0.2), fr(0.53), 12)}px)`,
            }}
          >
            {sub}
          </div>
          {extra ? (
            <div style={{marginTop: 26, display: 'flex'}}>
              <Pill>{extra}</Pill>
            </div>
          ) : null}
        </div>
      </div>
    </AbsoluteFill>
  );
};

// Panel teks di tengah layar (opening). start/end dalam detik.
const CenterPanel: React.FC<{start: number; end: number; children: React.ReactNode}> = ({
  start,
  end,
  children,
}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <CenterInner dur={fr(end) - fr(start)}>{children}</CenterInner>
    </Sequence>
  );
};

const CenterInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, fr(0.6), fr(0.47)),
        transform: `translateY(${rise(f, 0, fr(0.53), 22)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

const Line: React.FC<{
  size: number;
  weight: 600 | 800;
  color: string;
  mt?: number;
  spacing?: number;
  children: React.ReactNode;
}> = ({size, weight, color, mt = 0, spacing = 0, children}) => (
  <div
    style={{
      fontFamily: FONT,
      fontWeight: weight,
      fontSize: size,
      color,
      marginTop: mt,
      letterSpacing: spacing,
      lineHeight: 1.15,
      textShadow: shadow,
      maxWidth: 1500,
    }}
  >
    {children}
  </div>
);

const Rule: React.FC<{width?: number}> = ({width = 220}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const w = interpolate(f, [fr(0.27), fr(1.13)], [0, width], {
    ...clampOpts,
    easing: Easing.out(Easing.cubic),
  });
  return <div style={{height: 5, width: w, borderRadius: 3, background: GREEN, marginTop: 30}} />;
};

// Peredup lembut agar teks putih terbaca di atas footage terang. start/end dalam detik.
const Dim: React.FC<{start: number; end: number; strength: number}> = ({start, end, strength}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <DimInner dur={fr(end) - fr(start)} strength={strength} />
    </Sequence>
  );
};
const DimInner: React.FC<{dur: number; strength: number}> = ({dur, strength}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        background: `rgba(8,26,14,${strength})`,
        opacity: interpolate(f, [0, fr(0.73), dur - fr(0.73), dur], [0, 1, 1, 0], clampOpts),
      }}
    />
  );
};

// Kilau halus saat judul muncul (sinkron dengan efek kamera flash). at dalam detik.
const SoftFlash: React.FC<{at: number}> = ({at}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const a = fr(at);
  const o = interpolate(f, [a, a + fr(0.1), a + fr(0.47)], [0, 0.1, 0], clampOpts);
  return <AbsoluteFill style={{background: '#fff', opacity: o}} />;
};

/* ───────────────────────── latar kartu, logo, komponen kartu ───────────────────────── */
const CardsBg: React.FC = () => {
  const fr = useFr();
  return (
    <Sequence from={fr(CARDS_START_S)} durationInFrames={fr(ECO4_TOTAL_SECONDS) - fr(CARDS_START_S)}>
      <CardsBgInner />
    </Sequence>
  );
};
const CardsBgInner: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(f, [0, fr(OVERLAP_S)], [0, 1], clampOpts),
        background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)',
      }}
    />
  );
};

// Logo kecil di pojok atas, tampil sepanjang video.
const Logos: React.FC = () => {
  const op = 0.96; // langsung tampil: logo sudah ada sejak Hari 1, jadi tidak berkedip saat digabung
  const base: React.CSSProperties = {
    position: 'absolute',
    top: 44,
    height: 96,
    opacity: op,
    filter: 'drop-shadow(0 2px 8px rgba(0,0,0,0.45))',
  };
  return (
    <AbsoluteFill>
      <Img src={staticFile('eco4/logo-taman.svg')} style={{...base, left: 56}} />
      <Img src={staticFile('eco4/logo-sma.png')} style={{...base, right: 56}} />
    </AbsoluteFill>
  );
};

// Muncul bertahap di dalam CenterPanel (waktu lokal sequence).
const Stagger: React.FC<{i: number; step?: number; children: React.ReactNode}> = ({i, step = 0.25, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const d = fr(0.7 + i * step);
  return (
    <div
      style={{
        opacity: interpolate(f, [d, d + fr(0.45)], [0, 1], clampOpts),
        transform: `translateY(${rise(f, d, fr(0.45), 14)}px)`,
      }}
    >
      {children}
    </div>
  );
};


/* ───────────────────────── komponen khusus Hari 4 ───────────────────────── */
type Sess = {t: string; n: string; s?: string; hl?: boolean};
const JADWAL: Sess[] = [
  {t: '07.00–07.15', n: 'Persiapan Jalan Sehat', s: 'Persiapan peserta dan pengecekan kesiapan kegiatan'},
  {t: '07.15–09.10', n: 'Jalan Sehat', s: 'Bagian dari rangkaian hari terakhir ECO-ACTION 4 DAYS'},
  {t: '09.10–09.50', n: 'Pembuatan Video Dokumenter', s: 'Kelompok 5 mengumpulkan footage, menyusun dokumentasi, mulai mengedit', hl: true},
  {t: '09.50–10.20', n: 'Istirahat'},
  {t: '10.20–11.00', n: 'Melanjutkan Video Dokumenter', s: 'Melanjutkan penyuntingan dan menyusun dokumentasi menjadi satu rangkaian', hl: true},
  {t: '11.00–12.20', n: 'Penyusunan Laporan Kelas', s: 'Seluruh peserta menyusun laporan kelas'},
  {t: '12.20–12.50', n: 'Istirahat'},
  {t: '12.50–14.00', n: 'Penutupan dan Pengumpulan LKPD', s: 'Penutupan kegiatan dan pengumpulan LKPD setiap kelompok'},
];
const SessCard: React.FC<{i: number; x: Sess}> = ({i, x}) => (
  <Stagger i={i} step={0.22}>
    <div
      style={{
        width: 830,
        height: 142,
        boxSizing: 'border-box',
        padding: '16px 26px',
        borderRadius: 20,
        border: `2px solid ${x.hl ? GREEN : 'rgba(239,229,207,0.3)'}`,
        background: x.hl ? 'rgba(159,207,134,0.14)' : 'rgba(255,255,255,0.06)',
        textAlign: 'left',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
      }}
    >
      <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 24, color: GREEN}}>{x.t}</div>
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 31, color: WHITE, marginTop: 2, lineHeight: 1.2}}>{x.n}</div>
      {x.s ? (
        <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 21, color: BEIGE, marginTop: 4, lineHeight: 1.25}}>{x.s}</div>
      ) : null}
    </div>
  </Stagger>
);

const DAYS4 = [
  {d: 1, n: 'Audit dan Diagnosa Lingkungan'},
  {d: 2, n: 'Aksi Nyata dan Eksekusi Tamanisasi'},
  {d: 3, n: 'Pameran, Presentasi, Evaluasi, dan Refleksi'},
  {d: 4, n: 'Jalan Sehat dan Penyelesaian Dokumentasi'},
];
const DayStep: React.FC<{i: number; d: number; n: string}> = ({i, d, n}) => {
  const last = d === 4;
  return (
    <Stagger i={i} step={0.55}>
      <div
        style={{
          width: 400,
          height: 360,
          boxSizing: 'border-box',
          padding: '26px 24px',
          borderRadius: 24,
          border: `3px solid ${last ? GREEN : 'rgba(239,229,207,0.4)'}`,
          background: last ? 'rgba(159,207,134,0.16)' : 'rgba(255,255,255,0.06)',
          textAlign: 'center',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <div
          style={{
            width: 86,
            height: 86,
            borderRadius: 43,
            background: last ? GREEN : 'transparent',
            border: `3px solid ${GREEN}`,
            color: last ? DEEP : GREEN,
            fontFamily: FONT,
            fontWeight: 800,
            fontSize: 48,
            lineHeight: '80px',
          }}
        >
          {d}
        </div>
        <div style={{fontFamily: FONT, fontWeight: 800, fontSize: 40, color: WHITE, marginTop: 18}}>Hari {d}</div>
        <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 28, color: BEIGE, marginTop: 10, lineHeight: 1.25}}>{n}</div>
      </div>
    </Stagger>
  );
};

// Potongan footage kilas balik (dissolve + zoom halus).
const FlashSeg: React.FC<{src: string; dur: number; zoom: 'in' | 'out'}> = ({src, dur, zoom}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  const op = fadeWindow(f, dur, fr(0.4), fr(0.4));
  const scale = zoom === 'in' ? interpolate(f, [0, dur], [1.0, 1.06], clampOpts) : interpolate(f, [0, dur], [1.06, 1.0], clampOpts);
  return (
    <AbsoluteFill style={{opacity: op}}>
      <OffthreadVideo
        src={staticFile(`eco4/clips/${src}.mp4`)}
        volume={0}
        style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${scale})`, filter: GRADE}}
      />
    </AbsoluteFill>
  );
};

// Credit penutup bergaya film dokumenter: latar gelap, tulisan putih, muncul bergantian.
const CREDIT_BG = 'radial-gradient(ellipse at 50% 40%, #0d1a12 0%, #060d09 60%, #030604 100%)';
const CreditBg: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  return <AbsoluteFill style={{background: CREDIT_BG, opacity: interpolate(f, [0, fr(1.0)], [0, 1], clampOpts)}} />;
};
const Label: React.FC<{children: React.ReactNode}> = ({children}) => (
  <div style={{fontFamily: FONT, fontWeight: 600, fontSize: 28, letterSpacing: 12, color: GREEN, marginBottom: 28}}>{children}</div>
);
const Name: React.FC<{size?: number; weight?: 600 | 800; color?: string; sp?: number; mt?: number; children: React.ReactNode}> = ({
  size = 72,
  weight = 800,
  color = WHITE,
  sp = 4,
  mt = 0,
  children,
}) => (
  <div style={{fontFamily: FONT, fontWeight: weight, fontSize: size, color, letterSpacing: sp, marginTop: mt, lineHeight: 1.2}}>{children}</div>
);
const CreditBlock: React.FC<{start: number; end: number; children: React.ReactNode}> = ({start, end, children}) => {
  const fr = useFr();
  return (
    <Sequence from={fr(start)} durationInFrames={fr(end) - fr(start)}>
      <CreditInner dur={fr(end) - fr(start)}>{children}</CreditInner>
    </Sequence>
  );
};
const CreditInner: React.FC<{dur: number; children: React.ReactNode}> = ({dur, children}) => {
  const f = useCurrentFrame();
  const fr = useFr();
  return (
    <AbsoluteFill
      style={{
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        opacity: fadeWindow(f, dur, fr(1.0), fr(0.9)),
        transform: `translateY(${interpolate(f, [0, dur], [14, -14], clampOpts)}px)`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ───────────────────────── audio ───────────────────────── */
type SfxItem = {file: 'flash' | 'pop' | 'whoosh' | 'transition' | 'click'; at: number; vol: number};
const SFX_LEN = {flash: 1.2, pop: 0.45, whoosh: 1.2, transition: 0.4, click: 0.37};

const S0 = START_S;
const T_A = 4.6; // setelah tulisan "Hari 4"
const T_B = S0.b + 0.7;
const T_C = S0.c + 0.6;
const T_D = S0.d + 0.8;
const T_E = S0.e + 0.8;
const SFX: SfxItem[] = [
  {file: 'whoosh', at: 0.3, vol: 0.35}, // lingkaran membuka dari layar hijau akhir Hari 3
  {file: 'pop', at: 1.2, vol: 0.45}, // tulisan "Hari 4"
  {file: 'click', at: T_A + 0.1, vol: 0.4},
  {file: 'transition', at: S0.b, vol: 0.35},
  {file: 'click', at: T_B + 0.1, vol: 0.4},
  {file: 'whoosh', at: S0.c - 0.4, vol: 0.3},
  {file: 'click', at: T_C + 0.1, vol: 0.4},
  {file: 'whoosh', at: S0.d - 0.4, vol: 0.3},
  {file: 'click', at: T_D + 0.1, vol: 0.4},
  {file: 'transition', at: S0.e, vol: 0.35},
  {file: 'click', at: T_E + 0.1, vol: 0.4},
  {file: 'whoosh', at: CARDS_START_S - 0.3, vol: 0.3},
  {file: 'click', at: CARD.jadwal.start + 0.1, vol: 0.4},
  {file: 'click', at: CARD.empat.start + 0.1, vol: 0.4},
  {file: 'whoosh', at: FB0 - 0.4, vol: 0.3},
  {file: 'click', at: FB0 + 0.1, vol: 0.3},
  {file: 'click', at: FB0 + 2 * FB_STEP + 0.1, vol: 0.3},
  {file: 'click', at: FB0 + 4 * FB_STEP + 0.1, vol: 0.3},
  {file: 'click', at: FB0 + 6 * FB_STEP + 0.1, vol: 0.3},
];

const MUSIC_BASE = 0.3;
const MUSIC_DUCK = 0.38;
const duckAt = (t: number) => {
  let g = 1;
  for (const s of SFX) {
    const a = s.at - 0.12;
    const h = s.at + SFX_LEN[s.file];
    let v = 1;
    if (t >= a && t < a + 0.12) v = 1 - (1 - MUSIC_DUCK) * ((t - a) / 0.12);
    else if (t >= a + 0.12 && t < h) v = MUSIC_DUCK;
    else if (t >= h && t < h + 0.8) {
      const k = (t - h) / 0.8;
      v = MUSIC_DUCK + (1 - MUSIC_DUCK) * (k * k * (3 - 2 * k));
    }
    if (v < g) g = v;
  }
  return g;
};

const Sfx: React.FC<{file: string; at: number; vol?: number}> = ({file, at, vol = 0.5}) => {
  const fr = useFr();
  return (
    <Sequence from={Math.max(0, fr(at))}>
      <Audio src={staticFile(`eco4/sfx/${file}.mp3`)} volume={vol} />
    </Sequence>
  );
};

// Cincin hijau yang ikut melebar saat lingkaran membuka (mulai di OFF).
const IrisRing: React.FC = () => {
  const f = useCurrentFrame();
  const fr = useFr();
  const t = interpolate(f, [0, fr(1.0)], [0, 1], {...clampOpts, easing: Easing.inOut(Easing.cubic)});
  const d = t * 0.75 * 1556 * 2;
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: 1 - t}}>
      <div style={{width: d, height: d, borderRadius: d / 2, border: `6px solid ${GREEN}`, boxSizing: 'border-box'}} />
    </AbsoluteFill>
  );
};

/* ───────────────────────── komposisi ───────────────────────── */
export const EcoActionDay4: React.FC = () => {
  const {fps} = useVideoConfig();
  const TITLE_LEN = 4.0;
  const f = useCurrentFrame();
  const vig = interpolate(f / fps, [OFF, OFF + 1.2], [0, 1], clampOpts);
  const blackOp = interpolate(f / fps, [BLACK_START, BLACK_START + 3.0], [0, 1], clampOpts);

  // Backsound melanjutkan akhir Hari 3 (tanpa fade-in), turun saat ada SFX, memudar di akhir.
  const musicVolume = (fi: number) => {
    const t = fi / fps;
    const end = interpolate(t, [ECO4_TOTAL_SECONDS - 5, ECO4_TOTAL_SECONDS - 0.3], [1, 0], clampOpts);
    return MUSIC_BASE * duckAt(t) * end;
  };

  return (
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 30% 25%, #1d4a2f 0%, #123624 55%, #0b2116 100%)'}}>
      {/* ── video jalan sehat ── */}
      {SEGS.map((seg, i) => (
        <Sequence key={seg.id} from={Math.round(START_S[seg.id] * fps)} durationInFrames={Math.round(seg.sec * fps)}>
          <VideoSeg seg={seg} index={i} />
        </Sequence>
      ))}

      <Sequence from={Math.round(OFF * fps)} durationInFrames={Math.round(1.0 * fps)}>
        <IrisRing />
      </Sequence>

      <AbsoluteFill
        style={{
          opacity: vig,
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 58%, rgba(8,24,12,0.34) 100%)',
        }}
      />

      {/* ── Tulisan "Hari 4" ── */}
      <Dim start={0.6} end={4.3} strength={0.3} />
      <CenterPanel start={1.0} end={4.2}>
        <Line size={38} weight={600} color={BEIGE} spacing={10}>
          ECO-ACTION 4 DAYS
        </Line>
        <Line size={168} weight={800} color={WHITE} spacing={2} mt={10}>
          Hari 4
        </Line>
        <Rule />
        <Line size={54} weight={600} color={BEIGE} mt={30}>
          Hari terakhir
        </Line>
        <Line size={34} weight={600} color={BEIGE} mt={12}>
          Kelas X E7 · Kelompok 5 — Video Kampanye
        </Line>
      </CenterPanel>

      {/* ── footage + judul bagian (sesuai jadwal resmi) ── */}
      <LowerThird start={T_A} end={S0.a + 6.9 - 0.2} title="Persiapan Jalan Sehat" sub="Peserta bersiap sebelum kegiatan" extra="07.00–07.15" />
      <LowerThird start={T_B} end={T_B + TITLE_LEN} title="Jalan Sehat" sub="Peserta mengikuti kegiatan jalan sehat" extra="07.15–09.10" />
      <LowerThird start={T_C} end={T_C + TITLE_LEN} title="Jalan Sehat" sub="Suasana perjalanan bersama peserta" extra="07.15–09.10" />
      <LowerThird start={T_D} end={T_D + TITLE_LEN} title="Jalan Sehat" sub="Momen kebersamaan peserta" extra="07.15–09.10" />
      <LowerThird start={T_E} end={T_E + TITLE_LEN} title="Jalan Sehat" sub="Perjalanan kegiatan jalan sehat" extra="07.15–09.10" />

      {/* ── KARTU INFO ── */}
      <CardsBg />

      <CenterPanel start={CARD.jadwal.start} end={CARD.jadwal.end}>
        <Line size={58} weight={800} color={WHITE}>
          Jadwal Kegiatan Hari Keempat
        </Line>
        <Rule />
        <div style={{display: 'flex', gap: 30, marginTop: 28, alignItems: 'flex-start'}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
            {JADWAL.slice(0, 4).map((x, i) => (
              <SessCard key={x.t} i={i * 2} x={x} />
            ))}
          </div>
          <div style={{display: 'flex', flexDirection: 'column', gap: 16}}>
            {JADWAL.slice(4).map((x, i) => (
              <SessCard key={x.t} i={i * 2 + 1} x={x} />
            ))}
          </div>
        </div>
      </CenterPanel>

      <CenterPanel start={CARD.empat.start} end={CARD.empat.end}>
        <Line size={60} weight={800} color={WHITE}>
          Hari Terakhir ECO-ACTION 4 DAYS
        </Line>
        <Rule />
        <Line size={38} weight={600} color={BEIGE} mt={24}>
          Rangkaian empat hari kegiatan
        </Line>
        <div style={{display: 'flex', gap: 28, marginTop: 44, alignItems: 'stretch'}}>
          {DAYS4.map((x, i) => (
            <DayStep key={x.d} i={i} d={x.d} n={x.n} />
          ))}
        </div>
      </CenterPanel>

      {/* ── KILAS BALIK ── */}
      {FB.map((x, i) => (
        <React.Fragment key={x.src}>
          <Sequence from={Math.round((FB0 + i * FB_STEP) * fps)} durationInFrames={Math.round(FB_LEN * fps)}>
            <FlashSeg src={x.src} dur={Math.round(FB_LEN * fps)} zoom={i % 2 === 0 ? 'in' : 'out'} />
          </Sequence>
          <LowerThird start={FB0 + i * FB_STEP + 0.2} end={FB0 + i * FB_STEP + FB_LEN - 0.1} title={x.day} sub={x.sub} />
        </React.Fragment>
      ))}

      {/* logo kecil di pojok atas (hilang saat credit karena latar credit menutupinya) */}
      <Logos />

      {/* ── CREDIT PENUTUP ── */}
      <Sequence from={Math.round(CREDIT_BG_START * fps)}>
        <CreditBg />
      </Sequence>
      <CreditBlock start={CB0} end={CB0 + 5.5}>
        <Label>A DOCUMENTARY BY</Label>
        <Name size={112} sp={6}>ECO-ACTION 4 DAYS</Name>
        <Name size={40} weight={600} color={BEIGE} sp={1} mt={26}>Aksi Nyata Pelajar Hijau untuk Sekolah Asri dan Berkelanjutan</Name>
      </CreditBlock>
      <CreditBlock start={CB0 + 5.8} end={CB0 + 9.8}>
        <Label>ORGANIZED BY</Label>
        <Name size={84} sp={6}>SMA NEGERI 1 DORO</Name>
      </CreditBlock>
      <CreditBlock start={CB0 + 10.1} end={CB0 + 14.1}>
        <Label>PROJECT COORDINATOR</Label>
        <Name size={72} sp={3}>Eka Nandasari, S.Pd.</Name>
      </CreditBlock>
      <CreditBlock start={CB0 + 14.4} end={CB0 + 18.4}>
        <Label>VIDEO PRODUCTION &amp; EDITING</Label>
        <Name size={78} sp={5}>KELOMPOK 5 – X E7</Name>
      </CreditBlock>
      <CreditBlock start={CB0 + 18.7} end={CB0 + 24.2}>
        <Label>SPECIAL THANKS TO</Label>
        <Name size={50} weight={600} sp={2}>Bapak/Ibu Guru Pendamping</Name>
        <Name size={50} weight={600} sp={2} mt={18}>Seluruh Peserta Didik Kelas X</Name>
        <Name size={50} weight={600} sp={2} mt={18}>Seluruh Pihak yang Terlibat</Name>
      </CreditBlock>
      <CreditBlock start={CB0 + 24.5} end={CB0 + 32.5}>
        <Name size={86} sp={8}>THANK YOU FOR WATCHING</Name>
        <Name size={36} weight={600} color={BEIGE} sp={1} mt={34}>Gaya Hidup Berkelanjutan</Name>
        <Name size={40} weight={600} color={GREEN} sp={6} mt={26}>2026 – 2027</Name>
      </CreditBlock>

      {/* fade to black */}
      <AbsoluteFill style={{background: '#000', opacity: blackOp}} />

      {/* ── AUDIO ── */}
      {WITH_MUSIC ? <Audio src={staticFile('eco4/music.mp3')} volume={musicVolume} /> : null}
      {SFX.map((x, i) => (
        <Sfx key={i} file={x.file} at={x.at} vol={x.vol} />
      ))}
    </AbsoluteFill>
  );
};
